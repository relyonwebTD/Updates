﻿function ClearText(ctrl) {
    if (eval(ctrl.value) == 0) { ctrl.value = ""; }
}
function CheckForNos() { return !isNaN(window.clipboardData.getData('Text')) && parseInt(window.clipboardData.getData('Text')) > 0; }
function trim(stringToTrim) { return stringToTrim.replace(/^\s+|\s+$/g, ""); }
function Return(tempValue) {
    if (isNaN(tempValue)) { return 0; }
    else if (tempValue == "" || tempValue == "undefined") { return 0; }
    else if (tempValue == "0.00" || tempValue == "0.0000") { return 0; }
    else { return eval(parseFloat(tempValue).toString()); }
}
function ValidateLength(objName, objCaption, maxLen, isRequired) {
    if (isRequired) {
        if (objName.value.trim().length == 0) {
            alert("Specify " + objCaption);
            objName.focus();
            return false;
        }
    }
    if (objCaption == 'PinCode' || objCaption == 'Deductor Pincode' || objCaption == 'Responsible Person Pincode' || objCaption == 'RRR No.' || objCaption == "Receipt Number" || objCaption == "Voucher No" || objCaption == "PRN Number" || objCaption == "AIN") {
        if (objName.value.trim().length > 0) {
            if (objName.value.trim().length < maxLen) {
                alert(objCaption + " should be of length " + maxLen + ".");
                objName.select();
                objName.focus();
                return false;
            }
        }
    } return true;
}
function ValidateDropDown(objName, objCaption) {
    if (objName.selectedIndex == 0) {
        alert("Select " + objCaption);
        objName.focus();
        return false;
    } return true;
}
function ValidateEmail(objName) {
    var email = objName.value;
    var emailPattern = /^[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$/;
    var matchArray = email.match(emailPattern);
    if (matchArray == null) {
        alert("Specify valid Email-Id.");
        objName.focus();
        return false;
    }
    else
        return true;
}
function ValidateAckNo(objName, objCaption, maxLen, minLen, isReq) {
    var val = objName.value;
    if (isReq) {
        if (val.trim().length == 0) {
            alert("Specify " + objCaption);
            objName.focus();
            return false;
        }
    }
    if (val.trim().length > 0) {
        if (val.trim().length < minLen || val.trim().length > maxLen) {
            alert(objCaption + " should be of 12-15 characters.");
            return false;
        }
        else {
        }
    } return true;
}
function ValidateCertificateNumber(objName, objCaption, maxLen, isReq) {
    var value = objName.value;
    if (isReq) {
        if (value.trim().length == 0) {
            alert("Specify " + objCaption);
            objName.focus();
            return false;
        }
        else if (value.trim().length != maxLen) {
            alert("Certificate number should be of length 10.");
            objName.focus();
            return false;
        }
    }
    //    var pattern = /^[0-9]{4}[a-zA-Z]{2}[0-9]{3}[a-zA-Z]{1}$/;
    var pattern = /^[0-9A-Z]{10}$/;
    var matchArray = value.match(pattern);
    if (matchArray == null) {
        //        alert("Specify valid certificate number.(Ex: 1234AA123A)");
        alert("Specify valid certificate number.\nShould be alphanumeric of 10 digits.");
        objName.focus();
        return false;
    } return true;
}
function ValidateCertificateNumber(objName, objCaption, maxLen, isReq) {
    var value = objName.value;
    if (isReq) {
        if (value.trim().length == 0) {
            alert("Specify " + objCaption);
            objName.focus();
            return false;
        }
        else if (value.trim().length != maxLen) {
            alert("Certificate number should be of length 10.");
            objName.focus();
            return false;
        }
    }
    //    var pattern = /^[0-9]{4}[a-zA-Z]{2}[0-9]{3}[a-zA-Z]{1}$/;
    var pattern = /^[0-9A-Za-z]{10}$/;
    var matchArray = value.match(pattern);
    if (matchArray == null) {
        //        alert("Specify valid certificate number.(Ex: 1234AA123A)");
        alert("Specify valid certificate number. Should be alphanumeric of 10 digits.");
        objName.focus();
        return false;
    } return true;
}
function ValidatePAN(objName, objCaption, maxLen, isReq) {
    var value = objName.value;
    if (isReq) {
        if (value.trim().length == 0) {
            alert("Specify " + objCaption);
            objName.focus();
            return false;
        }
    }
    if (value.trim().length > 0) {
        for (var i = 0; i < value.length; i++) {
            if (value.charAt(i) == ' ') {
                if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                    alert(objCaption + " does not \nallow Blank Spaces. (Ex: AAAAA1234A OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
                else
                    alert(objCaption + " does not \nallow Blank Spaces. (Ex: AAAAA1234A)");
                objName.focus();
                return false;
            }
        }
        if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER') {
            if (value.trim().toUpperCase() == 'GOVERNMENT' || value.trim().toUpperCase() == 'NONRESDENT' || value.trim().toUpperCase() == 'OTHERVALUE') {
                return true;
            }
        }
        for (var i = 0; i < 5; i++) {
            if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z')) { ; }
            else {
                if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                    alert("Specify a valid character value for\n" + objCaption + ".(Ex: AAAAA1234A OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
                else
                    alert("Specify a valid character value for\n" + objCaption + ".(Ex: AAAAA1234A)");
                if (document.getElementsByName(objName.name)) {
                    objName.focus();
                } return false;
            }
        }
        for (var i = 5; i < 9; i++) {
            if (value.charAt(i) >= '0' && value.charAt(i) <= '9') { ; }
            else {
                if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                    alert("Specify a valid character value for\n" + objCaption + ".(Ex: AAAAA1234A OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
                else
                    alert("Specify a valid character value for\n" + objCaption + ".(Ex: AAAAA1234A)");
                objName.focus();
                return false;
            }
        }
        if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) { ; }
        else {
            if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                alert("Specify a valid character value for\n" + objCaption + ".(Ex: AAAAA1234A OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
            else
                alert("Specify a valid character value for\n" + objCaption + ".(Ex: AAAAA1234A)")
            objName.focus();
            return false;
        }
        if (value.charAt(3).toUpperCase() != 'P' && value.charAt(3).toUpperCase() != 'H' && value.charAt(3).toUpperCase() != 'C' && value.charAt(3).toUpperCase() != 'J' && value.charAt(3).toUpperCase() != 'F' && value.charAt(3).toUpperCase() != 'A' && value.charAt(3).toUpperCase() != 'T' && value.charAt(3).toUpperCase() != 'B' && value.charAt(3).toUpperCase() != 'L' && value.charAt(3).toUpperCase() != 'G') {
            if (objCaption.split(' ')[0].toUpperCase() == 'LANDLORD' || objCaption.split(' ')[0].toUpperCase() == 'LENDER')
                alert("Specify valid PAN OR \"GOVERNMENT\",\"NONRESDENT\",\"OTHERVALUE\")");
            else
                alert("Specify valid PAN.");
            objName.focus();
            return false;
        }
        return true;
    }
}
function ValidateTAN(objName, objCaption, maxLen, isReq) {
    value = objName.value;
    if (isReq) {
        if (value.trim().length == 0) {
            alert("Specify valid TAN (Ex: AAAA12345A)\nor TANAPPLIED.");
            objName.focus();
            return false;
        }
        for (var i = 0; i < value.length; i++) {
            if (value.charAt(i) == ' ') {
                alert("Specify valid TAN (Ex: AAAA12345A)\nor TANAPPLIED.");
                objName.focus();
                return false;
            }
        }
        for (var i = 0; i < 3; i++) {
            if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z')) { ; }
            else {
                alert("Specify valid TAN (Ex: AAAA12345A)\nor TANAPPLIED.");
                objName.focus();
                return false;
            }
        }
        if ((value.charAt(3) >= 'A' && value.charAt(3) <= 'Z') || (value.charAt(3) >= 'a' && value.charAt(3) <= 'z') || value.charAt(3) >= '0' && value.charAt(3) <= '9') { ; }
        else {
            alert("Specify valid TAN (Ex: AAAA12345A)\nor TANAPPLIED.");
            objName.focus();
            return false;
        }
        for (var i = 4; i < 9; i++) {
            if (value.charAt(i) >= '0' && value.charAt(i) <= '9') { ; }
            else {
                alert("Specify valid TAN (Ex: AAAA12345A)\nor TANAPPLIED");
                objName.focus();
                return false;
            }
        }
        if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) { ; }
        else {
            alert("Specify valid TAN (Ex: AAAA12345A)\nor TANAPPLIED");
            objName.focus();
            return false;
        }
        var intNumPart = value.substr(4, 5);
        intNumPart %= 7;
        var chrLastChar = value.substr(9, 1).toUpperCase();
        if ((intNumPart == 0 && (chrLastChar == 'A' || chrLastChar == 'H')) || (intNumPart == 1 && (chrLastChar == 'B' || chrLastChar == 'I')) || (intNumPart == 2 && (chrLastChar == 'C' || chrLastChar == 'J')) || (intNumPart == 3 && (chrLastChar == 'D' || chrLastChar == 'K')) || (intNumPart == 4 && (chrLastChar == 'E' || chrLastChar == 'L')) || (intNumPart == 5 && (chrLastChar == 'F' || chrLastChar == 'M')) || (intNumPart == 6 && (chrLastChar == 'G' || chrLastChar == 'N'))) { ; }
        else {
            alert("Specify valid TAN.");
            objName.focus();
            return false;
        } return true;
    }
}
function ValidateCustomerTAN(objName, objCaption, maxLen, isReq) {
    value = objName.value;
    if (isReq) {
        if (value.trim().length == 0) {
            alert("Specify valid TAN (Ex: AAAA12345A)");
            objName.focus();
            return false;
        }
        for (var i = 0; i < value.length; i++) {
            if (value.charAt(i) == ' ') {
                alert("Specify valid TAN (Ex: AAAA12345A).");
                objName.focus();
                return false;
            }
        }
        for (var i = 0; i < 3; i++) {
            if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z'))
            { ; }
            else {
                alert("Specify valid TAN (Ex: AAAA12345A)");
                objName.focus();
                return false;
            }
        }
        if ((value.charAt(3) >= 'A' && value.charAt(3) <= 'Z') || (value.charAt(3) >= 'a' && value.charAt(3) <= 'z') || value.charAt(3) >= '0' && value.charAt(3) <= '9') { ; }
        else {
            alert("Specify valid TAN (Ex: AAAA12345A)");
            objName.focus();
            return false;
        }
        for (var i = 4; i < 9; i++) {
            if (value.charAt(i) >= '0' && value.charAt(i) <= '9') { ; }
            else {
                alert("Specify valid TAN (Ex: AAAA12345A)");
                objName.focus();
                return false;
            }
        }
        if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) { ; }
        else {
            alert("Specify valid TAN (Ex: AAAA12345A)");
            objName.focus();
            return false;
        }
        var intNumPart = value.substr(4, 5);
        intNumPart %= 7;
        var chrLastChar = value.substr(9, 1).toUpperCase();
        if ((intNumPart == 0 && (chrLastChar == 'A' || chrLastChar == 'H')) || (intNumPart == 1 && (chrLastChar == 'B' || chrLastChar == 'I')) || (intNumPart == 2 && (chrLastChar == 'C' || chrLastChar == 'J')) || (intNumPart == 3 && (chrLastChar == 'D' || chrLastChar == 'K')) || (intNumPart == 4 && (chrLastChar == 'E' || chrLastChar == 'L')) || (intNumPart == 5 && (chrLastChar == 'F' || chrLastChar == 'M')) || (intNumPart == 6 && (chrLastChar == 'G' || chrLastChar == 'N'))) { ; }
        else {
            alert("Specify valid TAN.");
            objName.focus();
            return false;
        }
        return true;
    }
}
function ValidateAssesseePAN(objName, objCaption, maxLen, isReq) {
    value = objName;
    if (isReq) {
        if (value.trim().length == 0) {
            return false;
        }
    }
    if (value.trim().length > 0) {
        for (var i = 0; i < value.length; i++) {
            if (value.charAt(i) == ' ') {
                return false;
            }
        }
        for (var i = 0; i < 5; i++) {
            if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z')) { ; }
            else {
                if (document.getElementsByName(objName.name)) {
                } return false;
            }
        }
        for (var i = 5; i < 9; i++) {
            if (value.charAt(i) >= '0' && value.charAt(i) <= '9') { ; }
            else { return false; }
        }
        if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) { ; }
        else { return false; }
        if (value.charAt(3).toUpperCase() != 'P' && value.charAt(3).toUpperCase() != 'H' && value.charAt(3).toUpperCase() != 'C' && value.charAt(3).toUpperCase() != 'J' && value.charAt(3).toUpperCase() != 'F' && value.charAt(3).toUpperCase() != 'A' && value.charAt(3).toUpperCase() != 'T' && value.charAt(3).toUpperCase() != 'B' && value.charAt(3).toUpperCase() != 'L' && value.charAt(3).toUpperCase() != 'G') { return false; }
        return true;
    }
}
function ValidateEleventhChar(objName, objCaption, maxLen, isReq) {
    value = objName;
    if (isReq) {
        if (value.trim().length == 0) {
            return false;
        }
        for (var i = 0; i < value.length; i++) {
            if (value.charAt(i) == ' ') {
                return false;
            }
        }
        for (var i = 0; i < 1; i++) {
            if ((value.charAt(i) == 'S') || (value.charAt(i) == 'X') || (value.charAt(i) == 'E'))
            { ; }
            else {
                return false;
            }
        } return true;
    }
}
function setDateFormat(ObjectName) {
    var stringValue;
    var arrDate = new Array();
    var arrInput = new Array();
    var counter = 0;
    var returnValue;
    stringValue = ObjectName.value.trim()
    if (stringValue.length > 0) {
        if (stringValue.indexOf('/') > 0) {
            arrInput = stringValue.split('/');
        }
        else if (stringValue.indexOf('\\') > 0) {
            arrInput = stringValue.split('\\');
        }
        else if (stringValue.indexOf('.') > 0) {
            arrInput = stringValue.split('.');
        }
        else if (stringValue.indexOf('-') > 0) {
            arrInput = stringValue.split('-');
        }
        else if (stringValue.indexOf(',') > 0) {
            arrInput = stringValue.split(',');
        }
        else if (stringValue.indexOf(' ') > 0) {
            arrInput = stringValue.split(' ');
        }
        if (arrInput == '') {
            alert("Date should be in dd/MM/yyyy");
            ObjectName.select();
            ObjectName.focus();
            return;
        }
        for (i = 0; i < arrInput.length; i++) {
            if (arrInput[i].trim() == '') { }
            else { arrDate[counter++] = arrInput[i].trim(); }
        }
        if (arrDate.length != 3) {
            alert('Not a valid date');
            ObjectName.select();
            ObjectName.focus();
            return;
        }
        for (i = 0; i < arrDate.length; i++) {
            if (isNaN(arrDate[i].trim())) {
                alert('Not a valid date');
                ObjectName.select();
                ObjectName.focus();
                return;
            }
        }
        arrDate[0] = String(Number(arrDate[0]));
        arrDate[1] = String(Number(arrDate[1]));
        for (i = 0; i < arrDate.length; i++) {
            if ((i == 0 || i == 1) && arrDate[i].trim().length == 1) {
                arrDate[i] = '0' + arrDate[i].trim();
            }
            if (i == 2) {
                if (arrDate[i].trim().length == 1) {
                    arrDate[i] = '200' + arrDate[i];
                }
                else if (arrDate[i].trim().length == 2) {
                    arrDate[i] = '20' + arrDate[i];
                }
                else if (arrDate[i].trim().length == 3) {
                    arrDate[i] = '2' + arrDate[i];
                }
            }
        }
        for (i = 0; i < arrDate.length; i++) {
            if ((arrDate[2] > 2078) || (arrDate[2] < 1900)
                                    || (arrDate[0] < 1 || arrDate[0] > 31 || arrDate[1] < 1 || arrDate[1] > 12)
                                    || ((arrDate[1] == 1 || arrDate[1] == 3 || arrDate[1] == 5 || arrDate[1] == 7 || arrDate[1] == 8 || arrDate[1] == 10 || arrDate[1] == 12) && arrDate[0] > 31)
                                    || ((arrDate[1] == 04 || arrDate[1] == 06 || arrDate[1] == 9 || arrDate[1] == 11) && arrDate[0] > 30)
                                    || ((arrDate[2] % 4) == 0 && arrDate[1] == 2 && arrDate[0] > 29)
                || ((arrDate[2] % 4) != 0 && arrDate[1] == 2 && arrDate[0] > 28)) {
                returnValue = false;
                //alert("Enter Valid Date");
                //ObjectName.select();
                //ObjectName.focus();              
                //return false;
            }
            if (returnValue == false) {
                alert("Enter Valid Date");
                //ObjectName.focus();
                return false;
            }
        }
        ObjectName.value = arrDate[0] + '/' + arrDate[1] + '/' + arrDate[2];
    }
}
function ValidateForAlphaNumeric(e) {
    var keyCode;
    var keyChar;
    var numCheck = /^[a-zA-Z0-9 ]$/;
    if (window.event) {
        keyCode = e.keyCode;
    }
    else if (e.which) {
        keyCode = e.which;
    }
    keyChar = String.fromCharCode(keyCode);
    return numCheck.test(keyChar);
}
function ValidateForAlpha(e) {
    var keyCode;
    var keyChar;
    var numCheck = /^[a-zA-Z]$/;
    if (window.event) {
        keyCode = e.keyCode;
    }
    else if (e.which) {
        keyCode = e.which;
    }
    keyChar = String.fromCharCode(keyCode);
    return numCheck.test(keyChar);
}
function ValidateForOnlyNos(e) {
    var keyCode;
    var keyChar;
    var numCheck = /^[0-9]$/;
    if (window.event) {
        keyCode = e.keyCode;
    }
    else if (e.which) {
        keyCode = e.which;
    }
    keyChar = String.fromCharCode(keyCode);
    return numCheck.test(keyChar);
}
function ValidateForOnlyChars(e) {
    var keyCode;
    var keyChar;
    var numCheck = /^[a-zA-Z]$/;
    if (window.event) {
        keyCode = e.keyCode;
    }
    else if (e.which) {
        keyCode = e.which;
    }
    keyChar = String.fromCharCode(keyCode);
    return numCheck.test(keyChar);
}
function checkDecimalNo(obj) {
    var name = obj.value;
    if (isNaN(name) || name == "") {
        return obj.value = "";
    }
    else {
        return obj.value = parseFloat(name);
    }
}
function numeralsOnly(objectName, evt, digit, decimal, allowSign, allowDot, allowComma) {
    evt = (evt) ? evt : event;
    var sl;
    var text = "";
    var currv = objectName.value;
    if (currv.length == 0) {
        if (allowSign == 1) {
            if (evt.keyCode == 43 || evt.keyCode == 45)
                return true;
        }
        if (evt.keyCode == 46) {
            return false;
        }
    }
    if (currv.length > 0) {
        if (evt.keyCode == 46 && allowDot == 0) {
            return false;
        }
        if (evt.keyCode == 188 && allowComma == 0) {
            return false;
        }
    }
    if (currv.length > digit - 1 && currv.indexOf(".") == -1) {
        if (evt.keyCode != 46) {
            return false;
        }
    }
    if (currv.indexOf(".") != -1) {
        if (currv.length >= digit + decimal + 1) {
            return false;
        }
    }
    if (decimal > 0) {
        if (currv.length > 0) {
            text = (document.all) ? document.selection.createRange().text : document.getSelection();
            if (text != "") {
                test = false;
                var charCode1 = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode : ((evt.which) ? evt.which : 0));
                if (charCode1 > 31 && (charCode1 < 48 || charCode1 > 57) && charCode1 != 46) {
                    return false;
                }
                else {
                    if (charCode1 == 46) {
                        if (((currv.length + 1) - GetCursorStartPos(evt)) > 3)
                            return false;
                        else
                            return true;
                    }
                }
            }
            else {
                if (currv.length > 0) {
                    var charCode3 = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode : ((evt.which) ? evt.which : 0));
                    if (currv.indexOf(".") != -1 && charCode3 != 46) {
                        var stest = currv.substring(currv.indexOf("."));
                        if (GetCursorStartPos(evt) <= currv.indexOf(".")) {
                            if (numeralsOnlyCheck(currv, evt, decimal))
                                return true;
                            else
                                return false;
                        }
                        else {
                            if (stest.length > decimal)
                                return false;
                        }
                    }
                    else {
                        var charCode2 = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode : ((evt.which) ? evt.which : 0));
                        if (charCode2 > 31 && (charCode2 < 48 || charCode2 > 57) && charCode2 != 46) {
                            return false;
                        }
                        else {
                            if (currv.indexOf(".") != -1 && charCode2 != 46) {
                                if (((currv.length + 1) - GetCursorStartPos(evt)) > 3)
                                    return false;
                                else
                                    return true;
                            }
                            else if (currv.indexOf(".") == -1 && charCode2 == 46) {
                                if (((currv.length + 1) - GetCursorStartPos(evt)) > 3)
                                    return false;
                                else
                                    return true;
                            }
                        }
                    }
                }
            }
        }
    }
    var charCode = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode : ((evt.which) ? evt.which : 0));
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode != 46) {
        return false;
    }
    if (charCode == 46) {
        if (decimal == 0) {
            return false;
        } else {
            if (currv.indexOf(".") != -1) {
                return false;
            }
        }
    } else if (currv.indexOf(".") != -1) {
        var s = currv.substring(currv.indexOf(".") + 1);

        if (s.length > decimal) {

            if (text == true)
                return false;
        }
    }
    return true;
}
function GetCursorStartPos(evt) {
    var obj = evt.srcElement == null ? evt.target : evt.srcElement;
    var nPosition = parseInt(obj.getAttribute("position"), 10);
    if (nPosition >= 0)
        return nPosition;
    // IE
    if (document.selection != null) {
        var cur = document.selection.createRange();
        var pos = 0;
        if (obj && cur) {
            var tr = obj.createTextRange();
            if (tr) {
                while (cur.compareEndPoints("StartToStart", tr) > 0) {
                    tr.moveStart("character", 1);
                    pos++;
                }
                return pos;
            }
        } return -1;
    }
    else if (obj.selectionStart != null)// FF
    {
        return obj.selectionStart;
    }
    else { return -1; }
}
function numeralsOnlyCheck(currv, evt, decimal) {
    evt = (evt) ? evt : event;
    var sl;
    var text = "";
    var charCode1 = (evt.charCode) ? evt.charCode : ((evt.keyCode) ? evt.keyCode : ((evt.which) ? evt.which : 0));
    if (charCode1 > 31 && (charCode1 < 48 || charCode1 > 57) && charCode1 != 46) {
        return false;
    } return true;
}
function chars(e) {
    var char1 = e.charCode ? e.charCode : e.keyCode
    if (char1 != 8) {
        if (char1 > 64 || char1 < 90 && char1 > 97 || char1 < 122 && char1 == 32) {
            return true
        }
    }
    else {
        return false
    }
}
function textCounter(field, maxlimit) {
    if (field.value.length > maxlimit) {
        field.value = field.value.substring(0, maxlimit);
    }
}
function textMinCounter(field, maxlimit) {
    if (field.value.length < maxlimit) {
        alert("Please enter atleast 3 chars");
    }
}
function ValidatePassword(objName, objCaption) {
    if (objName.value == "") {
        alert("Specify " + objCaption);
        objName.focus();
        return false;
    }
    else if (objName.value.length < 5) {
        alert(objCaption + " cannot be less than 5 Characters.");
        objName.focus();
        return false;
    }
    else {
        for (var i = 0; i < objName.value.length; i++) {
            if (objName.value.charAt(i) == ' ') {
                alert(objCaption + " doesn't allow Blank Spaces.");
                objName.focus();
                return false;
            }
        }
        return true;
    }
}
function ValidatePasswordCBI(objName, objCaption) {
    if (objName.value == "") {
        alert("Specify " + objCaption);
        objName.focus();
        return false;
    }
    else if (objName.value.length < 8) {
        alert(objCaption + " cannot be less than 8 Characters.");
        objName.focus();
        return false;
    }
    else {
        for (var i = 0; i < objName.value.length; i++) {
            if (objName.value.charAt(i) == ' ') {
                alert(objCaption + " doesn't allow Blank Spaces.");
                objName.focus();
                return false;
            }
        }
        return true;
    }
}
function ValidateConfirmPassword(objName1, objName2, objCap1, objCap2) {
    if (objName1.value == "") {
        alert("Specify " + objCap1);
        objName1.focus();
        return false;
    }
    else if (objName2.value == "") {
        alert("Specify " + objCap2);
        objName2.focus();
        return false;
    }
    else {
        for (var i = 0; i < objName2.value.length; i++) {
            if (objName2.value.charAt(i) == ' ') {
                alert(objCap2 + " doesn't allow Blank Spaces.");
                objName2.focus();
                return false;
            }
        }
        if (objName1.value != objName2.value) {
            alert(objCap2 + " doesn't match with " + objCap1);
            objName2.focus();
            return false;
        }
        else { return true; }
    }
}
function ConvertToUC(ctrl) {
    ctrl.value = ctrl.value.toUpperCase();
}
function ValidateDelimiter(field, e) {
    if (window.event) {
        keyCode = e.keyCode;
    }
    else if (e.which) {
        keyCode = e.which;
    }
    if (keyCode == 94)
        return false;
    return true;
}
function ShowConfirm(msg) {
    return confirm(msg);
}
function PassWordValidate(obj) {
    var passw = /[^a-zA-Z]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    passw = /[0-9]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    passw = /[A-Z]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    passw = /[!@#$%&([)_]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    return true;
}
function PassWordValidate1(obj) {
    var passw = /[^a-zA-Z]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    passw = /[0-9]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    passw = /[A-Z]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    passw = /[!@#$%&([\/\])_*^+-=]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    return true;
}
function PassWordValidate2(obj) {
    var passw = /[0-9]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    passw = /[A-Z]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    passw = /[!@#$%]/;
    if (!obj.value.match(passw)) {
        return false;
    }
    return true;
}
function InputValidations(objName) {
    var alphaExp = /[a-zA-Z0-9]/;
    var specialcharsExp = /[`~!@#$%^&*()_+,.?;:[{]}|\/]/;
    if (!objName.value.match(alphaExp)) {
        if (!objName.value.match(specialcharsExp)) {
            alert("Only Special Characters or blank spaces are not allowed");
            return false;
        }
        else { return true; }
    }
    else { return true; }
}
function InputValidationsForAddress(objName) {
    var alphaExp = /[a-zA-Z0-9]/;
    var specialcharsExp = /[`~!@#$%^&*()_+,.?;:[{]}|\/]/;
    if (objName.value != "") {
        if (!objName.value.match(alphaExp)) {
            if (!objName.value.match(specialcharsExp)) {
                alert("Only Special Characters or blank spaces are not allowed");
                return false;
            }
            else { return true; }
        }
        else { return true; }
    }
}

function CheckSpecialCharacter(objName, objCaption) {
    var objValue = objName.value; 
    var returnvalue = true;
    var asciiNum;
    for (var i=0;i<objValue.length;i++)
    {
        asciiNum = objValue.charCodeAt(i); 
        if ((asciiNum == 32) || (asciiNum > 47 && asciiNum < 58) || (asciiNum > 64 && asciiNum < 91) || (asciiNum == 92) || (asciiNum>96 && asciiNum<123))
        {
            if(returnvalue != false) 
            {
                returnvalue = true; 
            } 
            else break;
         }
         else 
         {
            returnvalue = false;
         }
    }
    if(returnvalue == false)
    {
        alert("Special Characters are not allowed in " + objCaption );
        objName.focus();
    }
    return returnvalue;
}
function CheckPincode(ctrl) {
    var pincode = ctrl.value;
    var pincodePattern = /^[1-9][0-9][0-9]{4}$/;
    var matchArray = pincode.match(pincodePattern);
    if (matchArray == null) {
        alert("Specify valid pincode. Pincode starts from 110001.");
        ctrl.value = "";
       //ctrl.focus();
        return false;
    }
    else if(pincode < 110001) {
        alert("Specify valid pincode. Pincode starts from 110001.");
        ctrl.value = "";
        return false;
    }
    else {
        return true;
    }
}
function ValidateHtmlTags(inputString) {    
    var regex = /<\/?[a-z][^>]*(>|$)|<[a-z][^>]*\b(on\w+|src|href)=["'][^"']*["']/i;
    var matches = regex.test(inputString);
    if (matches) {
        alert("HTML tags are not allowed.");       
    }
    return matches;
}
