<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="eReturnF15GH_BulkEreturnF15GH, App_Web_bulkereturnf15gh.aspx.8fdb6599" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">

    <script language="javascript" type="text/javascript" src="../JavaScript/Validations.js"></script>

    <style type="text/css">
        table, tr, td
        {
            border: 1px solid blzck;
        }
        tr.noBorder td
        {
            border: 0;
        }
        .modalPopup
        {
            background-color: #ffffdd;
            border-width: 5px;
            border-style: solid;
            border-color: Gray;
            padding: 5px;
        }
        .table
        {
            border-color: Black;
            border-style: outset;
            border-collapse: collapse;
        }
        .table td
        {
            border-color: Black;
            border-style: outset;
            border-collapse: collapse;
            background-color: white;
        }
        .table th
        {
            background-color: #eeeeee;
            border-color: Black;
        }
    </style>

    <script type="text/javascript">
        function OpenPopUpSummaryReport() {
            $find('warningPopup').show();
        }
        function Validation() {
            if (document.getElementById("<%=ddlQuarter.ClientID%>").selectedIndex == 0) {
                alert("Select the Quarter.");
                document.getElementById("<%=ddlQuarter.ClientID%>").focus();
                return false;
            }
            if (document.getElementById("<%=ddlForm.ClientID%>").selectedIndex == 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value < 2026) {
                alert("Select the Form.");
                document.getElementById("<%=ddlForm.ClientID%>").focus();
                return false;
            }
            if (document.getElementById("<%=btnShow.ClientID %>").value == "Show") {
                document.getElementById("<%=btnShow.ClientID %>").value = "Please Wait...";
                return true;
            }
            else
                return false;
        }
        function ValidationBulkAll() {
            if (document.getElementById("<%=ddlQuarter.ClientID%>").selectedIndex == 0) {
                alert("Select the Quarter.");
                document.getElementById("<%=ddlQuarter.ClientID%>").focus();
                return false;
            }
            if (document.getElementById("<%=ddlForm.ClientID%>").selectedIndex == 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value < 2026) {
                alert("Select the Form.");
                document.getElementById("<%=ddlForm.ClientID%>").focus();
                return false;
            }
            if (document.getElementById("<%=btnEreturnAll.ClientID %>").value == "Initiate All") {
                document.getElementById("<%=btnEreturnAll.ClientID %>").value = "Please Wait...";
                document.getElementById("<%=btnShow.ClientID %>").value = "Please Wait...";
                document.getElementById("<%=btnDownloadFiles.ClientID %>").disabled = true;
                document.getElementById("<%=btnClear.ClientID %>").disabled = true;
                return true;
            }
            else
                return false;
        }
        function ValidationDownload() {
            if (document.getElementById("<%=ddlQuarter.ClientID%>").selectedIndex == 0) {
                alert("Select the Quarter.");
                document.getElementById("<%=ddlQuarter.ClientID%>").focus();
                return false;
            }
            if (document.getElementById("<%=ddlForm.ClientID%>").selectedIndex == 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value < 2026) {
                alert("Select the Form.");
                document.getElementById("<%=ddlForm.ClientID%>").focus();
                return false;
            }
        }
        function GetParentBranchValue(source, eventArgs) {
            ParentBranchId = document.getElementById("<%=hdnBranchID.ClientID%>");
            ParentBranchId.value = eventArgs.get_value();
        }
        function ClearParentBranch() {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) {
            }
            else {
                ParentBranchId = document.getElementById("<%=hdnBranchID.ClientID%>");
                ParentBranchId.value = "-1";
            }
        }
    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:HiddenField ID="hdnIsValidPANPercentage" runat="server" Value="1" />
    <asp:HiddenField ID="hdnInvalidStatusDedCount" runat="server" Value="0" />
    <asp:HiddenField ID="hdnUnlinkedDeductionCount" runat="server" Value="-1" />
    <asp:HiddenField ID="hdnFinYear" runat="server" Value="" />
    <asp:HiddenField ID="hdnHide" runat="server" Value="0" />
    <asp:HiddenField ID="selectedPageSize" runat="server" />
    <asp:HiddenField ID="selectedPageIndex" runat="server" />
    <asp:HiddenField ID="hdnBranchID" Value="-1" runat="server" />
    <asp:HiddenField ID="hdnTotalRowCount" Value="0" runat="server" />
    <asp:HiddenField ID="hdnTotalBranchesWithBasic" Value="0" runat="server" />
    <cc1:AutoCompleteExtender ID="AutoCompleteExtender1" runat="server" MinimumPrefixLength="2"
        ServiceMethod="GetParentBranch" ServicePath="~/WebServices/AutoCompleteService.asmx"
        TargetControlID="txtBranchCode" CompletionInterval="700" EnableCaching="false"
        CompletionSetCount="20" DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true"
        FirstRowSelected="True" OnClientItemSelected="GetParentBranchValue">
    </cc1:AutoCompleteExtender>
    <cc1:ModalPopupExtender ID="popupWarning" runat="server" CancelControlID="btnPopupOk"
        BackgroundCssClass="modalBackground" BehaviorID="warningPopup" PopupControlID="panelSummary"
        TargetControlID="pop">
    </cc1:ModalPopupExtender>
    <table>
        <tr>
            <td>
                <table>
                    <tr>
                        <td style="width: 80px">
                            Quarter
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlQuarter" runat="server" Width="170px">
                                <asp:ListItem Text="Select" Value="-1" />
                                <asp:ListItem Text="1" Value="1" />
                                <asp:ListItem Text="2" Value="2" />
                                <asp:ListItem Text="3" Value="3" />
                                <asp:ListItem Text="4" Value="4" />
                            </asp:DropDownList>
                        </td>
                        <td rowspan="2">
                            <asp:Label ID="lblEreturnBulkStatus" runat="server" Font-Bold="true" Width="400px"
                                Visible="false"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 80px">
                            Form
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlForm" runat="server" Width="170px">
                                <asp:ListItem Text="Select" Value="-1" />
                                <asp:ListItem Text="Form 15G" Value="1" />
                                <asp:ListItem Text="Form 15H" Value="2" />
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 80px">
                            Branch
                        </td>
                        <td>
                            <asp:TextBox ID="txtBranchCode" runat="server" Width="170px" CssClass="txtBML" onkeyup="ClearParentBranch()"></asp:TextBox>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td>
                <table>
                    <tr>
                        <td>
                            <asp:Button ID="btnShow" runat="server" Text="Show" CssClass="cmnBtn" OnClientClick="javascript:return Validation();"
                                OnClick="btnShow_Click" />
                        </td>
                        <td>
                            <asp:Button ID="btnClear" runat="server" Text="Clear" CssClass="cmnBtn" OnClick="btnClear_Click" />
                        </td>
                        <td>
                            <asp:Button ID="btnEreturnAll" runat="server" Text="Initiate All" CssClass="cmnBtn"
                                OnClientClick="javascript:return ValidationBulkAll();" Visible="false" OnClick="btnEreturnAll_Click" />
                        </td>
                        <td>
                            <asp:Button ID="btnDownloadFiles" runat="server" Text="Download Files" CssClass="cmnBtn" Width="114px"
                                OnClientClick="javascript:return ValidationDownload();" Visible="false" OnClick="btnDownloadFiles_Click" />
                        </td>
                        <td>
                            <asp:HyperLink ID="hlnkZipFile" runat="server" Text="" Target="_blank" Visible="false"></asp:HyperLink>
                        </td>
                        <td>
                            <asp:HyperLink ID="hlnkDownloadErrorFile" runat="server" Target="_blank" Visible="False"
                                ForeColor="Red"> Download Error File
                            </asp:HyperLink>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table>
        <tr>
            <td>
                <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                    Width="935px" BorderStyle="Solid" BorderWidth="1px" BorderColor="Gray" Visible="true">
                    <asp:Repeater ID="rptrBulkEreturn" runat="server" OnItemCommand="rptrBulkEreturn_ItemCommand">
                        <HeaderTemplate>
                            <table border="1" style="width:100%">
                                <tr>
                                    <th colspan="2" id="headerBranchCode" runat="server">
                                        <asp:Label ID="lblBranchCode" Text="Branch Code" runat="server" Width="150px"></asp:Label>
                                    </th>
                                    <th style="display: none">
                                        <asp:Label runat="server" ID="lblBranchID" Width="50px" Text="Branch Id" />
                                    </th>
                                    <th style="display: none">
                                        <asp:Label runat="server" ID="lblFormId" Width="50px" Text="FormId" />
                                    </th>
                                    <th style="display: none">
                                        <asp:Label runat="server" ID="lblBranchName" Width="50px" Text="FormId" />
                                    </th>
                                    <th colspan="2" id="headerForm" runat="server" width="150px">
                                        <asp:Label ID="lblForm" Text="Form" runat="server" Width="175px"></asp:Label>
                                    </th>
                                    <th colspan="2" id="headerQuarter" runat="server">
                                        <asp:Label ID="lblQuarter" Text="Quarter" runat="server" Width="160px"></asp:Label>
                                    </th>
                                    <th colspan="2" id="headerEreturn" runat="server">
                                        <asp:Label ID="lblEreturn" Text="Ereturn" runat="server" Width="175px"></asp:Label>
                                    </th>
                                </tr>
                        </HeaderTemplate>
                        <ItemTemplate>
                            <tr>
                                <td colspan="2" style="text-align: center">
                                    <%# Eval("BRANCHCODE")%>
                                </td>
                                <td style="display: none">
                                    <asp:Label ID="lblBranchId" runat="server" Text='<%# Eval("BranchId")%>'></asp:Label>
                                </td>
                                <td style="display: none">
                                    <asp:Label ID="lblFormId" runat="server" Text='<%# Eval("FormId")%>'></asp:Label>
                                </td>
                                <td style="display: none">
                                    <asp:Label ID="lblBranchName" runat="server" Text='<%# Eval("BranchName")%>'></asp:Label>
                                </td>
                                <td colspan="2" style="text-align: center">
                                    <asp:Label ID="lblFormType" runat="server" Text='<%# Eval("FORM")%>'></asp:Label>
                                </td>
                                <td colspan="2" style="text-align: center">
                                    <asp:Label ID="lblQuarter" runat="server" Text='<%# Eval("QUARTER")%>'></asp:Label>
                                </td>
                                <td colspan="2" style="text-align: center">
                                    <asp:Button ID="btnEreturn" runat="server" Text="Ereturn" CssClass="cmnBtn" CommandName="Ereturn"
                                        CommandArgument='<%#Eval("BranchId") %>'></asp:Button>
                                </td>
                            </tr>
                            <tr class="noBorder">
                                <td colspan="2" style="text-align: center">
                                    <asp:HyperLink ID="hlnkTextFile" runat="server"
                                        Text="Open Output"
                                        CommandName="DownloadXMLFile"
                                        Target="_blank"
                                        NavigateUrl='<%# Eval("TextFilePath")%>'
                                        Enabled='<%# Convert.ToString(Eval("TextFilePath")) != String.Empty %>'
                                        ForeColor='<%# Convert.ToString(Eval("TextFilePath")) != String.Empty ? System.Drawing.Color.FromName("Blue") : System.Drawing.Color.FromName("Grey") %>'>
                                    </asp:HyperLink>
                                </td>

                                <td colspan="2" style="text-align: center">
                                    <asp:HyperLink ID="hlnkValidatedFile" runat="server"
                                        Text="Download Validated File"
                                        CommandName="ValidatedFile"
                                        Target="_blank"
                                        Font-Bold="True"
                                        NavigateUrl='<%# Eval("ValidatedFilePath")%>'
                                        Enabled='<%# Convert.ToString(Eval("ValidatedFilePath")) != String.Empty %>'
                                        ForeColor='<%# Convert.ToString(Eval("ValidatedFilePath")) != String.Empty ? System.Drawing.Color.FromName("Blue") : System.Drawing.Color.FromName("Grey") %>'>
                                    </asp:HyperLink>
                                </td>

                                <td colspan="2" style="text-align: center">
                                    <asp:HyperLink ID="hlnkViewErrors" runat="server"
                                        Text="View Errors"
                                        CommandName="ViewErrors"
                                        Target="_blank"
                                        NavigateUrl='<%# Eval("ErrorFilePath")%>'
                                        Enabled='<%# Convert.ToString(Eval("ErrorFilePath")) != String.Empty %>'
                                        ForeColor='<%# Convert.ToString(Eval("ErrorFilePath")) != String.Empty ? System.Drawing.Color.FromName("Red") : System.Drawing.Color.FromName("Grey") %>'>
                                    </asp:HyperLink>
                                </td>
                            </tr>
                        </ItemTemplate>
                        <FooterTemplate>
                            </table>
                        </FooterTemplate>
                    </asp:Repeater>
                </asp:Panel>
                <table style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px" align="right">
                    <tr>
                        <td style="padding: 0px 0px 0px 0px">
                            <asp:Label ID="lblRecordsPerPage" runat="server" Text="Records per page : " Font-Size="X-Small" />
                        </td>
                        <td style="width: 50px; padding-top: 2px;">
                            <asp:DropDownList ID="ddlBranchInputGoTo" runat="server" Style="width: 50px; height: 15px;
                                float: left;" AutoPostBack="true" TabIndex="35" Font-Size="X-Small" CssClass="dropDownList"
                                OnSelectedIndexChanged="ddlBranchInputGoTo_SelectedIndexChanged">
                                <asp:ListItem Text="5" Value="5" Selected="True" />
                                <asp:ListItem Text="10" Value="10" />
                                <asp:ListItem Text="15" Value="15" />
                                <asp:ListItem Text="20" Value="20" />
                                <asp:ListItem Text="25" Value="25" />
                                <asp:ListItem Text="50" Value="50" />
                                <asp:ListItem Text="75" Value="75" />
                                <asp:ListItem Text="100" Value="100" />
                            </asp:DropDownList>
                        </td>
                        <td>
                            <asp:Label ID="lblBranchInputStatus" runat="server" Style="float: left;" Font-Size="X-Small"></asp:Label>
                        </td>
                        <td>
                            <asp:Button ID="btnBranchInputFirst" runat="server" Text="&lt;&lt;" Width="35px"
                                Font-Names="Arial" Font-Overline="False" Font-Size="X-Small" CssClass="navButton"
                                Enabled="False" TabIndex="36" OnClick="btnBranchInputFirst_Click"></asp:Button>
                        </td>
                        <td>
                            <asp:Button ID="btnBranchInputPrevious" runat="server" Text="&lt;" Font-Names="Arial"
                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                                TabIndex="37" OnClick="btnBranchInputPrevious_Click"></asp:Button>
                        </td>
                        <td>
                            <asp:TextBox ID="txtBranchInputGoTo" runat="server" Text="1" CssClass="navTextBox"
                                AutoPostBack="True" MaxLength="5" TabIndex="38" OnTextChanged="txtBranchInputGoTo_TextChanged"></asp:TextBox>
                        </td>
                        <td>
                            <asp:Button ID="btnBranchInputNext" runat="server" Text="&gt;" Font-Names="Arial"
                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" TabIndex="39"
                                OnClick="btnBranchInputNext_Click"></asp:Button>
                        </td>
                        <td>
                            <asp:Button ID="btnBranchInputLast" runat="server" Text="&gt;&gt;" Font-Names="Arial"
                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" TabIndex="40"
                                OnClick="btnBranchInputLast_Click"></asp:Button>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <asp:Button ID="pop" runat="server" Text="click" Style="display: none;" />
    <asp:Panel ID="panelSummary" runat="server" CssClass="modalPopup" Style="display: none"
        BackColor="White">
        <div class="dialog" style="width: 730px;">
            <div class="dHeader">
                Summary Report</div>
            <div style="padding: 10px; border-top: solid 1px gray">
                <table class="table" width="710px" border="1">
                    <tr>
                        <th align="center" colspan="4">
                            <b>Pan Percentage</b>
                        </th>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <asp:Label ID="lblTotalValidPanPercentage" runat="server" Font-Bold="True"> </asp:Label>
                        </td>
                        <td style="padding-left: 100px" colspan="2">
                            <asp:Label ID="lblValidPanPercentage" runat="server" Font-Bold="True"> </asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <th align="center" colspan="4">
                            <b>Summary in (Rs.)</b>
                        </th>
                    </tr>
                    <tr>
                        <th align="center">
                            <b>Description</b>
                        </th>
                        <th align="center">
                            <b>Count</b>
                        </th>
                        <th align="center">
                            <b>Gross Amount</b>
                        </th>
                        <th align="center">
                            <asp:Label ID="lblTDSAmount" runat="server" Text="TDS Amount" Font-Bold="true"></asp:Label>
                        </th>
                    </tr>
                    <tr>
                        <th>
                            <asp:Label ID="lblDeductionDetails" runat="server" Text="Deduction Details" Font-Bold="true"></asp:Label>
                        </th>
                        <td align="right">
                            <asp:Label ID="lblDeductionCount" runat="server" Text="Value"> </asp:Label>
                        </td>
                        <td align="right">
                            <asp:Label ID="lblDedTotalPayment" runat="server" Text="Value"> </asp:Label>
                        </td>
                        <td align="right">
                            <asp:Label ID="lblDedTaxDeducted" runat="server" Text="Value"> </asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            Challan Details
                        </th>
                        <td align="right">
                            <asp:Label ID="lblChallnCount" runat="server" Text="Value"> </asp:Label>
                        </td>
                        <td align="right">
                            <asp:Label ID="lblChallanGross" runat="server" Text="0"> </asp:Label>
                        </td>
                        <td align="right">
                            <asp:Label ID="lblChallanTotalAmount" runat="server" Text="Value"> </asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td align="center" colspan="4">
                            <asp:Button ID="btnPopupOk" runat="server" Text="Ok" CssClass="cmnBtn" />
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </asp:Panel>
</asp:Content>
