﻿<%@ page language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="eReturnF15GH_eReturnF15GH, App_Web_ereturnf15gh.aspx.8fdb6599" title="Untitled Page" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">

    <script language="javascript" type="text/javascript" src="../JavaScript/Validations.js">
    </script>

    <script type="text/javascript">  
         function CheckBasicIncome() {
            var BasicCount = document.getElementById("<%=hdnBasicCount.ClientID%>").value ;
            var IncomeCount = document.getElementById("<%=hdnIncomeCount.ClientID%>").value ;
            var DistinctCount = document.getElementById("<%=hdnDistinctCount.ClientID%>").value ;
            if (BasicCount == 0)
            {
                var msg = "No details available to generate eReturn file";
                alert(msg);
                return false;
            }
            return true;
        }
    </script>

    <style type="text/css">
        .table
        {
            border-color: Black;
            border-style: outset;
            border-collapse: collapse;
        }
        .table td
        {
            border-color: Black;
            border-style: outset;
            border-collapse: collapse;
            background-color: white;
        }
        .table th
        {
            background-color: #eeeeee;
            border-color: Black;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <asp:HiddenField ID="hdnIncomeCount" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnDistinctCount" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnBasicCount" runat="server" Value="-1" />
            <table width="100%">
                <tr>
                    <td>
                        <asp:Label ID="lblEreturnprocessOn" ForeColor="Red" Font-Bold="true" Font-Size="Small"
                            runat="server">
                        </asp:Label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <asp:Label ID="lblStatus" ForeColor="Red" Font-Bold="true" Font-Size="Small" runat="server">
                        </asp:Label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellpadding="0px" cellspacing="0px">
                            <tr>
                                <td style="width: 120px">
                                    Select Form
                                </td>
                                <td>
                                    <asp:RadioButton ID="rdbForm15G" Text="Form 15G" runat="server" GroupName="FormGroup"
                                        Checked="true" AutoPostBack="True" 
                                        oncheckedchanged="rdbForm15G_CheckedChanged" />
                                    <asp:RadioButton ID="rdbForm15H" Text="Form 15H" runat="server" GroupName="FormGroup"
                                        AutoPostBack="True" oncheckedchanged="rdbForm15H_CheckedChanged" />
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellpadding="0px" cellspacing="0px">
                            <tr>
                                <td style="width: 120px">
                                    eReturn Type
                                </td>
                                <td>
                                    <asp:RadioButton ID="rdbRegular" Text="Regular eReturn" runat="server" GroupName="eReturnGroup"
                                        Checked="true" />
                                    <asp:RadioButton ID="rdbCorrection" Text="Correction eReturn" runat="server" GroupName="eReturnGroup"
                                        Enabled="false" />
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellpadding="0px" cellspacing="0px">
                            <tr id = "trExcludeRecord" runat = "server" >
                                <td>
                                    <asp:CheckBox ID="chkExcludeRecord" runat="server" Checked="false"/>
                                    Exclude Records not having Mobile No.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellpadding="0px" cellspacing="0px">
                            <tr id = "trErrorCheck" runat = "server" >
                                <td>
                                    <asp:CheckBox ID="chkError" runat="server" Checked="false"/>
                                    Do not check for data errors
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table width="100%" cellpadding="0px" cellspacing="0px">
                            <tr>
                                <td>
                                    <asp:Button ID="btneReturn" runat="server" Text="e-Return" CssClass="cmnBtn" Visible="true"
                                        OnClientClick="javascript:return CheckBasicIncome();" OnClick="btneReturn_Click">
                                    </asp:Button>
                                    <asp:Label ID="lblBlockMessage" runat="server" Text="E-return Blocked By HO" Visible="false"
                                        Style="color: #000080; font-weight: bold"></asp:Label>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr height="40px">
                    <td>
                        <table width="100%" cellpadding="0px" cellspacing="0px">
                            <tr>
                                <td>
                                    <asp:HyperLink ID="hlnkDownloadErrorFile" runat="server" Target="_blank" Visible="False"
                                        ForeColor="Red"> Download Error File
                                    </asp:HyperLink>
                                </td>
                                <td style="width: 90px">
                                    <asp:HyperLink ID="hlnkOpenOutput" runat="server" Target="_blank" Visible="False"
                                        Font-Bold="True">Open Output</asp:HyperLink>
                                </td>
                                <td style="padding-left: 5px; width: 100px" align="center">
                                    <asp:HyperLink ID="hlnkDownloadZipFile" runat="server" Target="_blank" Visible="False"
                                        Font-Bold="True">Download Validated File</asp:HyperLink>
                                </td>
                                <td style="padding-left: 5px; width: 130px" align="center">
                                    <asp:HyperLink ID="hlnkDownloadDscUtility" runat="server" Target="_blank" Visible="False"
                                        Font-Bold="True">Download DSC Management Utility</asp:HyperLink>
                                </td>
                                <td style="padding-left: 5px; width: 120px">
                                    <asp:HyperLink ID="hlnkDownloadExcludedFile" runat="server" Target="_blank" Visible="false"
                                        Font-Bold="True">Excluded Records</asp:HyperLink>
                                </td>
                                <td align="right" style="width:300px">
                                    <asp:Label ID="lblDate" runat="server" Font-Bold="true" Font-Size="Small" Text=""></asp:Label>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <table>
                            <tr>
                                <td>
                                    <asp:Panel ID="pnlIdentifyError" runat="server" BorderStyle="Dashed" BorderWidth="1"
                                        CssClass="searchPanel" Width="305px" Style="display: none">
                                        <table cellpadding="1" cellspacing="1">
                                            <tr>
                                                <td>
                                                    Enter Line Number
                                                </td>
                                                <td>
                                                    <asp:TextBox ID="txtLineNo" runat="server" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">
                                                    <asp:Button ID="btnIdentify" Text="Identify" runat="server" CssClass="cmnBtn" OnClientClick="return Validate();" />
                                                    <asp:Button ID="btnPrint" Text="Show All" runat="server" CssClass="cmnBtn" />
                                                    <asp:Button ID="btnClose" Text="Close" runat="server" CssClass="cmnBtn" OnClientClick="ShowHideIdentifyError(false);return false;" />
                                                </td>
                                            </tr>
                                        </table>
                                    </asp:Panel>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <table cellspacing="0px" width="100%">
                <tr>
                    <td>
                        <div>
                            <div class="dialog" style="width: 730px;">
                                <div class="dHeader">
                                    Summary Report</div>
                                <div style="padding: 5px; border-top: solid 1px gray">
                                    <table class="table" width="710px" border="1">
                                        <tr>
                                            <th align="center" colspan="4">
                                                <b>Summary</b>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th align="center">
                                                Description
                                            </th>
                                            <th align="center">
                                                <b>Count</b>
                                            </th>
                                            <th align="center">
                                                <asp:Label ID="lblDecAmount" runat="server" Text="Declared Amount(Rs.)" Font-Bold="true"></asp:Label>
                                            </th>
                                            <th align="center" id="thIncome" runat="server">
                                                <asp:Label ID="lblIncomeCountAmt" runat="server" Text="Income Count/Amount(Rs.)"
                                                    Font-Bold="true"></asp:Label>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th align="center">
                                                <asp:Label ID="lblFormDetails" runat="server" Text="Form Details" Font-Bold="true"></asp:Label>
                                            </th>
                                            <td align="center">
                                                <asp:Label ID="lblCount" runat="server">
                                                </asp:Label>
                                            </td>
                                            <td align="center">
                                                <asp:Label ID="lblDeductionAmount" runat="server">
                                                </asp:Label>
                                            </td>
                                            <td align="center" id="tdIncome" runat="server">
                                                <asp:Label ID="lblRemittedAmount" runat="server"></asp:Label>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
    </asp:UpdatePanel>
</asp:Content>
