﻿<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" enableeventvalidation="false" inherits="Deduction_DeductionJK, App_Web_deductionjk.aspx.5ca9984b" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>
    <script type="text/javascript" language="javascript" src="../JavaScript/TDSValidations.js"></script>
    <script type="text/javascript">

        function ConfirmApprove() { return confirm('Do you want to Approve selected deductions ?'); }

        function ConfirmReject() { return confirm('Do you want to Reject selected deductions ?'); }

        function checkDateFormat(ObjectName) {
            var stringValue;
            var arrDate = new Array();
            var arrInput = new Array();
            var counter = 0;
            stringValue = ObjectName.value.trim()
            if (stringValue.length > 0) {
                if (stringValue.indexOf('/') > 0)
                    arrInput = stringValue.split('/');
                else if (stringValue.indexOf('\\') > 0)
                    arrInput = stringValue.split('\\');
                else if (stringValue.indexOf('.') > 0)
                    arrInput = stringValue.split('.');
                else if (stringValue.indexOf('-') > 0)
                    arrInput = stringValue.split('-');
                else if (stringValue.indexOf(',') > 0)
                    arrInput = stringValue.split(',');
                else if (stringValue.indexOf(' ') > 0)
                    arrInput = stringValue.split(' ');

                if (arrInput == '')
                    return false;
                else
                    return true;
            }
        }

        function GetDeducteeNameValue(source, eventArgs) {
            document.getElementById("<%=hdnIsChallanModified.ClientID%>").value = "1";
            var content = eventArgs.get_value();
            var arr = new Array();
            arr = content.indexOf(';') != -1 ? content.split(';') : content.split('-');
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                document.getElementById("<%=hdnDeducteeID.ClientID%>").value = arr[0];
                document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = arr[3] == "0" ? "1" : "0";
                document.getElementById("<%=hdnIsTran.ClientID%>").value = arr[2];
            }
            else {
                document.getElementById("<%=hdnDeducteeID.ClientID%>").value = arr[0];
                document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = arr[1] == "" ? "0" : arr[1];
                document.getElementById("<%=hdnIsTran.ClientID%>").value = arr[2];
            }
        }
        function ClearDeducteeName() {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) { }
            else { document.getElementById("<%=hdnDeducteeID.ClientID%>").value = "-1"; }
        }
        function GetChallanSlNoValue(source, eventArgs) {
            var content = eventArgs.get_value();
            var contents = new Array();
            contents = content.split(';');
            if (document.getElementById("<%=hdnIsPartPaymentActive.ClientID%>").value == "0") {
                document.getElementById("<%=hdnChallanID.ClientID%>").value = contents[0];
                document.getElementById("<%=txtChallanNo.ClientID%>").value = contents[1];
                document.getElementById("<%=txtChallanDate.ClientID%>").value = contents[2];
                document.getElementById("<%=txtTotalAmount.ClientID%>").value = contents[6];
                document.getElementById("<%=hdnChallanDeducteeCode.ClientID%>").value = contents[7];
                document.getElementById("<%=hdnChallanSection.ClientID%>").value = contents[9];

            }
            else {
                document.getElementById("<%=hdnChallanID.ClientID%>").value = contents[0];
                document.getElementById("<%=txtPPChallanNo.ClientID%>").value = contents[1];
                document.getElementById("<%=txtPPChallanDate.ClientID%>").value = contents[2];
                document.getElementById("<%=txtPPChallanIncomeTax.ClientID%>").value = contents[3];
                document.getElementById("<%=txtPPChallanSurcharge.ClientID%>").value = contents[4];
                document.getElementById("<%=txtPPChallanEduCess.ClientID%>").value = contents[5];
                document.getElementById("<%=txtPPChallanTotalAmount.ClientID%>").value = contents[6];
                document.getElementById("<%=hdnChallanSection.ClientID%>").value = contents[9];
            }
        }

        function validateEmpNameOnSal() {
            alert("Salary Details for '" + document.getElementById("<%=hdnEmployeeName.ClientID%>").value + "' is not provided. \nProvide Salary Details to avoid incorrect eReturn filing.");
            return true;
        }

        function EnableDisableControls(value) {
            var edit = document.getElementById("<%=chkEdit.ClientID%>");
            var IsChecker = document.getElementById("<%=hdnIsChecker.ClientID%>").value;
            var value = IsChecker == "1" ? true : false;
            if (edit != null) {
                if (edit.checked) {
                    if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                        if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26") {
                            document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = true;
                            document.getElementById("<%=txtSurchargeAmount.ClientID%>").disabled = true;
                            if (document.getElementById("<%=hdnIsChecker.ClientID%>").value == "1")
                                document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").disabled = true;
                            else
                                document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").disabled = false;
                        }
                        else {
                            if (document.getElementById("<%=hdnIsChecker.ClientID%>").value == "1") {
                                document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").disabled = true;
                                document.getElementById("<%=txtSurchargeAmount.ClientID%>").disabled = true;
                                document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = true;
                            }
                            else {
                                document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").disabled = false;
                                document.getElementById("<%=txtSurchargeAmount.ClientID%>").disabled = false;
                                document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = false;
                            }
                        }
                    }
                    else if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                        document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = false;
                    }
                }
                else {
                    if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                        document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").disabled = true;
                        document.getElementById("<%=txtSurchargeAmount.ClientID%>").disabled = true;
                        document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = true;
                    }
                    else if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                        document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = true;
                    }
                }
                if (value == 1) {
                    CalculateValues();
                }
            }
        }
        function SetSearchPanelVisibility() {
            var btnSearch = document.getElementById("<%=btnOpenSearch.ClientID%>");
            var pnlSearch = document.getElementById("<%=pnlSearch.ClientID%>");

            if (btnSearch == null) { document.getElementById("<%=hdnSearch.ClientID%>").value = "0"; return; }
            else {
                if (document.getElementById("<%=hdnSearch.ClientID%>").value == "0") {
                    if (btnSearch != null) btnSearch.style.display = '';
                    if (pnlSearch != null) pnlSearch.style.display = 'none';
                }
                else {
                    if (btnSearch != null) btnSearch.style.display = 'none';
                    if (pnlSearch != null) pnlSearch.style.display = '';
                }
            }
        }
        function SetStatus() {
            var hdnSearch = document.getElementById("<%=hdnSearch.ClientID%>");
            if (hdnSearch.value == "0") { hdnSearch.value = "1"; }
            else { hdnSearch.value = "0"; }
            SetSearchPanelVisibility();
        }
        function ClearAOP(ctrl) { if (eval(ctrl.value) == 0) { ctrl.value = ""; } }
        function SetDate() {
            if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) > 0) {
                document.getElementById("<%=txtTaxDedDate.ClientID%>").value = document.getElementById("<%=txtCreditedDate.ClientID%>").value;
            }
        }

        function CallServerSideReducedRate() {
            var creditedDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            if (creditedDate != null) {
                if (checkDateFormat(creditedDate)) {
                    if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E")
                        setTimeout(__doPostBack('<%=txtCreditedDate.UniqueID%>', 'Reducedrate'), 0);
                }
            }
        }

        function CalculateValues() {
            var ddlNonDeductionReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>")[document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex].text;
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            var incomeTaxRate = document.getElementById("<%=txtITRate.ClientID%>");
            var incomeTaxAmount = document.getElementById("<%=txtIncomeTaxAmount.ClientID%>");
            var surchargeRate = document.getElementById("<%=txtSurchargeRate.ClientID%>");
            var surchargeAmount = document.getElementById("<%=txtSurchargeAmount.ClientID%>");
            var eduCessRate = document.getElementById("<%=txtEduCessRate.ClientID%>");
            var eduCessAmount = document.getElementById("<%=txtEduCessAmount.ClientID%>");
            var taxDeductedRate = document.getElementById("<%=txtTaxDeductedRate.ClientID%>");
            var taxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
            var creditedDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            var hdnRoundOff = document.getElementById("<%=hdnRoundOff.ClientID%>");
            var chkEdit = document.getElementById("<%=chkEdit.ClientID%>");
            var hdnSetColor = document.getElementById("<%=hdnSetColor.ClientID%>");
            var deductedDate = document.getElementById("<%=txtTaxDedDate.ClientID%>");
            var IsChecker = document.getElementById("<%=hdnIsChecker.ClientID%>");
            var AmountOfCashWithdrawal = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            var amountOfPayment = document.getElementById("<%=txtAmountOfPayment.ClientID%>");

            var section = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;

            if (section.indexOf("194NF") != -1 && document.getElementById("<%=hdnIsValidPAN.ClientID%>").value == 1) {
                if (ddlNonDeductionReason == "" || ddlNonDeductionReason == "Select") {
                    var eduCessRate = document.getElementById("<%=txtEduCessRate.ClientID%>");
                    if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                        if (eduCessRate != null)
                            eduCessRate.value = Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2018 ? "4" : "3";
                    }
                    if (amountOfPayment.value > 2000000 && amountOfPayment.value <= 10000000) {
                        document.getElementById("<%=txtITRate.ClientID%>").value = 2;
                    }
                    else if (amountOfPayment.value > 10000000) {
                        document.getElementById("<%=txtITRate.ClientID%>").value = 5;
                    }
                    else {
                        document.getElementById("<%=txtITRate.ClientID%>").value = 0;
                        if (eduCessRate != null)
                            eduCessRate.value = document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" ? "0" : "";
                    }
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2023) {
                if (section.indexOf("194NFT") != -1 && document.getElementById("<%=hdnIsValidPAN.ClientID%>").value == 1) {
                    if (ddlNonDeductionReason == "" || ddlNonDeductionReason == "Select") {
                        var eduCessRate = document.getElementById("<%=txtEduCessRate.ClientID%>");
                        if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                            if (eduCessRate != null)
                                eduCessRate.value = Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2018 ? "4" : "3";
                        }
                        if (amountOfPayment.value > 2000000 && amountOfPayment.value <= 30000000) {
                            document.getElementById("<%=txtITRate.ClientID%>").value = 2;
                        }
                        else if (amountOfPayment.value > 30000000) {
                            document.getElementById("<%=txtITRate.ClientID%>").value = 5;
                        }
                        else {
                            document.getElementById("<%=txtITRate.ClientID%>").value = 0;
                            if (eduCessRate != null)
                                eduCessRate.value = document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" ? "0" : "";
                        }
                    }
                }
            }
            if (AmountOfCashWithdrawal != null) {
                amountOfPayment = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24" && IsChecker.value == "0") {
                CalculateTaxDeductedForForm24(amountOfPayment, creditedDate, incomeTaxAmount, surchargeRate, surchargeAmount, eduCessRate, eduCessAmount, taxDeducted, hdnRoundOff, chkEdit, hdnSetColor, deductedDate);
            }
            else if ((document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") && IsChecker.value == "0") {
                CalculateTaxDeducted(amountOfPayment, creditedDate, incomeTaxRate, incomeTaxAmount, surchargeRate, surchargeAmount, eduCessRate, eduCessAmount, taxDeductedRate, taxDeducted, deductedDate,
                    hdnRoundOff, chkEdit, hdnSetColor);
            }
            if (deductedDate != null) deductedDate.style.backgroundColor = hdnSetColor.value;

            SetDate();
        }

        function CalculateValues_Sub() {
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            var incomeTaxRate = document.getElementById("<%=txtITRate.ClientID%>");
            var incomeTaxAmount = document.getElementById("<%=txtIncomeTaxAmount.ClientID%>");
            var surchargeRate = document.getElementById("<%=txtSurchargeRate.ClientID%>");
            var surchargeAmount = document.getElementById("<%=txtSurchargeAmount.ClientID%>");
            var eduCessRate = document.getElementById("<%=txtEduCessRate.ClientID%>");
            var eduCessAmount = document.getElementById("<%=txtEduCessAmount.ClientID%>");
            var taxDeductedRate = document.getElementById("<%=txtTaxDeductedRate.ClientID%>");
            var taxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
            var creditedDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            var hdnRoundOff = document.getElementById("<%=hdnRoundOff.ClientID%>");
            var chkEdit = document.getElementById("<%=chkEdit.ClientID%>");
            var hdnSetColor = document.getElementById("<%=hdnSetColor.ClientID%>");
            var deductedDate = document.getElementById("<%=txtTaxDedDate.ClientID%>");
            var IsChecker = document.getElementById("<%=hdnIsChecker.ClientID%>");
            var AmountOfCashWithdrawal = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            var amountOfPayment = document.getElementById("<%=txtAmountOfPayment.ClientID%>");
            if (AmountOfCashWithdrawal != null) {
                amountOfPayment = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24" && IsChecker.value == "0") {
                CalculateTaxDeductedForForm24(amountOfPayment, creditedDate, incomeTaxAmount, surchargeRate, surchargeAmount, eduCessRate, eduCessAmount, taxDeducted, hdnRoundOff, chkEdit, hdnSetColor, deductedDate);
            }
            else if ((document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") && IsChecker.value == "0") {
                CalculateTaxDeducted_Sub(amountOfPayment, creditedDate, incomeTaxRate, incomeTaxAmount, surchargeRate, surchargeAmount, eduCessRate, eduCessAmount, taxDeductedRate, taxDeducted, deductedDate,
                    hdnRoundOff, chkEdit, hdnSetColor);
            }
            if (deductedDate != null) deductedDate.style.backgroundColor = hdnSetColor.value;
        }

        function CalculatePPAmounts() {
            var value;
            var ppAmountToCalc = document.getElementById("<%=txtPPAmountToCalculate.ClientID%>");
            var ppIT = document.getElementById("<%=txtPPIncomeTax.ClientID%>");
            var ppSur = document.getElementById("<%=txtPPSurcharge.ClientID%>");
            var ppEduCess = document.getElementById("<%=txtPPEduCess.ClientID%>");
            var ppTotal = document.getElementById("<%=txtPPTotal.ClientID%>");
            var ppTotal = document.getElementById("<%=txtPPTotal.ClientID%>");
            var incomeTax = document.getElementById("<%=hdnIT.ClientID%>");
            var surcharge = document.getElementById("<%=hdnSur.ClientID%>");
            var taxDeducted = document.getElementById("<%=hdnTaxDeducted.ClientID%>");
            value = Return((eval(Return(ppAmountToCalc.value)) / eval(Return(taxDeducted.value))) * eval(Return(incomeTax.value)));
            ppIT.value = Math.round(value);
            value = Return((eval(Return(ppAmountToCalc.value)) / eval(Return(taxDeducted.value))) * eval(Return(surcharge.value)));
            ppSur.value = Math.round(value);
            value = eval(Return(ppAmountToCalc.value)) - (eval(Return(ppIT.value)) + eval(Return(ppSur.value)));
            ppEduCess.value = Math.round(value);
            ppTotal.value = (eval(ppIT.value) + eval(ppSur.value) + eval(ppEduCess.value)).toFixed(2);
        }
        function CalcPPAmounts() {
            var ppIT = document.getElementById("<%=txtPPIncomeTax.ClientID%>");
            var ppSur = document.getElementById("<%=txtPPSurcharge.ClientID%>");
            var ppEduCess = document.getElementById("<%=txtPPEduCess.ClientID%>");
            var ppTotal = document.getElementById("<%=txtPPTotal.ClientID%>");
            ppTotal.value = (eval(Return(ppIT.value)) + eval(Return(ppSur.value)) + eval(Return(ppEduCess.value))).toFixed(2);
        }
        function ClearPPControls() {
            document.getElementById("<%=hdnLinkID.ClientID%>").value = "-1";
            document.getElementById("<%=hdnDeductionID.ClientID%>").value = "-1";
            document.getElementById("<%=hdnChallanID.ClientID%>").value = "-1";
            document.getElementById("<%=txtPPSlNo.ClientID%>").value = "";
            document.getElementById("<%=txtPPAmountToCalculate.ClientID%>").value = "";
            document.getElementById("<%=txtPPIncomeTax.ClientID%>").value = "";
            document.getElementById("<%=txtPPSurcharge.ClientID%>").value = "";
            document.getElementById("<%=txtPPEduCess.ClientID%>").value = "";
            document.getElementById("<%=txtPPTotal.ClientID%>").value = "";
            document.getElementById("<%=ddlPPQuarter.ClientID%>").selectedIndex = document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0;
            document.getElementById("<%=txtPPChallanSlNo.ClientID%>").disabled = false;
            document.getElementById("<%=txtPPChallanSlNo.ClientID%>").value = "";
            document.getElementById("<%=txtPPChallanNo.ClientID%>").value = "";
            document.getElementById("<%=txtPPChallanDate.ClientID%>").value = "";
            document.getElementById("<%=txtPPChallanIncomeTax.ClientID%>").value = "";
            document.getElementById("<%=txtPPChallanSurcharge.ClientID%>").value = "";
            document.getElementById("<%=txtPPChallanEduCess.ClientID%>").value = "";
            document.getElementById("<%=txtPPChallanTotalAmount.ClientID%>").value = "";
        }
        function Return(tempValue) {
            if (isNaN(tempValue)) { return tempValue = "0"; }
            else if (tempValue == "" || tempValue == "undefined") { return 0; }
            else if (tempValue == "0.00" || tempValue == "0.0000") { return 0; }
            else { return eval(parseFloat(tempValue).toString()); }
        }
        function ShowSectionHelp() {
            if (document.getElementById("<%=hdnFinYear.ClientID%>").value != 2009) {
                if (document.getElementById("<%=hdnFormType .ClientID%>").value == "Form26")
                    window.open('../TDS_Help/TDS_Rates/Form_26_(2010_11).htm');
                else if (document.getElementById("<%=hdnFormType .ClientID%>").value == "Form27")
                    window.open('../TDS_Help/TDS_Rates/Form_27_(2010_11).htm');
                else window.open('../TDS_Help/TDS_Rates/Form27E_(2010-11).htm');
            }
            else {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26")
                    window.open('../TDS_Help/TDS_Rates/Form_26_(2009_10)(Oct_Mar).htm');
                else window.open('../TDS_Help/TDS_Rates/Form_27_(2009_10)(Oct_Mar).htm');
            }
        }
        function Validations() {
            var txtAmtCashDrawn = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            if (txtAmtCashDrawn != null) {
                if (!ValidateLength(document.getElementById("<%=txtAmtCashDrawn.ClientID%>"), "Amount of Cash Withdrawal", 14, true)) return false;
            }

            var section = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                var ddlNonDeductionReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>")[document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex].text;
                if (ddlNonDeductionReason == "Remittance less than Rs.7 lakh - First proviso to Sec. 206C(1G)" ||
                    ddlNonDeductionReason == "TCS already collected by seller - Fourth proviso to Sec. 206C(1G)" ||
                    ddlNonDeductionReason == "TDS provisions applicable/ receipt from specified persons - Fifth proviso to Sec. 206C(1G)" ||
                    ddlNonDeductionReason == "TDS provisions applicable - Second proviso to Sec. 206C(1H)" ||
                    ddlNonDeductionReason == "Receipt from specified persons or as per notification issued - Explanation to Sec. 206C(1H)") {
                    var qtr = document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0;
                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2020) {
                        alert("Selected remarks is applicable from 1st October 2020");
                        return false;
                    }
                    else if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020) {
                        if (ddlNonDeductionReason != "Remittance less than Rs.7 lakh - First proviso to Sec. 206C(1G)" && qtr < 3) {
                            alert("Selected remarks is applicable from 1st October 2020");
                            return false;
                        }
                    }
                }
                if (ddlNonDeductionReason == "TDS provisions applicable - Second proviso to Sec. 206C(1H)" &&
                    section.indexOf("6CR") == -1) {
                    alert("Remark 'G' is applicable only for section 6CR.");
                    return false;
                }
                if (ddlNonDeductionReason == "TDS provisions applicable/ receipt from specified persons - Fifth proviso to Sec. 206C(1G)" &&
                    section.indexOf("6CO") == -1 && section.indexOf("6CP") == -1 && section.indexOf("6CQ") == -1) {
                    alert("Remark 'F' is applicable only for sections '6CO', '6CP' and '6CQ'");
                    return false;
                }

                <%--if (ddlNonDeductionReason == "Remittance less than Rs.7 lakh - First proviso to Sec. 206C(1G)" &&
                    (section.indexOf("6CO") != -1 || section.indexOf("6CP") != -1)) {
                    if ((Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020
                        && qtr >= 3) || Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2021) {
                        alert("Remark 'D' is not applicable for section '6CO' or '6CP' from 1st October 2020");
                        return false;
                    }
                }--%>
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                var ddlNonDeductionReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>")[document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex].text;
                <%--if (ddlNonDeductionReason != "PAN Not available - Higher Rate (5%)") {
                    if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value == "0") {
                        alert("Deductee does not have 'Structurally Valid PAN'.\nNon Deduction reason as 'PAN Not available - Higher Rate (5%)' should be given.");
                        return false;
                    }
                }--%>
            }

            var txtAmtCashDrawn = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            if (!ValidateLength(document.getElementById("<%=txtName.ClientID%>"), ("Deductee Name."), 75, true)) return false;
            if (!ValidateDeductee(document.getElementById("<%=hdnDeducteeID.ClientID%>"), document.getElementById("<%=txtName.ClientID%>"), null)) return false;
            if (!ValidateDropDown(document.getElementById("<%=ddlSection.ClientID%>"), "Section.")) return false;

            var labelText = (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") ? "Amt. of Salary/Pension" : "Amount Of Payment.";
            if (!ValidateLength(document.getElementById("<%=txtAmountOfPayment.ClientID%>"), labelText, 14, true)) return false;
            var section = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;

            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2020 && Return(document.getElementById("<%=hdnSectionID.ClientID%>").value) == 16) {
                alert("Section '194J' is not applicable from FY 2020-21 and onwards.\nSelect '194J(a)' or '194J(b)' Section.");
                return false;
            }

            var txtAmountOfPayment = document.getElementById("<%=txtAmountOfPayment.ClientID%>");
            if (txtAmountOfPayment != null) {
                if (section.indexOf("194NF") != -1) {
                    //if (Return(txtAmountOfPayment.value) <= 2000000) {
                    //    if (!confirm("For Section '194NF', 'Aggregate Amount of Payment' cannot be less than or equal to 'Rs. 2000000'\n Do you want to continue ?")) {
                    //        return false;
                    //    }
                    //}
                }
                else if (section.indexOf("194N") != -1) {
                    //                    if (Return(txtAmountOfPayment.value) <= 10000000) {
                    //                        alert("For Section '194N', 'Aggregate Amount of Payment' cannot be less than or equal to 'Rs. 10000000'");
                    //                        return false;
                    //                    }
                }
            }

            if (txtAmtCashDrawn != null) {
                if (section.indexOf("194N") != -1 || section.indexOf("194NF") != -1) {
                    if (!ValidateLength(document.getElementById("<%=txtAmtCashDrawn.ClientID%>"), "Amount of Cash Withdrawal", 14, true)) return false;
                }
            }
            if (Return(document.getElementById("<%=txtAmountOfPayment.ClientID%>").value) <= 0) {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                    alert("Amt. of Salary/Pension should be greater than zero.");
                    return false;
                } else {
                    alert("Amount of Payment should be greater than zero.");
                    return false;
                }
            }
            if (document.getElementById("<%=hdnIsValid.ClientID%>").value == "0" && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E")
                if (!ValidateLength(document.getElementById("<%=txtTotalValueOfPurchase.ClientID%>"), "Total Value of Pur.(s)", 14, true)) return false;

            if (!ValidateCreditedDate(document.getElementById("<%=txtCreditedDate.ClientID%>"), document.getElementById("<%=hdnFinYear.ClientID%>"), document.getElementById("<%=hdnQuarter.ClientID%>"))) return false;
            if (!ValidateRates(document.getElementById("<%=txtSurchargeRate.ClientID%>"), document.getElementById("<%=txtEduCessRate.ClientID%>"), document.getElementById("<%=txtTaxDeductedRate.ClientID%>"), document.getElementById("<%=hdnFormType.ClientID%>"))) return false;
            if (!ValidateTaxDedDate(document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=txtTaxDedDate.ClientID%>"), document.getElementById("<%=hdnFinYear.ClientID%>"), document.getElementById("<%=hdnQuarter.ClientID%>"))) return false;
            if (document.getElementById("<%=txtTaxDedDate.ClientID%>").value != "" && document.getElementById("<%=txtCreditedDate.ClientID%>").value != "") {
                if (!ValidateDate(document.getElementById("<%=txtCreditedDate.ClientID%>").value, document.getElementById("<%=txtTaxDedDate.ClientID%>").value)) return false;
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                var amt = document.getElementById("<%=txtAmountOfPayment.ClientID%>").value;
                if (amt > 999999999) {
                    alert("Amt. of Salary/Pension should be less than 100 Crores.")
                    document.getElementById("<%=txtAmountOfPayment.ClientID%>").focus();
                    return false;
                }
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                if (!ValidateNonDeductionReason(document.getElementById("<%=ddlSection.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=hdnFinYear.ClientID%>"))) return false;
                if (!ValidateTaxAmountsForParticularSections(document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=txtTaxDeductedRate.ClientID%>"), document.getElementById("<%=txtITRate.ClientID%>"), document.getElementById("<%=ddlSection.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=hdnFinYear.ClientID%>"))) return false;
                if (document.getElementById("<%=hdnFinYear.ClientID%>").value != 2009 && document.getElementById("<%=ddlSection.ClientID%>").style.display != 'none') {
                    if (!ValidateThreshold(document.getElementById("<%=ddlSection.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"))) return false;
                }
                if (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "6") {
                    if (!ValidatePaymentDateBasedOnSection()) return false;
                    if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value == "0") {
                        alert("Deductee does not have 'Structurally Valid PAN'.\nNon Deduction reason as 'Software Vendor Transaction' should not be given.");
                        return false;
                    }
                }
                if (!ValidateSectionandNonDedReason()) return false;
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
                var quarterr = document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0;
                var remittance = document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value;

                if (finYear >= 2024) {
                    if (remittance == "71" && quarterr < 2 && finYear == 2024) {
                        alert("'LTCG ARISING FROM TRANSFER OF UNITS REFERRED TO IN SECTION 115AB' applicable from FY 2024-25 Quarter-2 and onwards.");
                        return false;
                    }
                    else if (remittance == "71" && section.indexOf("196B") == -1) {
                        alert("'LTCG ARISING FROM TRANSFER OF UNITS REFERRED TO IN SECTION 115AB' is applicable for Section 196B.");
                        return false;
                    }

                    if (remittance == "72" && quarterr < 2 && finYear == 2024) {
                        alert("'LTCG ARISING FROM TRANSFER OF SUCH BOND OR GLOBAL DEPOSITORY RECEIPTS REFERRED TO IN SECTION 115AC' is applicable from FY 2024-25 Quarter-2 and onwards.");
                        return false;
                    }
                    else if (remittance == "72" && section.indexOf("196C") == -1) {
                        alert("LTCG ARISING FROM TRANSFER OF SUCH BOND OR GLOBAL DEPOSITORY RECEIPTS REFERRED TO IN SECTION 115AC' is applicable for Section 196C");
                        return false;
                    }

                }
                else if (finYear < 2024 && remittance == "71") {
                    alert("'LTCG ARISING FROM TRANSFER OF UNITS REFERRED TO IN SECTION 115AB' is applicable from FY 2024-25 Quarter-2 and onwards.");
                    return false;
                }
                else if (finYear < 2024 && remittance == "72") {
                    alert("LTCG ARISING FROM TRANSFER OF SUCH BOND OR GLOBAL DEPOSITORY RECEIPTS REFERRED TO IN SECTION 115AC' is applicable from FY 2024-25 Quarter-2 and onwards.");
                    return false;
                }
            }

            var section = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;

            if (section.indexOf("192A") != -1 || section.indexOf("194LBB") != -1) {
                var date = new Date(2015, 05, 01);
                var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                var date1 = paymentDate.value.split('/', 3);
                var creditedDate = new Date(date1[2], (Return(date1[1]) - 1), date1[0]);
                if (creditedDate < date) {
                    alert("Section '" + ((section.indexOf("192A") != -1) ? "192A" : "194LBB") + "' is Applicable from '01/06/2015'.");
                    return false;
                }
            }

            if (section.indexOf("194N") != -1 || section.indexOf("194NF") != -1) {
                if (!Validate194NSectionBasedOnDate()) return false;
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2012 && section.indexOf("194LC") != -1 && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "3") {
                alert("The Deduction Remark 'Deduction at Higher Rate 20% - PANNOTAVBL' is not applicable for Section 194LC");
                return false;
            }
            if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0 && (Return(document.getElementById("<%=hdnChallanID.ClientID%>").value) == -1 && Return(document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex) == 0)) {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value != "Form24") {
                    if ((section.indexOf("194BP") == 0) || (section.indexOf("194BAP") == 0) || (section.indexOf("194RP") == 0) || (section.indexOf("194SP") == 0)) {
                        alert("Specify the Remarks for Deduction.");
                        document.getElementById("<%=ddlNonDeductionReason.ClientID%>").focus();
                        return false;
                    }
                }
                else {
                    return confirm("'Remarks for Deduction' is required for Non-Deduction records.\nIf none are applicable, recommended to link to a paid challan.");
                }
            }
            <%--if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2012 && section.indexOf("194LC") == -1) {
                if (!ValidateIfPANNotAvailableSB(1, document.getElementById("<%=hdnIsValidPAN.ClientID%>"), document.getElementById("<%=hdnFormType.ClientID%>"), document.getElementById("<%=txtTaxDeductedRate.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=txtITRate.ClientID%>"), document.getElementById("<%=txtIncomeTaxAmount.ClientID%>"))) return false;
            }--%>
            var section = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;
            if (section.indexOf("192A") != -1 || section.indexOf("194LBB") != -1) {
                var date = new Date(2015, 05, 01);
                var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                var date1 = paymentDate.value.split('/', 3);
                var creditedDate = new Date(date1[2], (Return(date1[1]) - 1), date1[0]);
                if (creditedDate < date) {
                    alert("Section '" + ((section.indexOf("192A") != -1) ? "192A" : "194LBB") + "' is Applicable from '01/06/2015'.");
                    return false;
                }
            }
            //            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2012 && section.indexOf("194LC") != -1 && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "3") {
            //                alert("The Deduction Remark 'Deduction at Higher Rate 20% - PANNOTAVBL' is not applicable for Section 194LC");
            //                return false;
            //            }
            if (document.getElementById("<%=hdnFinYear.ClientID%>").value != "2009" && document.getElementById("<%=hdnIsValid.ClientID%>").value != "1") {
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2012 && section.indexOf("194LC") == -1) {
                    if (!ValidateIfPANNotAvailableOthers(0, document.getElementById("<%=hdnIsValidPAN.ClientID%>"), document.getElementById("<%=hdnFormType.ClientID%>"), document.getElementById("<%=txtTaxDeductedRate.ClientID%>"),
                        document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=txtITRate.ClientID%>"), document.getElementById("<%=txtIncomeTaxAmount.ClientID%>"))) return false;
                }
            }

            var txtAmountOfPayment = document.getElementById("<%=txtAmountOfPayment.ClientID %>");
            var txtTaxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
            if (txtAmtCashDrawn != null) {
                if (section.indexOf("194N") != -1 || section.indexOf("194NF") != -1) {
                    //                if (!Validate194NSectionBasedOnDate()) return false;
                    if ((Return(txtAmtCashDrawn.value)) > (Return(txtAmountOfPayment.value))) {
                        alert("Amount of Cash Withdrawal should be less than or equal to Aggregate Amount of Payment")
                        return false;
                    }
                    if ((Return(txtTaxDeducted.value)) > (Return(txtAmtCashDrawn.value))) {
                        var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                        alert((formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount should be less than or equal to Amount of Cash Withdrawal")
                        return false;
                    }
                }
            }
            else {
                if ((Return(txtTaxDeducted.value)) > (Return(txtAmountOfPayment.value))) {
                    var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                    alert((formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount should be less than or equal to " + (formTypeNew != "Form24" ? "Amount of Payment" : "Amt. of Salary/Pension"));
                    return false;
                }
            }
            if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value == 1 && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == 3) {
                alert("Remark 'PAN Not Available-Higher Rate(20%)' Required only if 'PAN is Invalid'");
                return false;
            }

            if (section.indexOf("194NF") != -1) {
                if (!ValidateNonDedReasonfor194NF(document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"))) return false;
            }
            else if (section.indexOf("194N") != -1) {
                //                if (!Validate194NSectionBasedOnDate()) return false;
                //                if ((Return(txtAmtCashDrawn.value)) > (Return(txtAmountOfPayment.value))) {
                //                    alert("Amount of Cash Withdrawal should be less than or equal to Amount of Payment")
                //                    return false;
                //                }
                if (!ValidateNonDedReasonfor194N(document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"))) return false;
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" && document.getElementById("<%=hdnIsTran.ClientID%>").value == "True") {
                if (!ValidateIfPANAndTransporter(document.getElementById("<%=hdnIsTran.ClientID%>"), document.getElementById("<%=hdnIsValidPAN.ClientID%>"),
                    document.getElementById("<%=txtTaxDeductedRate.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"),
                    document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=hdnFormType.ClientID%>"), document.getElementById("<%=txtITRate.ClientID%>"))) return false;
                if (!ValidateIfTransporter(document.getElementById("<%=hdnIsValidPAN.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"),
                    document.getElementById("<%=txtITRate.ClientID%>"), document.getElementById("<%=txtTaxDeductedRate.ClientID%>"))) return false;
            }
            if (document.getElementById("<%=txtCertNo.ClientID%>") != null && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012) {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                    if (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "1" || document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "2" ||
                        document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "65" || document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "66") {
                        if (document.getElementById("<%=txtCertNo.ClientID%>").value.trim() == "") {
                            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) { alert("Specify 'U/s 197 Cert.No.'."); }
                            else { alert("Specify 'U/s 395 Cert.No.'."); }
                            document.getElementById("<%=txtCertNo.ClientID%>").focus();
                            return false;
                        }
                        else {
                            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                    return false;
                            }
                            else {
                                var certInput = document.getElementById("<%=txtCertNo.ClientID%>");
                                if (certInput) {
                                    var value = certInput.value.trim();

                                    if (value === "") {
                                        alert("Specify U/s 395 Cert.No.");
                                        return false;
                                    } else if (!(/^[A-Za-z0-9]{10}$/.test(value) || /^[A-Za-z0-9]{15}$/.test(value))) {
                                        alert("Certificate number must be either 10 or 15 alphanumeric characters.");
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
                else if (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "1" || document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "2"
                    || document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "65" || document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "66") {
                    if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E" && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "1" && document.getElementById("<%=txtCertNo.ClientID%>").value.trim() == "") {
                        alert("Specify 'U/s 197 Cert.No.'.");
                        document.getElementById("<%=txtCertNo.ClientID%>").focus();
                        return false;
                    }
                    else {
                        if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                            if (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "2") {
                                if ((Return(document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0) > 2 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2015) || Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2015) {
                                    if (document.getElementById("<%=txtCertNo.ClientID%>").value.trim() != "") {
                                        var pattern = /^[gGhH]{1}[0-9]{14}$/;
                                        var val = document.getElementById("<%=txtCertNo.ClientID%>").value;
                                        var matchArray = val.match(pattern);
                                        if (matchArray == null) {
                                            if (document.getElementById("<%=hdnFormType.ClientID%>").value != "Form27E") {
                                               <%-- alert("Specify valid 15G/15H UIN.\nEx: G123456789/H123456789");
                                                document.getElementById("<%=txtCertNo.ClientID%>").focus();
                                                return false;--%>
                                                if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 10, true))
                                                    return false;
                                            }
                                            else {
                                                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                                    if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                                        return false;
                                                }
                                                else {
                                                    if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 10, true))
                                                        return false;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else {
                                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                    if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                        return false;
                                }
                                else {
                                    if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 10, true))
                                        return false;
                                }
                            }
                        }
                        if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026) {
                            if (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "66") {
                                if ((Return(document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0) > 2 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2015) || Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2015) {
                                    if (document.getElementById("<%=txtCertNo.ClientID%>").value.trim() != "") {
                                        var pattern = /^[gGhH]{1}[0-9]{9}$/;
                                        var val = document.getElementById("<%=txtCertNo.ClientID%>").value;
                                        var matchArray = val.match(pattern);
                                        if (matchArray == null) {
                                            if (document.getElementById("<%=hdnFormType.ClientID%>").value != "Form27E") {
                                               <%-- alert("Specify valid 121 UIN.\nEx: G123456789/H123456789");
                                                document.getElementById("<%=txtCertNo.ClientID%>").focus();
                                                return false;--%>
                                                if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 10, true))
                                                    return false;
                                            }
                                            else {
                                                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                                    if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                                        return false;
                                                }
                                                else {
                                                    if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 10, true))
                                                        return false;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else {
                                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                    if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                        return false;
                                }
                                else {
                                    var certInput = document.getElementById("<%=txtCertNo.ClientID%>");
                                    if (certInput) {
                                        var value = certInput.value.trim();
                                        if (value === "") {
                                            alert("Specify U/s 395 Cert.No.");
                                            return false;
                                        } else if (!(/^[A-Za-z0-9]{10}$/.test(value) || /^[A-Za-z0-9]{15}$/.test(value))) {
                                            alert("Certificate number must be either 10 or 15 alphanumeric characters.");
                                            return false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "3" && document.getElementById("<%=txtCertNo.ClientID%>").value.trim() != ""
                && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                    return false;
            }

            if (document.getElementById("<%=PnlResidentDetails.ClientID%>") != null) {
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2016
                    && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                    if (document.getElementById("<%=ddlDedNonRes.ClientID%>").selectedIndex == 0) {
                        alert("Specify whether Deductee is Non-Resident.");
                        return false;
                    }
                    else if (document.getElementById("<%=ddlDedNonRes.ClientID%>").selectedIndex == 1) {
                        if (document.getElementById("<%=ddlDedPerEstaIndia.ClientID%>").selectedIndex == 0) {
                            alert("Specify whether Deductee is having Permanent Establishment in India.");
                            return false;
                        }
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                var sectionID = document.getElementById("<%=hdnSectionID.ClientID%>").value;
                if ((document.getElementById("<%=hdnDeductorStatus.ClientID%>").value == 2) && (Return(sectionID) == 1 || Return(sectionID) == 25)) {
                    return confirm("If you are making entry for payment relating to " + (Return(sectionID) == 1 ? "State" : "Central") + " Govt Employee pension\n Click OK else Cancel");
                }
                else if (document.getElementById("<%=hdnDeductorStatus.ClientID%>").value == 1 && Return(sectionID) == 2) {
                    return confirm("Given Section is not valid for selected Deductor Type.\nAre you sure you want to continue?");
                }
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value != "Form24") {
                var itRate = document.getElementById("<%=txtITRate.ClientID%>").value;
                var incomeTaxAmt = document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").value;
                if (Return(itRate) == 0 && Return(incomeTaxAmt) > 0) {
                    alert("Please specify both Tax Rate and Tax Amount");
                    return false;
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012 && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                if (!ValidateAckNo(document.getElementById("<%=txtAckNo.ClientID%>"), "15CA Ack. No.", 12, false)) return false;
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026) {
                    if (document.getElementById("<%=ddlRateType.ClientID%>").selectedIndex == 0) {
                        alert("Select TDS Rate as per.");
                        return false;
                    }
                }
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                    if (document.getElementById("<%=ddlNatureofRemittance.ClientID%>").selectedIndex == 0) {
                        alert("Select Nature of Remittance.");
                        return false;
                    }
                }
                if (document.getElementById("<%=ddlCountries.ClientID%>").selectedIndex == 0) {
                    alert("Select Country of Residence.");
                    return false;
                }
            }
            if (Return(document.getElementById("<%=hdnIsSB.ClientID%>").value) == "1") {
                if ((!checkRate(document.getElementById("<%=txtSurchargeRate.ClientID%>").value, "1")) && (document.getElementById("<%=hdnTransStatus.ClientID%>").value != "2")) {
                    alert("Surcharge rate cannot be greater than 12.");
                    return false;
                }
                if ((!checkRate(document.getElementById("<%=txtEduCessRate.ClientID%>").value, "2")) && (document.getElementById("<%=hdnTransStatus.ClientID%>").value != "2")) {
                    alert("Education cess rate cannot be greater than 4.");
                    return false;
                }
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2021
                && document.getElementById("<%=hdnSectionID.ClientID%>").value != 21 && document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1" && (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026)) {
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2016 && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                    if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1" && (Return(document.getElementById("<%=txtITRate.ClientID%>").value) < 20) && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "3"
                        && (document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "27" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "49" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "21"
                            || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "52" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "31"
                        || (((Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020 && qtr >= 3) || Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2020)
                            && document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "16")) ||
                        (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2023)
                        && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "3"
                    && (Return(document.getElementById("<%=txtITRate.ClientID%>").value) < 20)
                    && (document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "66"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "67"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "68"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "69"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "70")) {
                        if (document.getElementById("<%=txtEmailDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Email is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Contact Number is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtAddressDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Address is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtIdentNumDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Identification Number is mandatory.")
                            return false;
                        }
                    }
                    else {
                        if (document.getElementById("<%=txtEmailDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Email should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Contact Number should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtAddressDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Address should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtIdentNumDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Identification Number should not be given.")
                            return false;
                        }
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" && document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1" && (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026)) {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                    if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1" && (Return(document.getElementById("<%=txtITRate.ClientID%>").value) < 20) && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "67"
                        && (document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "205" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "206" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "207" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "210"
                            || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "211" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "212"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "213" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "216"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "217")) {
                        if (document.getElementById("<%=txtEmailDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Email is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim() == "") {
                                alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Contact Number is mandatory.")
                                return false;
                            }
                            else if (document.getElementById("<%=txtAddressDed.ClientID%>").value.trim() == "") {
                                alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Address is mandatory.")
                                return false;
                            }
                            else if (document.getElementById("<%=txtIdentNumDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Identification Number is mandatory.")
                            return false;
                        }
                    }
                    else {
                        if (document.getElementById("<%=txtEmailDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Email should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim() != "") {
                                alert("Deductee Contact Number should not be given.")
                                return false;
                            }
                            else if (document.getElementById("<%=txtAddressDed.ClientID%>").value.trim() != "") {
                                alert("Deductee Address should not be given.")
                                return false;
                            }
                            else if (document.getElementById("<%=txtIdentNumDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Identification Number should not be given.")
                            return false;
                        }
                    }
                }
            }
            if ((Return(document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").value) + Return(document.getElementById("<%=txtSurchargeAmount.ClientID%>").value) +
                Return(document.getElementById("<%=txtEduCessAmount.ClientID%>").value)) != Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value)) {
                alert("Sum of Income Tax, Surcharge and Edu Cess is not matching Tax Deducted.");
                document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").focus();
                return false;
            }

            var ddlNonDeductionReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>")[document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex].text;
            var ITRateInput = document.getElementById("<%=txtITRate.ClientID%>").value;
            var hdnITPercentage = document.getElementById("<%=hdnITPercentage.ClientID%>").value;
            hdnITPercentage = hdnITPercentage * 2;
            if (hdnITPercentage < 5)
                hdnITPercentage = 5;

            if (ddlNonDeductionReason == "Section 206AB applicable - Higher rate" || ddlNonDeductionReason == "Section 206CCA applicable - Higher rate") {
                if (hdnITPercentage > ITRateInput) {
                    if (!confirm("For Selected Remark, Income Tax Rate should be of " + hdnITPercentage + "% .\nDo you want to continue ?")) {
                        return false;
                    }
                }
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" && section.indexOf("196D(1A)") != -1 &&
                ((document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "28") || document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "29")) {
                var date = new Date(2020, 10, 01);
                var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                var date1 = paymentDate.value.split('/', 3);
                var creditedDate = new Date(date1[2], date1[1], date1[0]);
                if (creditedDate <= date) {
                    alert("Selected 'Remarks for Deduction' is Applicable from '01/11/2020'.");
                    return false;
                }
            }
            if ((document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "7") && section.indexOf("194A") != -1) {
                var date = new Date(2021, 09, 17);
                var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                var date1 = paymentDate.value.split('/', 3);
                var creditedDate = new Date(date1[2], date1[1], date1[0]);
                if (creditedDate < date) {
                    alert("Remark 'NO DEDUCTION U/S 197A(1F)', for 194A\napplicable from '17/09/2021'.");
                    return false;
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2021 && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                var NatureOfRemittance = document.getElementById("<%=ddlNatureofRemittance.ClientID%>");
                var NonDedres = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
                if (document.getElementById("<%=hdnSectionID.ClientID%>").value == 21) {
                    if (!(NatureOfRemittance.value == "16" || NatureOfRemittance.value == "27")) {
                        alert("Selected Nature of Remittance is not applicable for Section 196D.");
                        return false;
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                if (!ValidateSectionandNonDedReason()) return false;
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26") {
                var quarter = document.getElementById("<%=hdnQuarter.ClientID%>").value;
                var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
                var minQuarterDate, maxQuarterDate;
                var currentDate = new Date();
                if (section.indexOf("194BP") != -1 || section.indexOf("194BAP") != -1 || section.indexOf("194RP") != -1 || section.indexOf("194SP") != -1) {
                    var SelectedChallanNumber = document.getElementById("<%=txtChallanSlNo.ClientID%>");
                    if (SelectedChallanNumber.value == "") {
                        if (finYear <= 2025) {
                            alert("For '" + (
                                (section.indexOf("194BP") != -1) ? "194BP" :
                                    (section.indexOf("194BAP") != -1) ? "194BAP" :
                                        (section.indexOf("194RP") != -1) ? "194RP" : "194SP"
                            ) + "', Challan should be linked.");
                        }
                        else {
                            alert("For '" + (
                                (section.indexOf("194BP") != -1) ? "1059" :
                                    (section.indexOf("194BAP") != -1) ? "1061" :
                                        (section.indexOf("194RP") != -1) ? "1034" : "1038"
                            ) + "', Challan should be linked.");
                        }
                        return false;
                    }
                    else {
                        txtTaxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
                        txtChallanDate = document.getElementById("<%=txtChallanDate.ClientID%>");
                        txtCreditedDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                        var date1 = txtChallanDate.value;
                        var date2 = txtCreditedDate.value;
                        if (date1.toString().indexOf("-") != -1) {
                            date1 = date1.split('-', 3);
                        }
                        else {
                            date1 = date1.split('/', 3);
                        }
                        if (date2.toString().indexOf("-") != -1) {
                            date2 = date2.split('-', 3);
                        }
                        else {
                            date2 = date2.split('/', 3);
                        }
                        var challanDate = new Date(date1[2], parseInt(date1[1]) - 1, date1[0]);
                        var creditedDate = new Date(date2[2], parseInt(date2[1]) - 1, date2[0]);
                        if (quarter == "Quarter1") {
                            minQuarterDate = new Date(finYear, 03, 01);
                            maxQuarterDate = new Date(finYear, 05, 30);
                        }
                        else if (quarter == "Quarter2") {
                            minQuarterDate = new Date(finYear, 06, 01);
                            maxQuarterDate = new Date(finYear, 08, 30);
                        }
                        else if (quarter == "Quarter3") {
                            minQuarterDate = new Date(finYear, 09, 01);
                            maxQuarterDate = new Date(finYear, 11, 31);
                        }
                        else if (quarter == "Quarter4") {
                            minQuarterDate = new Date(eval(finYear) + 1, 00, 01);
                            maxQuarterDate = new Date(eval(finYear) + 1, 02, 31);
                        }
                        if (challanDate < minQuarterDate) {
                            alert("Challan Date cannot be before Current Quarter.");
                            return false;
                        }
                        if (challanDate > maxQuarterDate) {
                            alert("Challan Date cannot be after Current Quarter.");
                            return false;
                        }
                        if (challanDate > currentDate) {
                            alert("Challan Date cannot be future date.");
                            return false;
                        }
                        if (challanDate > creditedDate) {
                            alert("For '" + ((section.indexOf("194BP") != -1) ? "194BP" : (section.indexOf("194BAP") != -1) ? "194BAP" : ((section.indexOf("194RP") != -1) ? "194RP" : "194SP"))
                                + "', Challan being linked should be paid\nOn or Before 'Paid/Credited Date'.");
                            return false;
                        }
                        if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0) {
                            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                                alert("For Deduction related to 194BP, 194RP, 194BAP or 194SP\nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                                return false;
                            }
                            else {
                                alert("For Deduction related to 1059, 1034, 1061 or 1038\nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                                return false;
                            }
                        }
                        if ((document.getElementById("<%=hdnIsValidPAN.ClientID%>").value) == "0") {
                            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                                alert("For Deduction related to 194BP, 194RP, 194BAP or 194SP\nInvalid PAN challan cannot be link.");
                                return false;
                            }
                            else {
                                alert("For Deduction related to 1059, 1034, 1061 or 1038\nInvalid PAN challan cannot be link.");
                                return false;
                            }
                        }
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                var quarter = document.getElementById("<%=hdnQuarter.ClientID%>").value;
                var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
                var minQuarterDate, maxQuarterDate;
                var currentDate = new Date();
                if (section.indexOf("194BP") != -1 || section.indexOf("194BAP") != -1) {
                    var SelectedChallanNumber = document.getElementById("<%=txtChallanSlNo.ClientID%>");
                    if (SelectedChallanNumber.value == "") {
                        alert("For '" + ((section.indexOf("194BP") != -1) ? "194BP" : "194BAP")
                            + "', Challan should be linked.");
                        return false;
                    }
                    else {
                        txtTaxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
                        txtChallanDate = document.getElementById("<%=txtChallanDate.ClientID%>");
                        txtCreditedDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                        var date1 = txtChallanDate.value;
                        var date2 = txtCreditedDate.value;
                        if (date1.toString().indexOf("-") != -1) {
                            date1 = date1.split('-', 3);
                        }
                        else {
                            date1 = date1.split('/', 3);
                        }
                        if (date2.toString().indexOf("-") != -1) {
                            date2 = date2.split('-', 3);
                        }
                        else {
                            date2 = date2.split('/', 3);
                        }
                        var challanDate = new Date(date1[2], parseInt(date1[1]) - 1, date1[0]);
                        var creditedDate = new Date(date2[2], parseInt(date2[1]) - 1, date2[0]);
                        if (quarter == "Quarter1") {
                            minQuarterDate = new Date(finYear, 03, 01);
                            maxQuarterDate = new Date(finYear, 05, 30);
                        }
                        else if (quarter == "Quarter2") {
                            minQuarterDate = new Date(finYear, 06, 01);
                            maxQuarterDate = new Date(finYear, 08, 30);
                        }
                        else if (quarter == "Quarter3") {
                            minQuarterDate = new Date(finYear, 09, 01);
                            maxQuarterDate = new Date(finYear, 11, 31);
                        }
                        else if (quarter == "Quarter4") {
                            minQuarterDate = new Date(eval(finYear) + 1, 00, 01);
                            maxQuarterDate = new Date(eval(finYear) + 1, 02, 31);
                        }
                        if (challanDate < minQuarterDate) {
                            alert("Challan Date cannot be before Current Quarter.");
                            return false;
                        }
                        if (challanDate > maxQuarterDate) {
                            alert("Challan Date cannot be after Current Quarter.");
                            return false;
                        }
                        if (challanDate > currentDate) {
                            alert("Challan Date cannot be future date.");
                            return false;
                        }
                        if (challanDate > creditedDate) {
                            alert("For '" + ((section.indexOf("194BP") != -1) ? "194BP" : "194BAP")
                                + "', Challan being linked should be paid\nOn or Before 'Paid/Credited Date'.");
                            return false;
                        }
                        if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0) {
                            alert("For Deduction related to 194BP,194BAP \nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                            return false;
                        }
                        if ((document.getElementById("<%=hdnIsValidPAN.ClientID%>").value) == "0") {
                            alert("For Deduction related to 194BP,194BAP \nInvalid PAN challan cannot be link.");
                            return false;
                        }
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                var theDropDown = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
                if (theDropDown.value == 13 || theDropDown.value == 14 || theDropDown.value == 70) {
                    if (document.getElementById("<%=ddl27EQLiableOption.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "") {
                            alert("Challan Serial Number cannot be blank.");
                            document.getElementById("<%=txt27EQChallanNo.ClientID%>").focus();
                            return false;
                        }
                        if (document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "0"
                            || document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "00"
                            || document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "000"
                            || document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "0000"
                            || document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "00000"
                        ) {
                            alert("Please enter valid Challan Serial Number.");
                            document.getElementById("<%=txt27EQChallanNo.ClientID%>").focus();
                            return false;
                        }
                        if (document.getElementById("<%=txt27EQChallanNo.ClientID%>").value.length != 5) {
                            alert("Challan Serial Number Should be of 5 Digits.");
                            document.getElementById("<%=txt27EQChallanNo.ClientID%>").focus();
                            return false;
                        }
                        if (document.getElementById("<%=txt27EQPaidDate.ClientID%>").value == "") {
                            alert("Challan Paid Date cannot be blank.");
                            document.getElementById("<%=txt27EQPaidDate.ClientID%>").focus();
                            return false;
                        }
                        var currentDate = new Date();
                        var date = new Date(2019, 04, 01);
                        var date1 = document.getElementById("<%=txt27EQPaidDate.ClientID%>").value.split('/', 3);
                        var challanPaidDate = new Date(date1[2], date1[1], date1[0]);
                        var challanPaidDate1 = new Date(date1[2], parseInt(date1[1]) - 1, date1[0]);
                        if (challanPaidDate < date) {
                            alert("Challan Paid date is applicable from 01/04/2019");
                            document.getElementById("<%=txt27EQPaidDate.ClientID%>").focus();
                            return false;
                        }
                        else if (challanPaidDate1 > currentDate) {
                            alert("Challan Paid date should not be future date.");
                            document.getElementById("<%=txt27EQPaidDate.ClientID%>").focus();
                            return false;
                        }
                    }
                    else {
                        if (document.getElementById("<%=txt27EQChallanNo.ClientID%>").value != "") {
                            alert("'Payment by Collectee liable to TDS' option is set to 'No' \nHence Challan Serial Number is not allowed to enter.");
                            document.getElementById("<%=txt27EQChallanNo.ClientID%>").focus();
                            return false;
                        }
                        if (document.getElementById("<%=txt27EQPaidDate.ClientID%>").value != "") {
                            alert("'Payment by Collectee liable to TDS' option is set to 'No' \nHence Challan Paid Date is not allowed to enter.");
                            document.getElementById("<%=txt27EQPaidDate.ClientID%>").focus();
                            return false;
                        }
                    }
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2024 && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                var NatureOfRemittance = document.getElementById("<%=ddlNatureofRemittance.ClientID%>");
                var NonDedres = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
                if (Return(document.getElementById("<%=hdnSectionID.ClientID%>").value) == 17) {
                    if ((NonDedres.value == "26")) {
                        if (!(NatureOfRemittance.value == "27")) {
                            alert("Remark 'Lower Deduction/No Deduction under sub-section (1F) of section 197A',\nis applicable for Section 195 having 'Nature of Remittance' as 'Interest Payment'.");
                            return false;
                        }
                    }
                }
                else {
                    if ((NonDedres.value == "26")) {
                        alert("Remark 'Lower Deduction/No Deduction under sub-section (1F) of section 197A' is only applicable for Section 195.");
                        return false;
                    }
                }
            }

            if (document.getElementById("<%=hdnDeducteeCode.ClientID%>").value != "" && document.getElementById("<%=hdnChallanDeducteeCode.ClientID%>").value != "") {
                if (document.getElementById("<%=hdnDeducteeCode.ClientID%>").value != document.getElementById("<%=hdnChallanDeducteeCode.ClientID%>").value) {
                    return confirm("Deductee code of Deductee is not matching with the challan to be linked.\nDo you want to continue?");
                }
            }
            if (section.indexOf("194LD") != -1) { if (!ValidateSectionBasedOnDate()) return false; }
            return true;
        }

        function ValidateIfPANNotAvailableOthers(isSB, hdnIsValidPAN, hdnFormType, txtTaxDeductedRate, ddlNonDeductionReason, txtTaxDeducted, txtITRate, txtIncomeTaxAmount) {
            if (hdnIsValidPAN.value != "1") {
                if (hdnFormType.value != "Form24" && hdnFormType.value != "Form27E") {
                    if (Return(txtTaxDeductedRate.value) < 20) {
                        if (!isSB) {
                            var res = confirm('Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 20%.\nDo you want to continue?');
                            if (res) {
                                if (ddlNonDeductionReason.value == "3") {
                                    if (Return(txtTaxDeducted.value) == 0) {
                                        var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                        alert("For 'PAN Not available - Higher Rate (20%)',\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " can't be Nil.'");
                                        txtITRate.focus();
                                        return false;
                                    }
                                }
                            }
                            else {
                                return false;
                            }
                        }
                        else {
                            alert("Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 20%");
                            return false;
                        }
                    }
                    else {
                        if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("Since Tax Dedcuted Amount is zero,\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " Rate should also be zero.");
                            txtITRate.focus();
                            return false;
                        }
                    }
                }
                else if (hdnFormType.value == "Form27E") {
                    //if (Return(txtTaxDeductedRate.value) < 5) {
                    //    alert("Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 5%");
                    //    return false;
                    //}
                }
                else {
                    if ((ddlNonDeductionReason.value == "3" && document.getElementById("<%=hdnFinYear.ClientID%>") < 2026) || (ddlNonDeductionReason.value == "67" && document.getElementById("<%=hdnFinYear.ClientID%>") >= 2026)) {
                        if (hdnFormType.value == "Form24") {
                            if (Return(txtTaxDeducted.value) == 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " can't be Nil.'");
                                txtIncomeTaxAmount.focus();
                                return false;
                            }
                        }
                        else {
                            if (Return(txtTaxDeducted.value) == 0 &&
                                Return(txtTaxDeductedRate.value) == 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " can't be Nil.'");
                                if (hdnFormType.value != "Form24") {
                                    txtITRate.focus();
                                    return false;
                                }
                            }
                            else if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " can't be Nil.'");
                                txtITRate.focus();
                                return false;
                            }
                            else if (Return(txtTaxDeducted.value) != 0 && Return(txtTaxDeductedRate.value) == 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " Rate can't be Nil.'");
                                txtITRate.focus();
                                return false;
                            }
                        }
                    }
                    return true;
                }
            }
            return true;
        }
        function ValidatePaymentDateBasedOnSection() {
            var date = new Date(2012, 07, 01);
            var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            var date1 = paymentDate.value.split('/', 3);
            var creditedDate = new Date(date1[2], date1[1], date1[0]);
            if (creditedDate < date) { alert("Remarks 'Software Vendor Transaction' is Applicable from '01/07/2012'."); return false; }
            Display("1"); return true;
        }
        function ValidateSectionandNonDedReason() {
            var nonDedReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
            var section = document.getElementById("<%=hdnSectionID.ClientID%>");
            var sections = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;
            var formType = document.getElementById("<%=hdnFormType.ClientID%>");

            if (formType.value == "Form24") {
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2020) {
                    if (nonDedReason.value != "3" && section.value == "74") {
                        alert("Deduction Remarks 'PAN Not available - Higher Rate (20%)' is applicable for Section 194P Only.");
                        return false;
                    }
                }
            }
            else if (formType.value == "Form26") {
                if (nonDedReason.value == "6" && (!(section.value == "16" || section.value == "73"))) {
                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2020) {
                        alert("Deduction Remarks 'Software Vendor Transaction' is applicable for Section 194J(a)/194J(b)/195/194Q Only.");
                    }
                    else {
                        alert("Deduction Remarks 'Software Vendor Transaction' is applicable for Section 194J/195 Only.");
                    }
                    return false;
                }
                if (nonDedReason.value == "8" && section.value != "5") {
                    alert("Deduction Remarks 'Deduction on Interest Income for Senior Citizens' is applicable for Section 194A Only.");
                    return false;
                }
            }
            else if (formType.value == "Form27") {
                if (nonDedReason.value == "6" && section.value != "17") {
                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2020) {
                        alert("Deduction Remarks 'Software Vendor Transaction' is applicable for Section 194J(a)/194J(b)/195 Only.");
                    }
                    else {
                        alert("Deduction Remarks 'Software Vendor Transaction' is applicable for Section 194J/195 Only.");
                    }
                    return false;
                }
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2020) {
                    if (((nonDedReason.value == "28" || nonDedReason.value == "29")) && (!(sections.indexOf("196D(1A)") != -1))) {
                        alert("Selected Deduction Remarks is not applicable for Section 196D(1A).");
                        return false;
                    }
                }
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020) {
                    if (nonDedReason.value == "29" && section.value == "21") {
                        alert("Deduction Remarks 'No Deduction on Income under Capital gains payable to FII (Sec.196D(2))' is applicable for Section 196D from 01-04-2021.");
                        return false;
                    }
                }
            }
            return true;
        }


        function ValidateDate(creditedDate, deductedDate) {
            var date1 = creditedDate.split('/', 3);
            var date2 = deductedDate.split('/', 3);
            var paymentDate = new Date(date1[2], date1[1], date1[0]);
            var dedDate = new Date(date2[2], date2[1], date2[0]);
            if (paymentDate > dedDate) {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert(formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited" + " Date should be less than " + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " Date."); return false;
            } return true;
        }
        function ValidateCreditedDate(creditedDate, hdnFinYear, hdnQuarter) {
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E" ? "1" : "0";
            var finYear = hdnFinYear.value;
            var date = creditedDate.value.split('/', 3);
            var endrange = new Date(date[2], date[1] - 1, date[0]);
            var quarterNo = hdnQuarter.value;
            var stardateFY = new Date(finYear, 03, 01);
            if (creditedDate.value == "") {
                if (formType == 1) {
                    alert("Specify Received/Debited Date");
                    creditedDate.focus();
                    return false;

                } else {
                    var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                    alert("Specify " + formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited" + " Date.");
                    creditedDate.focus();
                    return false;
                }
            }
            if (quarterNo == "Quarter1") { minQuarterDate = new Date(finYear, 03, 01); maxQuarterDate = new Date(finYear, 05, 30); }
            else if (quarterNo == "Quarter2") { minQuarterDate = new Date(finYear, 06, 01); maxQuarterDate = new Date(finYear, 08, 30); }
            else if (quarterNo == "Quarter3") { minQuarterDate = new Date(finYear, 09, 01); maxQuarterDate = new Date(finYear, 11, 31); }
            else if (quarterNo == "Quarter4") { minQuarterDate = new Date(eval(finYear) + 1, 00, 01); maxQuarterDate = new Date(eval(finYear) + 1, 02, 31); }
            if (endrange > maxQuarterDate || endrange < minQuarterDate) {
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                    alert((formType == "0" ? "Paid/Credited " : "Received/Debited ") + " Date should be within\nthe quarter of Financial Year.");
                }
                else {
                    alert((formType == "0" ? "Paid/Credited " : "Received/Debited ") + " Date should be within\nthe quarter of Tax Year.");
                }
                return false;
            } return true;
        }
        function ValidateTaxDedDate(taxDeducted, txtTaxDedDate, hdnFinYear, hdnQuarter) {
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E" ? "1" : "0";
            if (Return(taxDeducted.value) != 0) {
                var taxDedDate = txtTaxDedDate.value;
                var date = taxDedDate.split('/', 3);
                var endrange = new Date(date[2], date[1] - 1, date[0]);
                var now = new Date();
                if (taxDedDate == "") { alert("Specify Tax " + (formType == "0" ? "Deducted" : "Collected") + " Date."); txtTaxDedDate.focus(); return false; }
                else if (endrange > now) { alert("Specified Tax " + (formType == "0" ? "Deducted" : "Collected") + " date should not be greater than current date"); return false; }
                else {
                    var finYear = hdnFinYear.value;
                    var minQuarterDate, maxQuarterDate;
                    var taxDedDateDay = parseInt(taxDedDate.substring(0, 2), 10);
                    var taxDedDateMonth = parseInt(taxDedDate.substring(3, 5), 10);
                    var taxDedDateYear = parseInt(taxDedDate.substring(6, 10), 10);
                    taxDedDate = new Date(taxDedDateYear, taxDedDateMonth - 1, taxDedDateDay);
                    var quarterNo = hdnQuarter.value;
                    if (quarterNo == "Quarter1") { minQuarterDate = new Date(finYear, 03, 01); maxQuarterDate = new Date(finYear, 05, 30); }
                    else if (quarterNo == "Quarter2") { minQuarterDate = new Date(finYear, 06, 01); maxQuarterDate = new Date(finYear, 08, 30); }
                    else if (quarterNo == "Quarter3") { minQuarterDate = new Date(finYear, 09, 01); maxQuarterDate = new Date(finYear, 11, 31); }
                    else if (quarterNo == "Quarter4") { minQuarterDate = new Date(eval(finYear) + 1, 00, 01); maxQuarterDate = new Date(eval(finYear) + 1, 02, 31); }
                    if (taxDedDate < minQuarterDate) {
                        alert("Tax " + (formType == "0" ? "Deducted" : "Collected") + " Date cannot be before Current Quarter.");
                        if (document.getElementById("<%=txtTaxDedDate.ClientID%>") != null)
                            document.getElementById("<%=txtTaxDedDate.ClientID%>").focus();
                        return false;
                    }
                    if (taxDedDate > maxQuarterDate) {
                        alert("Tax " + (formType == "0" ? "Deducted" : "Collected") + " Date cannot be after Current Quarter.");
                        if (document.getElementById("<%=txtTaxDedDate.ClientID%>") != null)
                            document.getElementById("<%=txtTaxDedDate.ClientID%>").focus();
                        return false;
                    }
                    if (taxDedDate > now) {
                        alert("Tax " + (formType == "0" ? "Deducted" : "Collected") + " Date can not be future date.");
                        if (document.getElementById("<%=txtTaxDedDate.ClientID%>") != null)
                            document.getElementById("<%=txtTaxDedDate.ClientID%>").focus();
                        return false;
                    }
                }
            }
            else if (Return(taxDeducted.value) == 0 && document.getElementById("<%=txtTaxDedDate.ClientID%>").value != "") {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert(formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " Amount is zero.\nSo " + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " Date need not be specified.");
                txtTaxDedDate.focus();
                return false;
            } return true;
        }
        function ParameterChanged() { document.getElementById("<%=hdnIsSearchParameterChanged.ClientID %>").value = "1"; }
        function OnParameterChanged() {
            if (document.getElementById("<%=hdnIsSearchParameterChanged.ClientID %>").value == "1") {
                document.getElementById("<%=ddlGoTo.ClientID %>").value = document.getElementById("<%=hdnSelectedPageSize.ClientID %>").value;
                document.getElementById("<%=txtGoToPage.ClientID %>").value = document.getElementById("<%=hdnSelectedPageIndex.ClientID %>").value;
                alert("Search parameters are changed; So,Click on search and continue");
                return false;
            } else { return true; }
        }
        function FormatSearch() {
            var txtSearchAmountFrom = document.getElementById("<%=txtSearchAmountFrom.ClientID%>");
            var txtSearchAmountTo = document.getElementById("<%=txtSearchAmountTo.ClientID%>");
            var txtSearchPaidDateFrom = document.getElementById("<%=txtSearchPaidDateFrom.ClientID%>");
            var txtSearchPaidDateTo = document.getElementById("<%=txtSearchPaidDateTo.ClientID%>");
            var txtSrchTaxDeductedFrom = document.getElementById("<%=txtSrchTaxDeductedFrom.ClientID%>");
            var txtSrchTaxDeductedTo = document.getElementById("<%=txtSrchTaxDeductedTo.ClientID%>");
            var txtSrchTaxDateFrom = document.getElementById("<%=txtSrchTaxDateFrom.ClientID%>");
            var txtSrchTaxDateTo = document.getElementById("<%=txtSrchTaxDateTo.ClientID%>");
            var txtSearchDedSerialNo = document.getElementById("<%=txtSearchDedSerialNo.ClientID%>");
            var txtSearchName = document.getElementById("<%=txtSearchName.ClientID%>");
            if (txtSearchAmountFrom.value.trim() == "" && txtSearchAmountTo.value.trim() == "" && txtSearchPaidDateFrom.value.trim() == "" && txtSearchPaidDateTo.value.trim() == "" && txtSrchTaxDeductedFrom.value.trim() == "" && txtSrchTaxDeductedTo.value.trim() == "" && txtSrchTaxDateFrom.value.trim() == "" && txtSrchTaxDateTo.value.trim() == "" && txtSearchDedSerialNo.value.trim() == "" && txtSearchName.value.trim() == "") {
                var confirmLoad;
                if (confirm("Loading all details will take time.\nRecommend to use search filters.\n\nDo you want to continue?") == true) { return true; } else { return false; }
            }
            else {
                if ((txtSearchAmountFrom.value != "") && (txtSearchAmountTo.value == "")) { txtSearchAmountTo.value = txtSearchAmountFrom.value; }
                else if ((txtSearchAmountFrom.value == "") && (txtSearchAmountTo.value != "")) { txtSearchAmountFrom.value = txtSearchAmountTo.value; }
                else if ((txtSearchAmountFrom.value != "") && (txtSearchAmountTo.value != "")) {
                    if (eval(txtSearchAmountTo.value) < eval(txtSearchAmountFrom.value)) {
                        var temp = txtSearchAmountFrom.value;
                        txtSearchAmountFrom.value = txtSearchAmountTo.value;
                        txtSearchAmountTo.value = temp;
                    }
                }
                if ((txtSrchTaxDeductedFrom.value != "") && (txtSrchTaxDeductedTo.value == "")) { txtSrchTaxDeductedTo.value = txtSrchTaxDeductedFrom.value; }
                else if ((txtSrchTaxDeductedFrom.value == "") && (txtSrchTaxDeductedTo.value != "")) { txtSrchTaxDeductedFrom.value = txtSrchTaxDeductedTo.value; }
                else if ((txtSrchTaxDeductedFrom.value != "") && (txtSrchTaxDeductedTo.value != "")) {
                    if (eval(txtSrchTaxDeductedTo.value) < eval(txtSrchTaxDeductedFrom.value)) {
                        var temp = txtSrchTaxDeductedFrom.value;
                        txtSrchTaxDeductedFrom.value = txtSrchTaxDeductedTo.value;
                        txtSrchTaxDeductedTo.value = temp;
                    }
                }
                if ((txtSearchPaidDateFrom.value.trim() != "") && (txtSearchPaidDateTo.value.trim() == "")) { txtSearchPaidDateTo.value = txtSearchPaidDateFrom.value; }
                else if ((txtSearchPaidDateFrom.value.trim() == "") && (txtSearchPaidDateTo.value.trim() != "")) { txtSearchPaidDateFrom.value = txtSearchPaidDateTo.value; }
                if (!CheckDate(txtSearchPaidDateFrom.value, txtSearchPaidDateTo.value)) {
                    var temp = txtSearchPaidDateTo.value;
                    txtSearchPaidDateTo.value = txtSearchPaidDateFrom.value;
                    txtSearchPaidDateFrom.value = temp;
                }
                if ((txtSrchTaxDateFrom.value.trim() != "") && (txtSrchTaxDateTo.value.trim() == "")) { txtSrchTaxDateTo.value = txtSrchTaxDateFrom.value; }
                else if ((txtSrchTaxDateFrom.value.trim() == "") && (txtSrchTaxDateTo.value.trim() != "")) { txtSrchTaxDateFrom.value = txtSrchTaxDateTo.value; }
                if (!CheckDate(txtSrchTaxDateFrom.value, txtSrchTaxDateTo.value)) {
                    var temp = txtSrchTaxDateTo.value;
                    txtSrchTaxDateTo.value = txtSrchTaxDateFrom.value;
                    txtSrchTaxDateFrom.value = temp;
                }
            }
        }
        function CheckDate(fromDate, toDate) {
            var fromDateDay = parseInt(fromDate.substring(0, 2), 10);
            var fromDateMonth = parseInt(fromDate.substring(3, 5), 10);
            var fromDateYear = parseInt(fromDate.substring(6, 10), 10);
            var toDatedDay = parseInt(toDate.substring(0, 2), 10);
            var toDatedMonth = parseInt(toDate.substring(3, 5), 10);
            var toDatedYear = parseInt(toDate.substring(6, 10), 10);
            var fromDateTocheck = new Date(fromDateYear, fromDateMonth - 1, fromDateDay);
            var toDateCheck = new Date(toDatedYear, toDatedMonth - 1, toDatedDay);
            if (toDateCheck < fromDateTocheck) { return false; } return true;
        }
        function ConfirmDeleteForAutoGenerated() {
            if (confirm("This is Auto-Generated Deduction.\nDeletion will result in mismatch.\nDelete only if necessary.\n\n Do you want to Delete?")) {
                __doPostBack("updatePanelDeduction", "Delete");
            }
            else { return false; }
        }
        function EnableDisablePP() {
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            if (document.getElementById("<%=chkPartPayment.ClientID%>").checked && document.getElementById("<%=hdnTransStatus.ClientID%>").value == "2") {
                if (document.getElementById("<%=ddlQuarter.ClientID%>").selectedIndex > 0) {
                    if (document.getElementById("<%=txtChallanSlNo.ClientID%>").value != "") {
                        var res = confirm("Do you want to clear the Challan details and continue ?");
                        if (res) { __doPostBack('<%=updatePanelDeduction.UniqueID%>', 'DeductionDetail'); }
                        else {
                            document.getElementById("<%=hdnToBeUnlinked.ClientID%>").value = "0";
                            document.getElementById("<%=chkPartPayment.ClientID%>").checked = false;
                        }
                    }
                    else {
                        alert("Since Challan Details is not specified,\nChallan Quarter need not be specified.");
                        document.getElementById("<%=chkPartPayment.ClientID%>").checked = false;
                        return false;
                    }
                }
                else {
                    document.getElementById("<%=hdnToBeUnlinked.ClientID%>").value = "1";
                    if (ValidateForPP()) {
                        document.getElementById("<%=btnPartPayment.ClientID%>").disabled = false;
                        document.getElementById("<%=ddlQuarter.ClientID%>").disabled = true;
                        document.getElementById("<%=txtChallanSlNo.ClientID%>").disabled = true;
                        document.getElementById("<%=txtChallanNo.ClientID%>").disabled = true;
                        document.getElementById("<%=txtChallanDate.ClientID%>").disabled = true;
                        document.getElementById("<%=txtTotalAmount.ClientID%>").disabled = true;
                    }
                    else { document.getElementById("<%=chkPartPayment.ClientID%>").checked = false; }
                }
            }
            else {
                document.getElementById("<%=hdnToBeUnlinked.ClientID%>").value = "0";
                document.getElementById("<%=btnPartPayment.ClientID%>").disabled = true;
                if (document.getElementById("<%=hdnIsUB.ClientID%>").value = "1")
                    document.getElementById("<%=ddlQuarter.ClientID%>").disabled = false;
                else
                    document.getElementById("<%=ddlQuarter.ClientID%>").disabled = true;
                document.getElementById("<%=txtChallanSlNo.ClientID%>").disabled = document.getElementById("<%=ddlQuarter.ClientID%>").selectedIndex > 0 ? false : true;
            }
        }
        function ValidateForPP() {
            if (document.getElementById("<%=hdnLinkID.ClientID%>").value != "-1" && document.getElementById("<%=hdnToBeUnlinked.ClientID%>").value == "1") {
                alert("Save the Deduction detail first & later proceed to Part Payment.");
                return false;
            }
            else { document.getElementById("<%=hdnIsPartPaymentActive.ClientID%>").value = "0"; return true; }
        }
        function ValidatePP() {
            if (eval(Return(document.getElementById("<%=txtPPTotal.ClientID%>").value)) == "") {
                alert("Specify Amount.");
                document.getElementById("<%=txtPPIncomeTax.ClientID%>").focus();
                return false;
            }
            if (!ValidateDropDown(document.getElementById("<%=ddlPPQuarter.ClientID%>"), "Challan Quarter.")) return false;
            if (document.getElementById("<%=txtPPChallanSlNo.ClientID%>").value == "") {
                alert("Specify Challan Sl.No.");
                document.getElementById("<%=txtPPChallanSlNo.ClientID%>").focus();
                return false;
            }
            else return true;
        }
        function GetDetails(challanSlNo) {
            document.getElementById("<%=hdnIsChallanModified.ClientID%>").value = "1";
            if (document.getElementById("<%=hdnIsPartPaymentActive.ClientID%>").value == "1") {
                if (document.getElementById("<%=hdnChallanID.ClientID%>").value == "-1" && document.getElementById("<%=txtPPChallanSlNo.ClientID%>").value != "") {
                    SendRequest(challanSlNo.value);
                }
            }
        }
        function ClearChallanSlNo(screenType) {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) { }
            else {
                if (screenType == 1) {
                    document.getElementById("<%=hdnChallanID.ClientID%>").value = "-1";
                    document.getElementById("<%=txtChallanNo.ClientID%>").value = "";
                    document.getElementById("<%=txtChallanDate.ClientID%>").value = "";
                    document.getElementById("<%=txtTotalAmount.ClientID%>").value = "";
                }
                else {
                    document.getElementById("<%=hdnChallanID.ClientID%>").value = "-1";
                    document.getElementById("<%=txtPPChallanNo.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanDate.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanIncomeTax.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanSurcharge.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanEduCess.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanTotalAmount.ClientID%>").value = "";
                }
            }
        }
        function GetResult(returnValue, context) {
            var isPartPayment = document.getElementById("<%=hdnIsPartPaymentActive.ClientID%>").value == "1";
            if (isPartPayment) {
                if (returnValue.length > 4) {
                    var array = returnValue.split("*");
                    document.getElementById("<%=hdnChallanID.ClientID%>").value = array[0];
                    document.getElementById("<%=txtPPChallanNo.ClientID%>").value = array[1];
                    document.getElementById("<%=txtPPChallanDate.ClientID%>").value = array[2];
                    document.getElementById("<%=txtPPChallanIncomeTax.ClientID%>").value = array[3];
                    document.getElementById("<%=txtPPChallanSurcharge.ClientID%>").value = array[4];
                    document.getElementById("<%=txtPPChallanEduCess.ClientID%>").value = array[5];
                    document.getElementById("<%=txtPPChallanTotalAmount.ClientID%>").value = array[6];
                }
                else {
                    alert("Challan Details doesn't exist for the specified Serial No. under\nthe selected Section and Quarter.");
                    document.getElementById("<%=txtPPChallanSlNo.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanSlNo.ClientID%>").focus();
                    document.getElementById("<%=hdnChallanID.ClientID%>").value = "-1";
                    document.getElementById("<%=txtPPChallanNo.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanDate.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanIncomeTax.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanSurcharge.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanEduCess.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanTotalAmount.ClientID%>").value = "";
                    document.getElementById("<%=hdnChallanSection.ClientID%>").value = "-1";
                }
            }
        }
        function SendRequest(challanSerialNo) { CallServer(challanSerialNo); return false; }
        function DoRoundOff() {
            if (document.getElementById("<%=hdnRoundOff.ClientID%>").value == "HigherRupee") {
                //                if (document.getElementById("<%=chkEdit.ClientID%>").checked == false) {
                document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").value = Math.ceil(eval(Return(document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").value)));
                document.getElementById("<%=txtSurchargeAmount.ClientID%>").value = Math.ceil(eval(Return(document.getElementById("<%=txtSurchargeAmount.ClientID%>").value)));
                document.getElementById("<%=txtEduCessAmount.ClientID%>").value = Math.ceil(eval(Return(document.getElementById("<%=txtEduCessAmount.ClientID%>").value)));
                //                } 
                CalculateValues();
            }
        }

        function DoRoundOff_Sub() {
            if (document.getElementById("<%=hdnRoundOff.ClientID%>").value == "HigherRupee") {
                //                if (document.getElementById("<%=chkEdit.ClientID%>").checked == false) {
                document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").value = Math.ceil(eval(Return(document.getElementById("<%=txtIncomeTaxAmount.ClientID%>").value)));
                document.getElementById("<%=txtSurchargeAmount.ClientID%>").value = Math.ceil(eval(Return(document.getElementById("<%=txtSurchargeAmount.ClientID%>").value)));
                document.getElementById("<%=txtEduCessAmount.ClientID%>").value = Math.ceil(eval(Return(document.getElementById("<%=txtEduCessAmount.ClientID%>").value)));
                //                } 
                CalculateValues_Sub();
            }
        }

        function DisplayRow(row) { row.style.display = ''; }
        function HideRow(row) { row.style.display = 'none'; }
        function SetSection() {
            var cbl = document.getElementById('<%=chkSections.ClientID%>');
            var values = "";
            document.getElementById("<%=txtSection.ClientID%>").value = "";
            var tbody = cbl.childNodes[1];
            var length = (tbody.childNodes.length);
            for (i = 0; i < length; i++) {
                var td = tbody.childNodes[i].childNodes[1];
                var chk = td.childNodes[1].control.checked;
                if (chk) {
                    values = td.innerText + "," + values;
                    document.getElementById("<%=txtSection.ClientID%>").value = values;
                }
            }
        }
        function Resetvalues() {
            if (document.getElementById("<%=hdnDeducteeID.ClientID%>").value == "-1") {
                document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value = "0";
            }
        }
        function GetDetails(challanSlNo) {
            document.getElementById("<%=hdnIsChallanModified.ClientID%>").value = "1";
            if (document.getElementById("<%=hdnIsPartPaymentActive.ClientID%>").value == "0") {
                if (document.getElementById("<%=hdnChallanID.ClientID%>").value == "-1" && document.getElementById("<%=txtChallanSlNo.ClientID%>").value != "") {
                    SendRequest(challanSlNo.value);
                }
            }
            else {
                if (document.getElementById("<%=hdnChallanID.ClientID%>").value == "-1" && document.getElementById("<%=txtPPChallanSlNo.ClientID%>").value != "") {
                    SendRequest(challanSlNo.value);
                }
            }
        }

        function ClearChallanSlNo(screenType) {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) { }
            else {
                if (screenType == 1) {
                    document.getElementById("<%=hdnChallanID.ClientID%>").value = "-1";
                    document.getElementById("<%=txtChallanNo.ClientID%>").value = "";
                    document.getElementById("<%=txtChallanDate.ClientID%>").value = "";
                    document.getElementById("<%=txtTotalAmount.ClientID%>").value = "";
                }
                else {
                    document.getElementById("<%=hdnChallanID.ClientID%>").value = "-1";
                    document.getElementById("<%=txtPPChallanNo.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanDate.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanIncomeTax.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanSurcharge.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanEduCess.ClientID%>").value = "";
                    document.getElementById("<%=txtPPChallanTotalAmount.ClientID%>").value = "";
                }
            }
        }
        function GetChallanSlNoValue(source, eventArgs) {
            var content = eventArgs.get_value();
            var contents = new Array();
            contents = content.split(';');
            if (document.getElementById("<%=hdnIsPartPaymentActive.ClientID%>").value == "0") {
                document.getElementById("<%=hdnChallanID.ClientID%>").value = contents[0];
                document.getElementById("<%=txtChallanNo.ClientID%>").value = contents[1];
                document.getElementById("<%=txtChallanDate.ClientID%>").value = contents[2];
                document.getElementById("<%=txtTotalAmount.ClientID%>").value = contents[6];
                document.getElementById("<%=hdnChallanSection.ClientID%>").value = contents[9];
            }
            else {
                document.getElementById("<%=hdnChallanID.ClientID%>").value = contents[0];
                document.getElementById("<%=txtPPChallanNo.ClientID%>").value = contents[1];
                document.getElementById("<%=txtPPChallanDate.ClientID%>").value = contents[2];
                document.getElementById("<%=txtPPChallanIncomeTax.ClientID%>").value = contents[3];
                document.getElementById("<%=txtPPChallanSurcharge.ClientID%>").value = contents[4];
                document.getElementById("<%=txtPPChallanEduCess.ClientID%>").value = contents[5];
                document.getElementById("<%=txtPPChallanTotalAmount.ClientID%>").value = contents[6];
                document.getElementById("<%=hdnChallanSection.ClientID%>").value = contents[9];
            }
        }

        function Disable27EQMoreDetails() {
            tr27EQMoreDetails = document.getElementById("<%=tr27EQMoreDetails.ClientID%>");
            if (tr27EQMoreDetails != null)
                tr27EQMoreDetails.style.display = 'none';
        }

        function SetNonDedReason(theDropDown) {
            var toolTipObj = new Object();
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            var txtCertNo = document.getElementById("<%=txtCertNo.ClientID%>");
            toolTipObj = document.getElementById("tooltip");
            if (theDropDown == null)
                theDropDown = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
            if (theDropDown != null) {
                toolTipObj.innerHTML = theDropDown.options[theDropDown.selectedIndex].value != "0" ? theDropDown.options[theDropDown.selectedIndex].text : "";
                if (txtCertNo != null) {
                    var value = theDropDown.value;
                    if (formType == "Form24" || formType == "Form27") {
                        if (Return(value) == 1 || Return(value) == 2) txtCertNo.style.backgroundColor = "#E5E5E5";
                        else txtCertNo.style.backgroundColor = "White";
                    }
                    else {
                        if (Return(value) == 1 || Return(value) == 65) {
                            txtCertNo.style.backgroundColor = "#E5E5E5";
                            HideRow(document.getElementById("<%=tdGetUIN.ClientID%>"));
                            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "U/s 197 Cert. No.";
                            }
                            else {
                                document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "U/s 395 Cert. No.";
                            }
                        }
                        else {
                            if (Return(value) == 2 || Return(value) == 66) {
                                if ((Return(document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0) > 2 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2015) || Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2015) {
                                    if (document.getElementById("<%=hdnIsChecker.ClientID%>").value != "1" && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026)
                                        DisplayRow(document.getElementById("<%=tdGetUIN.ClientID%>"));
                                    else
                                        HideRow(document.getElementById("<%=tdGetUIN.ClientID%>"));
                                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026)
                                        document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "15G/15H UIN";
                                    else
                                        document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "121 UIN";
                                }
                            }
                            else {
                                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                    document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "U/s 197 Cert. No.";
                                }
                                else { document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "U/s 395 Cert. No."; }
                                HideRow(document.getElementById("<%=tdGetUIN.ClientID%>"));
                            } txtCertNo.style.backgroundColor = "White";
                        }
                        tr27EQMoreDetails = document.getElementById("<%=tr27EQMoreDetails.ClientID%>");
                        if (theDropDown.value == 13 || theDropDown.value == 14 || theDropDown.value == 70) {
                            if (tr27EQMoreDetails != null) {
                                tr27EQMoreDetails.style.display = '';
                                ddl27EQLiableOption = document.getElementById("<%=ddl27EQLiableOption.ClientID%>");
                            }
                        }
                        else {
                            if (tr27EQMoreDetails != null)
                                tr27EQMoreDetails.style.display = 'none';
                        }
                    } if (value == 0) txtCertNo.value = "";
                }
            }
        }
        function DisplayControls() {
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            var pnlDetailsHead = document.getElementById("<%=pnlDetailsHead.ClientID%>");
            var pnlMoreDetails = document.getElementById("<%=pnlMoreDetails.ClientID%>");
            var rowCertNo = document.getElementById("<%=rowCertNo.ClientID%>");
            if (rowCertNo != null) rowCertNo.style.display = Return(finYear) > 2012 ? '' : 'none';
            if (Return(finYear) > 2012 && formType == "Form27") {
                if (pnlDetailsHead != null) pnlDetailsHead.style.display = '';
                if (pnlMoreDetails != null) pnlMoreDetails.style.display = '';
            }
            else {
                if (pnlDetailsHead != null) pnlDetailsHead.style.display = 'none';
                if (pnlMoreDetails != null) pnlMoreDetails.style.display = 'none';
            }
        }
        <%--function ValidateIfPANNotAvailableSB(isSB, hdnIsValidPAN, hdnFormType, txtTaxDeductedRate, ddlNonDeductionReason, txtTaxDeducted, txtITRate, txtIncomeTaxAmount) {
            if (hdnIsValidPAN.value != "1") {
                if (hdnFormType.value != "Form24" && hdnFormType.value != "Form27E") {
                    if (Return(txtTaxDeductedRate.value) < 20) {
                        if (!isSB || (isSB && hdnFormType.value == "Form27")) {
                            var res = confirm('Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 20%.\nDo you want to continue?');
                            if (res) {
                                if (ddlNonDeductionReason.value == "3") {
                                    if (Return(txtTaxDeducted.value) == 0) {
                                        var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                        alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " can't be Nil.'");
                                        txtITRate.focus();
                                        return false;
                                    }
                                }
                            }
                            else { return false; }
                        }
                        else { alert("Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 20%"); return false; }
                    }
                    else {
                        if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("Since Tax Dedcuted Amount is zero,\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " Rate should also be zero.");
                            txtITRate.focus();
                            return false;
                        }
                    }
                }
                else if (hdnFormType.value == "Form27E") {
                    if (Return(txtTaxDeductedRate.value) < 5) {
                        alert("Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 5%");
                        return false;
                    }
                }
                else {
                    if (ddlNonDeductionReason.value == "3") {
                        if (hdnFormType.value == "Form24") {
                            if (Return(txtTaxDeducted.value) == 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " can't be Nil.'");
                                txtIncomeTaxAmount.focus();
                                return false;
                            }
                        } else {
                            if (Return(txtTaxDeducted.value) == 0 &&
                                Return(txtTaxDeductedRate.value) == 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " can't be Nil.'");
                                if (hdnFormType.value != "Form24") {
                                    txtITRate.focus();
                                    return false;
                                }
                            } else if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " can't be Nil.'");
                                txtITRate.focus();
                                return false;
                            } else if (Return(txtTaxDeducted.value) != 0 && Return(txtTaxDeductedRate.value) == 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("For 'PAN Not available - Higher Rate (20%)',\n" + formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected" + " Rate can't be Nil.'");
                                txtITRate.focus();
                                return false;
                            }
                        }
                    } return true;
                }
            } return true;
        }--%>
        function ValidateLoadAll() { return confirm("Loading all details will take time.\nRecommend to use search filters.\n\nDo you want to continue?"); }
        function checkRate(obj, option) {
            if (Return(document.getElementById("<%=hdnIsSB.ClientID%>").value) == "1") {
                if (option == "1") {
                    if (Return(document.getElementById("<%=txtSurchargeRate.ClientID%>").value) > 12) { return false; }
                    return true;
                }
                if (option == "2") {
                    if (Return(document.getElementById("<%=txtEduCessRate.ClientID%>").value) > 4) { return false; }
                    return true;
                }
            }
        }
        function checkValidEmail(object) {
            if (object.value.trim() != "") {
                if (!ValidateEmail(object)) { document.getElementById("<%=txtEmailDed.ClientID%>").value = ""; return false; }
            }
        }
        function checkValidContactNo(inputtxt) {
            var numbers = /^[0-9]+$/;
            if (inputtxt.value.trim() != "") {
                if (!inputtxt.value.match(numbers)) {
                    alert('Please input valid Contact Number.');
                    document.getElementById("<%=txtContactNoDed.ClientID%>").value = "";
                    return false;
                }
                else { return true; }
            }
        }
        function checkValidDedAddress(inputtxt) {
            if (inputtxt.value != "") {
                if (!InputValidationsForAddress(inputtxt)) {
                    document.getElementById("<%=txtAddressDed.ClientID%>").value = "";
                    return false;
                }
            }
        }
        function InputValidationsForIdentNum(objName) {
            var alphaExp = /[a-zA-Z0-9]/;
            var specialcharsExp = /[`~!@#$%^&*()_+,.?;:[{]}|\/]/;
            var zeros = /[0]+$/;
            if (objName.value != "") {
                if (!objName.value.match(alphaExp)) {
                    if (!objName.value.match(specialcharsExp)) {
                        alert("Only Zeros, Special Characters or blank spaces are not allowed");
                        document.getElementById("<%=txtIdentNumDed.ClientID%>").value = "";
                        return false;
                    } else { return true; }
                } else if (objName.value.match(zeros)) {
                    alert("Only Zeros, Special Characters or blank spaces are not allowed");
                    document.getElementById("<%=txtIdentNumDed.ClientID%>").value = "";
                    return false;
                } else { return true; }
            }
        }

        function ValidateNonDedReasonfor194N(ddlNonDeductionReason, txtTaxDeducted) {
            if (document.getElementById("<%=hdnFinYear.ClientID%>") < 2026) {
                if (ddlNonDeductionReason.value == "9" && Return(txtTaxDeducted.value) != 0) {
                    var res = confirm('For remark No deduction on account of Section 194N clause (iii) or (iv) or (v),\n\nDeduction amount is given.\n\nDo you want to continue?');
                    if (res) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
            }
            else {
                if (ddlNonDeductionReason.value == "78" && Return(txtTaxDeducted.value) != 0) {
                    var res = confirm('For remark No deduction on account of Section 393(4)-18 or fifth provisio to 194N,\n\nDeduction amount is given.\n\nDo you want to continue?');
                    if (res) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
            }
            return true;
        }
        function ValidateNonDedReasonfor194NF(ddlNonDeductionReason, txtTaxDeducted) {
            if (ddlNonDeductionReason.value == "22" && Return(txtTaxDeducted.value) != 0) {
                var res = confirm('For remark No deduction/lower deduction, notification issued under 2nd proviso to 194N,\n\nDeduction amount is given.\n\nDo you want to continue?');
                if (res) {
                    return true;
                }
                else {
                    return false;
                }
            }
            return true;
        }
        function Validate194NSectionBasedOnDate() {
            var date = new Date(2019, 09, 01);
            var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            var date1 = paymentDate.value;
            if (date1.toString().indexOf("-") != -1) {
                date1 = date1.split('-', 3);
            }
            else {
                date1 = date1.split('/', 3);
            }
            var creditedDate = new Date(date1[2], date1[1], date1[0]);
            if (creditedDate < date) {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert("Section '194N' is Applicable from '01/09/2019'.\nSpecify the correct date in " + formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited" + " Date");
                return false;
            }
            return true;
        }
        function ShowDate() {
            var rowDate = document.getElementById("<%=rowCreatedOn.ClientID%>");
            if (document.getElementById("<%=hdnIsSuperAdmin.ClientID%>").value == "1")
                rowDate.style.display = '';
            else
                rowDate.style.display = 'none';
        }

        function CheckPANValue() {
            if (document.getElementById("<%=ddlSearchPAN.ClientID%>").value == 1) {
                document.getElementById("<%=txtPANRefNo.ClientID%>").disabled = false;
                document.getElementById("<%=txtPANRefNo.ClientID%>").focus();
            }
            else {
                document.getElementById("<%=txtPANRefNo.ClientID%>").value = "";
                document.getElementById("<%=txtPANRefNo.ClientID%>").disabled = true;
            }
        }

    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="updatePanelDeduction" runat="server" OnLoad="updatePanelDeduction_Load"
        UpdateMode="Conditional">
        <ContentTemplate>
            <asp:HiddenField ID="hdnFinYear" runat="server" Value="" />
            <asp:HiddenField ID="hdnFormType" runat="server" Value="" />
            <asp:HiddenField ID="hdnQuarter" runat="server" Value="" />
            <asp:HiddenField ID="hdnDeducteeID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnDeducteeName" runat="server" Value="" />
            <asp:HiddenField ID="hdnDeducteePAN" runat="server" Value="" />
            <asp:HiddenField ID="hdnDeductionID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnChallanID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnSearch" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsValidPAN" runat="server" Value="1" />
            <asp:HiddenField ID="hdnIsTran" runat="server" Value="" />
            <asp:HiddenField ID="hdnIsChallanModified" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsEReturnGenerated" Value="N" runat="server" />
            <asp:HiddenField ID="hdnAllow92A92B" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsPartPaymentActive" runat="server" Value="0" />
            <asp:HiddenField ID="hdnSectionID" runat="server" Value="" />
            <asp:HiddenField ID="hdnSelectedPageIndex" runat="server" Value="1" />
            <asp:HiddenField ID="hdnSelectedPageSize" runat="server" Value="10" />
            <asp:HiddenField ID="hdnPartPaymentID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnLinkID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnIsInvolvedInPP" runat="server" Value="0" />
            <asp:HiddenField ID="hdnRoundOff" runat="server" Value="1" />
            <asp:HiddenField ID="hdnDeductorStatus" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsQuarterLocked" runat="server" Value="0" />
            <asp:HiddenField ID="hdnSetColor" runat="server" Value="White" />
            <asp:HiddenField ID="hdnToBeUnlinked" runat="server" Value="0" />
            <asp:HiddenField ID="hdnTaxDeducted" runat="server" Value="0" />
            <asp:HiddenField ID="hdnPaymentMade" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIT" runat="server" Value="0" />
            <asp:HiddenField ID="hdnSur" runat="server" Value="White" />
            <asp:HiddenField ID="hdnEduCess" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsChecker" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsSearchParameterChanged" runat="server" Value="0" />
            <asp:HiddenField ID="hdnTimeStamp" runat="server" Value="" />
            <asp:HiddenField ID="hdnTransStatus" runat="server" Value="" />
            <asp:HiddenField ID="hdnDeducteeCode" runat="server" Value="" />
            <asp:HiddenField ID="hdnChallanDeducteeCode" runat="server" Value="" />
            <asp:HiddenField ID="hdnTDSRate" runat="server" Value="" />
            <asp:HiddenField ID="hdnITRate" runat="server" Value="" />
            <asp:HiddenField ID="hdnSectionIDs" runat="server" Value="" />
            <asp:HiddenField ID="hdnIsJK" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsUB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsSB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsCBI" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsSuperAdmin" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsTaxRateChanged" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsValid" runat="server" Value="0" />
            <asp:HiddenField ID="hdnITPercentage" runat="server" Value="0" />
            <asp:HiddenField ID="hdnAvlChallanAmt" runat="server" Value="0" />
            <asp:HiddenField ID="hdnChallanSection" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnEmployeeName" runat="server" Value="" />
            <asp:MultiView ID="mvDeductionDetail" runat="server" ActiveViewIndex="0">
                <asp:View ID="viewDeduction" runat="server">
                    <cc1:CollapsiblePanelExtender ID="pnlChallanCollapsible" runat="server" CollapseControlID="pnlChallanHeader"
                        CollapsedText="Show" CollapsedImage="~/App_Themes/Standard/Images/collapse.png"
                        ImageControlID="imgToggle" Collapsed="false" ExpandControlID="pnlChallanHeader"
                        ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlChallan" ExpandedImage="~/App_Themes/Standard/Images/expand.png">
                    </cc1:CollapsiblePanelExtender>
                    <cc1:CollapsiblePanelExtender ID="pnlDetailsCollapsible" runat="server" CollapseControlID="pnlDetailsHead"
                        CollapsedText="Show" CollapsedImage="~/App_Themes/Standard/Images/collapse.png"
                        ImageControlID="ImgToggleDetails" Collapsed="false" ExpandControlID="pnlDetailsHead"
                        ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlMoreDetails"
                        ExpandedImage="~/App_Themes/Standard/Images/expand.png">
                    </cc1:CollapsiblePanelExtender>
                    <cc1:CollapsiblePanelExtender ID="pnl27EQDetailsCollapsible" runat="server" CollapseControlID="pnl27EQMoreDetailsHeader"
                        CollapsedText="Show" CollapsedImage="~/App_Themes/Standard/Images/collapse.png"
                        ImageControlID="img27EQMoreDetailsToggle" Collapsed="false" ExpandControlID="pnl27EQMoreDetailsHeader"
                        ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnl27EQMoreDetails"
                        ExpandedImage="~/App_Themes/Standard/Images/expand.png">
                    </cc1:CollapsiblePanelExtender>
                    <asp:Panel ID="pnlControls" runat="server">
                        <table class="ntblPer">
                            <tr>
                                <td valign="top" class="auto-style1">
                                    <table class="nTbl">
                                        <tr>
                                            <td valign="top" style="margin-left: 0px; width: 52%" class="style9">
                                                <table class="eCol" cellpadding="0" style="width: 100%">
                                                    <tr>
                                                        <td class="vHColPer" style="width: 27%">Serial No.
                                                        </td>
                                                        <td>
                                                            <asp:TextBox ID="txtSerialNo" runat="server" ReadOnly="true" Style="background-color: #d5dadd; color: Black; width: 86%"
                                                                CssClass="txtBPL"> </asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="vHColPer">
                                                            <asp:Label ID="lblName" runat="server" Text="Name"></asp:Label>
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:TextBox ID="txtName" Width="86%" runat="server" onkeyup="ClearDeducteeName()"
                                                                CssClass="txtBML" TabIndex="1" onkeypress="return ValidateDelimiter(this,event);"></asp:TextBox>
                                                            <cc1:AutoCompleteExtender ID="autoCompleteExtender" runat="server" MinimumPrefixLength="2"
                                                                ServicePath="~/WebServices/AutoCompleteService.asmx" TargetControlID="txtName"
                                                                CompletionInterval="700" EnableCaching="false" CompletionSetCount="50" DelimiterCharacters=""
                                                                ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="True" OnClientItemSelected="GetDeducteeNameValue">
                                                            </cc1:AutoCompleteExtender>
                                                        </td>
                                                    </tr>
                                                    <tr runat="server" id="rowSection">
                                                        <td class="vHColPer">Section
                                                        </td>
                                                        <td style="width: 100%">
                                                            <asp:DropDownList ID="ddlSection" runat="server" AutoPostBack="true" CssClass="mCBs"
                                                                OnSelectedIndexChanged="ddlSection_SelectedIndexChanged" Width="314px" TabIndex="2"
                                                                Font-Size="9">
                                                            </asp:DropDownList>
                                                            <asp:Button ID="btnSectionHelp" runat="server" Text="?" OnClientClick="ShowSectionHelp();return false;"
                                                                CssClass="cmnBtn" Height="20px" Width="20px" />
                                                        </td>
                                                    </tr>
                                                    <tr id="trAmtCashDrawn" runat="server" visible="false">
                                                        <td class="vHColPer">Amount of Cash Withdrawal
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:TextBox ID="txtAmtCashDrawn" runat="server" MaxLength="14" AutoComplete="Off"
                                                                Width="86%" onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                                onkeyup="CalculateValues()" onBlur="ClearAOP(this);" TabIndex="3" CssClass="txtBMR"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="vHColPer" id="tdAmtPay" runat="server">Amount of Payment
                                                        </td>
                                                        <td class="vHColPer" id="tdAggAmtPay" runat="server" visible="false">Aggregate Amount of Payment
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:TextBox ID="txtAmountOfPayment" runat="server" MaxLength="14" AutoComplete="Off" Width="86%"
                                                                onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                                onkeyup="CalculateValues()" onBlur="ClearAOP(this);" TabIndex="3" CssClass="txtBMR"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr runat="server" id="rowForm27EDeductedDate">
                                                        <td class="vHColPer">Total Value of Pur.(s)
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:TextBox ID="txtTotalValueOfPurchase" runat="server" MaxLength="14" AutoComplete="Off" Width="86%"
                                                                onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                                onkeyup="CalculateValues()" onBlur="ClearAOP(this);" TabIndex="3" CssClass="txtBMR"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="vHColPer">
                                                            <asp:Label ID="lblpaidDate" runat="server" Text="Paid/Credited Date"></asp:Label>
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:TextBox ID="txtCreditedDate" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                                                runat="server" Width="86%" BackColor="#E5E5E5" AutoComplete="Off" CssClass="txtBPR"
                                                                TabIndex="4" onBlur="setDateFormat(this);SetDate();CallServerSideReducedRate()"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="vHColPer">
                                                            <asp:Label ID="lblIncomeTaxPercAndAmnt" runat="server" Text="Income Tax(% and Amt)"> </asp:Label>
                                                        </td>
                                                        <td style="width: 100%">
                                                            <table width="95%" cellpadding="0" cellspacing="0" border="0">
                                                                <tr style="width: 95%">
                                                                    <td style="width: 13%">
                                                                        <asp:TextBox ID="txtITRate" Style="border: 1px solid #9f9f9f; width: 82%; text-align: right"
                                                                            AutoComplete="Off" runat="server" MaxLength="14" onchange="return checkDecimalNo(this);"
                                                                            onkeypress="return numeralsOnly(this, event,2,3,0,1);" onkeyup="CalculateValues_Sub()"
                                                                            TabIndex="5" CssClass="txtBPL"></asp:TextBox>
                                                                    </td>
                                                                    <td align="left" style="width: 70%">
                                                                        <asp:TextBox ID="txtIncomeTaxAmount" Style="border: 1px solid #9f9f9f; width: 87%; text-align: right"
                                                                            AutoComplete="Off" runat="server" MaxLength="14" Enabled="false"
                                                                            onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                                            onkeyup="CalculateValues_Sub();" onBlur="DoRoundOff_Sub();SetDate();" TabIndex="6"
                                                                            CssClass="txtBPL"></asp:TextBox>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="vHColPer">Surcharge (% and Amt)
                                                        </td>
                                                        <td style="width: 100%">
                                                            <table width="95%" cellpadding="0" cellspacing="0" style="padding: 0px">
                                                                <tr style="width: 95%">
                                                                    <td style="width: 13%">
                                                                        <asp:TextBox ID="txtSurchargeRate" runat="server" Style="border: 1px solid #9f9f9f; width: 82%; text-align: right"
                                                                            AutoComplete="Off" TabIndex="7" MaxLength="14"
                                                                            onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,2,3,0,1);"
                                                                            onkeyup="CalculateValues_Sub()" onBlur="DoRoundOff_Sub();" Enabled="true" CssClass="txtBPL"></asp:TextBox>
                                                                    </td>
                                                                    <td align="left" style="width: 70%">
                                                                        <asp:TextBox ID="txtSurchargeAmount" runat="server" Style="border: 1px solid #9f9f9f; width: 87%; text-align: right"
                                                                            AutoComplete="Off" TabIndex="8" MaxLength="14"
                                                                            Enabled="false" onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                                            onkeyup="CalculateValues_Sub()" CssClass="txtBPL"></asp:TextBox>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="vHColPer">Edu Cess (% and Amt)
                                                        </td>
                                                        <td style="width: 100%">
                                                            <table width="95%" cellpadding="0" cellspacing="0">
                                                                <tr style="width: 95%">
                                                                    <td style="width: 13%">
                                                                        <asp:TextBox ID="txtEduCessRate" runat="server" Style="border: 1px solid #9f9f9f; width: 82%; text-align: right"
                                                                            AutoComplete="Off" MaxLength="14" onchange="return checkDecimalNo(this);"
                                                                            onkeypress="return numeralsOnly(this, event,2,3,0,1);" onkeyup="CalculateValues_Sub()"
                                                                            onBlur="DoRoundOff_Sub();" TabIndex="9" CssClass="txtBPL"></asp:TextBox>
                                                                    </td>
                                                                    <td align="left" style="width: 70%">
                                                                        <asp:TextBox ID="txtEduCessAmount" runat="server" Style="border: 1px solid #9f9f9f; width: 87%; text-align: right"
                                                                            AutoComplete="Off" TabIndex="10" MaxLength="14"
                                                                            onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                                            onkeyup="CalculateValues_Sub()" Enabled="false" CssClass="txtBPL"></asp:TextBox>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <table cellpadding="0" cellspacing="0">
                                                                <tr>
                                                                    <td valign="top">
                                                                        <asp:Label ID="lblTaxDeducted" runat="server" Text="Tax Deducted"></asp:Label>
                                                                    </td>
                                                                    <td>
                                                                        <asp:CheckBox ID="chkEdit" Text="Edit" runat="server" TabIndex="11" />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                        <td style="width: 100%">
                                                            <table width="95%" cellpadding="0" cellspacing="0">
                                                                <tr style="width: 95%">
                                                                    <td style="width: 13%">
                                                                        <asp:TextBox ID="txtTaxDeductedRate" runat="server" MaxLength="14" CssClass="txtboxRO"
                                                                            AutoComplete="Off" Style="width: 50px;" Enabled="false"></asp:TextBox>
                                                                    </td>
                                                                    <td align="left" style="width: 70%">
                                                                        <asp:TextBox ID="txtTaxDeducted" runat="server" AutoComplete="Off" CssClass="txtboxRO"
                                                                            Style="width: 87%; text-align: right" MaxLength="14" Enabled="false"> </asp:TextBox>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr id="rowCreatedOn" runat="server">
                                                        <td class="style9" style="width: 299px" colspan="2">
                                                            <table class="vHCol" cellpadding="0" cellspacing="0" style="width: 299px">
                                                                <tr>
                                                                    <td valign="top">
                                                                        <asp:Label ID="Label12" runat="server" Text="Created On : "></asp:Label>
                                                                        <asp:Label ID="lblCreatedOn" runat="server" Text="" Font-Bold="true" />
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td valign="top">
                                                                        <asp:Label ID="lblDateofApp" runat="server" Text=" Date of Approval :"></asp:Label>
                                                                        <asp:Label ID="lblDateOfApproval" runat="server" Text="" Font-Bold="true" />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td class="eCol" valign="top">
                                                <table>
                                                    <tr>
                                                        <td class="auto-style2" style="width: 21%;">
                                                            <asp:Label ID="lblDeductedDate" Text="Tax Deducted Date" runat="server"></asp:Label>
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:TextBox ID="txtTaxDedDate" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                                                runat="server" BackColor="#E5E5E5" onBlur="setDateFormat(this);" CssClass="txtBPR"
                                                                TabIndex="12" AutoComplete="Off"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr runat="server" id="rowForm27ECertDate">
                                                        <td class="auto-style2">
                                                            <asp:Label ID="lblCertDate" Text="TCS Cert. Date" runat="server"></asp:Label>
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:TextBox ID="txtCertDate" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                                                runat="server" BackColor="White" onBlur="setDateFormat(this);" CssClass="txtBPR"
                                                                TabIndex="12" AutoComplete="Off"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:Label ID="lblReferenceNo" runat="server"></asp:Label>
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:CheckBox ID="chkBookEntry" runat="server" Text="Book Entry" TabIndex="13" />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="auto-style2">
                                                            <asp:Label ID="lblNonDedReason" runat="server" Text="Remarks for Deduction"></asp:Label>
                                                        </td>
                                                        <td>
                                                            <asp:DropDownList ID="ddlNonDeductionReason" runat="server" Width="100%" Font-Size="9"
                                                                OnChange="SetNonDedReason(this); CalculateValues();" TabIndex="16" CssClass="dropDownList">
                                                            </asp:DropDownList>
                                                            <div id="tooltip" style="font-size: 10px; font-family: Verdana">
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr runat="server" id="tdGetUIN" style="display: none">
                                                        <td class="auto-style2">
                                                            <asp:LinkButton ID="lnkGetUIN" runat="server" Text="Get UIN" Font-Bold="true" OnClick="lnkGetUIN_Click"></asp:LinkButton>
                                                        </td>
                                                        <td></td>
                                                    </tr>
                                                    <tr runat="server" id="rowCertNo">
                                                        <td class="auto-style2">
                                                            <asp:Label ID="lblCertNo" runat="server" Text="U/s 197 Cert. No."></asp:Label>
                                                        </td>
                                                        <td class="iColPer">
                                                            <asp:TextBox ID="txtCertNo" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="20"
                                                                onBlur="ConvertToUC(this);" onkeypress="return ValidateForAlphaNumeric(event);">
                                                            </asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="auto-style2">
                                                            <asp:Label ID="lblGrossingUpIndicator" runat="server" Text="Grossing up Indicator"
                                                                Visible="false"></asp:Label>
                                                        </td>
                                                        <td>
                                                            <asp:DropDownList ID="ddlGrossingUpIndicator" runat="server" Width="200" TabIndex="17"
                                                                Visible="false" CssClass="dropDownList">
                                                                <asp:ListItem Text="Yes" Value="True"> </asp:ListItem>
                                                                <asp:ListItem Text="No" Value="False"></asp:ListItem>
                                                            </asp:DropDownList>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2" width="100%">
                                                            <asp:Panel ID="PnlResidentDetails" runat="server" CssClass="dialog" Style="border-top-width: 0px"
                                                                Visible="false">
                                                                <div style="padding: 10px; border-top: solid 1px gray" id="Div1" runat="server">
                                                                    <table>
                                                                        <tr>
                                                                            <td class="vHCol" width="355px">Deductee is Non-Resident
                                                                            </td>
                                                                            <td class="iCol" style="padding-left: 5px">
                                                                                <asp:DropDownList ID="ddlDedNonRes" runat="server" CssClass="mdropDownList" Width="100px"
                                                                                    OnSelectedIndexChanged="ddlDedNonRes_SelectedIndexChanged" AutoPostBack="true">
                                                                                    <asp:ListItem Text="Select" Value=""></asp:ListItem>
                                                                                    <asp:ListItem Text="Yes" Value="Y"></asp:ListItem>
                                                                                    <asp:ListItem Text="No" Value="N"></asp:ListItem>
                                                                                </asp:DropDownList>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td width="355px">Deductee is having Permanent Establishment in India
                                                                            </td>
                                                                            <td class="iCol" style="padding-left: 5px">
                                                                                <asp:DropDownList ID="ddlDedPerEstaIndia" runat="server" CssClass="dropDownList"
                                                                                    Width="100px">
                                                                                    <asp:ListItem Text="Select" Value=""></asp:ListItem>
                                                                                    <asp:ListItem Text="Yes" Value="Y"></asp:ListItem>
                                                                                    <asp:ListItem Text="No" Value="N"></asp:ListItem>
                                                                                </asp:DropDownList>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2" width="100%">
                                                            <asp:Panel runat="server" CssClass="dHeader" ID="pnlDetailsHead" Style="cursor: hand">
                                                                More Details / Country Details
                                                                <asp:Image ID="ImgToggleDetails" runat="server" Style="margin-left: 228px; cursor: hand" />
                                                            </asp:Panel>
                                                            <asp:Panel ID="pnlMoreDetails" runat="server" CssClass="dialog" Style="border-top-width: 0px">
                                                                <div style="padding: 10px; border-top: solid 1px gray" id="Div2" runat="server">
                                                                    <table>
                                                                        <tr>
                                                                            <td>TDS Rate as per
                                                                            </td>
                                                                            <td class="iCol">
                                                                                <asp:DropDownList ID="ddlRateType" runat="server" TabIndex="16" CssClass="dropDownList"
                                                                                    Width="200px">
                                                                                    <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                                                                    <asp:ListItem Text="IT Act" Value="A"></asp:ListItem>
                                                                                    <asp:ListItem Text="DTAA" Value="B"></asp:ListItem>
                                                                                </asp:DropDownList>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td width="130px">15CA Ack. No.
                                                                            </td>
                                                                            <td class="iCol">
                                                                                <asp:TextBox ID="txtAckNo" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="12"
                                                                                    onBlur="ConvertToUC(this);" onkeypress="return ValidateForAlphaNumeric(event);">
                                                                                </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Nature of Remittance
                                                                            </td>
                                                                            <td class="iCol">
                                                                                <asp:DropDownList ID="ddlNatureofRemittance" runat="server" TabIndex="16" CssClass="mdropDownList"
                                                                                    Width="200px">
                                                                                </asp:DropDownList>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Country Remitted to
                                                                            </td>
                                                                            <td class="iCol">
                                                                                <asp:DropDownList ID="ddlCountries" runat="server" TabIndex="16" CssClass="mdropDownList"
                                                                                    Width="200px">
                                                                                </asp:DropDownList>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Deductee Email
                                                                            </td>
                                                                            <td class="iCol">
                                                                                <asp:TextBox ID="txtEmailDed" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="75"
                                                                                    onchange="return checkValidEmail(this);">
                                                                                </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Deductee Contact No.
                                                                            </td>
                                                                            <td class="iCol">
                                                                                <asp:TextBox ID="txtContactNoDed" runat="server" TabIndex="16" CssClass="txtBPL"
                                                                                    MaxLength="15" onchange="return checkValidContactNo(this);">
                                                                                </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Deductee Address
                                                                            </td>
                                                                            <td class="iCol">
                                                                                <asp:TextBox ID="txtAddressDed" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="150"
                                                                                    onchange="return checkValidDedAddress(this);">
                                                                                </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Deductee Identification No.
                                                                            </td>
                                                                            <td class="iCol">
                                                                                <asp:TextBox ID="txtIdentNumDed" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="25"
                                                                                    onchange="return InputValidationsForIdentNum(this);">
                                                                                </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr runat="server" id="tr27EQMoreDetails">
                                                        <td colspan="2" width="100%">
                                                            <asp:Panel ID="pnl27EQMoreDetailsHeader" runat="server" CssClass="dHeader" Style="cursor: hand">
                                                                More Details
                                                                <asp:Image ID="img27EQMoreDetailsToggle" runat="server" Style="margin-left: 215px; cursor: hand" />
                                                            </asp:Panel>
                                                            <asp:Panel ID="pnl27EQMoreDetails" runat="server" CssClass="dialog" Style="border-top-width: 0px">
                                                                <div style="padding: 10px; border-top: solid 1px gray" id="div27EQMoreDetails" runat="server">
                                                                    <table>
                                                                        <tr>
                                                                            <td width="300px">Is Payment by Collectee liable to TDS ?
                                                                            </td>
                                                                            <td width="80px">
                                                                                <asp:DropDownList ID="ddl27EQLiableOption" runat="server" CssClass="dropDownList"
                                                                                    Width="80px">
                                                                                    <asp:ListItem Text="Yes" Value="1"></asp:ListItem>
                                                                                    <asp:ListItem Text="No" Value="0"></asp:ListItem>
                                                                                </asp:DropDownList>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                    <table>
                                                                        <tr>
                                                                            <td width="80px">Challan No.
                                                                            </td>
                                                                            <td width="110px">
                                                                                <asp:TextBox ID="txt27EQChallanNo" runat="server" CssClass="txtBPR" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                                                    MaxLength="5" Style="width: 92px; text-align: right"> 
                                                                                </asp:TextBox>
                                                                            </td>
                                                                            <td width="65px">Paid Date
                                                                            </td>
                                                                            <td>
                                                                                <asp:TextBox ID="txt27EQPaidDate" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                                                                    runat="server" Width="110px" AutoComplete="Off" CssClass="txtBPR" onBlur="setDateFormat(this);"></asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="2" width="100%">
                                                            <asp:Panel ID="pnlChallanHeader" runat="server" CssClass="dHeader" Style="cursor: hand">
                                                                Challan&nbsp;Details
                                                                <asp:Image ID="imgToggle" runat="server" Style="margin-left: 215px; cursor: hand" />
                                                            </asp:Panel>
                                                            <asp:Panel ID="pnlChallan" runat="server" CssClass="dialog" Style="border-top-width: 0px">
                                                                <div style="padding: 10px; border-top: solid 1px gray" id="challanDiv" runat="server">
                                                                    <table>
                                                                        <tr>
                                                                            <td>Part Payment
                                                                            </td>
                                                                            <td style="padding-left: 27px">
                                                                                <table>
                                                                                    <tr>
                                                                                        <td>
                                                                                            <asp:CheckBox ID="chkPartPayment" runat="server" OnClick="EnableDisablePP();" />
                                                                                        </td>
                                                                                        <td style="width: 150px">
                                                                                            <asp:Button ID="btnPartPayment" runat="server" CssClass="cmnBtn" Style="width: 153px;"
                                                                                                OnClientClick="return ValidateForPP();" Text="Part Payment Details" OnClick="btnPartPayment_Click" />
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td width="130px">Serial No.
                                                                            </td>
                                                                            <td style="padding-left: 29px">
                                                                                <table>
                                                                                    <tr>
                                                                                        <td>
                                                                                            <asp:DropDownList ID="ddlQuarter" runat="server" Enabled="false" AutoPostBack="true"
                                                                                                CssClass="dropDownList" Width="75px" TabIndex="14" Font-Size="9" OnSelectedIndexChanged="ddlQuarter_SelectedIndexChanged">
                                                                                            </asp:DropDownList>
                                                                                        </td>
                                                                                        <td>
                                                                                            <asp:TextBox ID="txtChallanSlNo" runat="server" Enabled="false" TabIndex="15" Width="93px"
                                                                                                onkeypress="return ValidateForOnlyNos(event);" onkeyup="ClearChallanSlNo(1);"
                                                                                                OnBlur="return GetDetails(this);" CssClass="txtBPL"></asp:TextBox>
                                                                                            <cc1:AutoCompleteExtender ID="challanSlNoAutoCompleteExtender" runat="server" MinimumPrefixLength="1"
                                                                                                ServicePath="~/WebServices/AutoCompleteService.asmx" TargetControlID="txtChallanSlNo"
                                                                                                ServiceMethod="GetChallanSlNosForAutoComplete" CompletionInterval="700" EnableCaching="false"
                                                                                                CompletionSetCount="20" DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true"
                                                                                                FirstRowSelected="True" OnClientItemSelected="GetChallanSlNoValue">
                                                                                            </cc1:AutoCompleteExtender>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 38%;">Challan/Vou No.
                                                                                &amp; Date
                                                                            </td>
                                                                            <td style="padding-left: 28px">
                                                                                <table style="margin: 0px; padding: 0px" cellpadding="0px" cellspacing="0px">
                                                                                    <tr>
                                                                                        <td width="20%" class="iCol" style="padding-left: 4px">
                                                                                            <asp:TextBox ID="txtChallanNo" runat="server" CssClass="txtboxRO" Style="width: 92px; text-align: right"
                                                                                                Enabled="false"> </asp:TextBox>
                                                                                        </td>
                                                                                        <td width="80%">
                                                                                            <asp:TextBox ID="txtChallanDate" runat="server" CssClass="txtboxRO" Style="width: 74px; text-align: right"
                                                                                                Enabled="false"> </asp:TextBox>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Total Amount
                                                                            </td>
                                                                            <td class="iCol" style="padding-left: 32px">
                                                                                <asp:TextBox ID="txtTotalAmount" runat="server" MaxLength="14" CssClass="txtboxRO"
                                                                                    Style="width: 173px;" Enabled="false"> </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </asp:Panel>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </asp:Panel>
                    <table>
                        <tr>
                            <td>
                                <table cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td id="rwNote" runat="server" visible="false" valign="top" style="width: 380px">
                                            <span><b>Note : &nbsp</b></span>
                                            <asp:Label ID="lblmsg" runat="server" Text="" Style="color: Blue;"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td id="rwadditionalfield" runat="server" visible="false" valign="top" style="width: 380px">
                                            <span><b>
                                                <asp:Label ID="lblAccountNumberAddl2Head" runat="server" Text="AccountNumber : " Style="color: Black;"></asp:Label>
                                                &nbsp </b></span>
                                            <asp:Label ID="lblAccountNumberAddl2" runat="server" Text="" Style="color: Blue;"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <br />
                                        </td>
                                    </tr>
                                </table>
                                <table cellpadding="0" cellspacing="0">

                                    <tr id="rowRegimeType" runat="server" visible="false">
                                        <td colspan="2">
                                            <span><b>
                                                <asp:Label ID="Label18" runat="server"
                                                    Style="color: Black;" Text="Regime Type : ">
                                                </asp:Label>
                                                &nbsp;
                                            </b></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <asp:Label ID="lblRegimeType" runat="server"
                Style="color: Blue;" Text="">
            </asp:Label>
                                        </td>
                                    </tr>

                                    <tr id="rowDedCodeMore" runat="server" visible="false">
                                        <td colspan="2">
                                            <span><b>
                                                <asp:Label ID="Label20" runat="server"
                                                    Style="color: Black;" Text="Code for 27/27E : ">
                                                </asp:Label>
                                                &nbsp;
                                            </b></span>

                                            <asp:Label ID="lblDedCodeMore" runat="server"
                                                Style="color: Blue;" Text="">
                                            </asp:Label>
                                        </td>
                                    </tr>

                                    <!-- TABLE BEFORE NEW BUTTON -->
                                    <tr>
                                        <td colspan="8">
                                            <table cellpadding="0" cellspacing="0" style="width: 100%;">
                                                <tr>
                                                    <td>
                                                        <!-- Add your required content here -->
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>

                                    <!-- NEW BUTTON -->
                                    <tr>
                                        <td colspan="8" style="padding-left: 1px; white-space: nowrap;">

                                            <asp:Button ID="btnNew"
                                                Text="New"
                                                runat="server"
                                                CssClass="cmnBtn"
                                                Width="80px"
                                                UseSubmitBehavior="false"
                                                TabIndex="19"
                                                OnClick="btnNew_Click" />

                                            <span style="display: inline-block; width: 5px;"></span>

                                            <asp:Button ID="btnSave"
                                                Text="Save"
                                                OnClientClick="javascript:return Validations();"
                                                OnClick="btnSave_Click"
                                                runat="server"
                                                CssClass="cmnBtn"
                                                Width="80px"
                                                TabIndex="18" />

                                            <span style="display: inline-block; width: 5px;"></span>

                                            <asp:Button ID="btnOpenSearch"
                                                runat="server"
                                                Text="Search"
                                                TabIndex="20"
                                                CssClass="cmnBtn"
                                                OnClientClick="SetStatus();return false;"
                                                Width="80px"
                                                OnClick="btnOpenSearch_Click" />

                                            <span style="display: inline-block; width: 5px;"></span>

                                            <asp:Button ID="btnApprove"
                                                runat="server"
                                                Text="Approve"
                                                TabIndex="20"
                                                CssClass="cmnBtn"
                                                Visible="false"
                                                OnClick="btnApprove_Click"
                                                Width="80px" />

                                            <span style="display: inline-block; width: 5px;"></span>

                                            <asp:Button ID="btnReject"
                                                runat="server"
                                                Text="Reject"
                                                TabIndex="20"
                                                CssClass="cmnBtn"
                                                Visible="false"
                                                OnClick="btnReject_Click"
                                                Width="80px" />

                                            <span style="display: inline-block; width: 5px;"></span>

                                            <asp:Button ID="btnBack"
                                                runat="server"
                                                Text="Back"
                                                TabIndex="20"
                                                CssClass="cmnBtn"
                                                Visible="false"
                                                OnClick="btnBack_Click"
                                                Width="80px" />

                                        </td>
                                    </tr>

                                    <!-- EXISTING NOTES -->
                                    <tr>
                                        <td style="padding-left: 1px; text-align: center" colspan="8">
                                            <asp:Label ID="lblNote" runat="server"
                                                ForeColor="#0000CC"
                                                Text="Note : Regular / Correction return filed. Data can only be viewed.">
                                            </asp:Label>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="padding-left: 1px; text-align: center" colspan="8">
                                            <asp:Label ID="lblBulk" runat="server"
                                                Visible="false"
                                                ForeColor="#0000CC"
                                                Text="Note:Data can only be viewed. Quarter has locked in Bulk challan">
                                            </asp:Label>
                                        </td>
                                    </tr>

                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Panel ID="pnlSearch" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel">
                                    <table>
                                        <tr>
                                            <td colspan="2">Serial No.
                                            </td>
                                            <td colspan="3">
                                                <asp:TextBox ID="txtSearchDedSerialNo" runat="server" Width="354px" TabIndex="20"
                                                    CssClass="txtBPL" onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75"
                                                    onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td colspan="2">
                                                <asp:Label ID="lblSearchSection" Text="Section" runat="server"></asp:Label>
                                            </td>
                                            <td colspan="3">
                                                <asp:Panel ID="Panel1" runat="server" Style="background-color: white; width: 325px; border-right: 1px solid #9f9f9f; border-left: 1px solid #9f9f9f; border-bottom: 1px solid #9f9f9f">
                                                    <asp:CheckBoxList ID="chkSections" runat="server">
                                                    </asp:CheckBoxList>
                                                </asp:Panel>
                                                <asp:TextBox ID="txtSection" runat="server" ToolTip="Enter Section with comma(,) separated value. Ex : 193,194," CssClass="txtBPL" Width="323px"></asp:TextBox>
                                                <cc1:PopupControlExtender ID="PopEx" runat="server" TargetControlID="txtSection"
                                                    PopupControlID="Panel1" Position="Bottom" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">Name
                                            </td>
                                            <td colspan="3">
                                                <asp:TextBox ID="txtSearchName" runat="server" Width="353px" TabIndex="20" CssClass="txtBPL"
                                                    onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td colspan="2">PAN
                                            </td>
                                            <td colspan="3">
                                                <asp:DropDownList ID="ddlSearchPAN" runat="server" Width="330px" CssClass="dropDownList" OnChange="CheckPANValue();">
                                                    <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                                    <asp:ListItem Text="PAN Given" Value="1"></asp:ListItem>
                                                    <asp:ListItem Text="PANAPPLIED" Value="2"></asp:ListItem>
                                                    <asp:ListItem Text="PANINVALID" Value="3"></asp:ListItem>
                                                    <asp:ListItem Text="PANNOTAVBL" Value="4"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td id="PaymentAmtSearch" runat="server">Amount of Payment
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">From
                                            </td>
                                            <td style="width: 16%">
                                                <asp:TextBox ID="txtSearchAmountFrom" runat="server" Width="147px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="22"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 1px; font-size: 9px" align="right">To
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtSearchAmountTo" runat="server" Width="173px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="23"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td colspan="5" align="left" id="td4" runat="server">
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <asp:Label ID="lblPANasthis" runat="server" Width="100px" Text="PAN as this">
                                                            </asp:Label>
                                                        </td>
                                                        <td style="width: 10px">
                                                            <asp:TextBox ID="txtPANRefNo" CssClass="txtBPL" Width="320px" TabIndex="36"
                                                                runat="server" onBlur="ConvertToUC(this);" BackColor="White" MaxLength="10" margin="0px 0px 0px 24px"
                                                                onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Label ID="lblSearchDeducted" Text="Tax Deducted Amount" runat="server"></asp:Label>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">From
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtSrchTaxDeductedFrom" runat="server" Width="147px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="26"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">To
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtSrchTaxDeductedTo" runat="server" Width="173px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="27"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td>
                                                <asp:Label ID="lblSearchPaidDate" Text="Paid/Credited Date" runat="server"></asp:Label>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">From
                                            </td>
                                            <td style="width: 15%">
                                                <asp:TextBox ID="txtSearchPaidDateFrom" runat="server" Width="140px" CssClass="txtBPR"
                                                    onBlur="setDateFormat(this);" TabIndex="24" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">To
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtSearchPaidDateTo" runat="server" Width="155px" CssClass="txtBPR"
                                                    onBlur="setDateFormat(this);" TabIndex="25" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">Non Deduction Reason
                                            </td>
                                            <td colspan="3">
                                                <asp:DropDownList ID="ddlSearchNonDedReason" runat="server" Width="357px" TabIndex="20"
                                                    CssClass="dropDownList">
                                                </asp:DropDownList>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td>
                                                <asp:Label ID="lblSearchDeductedDate" Text="Tax Deducted Date" runat="server"></asp:Label>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">From
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtSrchTaxDateFrom" runat="server" Width="140px" CssClass="txtBPR"
                                                    onBlur="setDateFormat(this);" TabIndex="28" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">To
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtSrchTaxDateTo" runat="server" Width="156px" CssClass="txtBPR"
                                                    onBlur="setDateFormat(this);" TabIndex="29" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" style="width: 130px;">Status
                                            </td>
                                            <td colspan="3" style="width: 10px">
                                                <asp:DropDownList ID="ddlStatus" runat="server" Width="357px" CssClass="dropDownList">
                                                    <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                                    <asp:ListItem Text="Approved" Value="2"></asp:ListItem>
                                                    <%--<asp:ListItem Text="Rejected" Value="3"></asp:ListItem>--%>
                                                </asp:DropDownList>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td colspan="5" align="left" id="tdReferenceNo" runat="server">
                                                <table>
                                                    <tr>
                                                        <td>
                                                            <asp:Label ID="lblReferenceNos" runat="server" Width="100px" Text="Reference No.">
                                                            </asp:Label>
                                                        </td>
                                                        <td style="width: 10px">
                                                            <asp:TextBox ID="txtSearchReferenceNo" CssClass="txtBPL" Width="323px" TabIndex="23"
                                                                runat="server"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr id="rowSearchRTBranchCode" runat="server" visible="false">
                                            <td colspan="2">Branch Code
                                            </td>
                                            <td colspan="3">
                                                <asp:TextBox ID="txtSearchRTBranchCode" CssClass="txtBPL" Width="351px" TabIndex="37"
                                                    runat="server"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td colspan="5" align="left" id="td2" runat="server"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="6">
                                                <table>
                                                    <tr>
                                                        <td align="right">
                                                            <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="cmnBtn" TabIndex="30"
                                                                OnClientClick="return FormatSearch();" OnClick="btnSearch_Click" />
                                                        </td>
                                                        <td align="right" id="rowSearchBranch" runat="server" visible="false">
                                                            <asp:Button ID="btnSearchBranch" runat="server" Text="Search Branch" CssClass="cmnBtn"
                                                                TabIndex="30" OnClientClick="return FormatSearch()" OnClick="btnSearchBranch_Click" />
                                                        </td>
                                                        <td>
                                                            <asp:Button ID="btnClear" runat="server" Text="Show All" CssClass="cmnBtn" TabIndex="31"
                                                                OnClientClick="return ValidateLoadAll()" OnClick="btnClear_Click" />
                                                        </td>
                                                        <td id="rowShowAllBranch" runat="server" visible="false">
                                                            <asp:Button ID="btnShowAllBranch" runat="server" Text="Show All Branch" Width="110px"
                                                                CssClass="cmnBtn" TabIndex="31" OnClientClick="return ValidateLoadAll()" OnClick="btnShowAllBranch_Click" />
                                                        </td>
                                                        <td>
                                                            <asp:Button ID="btnClose" runat="server" Text="Close" Width="80px" CssClass="cmnBtn"
                                                                OnClientClick="SetStatus();" TabIndex="32" OnClick="btnClose_Click" />
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Panel ID="pnlDeduction" CssClass="navPanel" runat="server" ScrollBars="Horizontal" Width="1039px"
                                    Visible="false">
                                    <asp:Repeater ID="rptrDeduction" runat="server" OnItemCommand="rptrDeduction_ItemCommand"
                                        OnItemDataBound="rptrDeduction_ItemDataBound">
                                        <HeaderTemplate>
                                            <table id="NavTable" border="0">
                                                <tr bgcolor="#EEEEEE">
                                                    <th colspan="3" id="headerDeductionAction" runat="server">
                                                        <asp:Label runat="server" ID="Label7" Width="60px" Text="Action" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblSerNo" Width="40px" Text="Serial No." />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblName" Width="200px" Text="Name" />
                                                    </th>
                                                    <th id="headerStatus" runat="server">
                                                        <asp:Label runat="server" ID="lblStatus" Width="70px" Text="Status" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblPAN" Width="70px" Text="PAN" />
                                                    </th>
                                                    <th id="headerRefNo" runat="server">
                                                        <asp:Label runat="server" ID="lblRef" Width="70px" Text="Employee No." />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblSection" Width="150px" Text="Section" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblChallanNumber" Width="50px" Text="Challan Number" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblChallanDate" Width="50px" Text="Challan Date" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblBsrCode" Width="50px" Text="BSR Code" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblAmountOfPayment" Width="100px" Text="Amount Of Payment" />
                                                    </th>
                                                    <th id="headerValueOfPur" runat="server">
                                                        <asp:Label runat="server" ID="lblValueOfPur" Width="150px" Text="Total Value of Purchase(s) " />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="lblDate" Text="Paid/Credited Date" runat="server" Width="112px"></asp:Label>
                                                    </th>
                                                    <th id="headerITRate" runat="server">
                                                        <asp:Label runat="server" ID="lblIncomeTaxRate" Width="80px" Text="Income Tax Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="Label2" Width="80px" Text="Income Tax" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Labels2" Text="Surcharge Rate" runat="server" Width="65px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label3" runat="server" Width="65px" Text="Surcharge" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblCessRate" Width="50px" Text="Cess Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label4" runat="server" Width="50px" Text="Cess" />
                                                    </th>
                                                    <th id="headerTaxRate" runat="server">
                                                        <asp:Label runat="server" ID="lblTaxRate" Width="60px" Text="Tax Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblTaxDeducted" Width="80px" Text="Tax Deducted" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblTaxDedDate" Width="70px" Text=" Tax Deducted Date" />
                                                    </th>
                                                    <th id="headerTCSCertDate" runat="server">
                                                        <asp:Label runat="server" ID="lblTCSCertDate" Width="130px" Text="Tax Collection Cert Date" />
                                                    </th>
                                                    <th id="headerBookEntry" runat="server">
                                                        <asp:Label ID="lblBookEntry" runat="server" Width="80px" Text="Book Entry" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblNonDeductionReason" Width="290px" Text="Remarks for Deduction" />
                                                    </th>
                                                    <th style="display: none">
                                                        <asp:Label runat="server" ID="EntryType" Width="290px" Text="Entry Type" />
                                                    </th>
                                                    <th id="headerGrossUp" runat="server">
                                                        <asp:Label ID="Label5" runat="server" Width="130px" Text="Grossing Up Indicator" />
                                                    </th>
                                                    <th style="display: none">
                                                        <asp:Label ID="Label6" runat="server" Width="130px" Text="Time Stamp" />
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white">
                                                <td id="edit" runat="server">
                                                    <asp:LinkButton ID="lnkEdit" runat="server" Text="Edit" TabIndex="33" CommandName="Edit"
                                                        CommandArgument='<%#Eval("PartPaymentID") %>'></asp:LinkButton>
                                                </td>
                                                <td style="border-right: none" id="coldelete" runat="server">
                                                    <asp:LinkButton ID="lnkDelete" runat="server" TabIndex="34" Text="Delete" CommandName="Delete"
                                                        CommandArgument='<%#Eval("PartPaymentID") %>'></asp:LinkButton>
                                                </td>
                                                <td id="colCheck" runat="server">
                                                    <asp:CheckBox ID="chkSelect" runat="server" />
                                                    <asp:Label ID="lblDeductionId" runat="server" Visible="false" Text='<%# Eval("DeductionId")%>'></asp:Label>
                                                    <asp:Label ID="lblPartPaymentId" runat="server" Visible="false" Text='<%# Eval("PartPaymentID")%>'></asp:Label>
                                                </td>
                                                <td id="colDummy" runat="server"></td>
                                                <td>
                                                    <%# Eval("SLNo")%>
                                                </td>
                                                <td>
                                                    <%# Eval("Name")%>
                                                </td>
                                                <td id="dataStatus" runat="server">
                                                    <asp:Label ID="lblTransStatus" runat="server" Text='<%# Eval("TransactionStatus")%>'></asp:Label>
                                                </td>
                                                <td>
                                                    <%# Eval("PAN")%>
                                                </td>
                                                <td id="dataRefNo" runat="server">
                                                    <%# Eval("ReferenceNo")%>
                                                </td>
                                                <td>
                                                    <%# Eval("Section")%>
                                                </td>
                                                <td>
                                                    <%# Eval("ChallanNo")%>
                                                </td>
                                                <td>
                                                    <%# Eval("ChallanDate")%>
                                                </td>
                                                <td>
                                                    <%# Eval("BSRCode")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("PaymentMade")%>
                                                </td>
                                                <td style="text-align: right" id="tdValueofPurchase" runat="server">
                                                    <%# Eval("TotalValueofPurchase")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("CreditedDate")%>
                                                </td>
                                                <td style="text-align: right" id="dataITRate" runat="server">
                                                    <%# Eval("IncomeTaxPerc")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("IncomeTax") %>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("SurchargeRate")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("Surcharge")%>
                                                </td>
                                                <td style="width: 400px!important; text-align: right">
                                                    <%# Eval("CessRate")%>
                                                </td>
                                                <td style="width: 400px!important; text-align: right">
                                                    <%# Eval("Cess")%>
                                                </td>
                                                <td style="text-align: right" id="dataTaxRate" runat="server">
                                                    <%# Eval("TaxRate")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TaxDeducted")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TaxDeductedDate")%>
                                                </td>
                                                <td style="text-align: right" id="tdCertDate" runat="server">
                                                    <%# Eval("TaxCertDate")%>
                                                </td>
                                                <td id="dataBookEntry" runat="server">
                                                    <%#Eval("BookEntry") %>
                                                </td>
                                                <td>
                                                    <%# Eval("NonDeductionReason")%>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblEntryType" runat="server" Text='<%# Eval("EntryType")%>'></asp:Label>
                                                </td>
                                                <td id="dataGrossUp" runat="server">
                                                    <%# Eval("GrossingUpIndicator")%>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblTimeStamp" runat="server" Text='<%# Eval("TimeStamp")%>'></asp:Label>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px; display: none"
                                    align="left" id="tableFooter" runat="server">
                                    <tr style="width: 100%">
                                        <td style="width: 42%" align="left">
                                            <asp:Label ID="lblDeductionTotal" runat="server" Text="DeductionTotal : Nil" Font-Size="Small" />
                                        </td>
                                        <td style="padding: 0px 0px 0px 120px">
                                            <asp:Label ID="ASPxLabel4" runat="server" Text="Records per page : " Font-Size="X-Small" />
                                        </td>
                                        <td style="width: 50px; padding-top: 2px;">
                                            <asp:DropDownList ID="ddlGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                OnSelectedIndexChanged="ddlGoTo_SelectedIndexChanged" AutoPostBack="true" TabIndex="35"
                                                Font-Size="X-Small" CssClass="dropDownList">
                                                <asp:ListItem Text="5" Value="5" />
                                                <asp:ListItem Text="10" Value="10" />
                                                <asp:ListItem Text="15" Value="15" />
                                                <asp:ListItem Text="20" Value="20" />
                                                <asp:ListItem Text="25" Value="25" />
                                                <asp:ListItem Text="50" Value="50" />
                                                <asp:ListItem Text="75" Value="75" />
                                                <asp:ListItem Text="100" Value="100" />
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblGridStatus" runat="server" Style="float: left;" Text="" Font-Size="X-Small"></asp:Label>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnFirst" runat="server" Text="&lt;&lt;" Width="35px" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" OnClick="btnFirst_Click" CssClass="navButton"
                                                Enabled="False" TabIndex="36"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnPrevious" runat="server" Text="&lt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnPrevious_Click" CssClass="navButton" Enabled="False"
                                                TabIndex="37"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtGoToPage" runat="server" Text="1" CssClass="navTextBox" AutoPostBack="True"
                                                OnTextChanged="txtGoToPage_TextChanged" MaxLength="5" TabIndex="38"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnNext" runat="server" Text="&gt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnNext_Click" CssClass="navButton" TabIndex="39"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnLast" runat="server" Text="&gt;&gt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnLast_Click" CssClass="navButton" TabIndex="40"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                                <table id="tableMultiControls" runat="server" style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px; display: none">
                                    <tr>
                                        <td style="padding-left: 5px">
                                            <asp:CheckBox ID="chkSelectAll" runat="server" AutoPostBack="true" OnCheckedChanged="chkSelectAll_CheckedChanged" Visible="false" />
                                            <asp:Label ID="lblSelectAll" runat="server" Style="color: Blue;" Text="Select All"></asp:Label>
                                            &nbsp;&nbsp;
                                            <asp:Button ID="btnApproveMulti" runat="server" CssClass="cmnBtn" OnClick="btnApproveMulti_Click" OnClientClick="return ConfirmApprove()" TabIndex="20" Text="Approve" Visible="false" Width="80px" />
                                            <asp:Button ID="btnRejectMulti" runat="server" CssClass="cmnBtn" OnClick="btnRejectMulti_Click" OnClientClick="return ConfirmReject()" TabIndex="20" Text="Reject" Visible="false" Width="80px" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        </td>
                        </tr>
                    </table>
                </asp:View>
                <asp:View ID="vwPartPayment" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td valign="top">
                                <table class="nTbl">
                                    <tr>
                                        <td valign="top" style="margin-left: 0px">
                                            <table class="eCol" cellpadding="0">
                                                <tr>
                                                    <td class="vHCol">Serial No.
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtPPSlNo" runat="server" ReadOnly="true" Style="background-color: #d5dadd; color: Black;"
                                                            CssClass="txtBPL"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Amount to Calc
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtPPAmountToCalculate" runat="server" MaxLength="14" AutoComplete="Off"
                                                            TabIndex="1" CssClass="txtBPR" onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                            onkeyup="CalculatePPAmounts();"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Income Tax
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtPPIncomeTax" CssClass="txtBPR" AutoComplete="Off" runat="server"
                                                            MaxLength="14" Enabled="true" onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                            onkeyup="CalcPPAmounts();" TabIndex="2"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Surcharge
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtPPSurcharge" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                                            TabIndex="3" MaxLength="14" Enabled="true" onchange="return checkDecimalNo(this);"
                                                            onkeyup="CalcPPAmounts();" onkeypress="return numeralsOnly(this, event,11,2,0,1);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Edu Cess
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtPPEduCess" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                                            TabIndex="4" MaxLength="14" onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                            onkeyup="CalcPPAmounts();"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Total
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtPPTotal" runat="server" AutoComplete="Off" CssClass="txtboxRO"
                                                            Width="196px" MaxLength="14" Enabled="false"> </asp:TextBox>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td class="eCol" valign="top">
                                            <table>
                                                <tr>
                                                    <td width="100%" id="Td1">
                                                        <div style="padding-bottom: 3px">
                                                            <div class="dialog" style="width: 100%;">
                                                                <div class="dHeader">
                                                                    Challan Details
                                                                </div>
                                                                <div style="padding: 5px 5px 10px 10px; border-top: solid 1px gray">
                                                                    <table>
                                                                        <tr>
                                                                            <td width="130px">Serial No.
                                                                            </td>
                                                                            <td style="padding-left: 32px">
                                                                                <table>
                                                                                    <tr>
                                                                                        <td>
                                                                                            <asp:DropDownList ID="ddlPPQuarter" runat="server" AutoPostBack="true" CssClass="mCBs"
                                                                                                Width="75px" TabIndex="5" Font-Size="9" OnSelectedIndexChanged="ddlPPQuarter_SelectedIndexChanged">
                                                                                            </asp:DropDownList>
                                                                                        </td>
                                                                                        <td>
                                                                                            <asp:TextBox ID="txtPPChallanSlNo" runat="server" Enabled="false" TabIndex="15" Width="90px"
                                                                                                onkeypress="return ValidateForOnlyNos(event);" onkeyup="ClearChallanSlNo(2);"
                                                                                                OnBlur="return GetDetails(this);" CssClass="txtBPL"></asp:TextBox>
                                                                                            <cc1:AutoCompleteExtender ID="AutoCompleteExtender1" runat="server" MinimumPrefixLength="1"
                                                                                                ServicePath="~/WebServices/AutoCompleteService.asmx" TargetControlID="txtPPChallanSlNo"
                                                                                                ServiceMethod="GetChallanSlNosForAutoComplete" CompletionInterval="700" EnableCaching="false"
                                                                                                CompletionSetCount="20" DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true"
                                                                                                FirstRowSelected="True" OnClientItemSelected="GetChallanSlNoValue">
                                                                                            </cc1:AutoCompleteExtender>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Challan/Vou No.
                                                                                <br />
                                                                                &amp; Date
                                                                            </td>
                                                                            <td style="padding-left: 28px">
                                                                                <table style="margin: 0px; padding: 0px" cellpadding="0px" cellspacing="0px">
                                                                                    <tr>
                                                                                        <td width="20%" class="iCol" style="padding-left: 4px">
                                                                                            <asp:TextBox ID="txtPPChallanNo" runat="server" CssClass="txtboxRO" Style="width: 92px; text-align: right"
                                                                                                Enabled="false"> </asp:TextBox>
                                                                                        </td>
                                                                                        <td width="80%">
                                                                                            <asp:TextBox ID="txtPPChallanDate" runat="server" CssClass="txtboxRO" Style="width: 80px; text-align: right"
                                                                                                Enabled="false"> </asp:TextBox>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Income Tax
                                                                            </td>
                                                                            <td class="iCol" style="padding-left: 32px">
                                                                                <asp:TextBox ID="txtPPChallanIncomeTax" runat="server" MaxLength="14" CssClass="txtboxRO"
                                                                                    Style="width: 177px;" Enabled="false"> </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Surcharge
                                                                            </td>
                                                                            <td class="iCol" style="padding-left: 32px">
                                                                                <asp:TextBox ID="txtPPChallanSurcharge" runat="server" MaxLength="14" CssClass="txtboxRO"
                                                                                    Style="width: 177px;" Enabled="false"> </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Edu Cess
                                                                            </td>
                                                                            <td class="iCol" style="padding-left: 32px">
                                                                                <asp:TextBox ID="txtPPChallanEduCess" runat="server" MaxLength="14" CssClass="txtboxRO"
                                                                                    Style="width: 177px;" Enabled="false"> </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>Total Amount
                                                                            </td>
                                                                            <td class="iCol" style="padding-left: 32px">
                                                                                <asp:TextBox ID="txtPPChallanTotalAmount" runat="server" MaxLength="14" CssClass="txtboxRO"
                                                                                    Style="width: 177px;" Enabled="false"> </asp:TextBox>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <table cellpadding="0" cellspacing="0">
                                                <tr>
                                                    <td>
                                                        <asp:Button ID="btnPPNew" Text="New" runat="server" CssClass="cmnBtn" Width="80px"
                                                            OnClientClick="return ClearPPControls();" UseSubmitBehavior="False" TabIndex="8" />
                                                    </td>
                                                    <td style="padding-left: 4px">
                                                        <asp:Button ID="btnPPSave" Text="Save" runat="server" CssClass="cmnBtn" Width="80px"
                                                            TabIndex="7" OnClientClick="return ValidatePP();" OnClick="btnPPSave_Click" />
                                                    </td>
                                                    <td style="padding-left: 4px">
                                                        <asp:Button ID="btnPPClose" runat="server" OnClientClick="ValidateForPP();" Text="Close"
                                                            TabIndex="9" CssClass="cmnBtn" OnClick="btnPPClose_Click" />
                                                    </td>
                                                    <td style="padding-left: 10px">
                                                        <asp:Label ID="lblPPNote" runat="server" Visible="false" ForeColor="#0000CC" Text="Note:Data can only be viewed. Quarter has locked in Bulk challan"></asp:Label>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <asp:Panel ID="partPaymentPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal">
                                                <asp:Repeater ID="rptrPartPayment" runat="server" OnItemCommand="rptrPartPayment_ItemCommand"
                                                    OnItemDataBound="rptrPartPayment_ItemDataBound">
                                                    <HeaderTemplate>
                                                        <table id="NavTable" border="0">
                                                            <tr bgcolor="#EEEEEE">
                                                                <th colspan="2">Action
                                                                </th>
                                                                <th>
                                                                    <asp:Label runat="server" ID="Label2" Width="112px" Text="Income Tax" />
                                                                </th>
                                                                <th>
                                                                    <asp:Label ID="Label4" runat="server" Width="115px" Text="Surcharge" />
                                                                </th>
                                                                <th>
                                                                    <asp:Label ID="lblEduCess" runat="server" Width="120px" Text="Edu Cess" />
                                                                </th>
                                                                <th>
                                                                    <asp:Label runat="server" ID="lblAmount" Width="120px" Text="Amount" />
                                                                </th>
                                                                <th>
                                                                    <asp:Label runat="server" ID="lblTaxDedDate" Width="120px" Text="Challan" />
                                                                </th>
                                                            </tr>
                                                    </HeaderTemplate>
                                                    <ItemTemplate>
                                                        <tr bgcolor="white">
                                                            <td>
                                                                <asp:LinkButton ID="lnkEdit" runat="server" Text="Edit" TabIndex="10" CommandName="Edit"
                                                                    CommandArgument='<%#Eval("DeductionID") %>'></asp:LinkButton>
                                                            </td>
                                                            <td>
                                                                <asp:LinkButton ID="lnkDelete" runat="server" TabIndex="11" Text="Delete" CommandName="Delete"
                                                                    CommandArgument='<%#Eval("DeductionID") %>'></asp:LinkButton>
                                                            </td>
                                                            <td style="text-align: right">
                                                                <%# Eval("IncomeTax") %>
                                                            </td>
                                                            <td style="text-align: right">
                                                                <%# Eval("Surcharge")%>
                                                            </td>
                                                            <td style="width: 400px!important; text-align: right">
                                                                <%# Eval("Cess")%>
                                                            </td>
                                                            <td style="text-align: right">
                                                                <%# Eval("TotalDeducted")%>
                                                            </td>
                                                            <td style="border-right-style: none; text-align: left">
                                                                <%# Eval("Challan")%>
                                                            </td>
                                                        </tr>
                                                    </ItemTemplate>
                                                    <FooterTemplate>
                                                        </table>
                                                    </FooterTemplate>
                                                </asp:Repeater>
                                            </asp:Panel>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </asp:View>
            </asp:MultiView>
        </ContentTemplate>
        <Triggers>
            <asp:PostBackTrigger ControlID="btnSearch" />
            <asp:AsyncPostBackTrigger ControlID="btnSave" EventName="Click" />
            <asp:PostBackTrigger ControlID="btnOpenSearch" />
            <asp:PostBackTrigger ControlID="btnClear" />
            <asp:PostBackTrigger ControlID="btnClose" />
        </Triggers>
    </asp:UpdatePanel>
</asp:Content>
