<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Summary_DeductionChallanSummary, App_Web_summary.aspx.6d031aae" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style type="text/css">
        .total
        {
            width: 250px;
            height: 100px;
            border-color: #ccc;
            border-style: outset;
            border-collapse: collapse;
        }
        .total tr td
        {
            width: 20px;
            width: 250px;
            height: 10px;
            border-color: #ccc;
            border-style: outset;
            border-collapse: collapse;
            background-color: white;
        }
        .detailed
        {
            text-align: center;
            width: 250px;
            height: 100px;
            border-color: #ccc;
            border-style: outset;
            border-collapse: collapse;
        }
        .detailed tr td, .detailed tr th
        {
            width: 20px;
            width: 250px;
            height: 10px;
            border-color: #ccc;
            border-style: outset;
            border-collapse: collapse;
        }
        .detailed tr td
        {
            background-color: white;
        }
        .detailed tr th
        {
            background-color: Gray;
            color: white;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <table>
        <tr>
            <td>
                <table class="total" style="width: 250px; height: 100px; border-color: #ccc; border-style: outset;
                    border-collapse: collapse;" border="1px" cellpadding="0px" cellspacing="0px">
                    <tr>
                        <td colspan="2" style="border-color: #ccc; padding: 2px 3px 2px 5px;">
                            Total Users
                        </td>
                    </tr>
                    <tr>
                        <td align="left" style="border-color: #ccc; padding: 2px 3px 2px 20px;">
                            Active Users
                        </td>
                        <td style="border-color: #ccc" align="center">
                            <asp:Label ID="lblActiveUsers" runat="server" Text="35"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td align="left" style="border-color: #ccc; padding: 2px 3px 2px 20px;">
                            Non Active Users
                        </td>
                        <td style="border-color: #ccc" align="center">
                            <asp:Label ID="lblNonActiveUsers" runat="server" Text="5"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td style="border-color: #ccc; padding: 2px 3px 2px 7px;">
                            Total Branches
                        </td>
                        <td style="border-color: #ccc" align="center">
                            <asp:Label ID="lblTotalBranches" runat="server" Text="25"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td style="border-color: #ccc; padding: 2px 3px 2px 7px;">
                            eReturn Filed
                        </td>
                        <td style="border-color: #ccc" align="center">
                            <asp:Label ID="lbleReturnFiled" runat="server" Text="" Width="15px"></asp:Label>
                        </td>
                    </tr>
                </table>
            </td>
            <td valign="top" style="padding-left: 15px">
                <asp:Label ID="lblRequest" runat="server" Text="Request accepted for e-Return"></asp:Label>
            </td>
        </tr>
        <tr height="15px">
            <td colspan="2">
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <table class="detailed" border="1" cellpadding="0px" cellspacing="0px">
                    <tr>
                        <th>
                        </th>
                        <th>
                            Q1
                        </th>
                        <th>
                            Q2
                        </th>
                        <th>
                            Q3
                        </th>
                        <th>
                            Q4
                        </th>
                    </tr>
                    <tr runat="server" id="rowForm24">
                        <th>
                            <asp:Label ID="lblF24" runat="server" Text="Form24"></asp:Label>
                        </th>
                        <td>
                            <asp:Label ID="lblF24Q1EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF24Q2EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF24Q3EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF24Q4EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                    </tr>
                    <tr runat="server" id="rowForm26">
                        <th>
                            <asp:Label ID="lblF26" runat="server" Text="Form26"></asp:Label>
                        </th>
                        <td>
                            <asp:Label ID="lblF26Q1EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF26Q2EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF26Q3EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF26Q4EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                    </tr>
                    <tr runat="server" id="rowForm27">
                        <th>                            
                            <asp:Label ID="lblF27" runat="server" Text="Form27"></asp:Label>
                        </th>
                        <td>
                            <asp:Label ID="lblF27Q1EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF27Q2EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF27Q3EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF27Q4EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                    </tr>
                    <tr runat="server" id="rowForm27E">
                        <th>                            
                            <asp:Label ID="lblF27E" runat="server" Text="Form27E"></asp:Label>
                        </th>
                        <td>
                            <asp:Label ID="lblF27EQ1EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF27EQ2EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF27EQ3EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF27EQ4EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                    </tr>
                    <tr runat="server" id="rowForm15G">
                        <th>                            
                            <asp:Label ID="lblF15G" runat="server" Text="Form15G"></asp:Label>
                        </th>
                        <td>
                            <asp:Label ID="lblF15GQ1EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF15GQ2EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF15GQ3EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF15GQ4EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                    </tr>
                    <tr runat="server" id="rowForm15H">
                        <th>
                            Form15H
                        </th>
                        <td>
                            <asp:Label ID="lblF15HQ1EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF15HQ2EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF15HQ3EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                        <td>
                            <asp:Label ID="lblF15HQ4EReturnCount" runat="server" Text="0"></asp:Label>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <br />
    <br />
    <asp:Button ID="btnSummary" runat="server" Text="eReturn Summary" OnClick="btnSummary_Click"
        CssClass="cmnBtn" Width="120px" />
</asp:Content>
