<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Deductor_Deductor, App_Web_deductor.aspx.8c6355ba" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">

    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>

    <script type="text/javascript">
        function onConfirm() {
            var quarter = document.getElementById("<%=cmbQuarter.ClientID %>");
            quarter = quarter.value;
            var out = '';
            var quarterConfirmation = document.getElementById("<%=hdnQuarterConfirm.ClientID %>");
            for (var i = quarter; i < 4; i++) {
                var str = Number(i) + 1;

                out = out + str + ',';
            }
            if (out.length > 0) {
                document.getElementById("<%=hdnQuarters.ClientID%>").value = out.substring(0, out.length - 1);
                //                temp = confirm('Update Same Details To Quarter ' + out.substring(0, out.length - 1) + '');
                temp = true;
                if (temp) {
                    document.getElementById("<%=hdnConfirmOrNot.ClientID %>").value = "1";
                    quarterConfirmation.value = true;
                }
                else {
                    document.getElementById("<%=hdnConfirmOrNot.ClientID %>").value = "0";
                    quarterConfirmation.value = false;
                }
            }
            else {
                quarterConfirmation.value = false;
            }
        }
        function EnableDisableControls() {
            var cmbDeductorType = document.getElementById("<%=cmbDeductorType.ClientID %>");
            var deductorType = cmbDeductorType.value;
            var cmbGovtAddState = document.getElementById("<%=cmbGovtAddState.ClientID %>");
            var txtPAOCode = document.getElementById("<%=txtPAOCode.ClientID %>");
            var txtPAORegnNo = document.getElementById("<%=txtPAORegnNo.ClientID %>");
            var txtDDOCode = document.getElementById("<%=txtDDOCode.ClientID %>");
            var txtDDORegnNo = document.getElementById("<%=txtDDORegnNo.ClientID %>");
            var cmbGovtAddMinistry = document.getElementById("<%=cmbGovtAddMinistry.ClientID %>");
            var cmbGovtAddMainMinistry = document.getElementById("<%=cmbGovtAddMainMinistry.ClientID %>");
            var txtMinOtherName = document.getElementById("<%=txtMinOtherName.ClientID %>");
            var txtAIN = document.getElementById("<%=txtAIN.ClientID%>")
            if (deductorType != -1) {
                if (deductorType == "1") {
                    cmbGovtAddState.selectedIndex = 0;
                    txtPAOCode.value = '';
                    txtPAOCode.disabled = false;
                    txtPAORegnNo.value = '';
                    txtPAORegnNo.disabled = false;
                    txtDDOCode.value = '';
                    txtDDOCode.disabled = false;
                    txtDDORegnNo.value = '';
                    txtDDORegnNo.disabled = false;
                    cmbGovtAddMinistry.selectedIndex = 0;
                    cmbGovtAddMainMinistry.selectedIndex = 0;
                    txtMinOtherName.value = '';
                    cmbGovtAddState.style.backgroundColor = "White";
                    cmbGovtAddState.disabled = true;
                    txtPAOCode.style.backgroundColor = "White";
                    txtDDOCode.style.backgroundColor = "White";
                    cmbGovtAddMinistry.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddMainMinistry.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddMinistry.disabled = true;
                    cmbGovtAddMainMinistry.disabled = false;
                    txtMinOtherName.disabled = false;
                    txtMinOtherName.style.backgroundColor = "White";
                    txtAIN.style.backgroundColor = "White"
                }
                else if (deductorType == "2") {
                    cmbGovtAddState.selectedIndex = 0;
                    txtPAOCode.value = '';
                    txtPAOCode.disabled = false;
                    txtPAORegnNo.value = '';
                    txtPAORegnNo.disabled = false;
                    txtDDOCode.value = '';
                    txtDDOCode.disabled = false;
                    txtDDORegnNo.value = '';
                    txtDDORegnNo.disabled = false;
                    cmbGovtAddMinistry.selectedIndex = 0;
                    cmbGovtAddMainMinistry.selectedIndex = 0;
                    txtMinOtherName.value = '';
                    cmbGovtAddState.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddState.disabled = false;
                    txtPAOCode.style.backgroundColor = "White";
                    txtDDOCode.style.backgroundColor = "White";
                    cmbGovtAddMinistry.style.backgroundColor = "White";
                    cmbGovtAddMinistry.disabled = true;
                    cmbGovtAddMainMinistry.style.backgroundColor = "White";
                    cmbGovtAddMainMinistry.disabled = false;
                    txtMinOtherName.disabled = false;
                    txtMinOtherName.style.backgroundColor = "White";
                    txtAIN.style.backgroundColor = "White"
                }
                else if (deductorType == "3") {
                    cmbGovtAddState.selectedIndex = 0;
                    txtPAOCode.value = '';
                    txtPAOCode.disabled = false;
                    txtPAORegnNo.value = '';
                    txtPAORegnNo.disabled = false;
                    txtDDOCode.value = '';
                    txtDDOCode.disabled = false;
                    txtDDORegnNo.value = '';
                    txtDDORegnNo.disabled = false;
                    cmbGovtAddMinistry.selectedIndex = 0;
                    cmbGovtAddMainMinistry.selectedIndex = 0;
                    txtMinOtherName.value = '';
                    cmbGovtAddState.disabled = true;
                    cmbGovtAddState.style.backgroundColor = "White";
                    txtPAOCode.style.background = "#E5E5E5";
                    txtDDOCode.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddMinistry.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddMinistry.disabled = true;
                    cmbGovtAddMainMinistry.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddMainMinistry.disabled = false;
                    txtMinOtherName.disabled = false;
                    txtMinOtherName.style.backgroundColor = "White";
                    txtAIN.style.backgroundColor = "#E5E5E5"
                }
                else if (deductorType == "4") {
                    cmbGovtAddState.selectedIndex = 0;
                    txtPAOCode.value = '';
                    txtPAOCode.disabled = false;
                    txtPAORegnNo.value = '';
                    txtPAORegnNo.disabled = false;
                    txtDDOCode.value = '';
                    txtDDOCode.disabled = false;
                    txtDDORegnNo.value = '';
                    txtDDORegnNo.disabled = false;
                    cmbGovtAddMinistry.selectedIndex = 0;
                    cmbGovtAddMainMinistry.selectedIndex = 0;
                    txtMinOtherName.value = '';
                    cmbGovtAddState.style.backgroundColor = "White";
                    cmbGovtAddState.disabled = true;
                    txtPAOCode.style.backgroundColor = "White";
                    txtDDOCode.style.backgroundColor = "White";
                    cmbGovtAddMinistry.style.backgroundColor = "White";
                    cmbGovtAddMinistry.disabled = true;
                    cmbGovtAddMainMinistry.style.backgroundColor = "White";
                    cmbGovtAddMainMinistry.disabled = false;
                    txtMinOtherName.disabled = false;
                    txtMinOtherName.style.backgroundColor = "White";
                    txtAIN.style.backgroundColor = "White"
                }
                else if (deductorType == "5") {
                    cmbGovtAddState.selectedIndex = 0;
                    txtPAOCode.value = '';
                    txtPAOCode.disabled = false;
                    txtPAORegnNo.value = '';
                    txtPAORegnNo.disabled = false;
                    txtDDOCode.value = '';
                    txtDDOCode.disabled = false;
                    txtDDORegnNo.value = '';
                    txtDDORegnNo.disabled = false;
                    cmbGovtAddMinistry.selectedIndex = 0;
                    cmbGovtAddMainMinistry.selectedIndex = 0;
                    txtMinOtherName.value = '';
                    cmbGovtAddState.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddState.disabled = false;
                    txtPAOCode.style.backgroundColor = "White";
                    txtDDOCode.style.backgroundColor = "White";
                    cmbGovtAddMinistry.style.backgroundColor = "White";
                    cmbGovtAddMinistry.disabled = true;
                    cmbGovtAddMainMinistry.style.backgroundColor = "White";
                    cmbGovtAddMainMinistry.disabled = false;
                    txtMinOtherName.disabled = false;
                    txtMinOtherName.style.backgroundColor = "White";
                    txtAIN.style.backgroundColor = "White"
                }
                else if (deductorType == "6") {
                    cmbGovtAddState.selectedIndex = 0;
                    txtPAOCode.value = '';
                    txtPAOCode.disabled = false;
                    txtPAORegnNo.value = '';
                    txtPAORegnNo.disabled = false;
                    txtDDOCode.value = '';
                    txtDDOCode.disabled = false;
                    txtDDORegnNo.value = '';
                    txtDDORegnNo.disabled = false;
                    cmbGovtAddMinistry.selectedIndex = 0;
                    cmbGovtAddMainMinistry.selectedIndex = 0;
                    txtMinOtherName.value = '';
                    cmbGovtAddState.style.backgroundColor = "#E5E5E5";
                    txtPAOCode.style.backgroundColor = "White";
                    txtDDOCode.style.backgroundColor = "White";
                    cmbGovtAddState.disabled = false;
                    cmbGovtAddMinistry.style.backgroundColor = "White";
                    cmbGovtAddMinistry.disabled = true;
                    cmbGovtAddMainMinistry.style.backgroundColor = "White";
                    cmbGovtAddMainMinistry.disabled = true;
                    txtMinOtherName.disabled = true;
                    txtMinOtherName.style.backgroundColor = "White";
                    txtAIN.style.backgroundColor = "#E5E5E5"
                }
                else if (deductorType == "7") {
                    cmbGovtAddState.selectedIndex = 0;
                    txtPAOCode.value = '';
                    txtPAOCode.disabled = false;
                    txtPAORegnNo.value = '';
                    txtPAORegnNo.disabled = false;
                    txtDDOCode.value = '';
                    txtDDOCode.disabled = false;
                    txtDDORegnNo.value = '';
                    txtDDORegnNo.disabled = false;
                    cmbGovtAddMinistry.selectedIndex = 0;
                    cmbGovtAddMainMinistry.selectedIndex = 0;
                    txtMinOtherName.value = '';
                    cmbGovtAddState.disabled = true;
                    cmbGovtAddState.style.backgroundColor = "White";
                    txtPAOCode.style.backgroundColor = "White";
                    txtDDOCode.style.backgroundColor = "White";
                    cmbGovtAddMinistry.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddMinistry.disabled = true;
                    cmbGovtAddMainMinistry.style.backgroundColor = "#E5E5E5";
                    cmbGovtAddMainMinistry.disabled = false;
                    txtMinOtherName.disabled = false;
                    txtMinOtherName.style.backgroundColor = "White";
                    txtAIN.style.backgroundColor = "White"
                }
                else if (deductorType == "8") {
                    cmbGovtAddState.selectedIndex = 0;
                    txtPAOCode.value = '';
                    txtPAOCode.disabled = false;
                    txtPAORegnNo.value = '';
                    txtPAORegnNo.disabled = false;
                    txtDDOCode.value = '';
                    txtDDOCode.disabled = false;
                    txtDDORegnNo.value = '';
                    txtDDORegnNo.disabled = false;
                    cmbGovtAddMinistry.selectedIndex = 0;
                    cmbGovtAddMainMinistry.selectedIndex = 0;
                    txtMinOtherName.value = '';
                    cmbGovtAddState.disabled = false;
                    cmbGovtAddState.style.backgroundColor = "#E5E5E5";
                    txtPAOCode.style.backgroundColor = "White";
                    txtDDOCode.style.backgroundColor = "White";
                    cmbGovtAddMinistry.style.backgroundColor = "White";
                    cmbGovtAddMinistry.disabled = true;
                    cmbGovtAddMainMinistry.style.backgroundColor = "White";
                    cmbGovtAddMainMinistry.disabled = false;
                    txtMinOtherName.disabled = false;
                    txtMinOtherName.style.backgroundColor = "White";
                    txtAIN.style.backgroundColor = "White"
                }
            }
            else {
                cmbGovtAddState.selectedIndex = 0;
                txtPAOCode.value = '';
                txtPAORegnNo.value = '';
                txtDDOCode.value = '';
                txtDDORegnNo.value = '';
                cmbGovtAddMinistry.selectedIndex = 0;
                cmbGovtAddMainMinistry.selectedIndex = 0;
                txtMinOtherName.value = '';
            }
        }
        function EnableSubMinisrtyControls() {

            var cmbGovtAddMinistry = document.getElementById("<%=cmbGovtAddMinistry.ClientID %>");
            var cmbGovtAddMainMinistry = document.getElementById("<%=cmbGovtAddMainMinistry.ClientID %>");
            if (cmbGovtAddMainMinistry.selectedIndex > 0) {
                cmbGovtAddMinistry.disabled = false;
                cmbGovtAddMinistry.selectedIndex = 0;
            }
            else {
                cmbGovtAddMinistry.disabled = true;
                cmbGovtAddMinistry.selectedIndex = 0;
                document.getElementById("<%=txtMinOtherName.ClientID %>").value = "";
            }
        }
    </script>

    <script type="text/javascript" language="javascript">
        function setDates() {
            var fromFinacialYear = document.getElementById("<%=txtFromFY.ClientID %>");
            var toFinancialYear = document.getElementById("<%=txtToFY.ClientID %>");
            var fromAssesmentYear = document.getElementById("<%=txtFromAY.ClientID %>");
            var toAssesmentYear = document.getElementById("<%=txtToAY.ClientID %>");
            if (eval(fromFinacialYear.value) != '') {
                toFinancialYear.value = eval(fromFinacialYear.value) + 1;
                fromAssesmentYear.value = eval(toFinancialYear.value);
                toAssesmentYear.value = eval(fromAssesmentYear.value) + 1;
            }
        }

        function Validation() {
            debugger;
            var isValid = false;
            if (!ValidateLength(document.getElementById("<%=txtDeductorName.ClientID%>"), "Deductor Name", 75, true)) return false;
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2025) {
                if (document.getElementById("<%=txtDeductorBranch.ClientID%>").value.trim() == "") {
                    alert("Specify Country/Region");
                    return false;
                }
            }
            if (!ValidateLength(document.getElementById("<%=txtAddress1.ClientID%>"), "Deductor Flat/Door/Block No.", 25, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtAddress5.ClientID%>"), "Deductor City", 25, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtPincode.ClientID%>"), "PinCode", 6, true)) return false;
            if (!ValidateDropDown(document.getElementById("<%=cmbState.ClientID%>"), "Deductor State")) return false;
            if (ValidateDropDown(document.getElementById("<%=cmbAddressChange.ClientID%>"), "Deductor Address Change") == false) return false;
            if (InputValidations(document.getElementById("<%=txtDeductorName.ClientID%>")) == false) return false;
            //if (InputValidations(document.getElementById("<%=txtDeductorBranch.ClientID%>")) == false) return false;
            if (InputValidations(document.getElementById("<%=txtRPName.ClientID%>")) == false) return false;
            if (InputValidations(document.getElementById("<%=txtRPDesignation.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress1.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress2.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress3.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress4.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress5.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress1.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress2.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress3.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress4.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress5.ClientID%>")) == false) return false;

            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2009 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                if (document.getElementById("<%=txtSTDCode.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtTelephone.ClientID%>"), "Phone No.", 10, true)) return false;
                }
                else if (document.getElementById("<%=txtTelephone.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtSTDCode.ClientID%>"), "STD Code", 5, true)) return false;
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026) {
                if (!ValidateLength(document.getElementById("<%=txtSTDCode.ClientID%>"), "STD Code", 5, true)) return false;
                if (!ValidateLength(document.getElementById("<%=txtTelephone.ClientID%>"), "Phone No.", 10, true)) return false;
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012) {
                if (document.getElementById("<%=txtAlternateSTDCode.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtAlternatePhone.ClientID%>"), "Alternate Phone No.", 10, true)) return false;
                }
                else if (document.getElementById("<%=txtAlternatePhone.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtAlternateSTDCode.ClientID%>"), "Alternate STD Code", 5, true)) return false;
                }
            }

            if (document.getElementById("<%=txtEmail.ClientID%>").value != "") {
                if (!ValidateEmail(document.getElementById("<%=txtEmail.ClientID%>"))) return false;
            }

            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012 && document.getElementById("<%=txtAlternateEmail.ClientID%>").value != "") {
                if (!ValidateEmail(document.getElementById("<%=txtAlternateEmail.ClientID%>"))) {
                    document.getElementById("<%=txtAlternateEmail.ClientID%>").focus();
                    return false;
                }
            }
            var cmbStatus = document.getElementById("<%=cmbStatus.ClientID%>");
            if (cmbStatus.value == "1") {
                if (document.getElementById("<%=txtPAN.ClientID%>").value.toUpperCase() == "PANNOTREQD") {
                }
                else
                    if (!ValidatePAN(document.getElementById("<%=txtPAN.ClientID%>"), "Deductor PAN", 10, true)) return false;
            }
            else {
                if (!ValidatePAN(document.getElementById("<%=txtPAN.ClientID%>"), "Deductor PAN", 10, true)) return false;
            }
            if (!document.getElementById("<%=chkTanApplied.ClientID%>").checked) {
                if (!ValidateTAN(document.getElementById("<%=cmbTAN.ClientID%>"), "Deductor TAN", 10, true)) return false;
            }

            if (!ValidateDropDown(document.getElementById("<%=cmbExistingTDSAssessee.ClientID%>"), "Existing TDS Assesse")) return false;
            if (!ValidateDropDown(cmbStatus, "Status")) return false;
            var cmbDeductorType = document.getElementById("<%=cmbDeductorType.ClientID%>");
            if (!ValidateDropDown(cmbDeductorType, "Deductor Type")) return false;
            if (!ValidateLength(document.getElementById("<%=txtAIN.ClientID%>"), "AIN", 7, false)) return false;
            if (cmbStatus.value == "1") {
                if (cmbDeductorType.value == "3") {
                    if (!ValidateLength(document.getElementById("<%=txtPAOCode.ClientID%>"), "PAO Code", 14, true)) return false;
                    if (!ValidateLength(document.getElementById("<%=txtDDOCode.ClientID%>"), "DDO Code", 20, true)) return false;
                    if (!ValidateDropDown(document.getElementById("<%=cmbGovtAddMainMinistry.ClientID%>"), "Ministry")) return false;
                    if (!ValidateDropDown(document.getElementById("<%=cmbGovtAddMinistry.ClientID%>"), "Sub Ministry")) return false;
                }
                else if (cmbDeductorType.value == "2" || cmbDeductorType.value == "5" || cmbDeductorType.value == "6" || cmbDeductorType.value == "8") {
                    if (!ValidateDropDown(document.getElementById("<%=cmbGovtAddState.ClientID%>"), "State for selected Deductor Type")) return false;
                }
                else if (cmbDeductorType.value == "1" || cmbDeductorType.value == "7") {
                    if (!ValidateDropDown(document.getElementById("<%=cmbGovtAddMainMinistry.ClientID%>"), "Ministry for selected Deductor Type")) return false;
                    if (!ValidateDropDown(document.getElementById("<%=cmbGovtAddMinistry.ClientID%>"), "Sub Ministry for selected Deductor Type")) return false;
                }
                if (cmbDeductorType.value == 99) {
                    if (!ValidateLength(document.getElementById("<%=txtMinOtherName.ClientID%>"), "Ministry Other Name", 75, true)) return false;
                }
                if (cmbDeductorType.value == "3" || cmbDeductorType.value == "6") {
                    if (document.getElementById("<%=txtAIN.ClientID%>").value == "") {
                        alert("AIN is Mandatory for the Deductor Type Central and State Government")
                        document.getElementById("<%=txtAIN.ClientID%>").focus();
                        return false;
                    }
                }
            }
            if (!ValidateStatus(document.getElementById("<%=cmbDeductorType.ClientID%>"), document.getElementById("<%=hdnIsTVExistingInChallans.ClientID%>"))) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPName.ClientID%>"), "Responsible Person Name", 75, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPDesignation.ClientID%>"), "Responsible Person Designation", 20, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPAddress1.ClientID%>"), "Responsible Person Door Number", 25, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPAddress5.ClientID%>"), "Responsible Person City", 25, true)) return false;
            if (!ValidateResponsiblePAN(document.getElementById("<%=txtTan.ClientID%>"), "Responsible Person PAN", 10, true)) return false;
            if (!ValidateDropDown(document.getElementById("<%=cmbRPState.ClientID%>"), "Responsible Person State")) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPPincode.ClientID%>"), "PinCode", 6, true)) return false;
            if (!ValidateDropDown(document.getElementById("<%=cmbRPAddressChange.ClientID%>"), "Responsible Person Address Change")) return false;
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2009 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                if (document.getElementById("<%=txtRPSTDCode.ClientID%>").value.length > 0) {
                if (!ValidateLength(document.getElementById("<%=txtRPPhoneNumber.ClientID%>"), "Responsible Person Phone No.", 10, true)) return false;
                }
                else if (document.getElementById("<%=txtRPPhoneNumber.ClientID%>").value.length > 0) {
                if (!ValidateLength(document.getElementById("<%=txtRPSTDCode.ClientID%>"), "Responsible Person STD Code", 5, true)) return false;
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026) {
                if (!ValidateLength(document.getElementById("<%=txtRPPhoneNumber.ClientID%>"), "Responsible Person Phone No.", 10, true)) return false;
                if (!ValidateLength(document.getElementById("<%=txtRPSTDCode.ClientID%>"), "Responsible Person STD Code", 5, true)) return false;
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012) {
                if (document.getElementById("<%=txtRPSTDCodeAlternate.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtRPPhoneNoAlternate.ClientID%>"), "Alternate Phone No.", 10, true)) return false;
                }
                else if (document.getElementById("<%=txtRPPhoneNoAlternate.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtRPSTDCodeAlternate.ClientID%>"), "Alternate STD Code", 5, true)) return false;
                }
            }
            if (document.getElementById("<%=txtRPEmail.ClientID%>").value != "") {
                if (!ValidateEmail(document.getElementById("<%=txtRPEmail.ClientID%>"), "Responsible Person ", 100, false)) return false;
                else isValid = true;
            }
            else
                isValid = true;

            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026) {
                if (document.getElementById("<%=txtRPCountryRegion.ClientID%>").value == "") {
                    alert("Specify Responsible Person Country/Region");
                    return false;
                }
            }
            if (document.getElementById("<%=txtRPEmailAlternate.ClientID%>").value != "") {
                if (!ValidateEmail(document.getElementById("<%=txtRPEmailAlternate.ClientID%>"), "Responsible Person Alternate", 100, false)) return false;
            }
            if (document.getElementById("<%=txtRPMobileNumber.ClientID%>").value != "") {
                if (document.getElementById("<%=txtRPMobileNumber.ClientID%>").value.length != 10 || document.getElementById("<%=txtRPMobileNumber.ClientID%>").value.substring(0, 1) == "0") {
                    alert("Specify Valid Mobile No");
                    return false;
                }
            }
            var mobileNo = document.getElementById("<%=txtRPMobileNumber.ClientID%>").value;
            if (!(mobileNo.charAt(0) == '6' || mobileNo.charAt(0) == '7' || mobileNo.charAt(0) == '8' || mobileNo.charAt(0) == '9')) {
                alert("Mobile No. should start with 6, 7, 8 or 9");
                return false;
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2009) {
                if (document.getElementById("<%=txtEmail.ClientID%>").value.length == 0 &&
                    document.getElementById("<%=txtRPEmail.ClientID%>").value.length == 0) {
                    alert("Specify ANY ONE of the below \n" +
                        "1. Deductor Email id.\n" +
                        "2. Responsible person Email id.")
                    document.getElementById("<%=txtEmail.ClientID%>").focus();
                    return false;
                }
            }
            if (isValid) {
                document.getElementById("<%=hdnTAN.ClientID%>").value = document.getElementById("<%=cmbTAN.ClientID%>").value;
                if (document.getElementById("<%=cmbTAN.ClientID%>").value.charAt(3) >= '0' && document.getElementById("<%=cmbTAN.ClientID%>").value.charAt(3) <= '9') {
                    if (!confirm("4th character of TAN specified is a number.\nKindle Re-check if number is given by oversight.\n\nDo you want to continue if TAN given is proper?"))
                        return false;
                }
            }
            var GSTIN = document.getElementById("<%=txtGSTIN.ClientID%>").value.trim();
            if (GSTIN.length > 0) {
                if (GSTIN.length == 15) {
                    if (Number(GSTIN.substring(0, 2)) > 37 || Number(GSTIN.substring(0, 2)) == 0) {
                        alert("First 2 characters of the GSTIN(State code) should be between 01 and 37");
                        return false;
                    }
                    if (!ValidateAssesseePAN(GSTIN.substring(2, 12), "PAN", 10, true)) {
                        alert("PAN specified in GSTIN is Invalid.");
                        return false;
                    }
                    if (GSTIN.substring(13, 14).toUpperCase() != 'Z') {
                        alert("14th character of GSTIN should be \"Z\"");
                        return false;
                    }
                }
                var pattern = /^([0-9]){2}([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}([1-9A-Za-z]){1}([Z]){1}([a-zA-Z0-9]){1}?$/;
                var matchArray = GSTIN.match(pattern);
                if (matchArray == null) {
                    alert("Specify valid GSTIN.\nGSTIN should be in the following format.\n1.Characters 1 and 2 represents a valid state code.\n2.Characters 3 through 12 should represent a valid PAN.\n3.Character 13 represents numeric value of entities having same PAN in the state.\n4.Character 14 should always be the alphabet \"Z\" by default.\n5.Character 15 represents a checksum value which can be alphanumeric.");
                    return false;
                }
            }

            if (document.getElementById("<%=hdnIsShowConfirm.ClientID %>").value == "0") {
                onConfirm();
            }
            else {
                document.getElementById("<%=hdnQuarterConfirm.ClientID %>").value = false;
            }

            if (ValidateHtmlTags(document.getElementById("<%=txtDeductorName.ClientID%>").value)) {
                document.getElementById("<%=txtDeductorName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress1.ClientID%>").value)) {
                document.getElementById("<%=txtAddress1.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress2.ClientID%>").value)) {
                document.getElementById("<%=txtAddress2.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress3.ClientID%>").value)) {
                document.getElementById("<%=txtAddress3.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress4.ClientID%>").value)) {
                document.getElementById("<%=txtAddress4.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress5.ClientID%>").value)) {
                document.getElementById("<%=txtAddress5.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPName.ClientID%>").value)) {
                document.getElementById("<%=txtRPName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPFatherName.ClientID%>").value)) {
                document.getElementById("<%=txtRPFatherName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress1.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress1.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress2.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress2.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress3.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress3.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress4.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress4.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress5.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress5.ClientID%>").value = "";
                return false;
            }

            return true;
        }
        function ChangeAoApprovalColor() {
            var txtApprovalNumber = document.getElementById("<%=txtApprovalNumber.ClientID%>");
            var cmbAOApproval = document.getElementById("<%=cmbAOApproval.ClientID%>")
            if (cmbAOApproval.value == "True")
                txtApprovalNumber.style.backgroundColor = "#E5E5E5";
            else
                txtApprovalNumber.style.backgroundColor = "White";
        }
        function ChangeOtherNameColor() {
            var txtMinOtherName = document.getElementById("<%=txtMinOtherName.ClientID%>");
            if (cmbGovtAddMinistry.GetValue() == 99) { txtMinOtherName.style.backgroundColor = '#E5E5E5'; }
            else { txtMinOtherName.style.backgroundColor = 'White'; }
        }
        function EnableDisable() {
            if (document.getElementById("<%=chkTanApplied.ClientID%>").checked == true) {
                document.getElementById("<%=cmbTAN.ClientID%>").value = "TANAPPLIED";
                document.getElementById("<%=cmbTAN.ClientID%>").disabled = true;
            }
            else {
                document.getElementById("<%=cmbTAN.ClientID%>").disabled = false;
                document.getElementById("<%=cmbTAN.ClientID%>").value = "";
            }
        }
        function ValidateStatus(status, isTransferVoucherExistingInChallans) {
            if ((status.value != "3" && status.value != "6") && isTransferVoucherExistingInChallans.value == "1") {
                alert("Since Challan(s) with Transfer Voucher exists,\nDeductor Status cannot be changed.");
                status.focus();
                return false;
            }
            else return true;
        }
        function DisplayControls() {
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
            var rowSTDAlternate = document.getElementById("<%=rowSTDAlternate.ClientID%>");
            var rowEmailAlternate = document.getElementById("<%=rowEmailAlternate.ClientID%>");
            var rowSTDCodeAlternate = document.getElementById("<%=rowSTDCodeAlternate.ClientID%>");
            var rowRPEmailAlternate = document.getElementById("<%=rowRPEmailAlternate.ClientID%>");
            if (Return(finYear) > 2012) {
                rowSTDAlternate.style.display = '';
                rowEmailAlternate.style.display = '';
                rowSTDCodeAlternate.style.display = '';
                rowRPEmailAlternate.style.display = '';
            }
            else {
                rowSTDAlternate.style.display = 'none';
                rowEmailAlternate.style.display = 'none';
                rowSTDCodeAlternate.style.display = 'none';
                rowRPEmailAlternate.style.display = 'none';
            }
        }
        function EnableOtherName(obj) {
            var vale = obj.value;
            var minOtherName = document.getElementById("<%=txtMinOtherName.ClientID%>");

            if (Return(vale) == 99) {
                minOtherName.disabled = false;
            }
            else {
                minOtherName.disabled = true;
            }
        }
        function ValidateResponsiblePAN(objName, objCaption, maxLen, isReq) {
            var value = objName.value;
            if (isReq) {
                if (value.trim().length == 0) {
                    alert("Specify " + objCaption);
                    if (objName.isDisabled != true) {
                        objName.focus();
                    }
                    return false;
                }
            }
            if (value.trim().length > 0) {
                for (var i = 0; i < value.length; i++) {
                    if (value.charAt(i) == ' ') {
                        alert(objCaption + " does not \nallow Blank Spaces. (Ex: AAAAA1234A)");
                        objName.focus();
                        return false;
                    }
                }
                for (var i = 0; i < 5; i++) {
                    if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z')) { ; }
                    else {
                        alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
                        if (document.getElementsByName(objName.name)) {
                            objName.focus();
                        }
                        return false;
                    }
                }
                if (value.charAt(3).toUpperCase() == 'P') {
                    ;
                }
                else {
                    alert("Specify PAN of 'Individual' in\n" + objCaption + " Field. (Ex: AAAPA1234A)")
                    if (document.getElementsByName(objName.name)) {
                        objName.focus();
                    }
                    return false;
                }
                for (var i = 5; i < 9; i++) {
                    if (value.charAt(i) >= '0' && value.charAt(i) <= '9') {
                        ;
                    }
                    else {
                        alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
                        objName.focus();
                        return false;
                    }
                }
                if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) {
                }
                else {
                    alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
                    objName.focus();
                    return false;
                }
                if (value.charAt(3).toUpperCase() != 'P' && value.charAt(3).toUpperCase() != 'H' && value.charAt(3).toUpperCase() != 'C' && value.charAt(3).toUpperCase() != 'J' && value.charAt(3).toUpperCase() != 'F' && value.charAt(3).toUpperCase() != 'A' && value.charAt(3).toUpperCase() != 'T' && value.charAt(3).toUpperCase() != 'B' && value.charAt(3).toUpperCase() != 'L' && value.charAt(3).toUpperCase() != 'G') {
                    alert("Specify valid PAN.");
                    objName.focus();
                    return false;
                }
                return true;
            }
        }
    </script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="up1" runat="server">
        <contenttemplate>
            <asp:HiddenField ID="hdnIs24G" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsEreturnGenerated" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsShowConfirm" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsTVExistingInChallans" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsQuarterLocked" runat="server" Value="0" />
            <asp:HiddenField ID="hdnQuarters" runat="server" Value="" />
            <asp:HiddenField ID="hdnDefaultPan" runat="server" Value="" />
            <asp:HiddenField ID="hdnDefaultStatus" runat="server" Value="" />
            <asp:HiddenField ID="hdnDefaultDeductorType" runat="server" Value="" />
            <asp:HiddenField ID="hdnDeductorID" runat="server" />
            <asp:HiddenField ID="hdnTAN" runat="server" />
            <asp:HiddenField ID="hdnQuarterConfirm" runat="server" Value="false"/>
            <asp:HiddenField ID="hdnFinYear" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnConfirmOrNot" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsJK" runat="server" Value="0" />
            <table class="nTbl">
                <tr>
                    <td valign="top">
                        <table class="nTbl" width="100%">
                            <tr>
                                <td colspan="2">
                                    <b>Deductor Details</b>
                                </td>
                            </tr>
                            <tr>
                                <td valign="top">
                                    <table class="eCol" width="400px">
                                        <tr>
                                            <td class="vHCol">Quarter
                                            </td>
                                            <td class="iCol">
                                                <asp:DropDownList ID="cmbQuarter" runat="server" AutoPostBack="True" CssClass="mdropDownList"
                                                    TabIndex="1" OnSelectedIndexChanged="cmbQuarter_SelectedIndexChanged" Width="100%"
                                                    Font-Size="9">
                                                    <asp:ListItem Text="Quarter1" Value="1"></asp:ListItem>
                                                    <asp:ListItem Text="Quarter2" Value="2"></asp:ListItem>
                                                    <asp:ListItem Text="Quarter3" Value="3"></asp:ListItem>
                                                    <asp:ListItem Text="Quarter4" Value="4"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Name
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtDeductorName" runat="server" CssClass="txtBML" Width="98%"
                                                    Style="text-transform: capitalize" AutoComplete="Off" TabIndex="2" MaxLength="75"
                                                    onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidations(this);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr id="rowBranchDivision" runat="server">
                                            <td class="vHCol">
                                                <asp:Label ID="lblBranchDevision" Text="Branch/Division" runat="server"></asp:Label>
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtDeductorBranch" runat="server" TabIndex="3" CssClass="txtBML" MaxLength="25"
                                                    Width="98%" ReadOnly="True"  onkeypress="return ValidateForAlphaNumeric(event);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Flat /Door / Block No.
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtAddress1" runat="server" CssClass="txtBML" MaxLength="25" TabIndex="4" Width="98%"
                                                    AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Building Name
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtAddress2" runat="server" CssClass="txtBPL" MaxLength="25" TabIndex="5" Width="98%"
                                                    AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Street / Road Name
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtAddress3" runat="server" CssClass="txtBPL" MaxLength="25" TabIndex="6" Width="98%"
                                                    AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Area
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtAddress4" runat="server" CssClass="txtBPL" MaxLength="25" TabIndex="7" Width="98%"
                                                    AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">City
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtAddress5" runat="server" MaxLength="25" CssClass="txtBML" TabIndex="8" Width="98%"
                                                    onkeypress="return ValidateForAlphaNumeric(event);" onchange="return InputValidationsForAddress(this);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Pincode
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtPincode" runat="server" CssClass="txtBML" MaxLength="6" TabIndex="9" Width="98%"
                                                    AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">State
                                            </td>
                                            <td class="iCol">
                                                <asp:DropDownList ID="cmbState" runat="server" Width="98%" CssClass="mdropDownList"
                                                    TabIndex="10" Font-Size="9">
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Address Change
                                            </td>
                                            <td class="iCol">
                                                <asp:DropDownList ID="cmbAddressChange" runat="server" Width="98%" TabIndex="11"
                                                    CssClass="mdropDownList" Font-Size="9">
                                                    <asp:ListItem Text="SELECT" Value="-1"></asp:ListItem>
                                                    <asp:ListItem Text="YES" Value="True"></asp:ListItem>
                                                    <asp:ListItem Text="NO" Value="False"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">STD Code - Phone No.
                                            </td>
                                            <td class="iCol" width="200px">
                                                <table class="nTbl" cellpadding="0px" cellspacing="0px" border="0px">
                                                    <tr>
                                                        <td width="50px">
                                                            <asp:TextBox ID="txtSTDCode" CssClass="txtAR" runat="server" Width="50px" MaxLength="5"
                                                                AutoComplete="Off" TabIndex="12" onkeypress="return ValidateForOnlyNos(event);">
                                                            </asp:TextBox>
                                                        </td>
                                                        <td>
                                                            <asp:TextBox ID="txtTelephone" CssClass="txtAR" runat="server" Width="97%" MaxLength="10"
                                                                AutoComplete="Off" TabIndex="13" onkeypress="return ValidateForOnlyNos(event);">
                                                            </asp:TextBox>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr runat="server" id="rowSTDAlternate">
                                            <td class="vHCol">STD Code - Phone No.(Alternate)
                                            </td>
                                            <td class="iCol" width="200px">
                                                <table class="nTbl" cellpadding="0px" cellspacing="0px" border="0px">
                                                    <tr>
                                                        <td width="50px">
                                                            <asp:TextBox ID="txtAlternateSTDCode" CssClass="txtAR" runat="server" Width="50px"
                                                                MaxLength="5" AutoComplete="Off" TabIndex="14" onkeypress="return ValidateForOnlyNos(event);">
                                                            </asp:TextBox>
                                                        </td>
                                                        <td>
                                                            <asp:TextBox ID="txtAlternatePhone" CssClass="txtAR" runat="server" Width="97%" MaxLength="10"
                                                                AutoComplete="Off" TabIndex="15" onkeypress="return ValidateForOnlyNos(event);">
                                                            </asp:TextBox>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Fax
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtFax" runat="server" CssClass="txtBPL" MaxLength="9" TabIndex="16" Width="97%"
                                                    AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">E-Mail
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtEmail" runat="server" CssClass="txtBPL" MaxLength="75" TabIndex="17"
                                                    Width="97%" AutoComplete="Off">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr id="rowEmailAlternate" runat="server">
                                            <td class="vHCol">E-Mail(Alternate)
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtAlternateEmail" runat="server" CssClass="txtBPL" MaxLength="75" Width="97%"
                                                    TabIndex="18" AutoComplete="Off">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr runat="server" id="trResident">
                                            <td class="vHCol">
                                                <asp:Label ID="lblResident" runat="server" Text="Residential Status"></asp:Label>
                                            </td>
                                            <td class="iCol">
                                                <asp:DropDownList ID="cmbResidentialStatus" runat="server" Width="97%" TabIndex="19"
                                                    CssClass="mdropDownList">
                                                    <asp:ListItem Text="SELECT" Value="-1"></asp:ListItem>
                                                    <asp:ListItem Text="Resident" Value="True"></asp:ListItem>
                                                    <asp:ListItem Text="NonResident" Value="False"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">PAN
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtPAN" runat="server" MaxLength="10" CssClass="txtBML" TabIndex="20" Width="97%"
                                                    AutoComplete="Off" onBlur="ConvertToUC(this);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr id="rowGSTIN" runat="server">
                                            <td class="vHCol">GSTIN
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtGSTIN" runat="server" Width="97%" onBlur="ConvertToUC(this);"
                                                    MaxLength="15" TabIndex="21" CssClass="txtBPL" ToolTip="GSTIN should be in the following format
1.Characters 1 and 2 represents a valid state code.
2.Characters 3 through 12 should represent a valid PAN.
3.Character 13 represents numeric value of entities having same PAN in the state.
4.Character 14 should always be the alphabet 'Z' by default.
5.Character 15 represents a checksum value which can be alphanumeric.">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr id="rowBsrcode" runat="server">
                                            <td class="vHCol">BSR Code (26QAA)
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtBSRCode" runat="server" MaxLength="7" CssClass="txtBPL" Width="97%"
                                                    ToolTip="For Form26QAA Only">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td valign="top">
                                    <table class="eCol">
                                        <tr>
                                            <td class="vHCol">TAN&nbsp;&nbsp;<asp:CheckBox ID="chkTanApplied" runat="server" Text="TANAPPLIED"
                                                Font-Size="X-Small" />
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="cmbTAN" runat="server" TabIndex="21" CssClass="txtBML" MaxLength="10" Width="97%"
                                                    AutoComplete="Off" onBlur="ConvertToUC(this);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Existing TDS Assesse
                                            </td>
                                            <td class="iCol">
                                                <asp:DropDownList ID="cmbExistingTDSAssessee" runat="server" CssClass="mdropDownList" Width="97%"
                                                    BackColor="#E5E5E5" TabIndex="22" Font-Size="9">
                                                    <asp:ListItem Text="SELECT" Value="-1"></asp:ListItem>
                                                    <asp:ListItem Text="YES" Value="True"></asp:ListItem>
                                                    <asp:ListItem Text="NO" Value="False"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">
                                                <asp:Label ID="lblFinYear" Text="Financial Year" runat="server"></asp:Label>
                                            </td>
                                            <td class="iCol">
                                                <table cellpadding="0" cellspacing="0" class="nTbl">
                                                    <tr>
                                                        <td>
                                                            <asp:TextBox ID="txtFromFY" CssClass="txtAR" runat="server" Width="92%" ReadOnly="True"
                                                                TabIndex="23">
                                                            </asp:TextBox>
                                                        </td>
                                                        <td></td>
                                                        <td>
                                                            <asp:TextBox ID="txtToFY" CssClass="txtAR" runat="server" ReadOnly="True" Width="97%"
                                                                TabIndex="24">
                                                            </asp:TextBox>
                                                        </td>

                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Asst. Year
                                            </td>
                                            <td class="iCol">
                                                <table class="nTbl" cellpadding="0" cellspacing="0">
                                                    <tr>
                                                        <td>
                                                            <asp:TextBox ID="txtFromAY" CssClass="txtAR" runat="server" MaxLength="5" Width="92%"
                                                                TabIndex="25" ReadOnly="true">
                                                            </asp:TextBox>
                                                        </td>
                                                        <td>
                                                            <asp:TextBox ID="txtToAY" CssClass="txtAR" runat="server" MaxLength="9" Width="97%"
                                                                TabIndex="26" ReadOnly="true">
                                                            </asp:TextBox>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr runat="server" id="trReturnType">
                                            <td class="vHCol">Return Type
                                            </td>
                                            <td class="iCol">
                                                <asp:DropDownList ID="cmbReturnType" runat="server" TabIndex="27" CssClass="mdropDownList"
                                                    Width="97%" Font-Size="9">
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr style="display: none">
                                            <td class="vHCol">Assessing Officer&#39;s Approval Information
                                            </td>
                                            <td class="iCol" width="100%">
                                                <table cellpadding="0" cellspacing="0" width="100%">
                                                    <tr>
                                                        <td>
                                                            <asp:DropDownList ID="cmbAOApproval" runat="server" CssClass="mdropDownList" TabIndex="28"
                                                                Width="60px" OnChange="ChangeAoApprovalColor();" Font-Size="9">
                                                                <asp:ListItem Text="NO" Value="False"></asp:ListItem>
                                                                <asp:ListItem Text="YES" Value="True"></asp:ListItem>
                                                            </asp:DropDownList>
                                                        </td>
                                                        <td width="100%">
                                                            <asp:TextBox ID="txtApprovalNumber" runat="server" MaxLength="15" TabIndex="29" CssClass="txtBPL"
                                                                Width="97%" AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);">
                                                            </asp:TextBox>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Assessing Officer Designation
                                            </td>
                                            <td class="iCol">
                                                <asp:TextBox ID="txtAODesignation" runat="server" CssClass="txtBPL" TabIndex="30"
                                                    Width="97%" MaxLength="30" AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);">
                                                </asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Status
                                            </td>
                                            <td class="iCol">
                                                <asp:DropDownList ID="cmbStatus" runat="server" CssClass="mdropDownList" TabIndex="31"
                                                    AutoPostBack="true" OnSelectedIndexChanged="cmbStatus_SelectedIndexChanged" Width="100%"
                                                    Font-Size="9">
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="vHCol">Deductor Type
                                            </td>
                                            <td class="iCol">
                                                <asp:DropDownList ID="cmbDeductorType" runat="server" TabIndex="32" CssClass="mdropDownList"
                                                    OnChange="EnableDisableControls();" Width="100%" Font-Size="9">
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="nTbl" style="padding-top: 5px" colspan="2" id="govtDetails">
                                                <div id="rndPanelGovAddList1">
                                                    <div class="dialog" style="width: 100%;">
                                                        <div class="dHeader">
                                                            Govt. AddL. Details
                                                        </div>
                                                        <div style="padding: 10px; border-top: solid 1px gray">
                                                            <asp:Panel ID="rndPanelGovAddList" runat="server">
                                                                <table width="100%">
                                                                    <tr>
                                                                        <td align="left" width="40px" class="vHCol">State
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:DropDownList ID="cmbGovtAddState" runat="server" CssClass="mdropDownList" Width="100%"
                                                                                TabIndex="33" Font-Size="9">
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <asp:Label ID="lblAIN" Text="AIN" runat="server"></asp:Label>
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:TextBox ID="txtAIN" runat="server" MaxLength="7" CssClass="txtBPL" onkeypress="return ValidateForOnlyNos(event);"
                                                                                TabIndex="34">
                                                                            </asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>PAO Code
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <table cellpadding="0" cellspacing="0" width="100%">
                                                                                <tr>
                                                                                    <td>
                                                                                        <asp:TextBox ID="txtPAOCode" CssClass="txtBPL" runat="server" MaxLength="20" Width="60px"
                                                                                            TabIndex="35" onkeypress="return ValidateForAlphaNumeric(event);">
                                                                                        </asp:TextBox>
                                                                                    </td>
                                                                                    <td width="120px" align="center">&nbsp;Regn. No.
                                                                                    </td>
                                                                                    <td>
                                                                                        <asp:TextBox ID="txtPAORegnNo" CssClass="txtBPL" runat="server" MaxLength="7" Width="60px"
                                                                                            TabIndex="36" onkeypress="return ValidateForOnlyNos(event);">
                                                                                        </asp:TextBox>
                                                                                    </td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>DDO Code
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <table cellpadding="0" cellspacing="0" width="100%">
                                                                                <tr>
                                                                                    <td>
                                                                                        <asp:TextBox ID="txtDDOCode" CssClass="txtBPL" runat="server" MaxLength="20" Width="60px"
                                                                                            TabIndex="37" onkeypress="return ValidateForAlphaNumeric(event);">
                                                                                        </asp:TextBox>
                                                                                    </td>
                                                                                    <td align="center" width="120px">Regn. No.
                                                                                    </td>
                                                                                    <td>
                                                                                        <asp:TextBox ID="txtDDORegnNo" CssClass="txtBPL" runat="server" MaxLength="10" Width="60px"
                                                                                            TabIndex="38" onkeypress="return ValidateForAlphaNumeric(event);">
                                                                                        </asp:TextBox>
                                                                                    </td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Ministry
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:DropDownList ID="cmbGovtAddMainMinistry" runat="server" OnChange="EnableSubMinisrtyControls();"
                                                                                CssClass="mdropDownList" TabIndex="39" Width="100%" Font-Size="9">
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Sub Ministry
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:DropDownList ID="cmbGovtAddMinistry" runat="server" CssClass="mdropDownList"
                                                                                TabIndex="40" OnChange="EnableOtherName(this);" Width="100%" Font-Size="9">
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td align="left">Other Name
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:TextBox ID="txtMinOtherName" runat="server" MaxLength="75" CssClass="txtBPL"
                                                                                TabIndex="41" onkeypress="return ValidateDelimiter(this,event);">
                                                                            </asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </asp:Panel>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <table class="nTbl" id="tblResponsiblePerson" runat="server">
                <tr>
                    <td colspan="2">
                        <b>Responsible Person Details</b>
                    </td>
                </tr>
                <tr>
                    <td valign="top">
                        <table class="eCol">
                            <tr>
                                <td class="vHCol">Name
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtRPName" runat="server" BackColor="#E5E5E5" MaxLength="75" Width="97%"
                                        CssClass="txtBML" TabIndex="37" AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);"
                                        onchange="return InputValidations(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Designation
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtRPDesignation" runat="server" BackColor="#E5E5E5" MaxLength="20" Width="97%"
                                        AutoComplete="Off" TabIndex="38" CssClass="txtBML" onkeypress="return ValidateDelimiter(this,event);"
                                        onchange="return InputValidations(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Father&#39;s Name
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtRPFatherName" runat="server" MaxLength="75" Width="97%" CssClass="txtBPL"
                                        TabIndex="39" AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);"
                                        onchange="return InputValidations(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Flat /Door / Block No.
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtRPAddress1" runat="server" BackColor="#E5E5E5" MaxLength="25" Width="97%"
                                        AutoComplete="Off" TabIndex="40" CssClass="txtBML" onkeypress="return ValidateDelimiter(this,event);"
                                        onchange="return InputValidationsForAddress(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Building Name
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtRPAddress2" runat="server" MaxLength="25" CssClass="txtBPL" TabIndex="41" Width="97%"
                                        AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Street / Road Name
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtRPAddress3" runat="server" MaxLength="25" CssClass="txtBPL" TabIndex="42" Width="97%"
                                        AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Area
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtRPAddress4" runat="server" MaxLength="25" CssClass="txtBPL" TabIndex="43" Width="97%"
                                        AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">City
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtRPAddress5" runat="server" MaxLength="25" CssClass="txtBML" TabIndex="44" Width="97%"
                                        AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);" onchange="return InputValidationsForAddress(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                            <tr runat="server" id="tanRegRow">
                                <td class="vHCol">PAN
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtTan" runat="server" CssClass="txtBML" MaxLength="10" TabIndex="45" Width="97%"
                                        AutoComplete="Off" onBlur="ConvertToUC(this);">
                                    </asp:TextBox>
                                </td>
                            </tr>
                        </table>
                    </td>
                    <td valign="top">
                        <table class="eCol">
                            <tr>
                                <td id="top" class="vHCol">
                                    <asp:RadioButton ID="btnMale" runat="server" Checked="True" GroupName="Gender" TabIndex="45"
                                        Text="Male">
                                    </asp:RadioButton>
                                </td>
                                <td class="iCol">
                                    <asp:RadioButton ID="btnFemale" runat="server" GroupName="Gender" Text="Female" TabIndex="46"></asp:RadioButton>
                                </td>
                                <tr>
                                    <td class="vHCol">State
                                    </td>
                                    <td class="iCol">
                                        <asp:DropDownList ID="cmbRPState" runat="server" CssClass="mdropDownList" TabIndex="47"
                                            Width="100%" Font-Size="9">
                                        </asp:DropDownList>
                                    </td>
                                </tr>
                                <tr id="trRPCountryRegion" runat="server" visible="false">
                                    <td class="vHcol">Country/Region</td> 
                                     <td class="iCol">
                                                <asp:TextBox ID="txtRPCountryRegion" runat="server" CssClass="txtBML" MaxLength="25"
                                                    Width="98%" onkeypress="return ValidateForAlphaNumeric(event);">
                                                </asp:TextBox>
                                    </td>
                                </tr>                               
                                <tr>
                                    <td class="vHCol">Pincode
                                    </td>
                                    <td class="iCol">
                                        <asp:TextBox ID="txtRPPincode" runat="server" BackColor="#E5E5E5" MaxLength="6" CssClass="txtBML" Width="97%"
                                            TabIndex="48" AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                        </asp:TextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="vHCol">Address Change
                                    </td>
                                    <td class="iCol">
                                        <asp:DropDownList ID="cmbRPAddressChange" runat="server" CssClass="mdropDownList"
                                            TabIndex="49" Width="100%" Font-Size="9">
                                            <asp:ListItem Text="SELECT" Value="-1"></asp:ListItem>
                                            <asp:ListItem Text="YES" Value="True"></asp:ListItem>
                                            <asp:ListItem Text="NO" Value="False"></asp:ListItem>
                                        </asp:DropDownList>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="vHCol">STD Code - Phone No.
                                    </td>
                                    <td class="iCol">
                                        <table cellpadding="0px" cellspacing="0px" width="100%" border="0px">
                                            <tr>
                                                <td width="50px">
                                                    <asp:TextBox ID="txtRPSTDCode" CssClass="txtAR" runat="server" MaxLength="5" Width="50px"
                                                        TabIndex="50" AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                                    </asp:TextBox>
                                                </td>
                                                <td>
                                                    <asp:TextBox ID="txtRPPhoneNumber" CssClass="txtAR" runat="server" MaxLength="10"
                                                        Width="97%" TabIndex="51" AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr runat="server" id="rowSTDCodeAlternate">
                                    <td class="vHCol">STD Code - Phone No.(Alternate)
                                    </td>
                                    <td class="iCol">
                                        <table cellpadding="0px" cellspacing="0px" width="100%" border="0px">
                                            <tr>
                                                <td width="50px">
                                                    <asp:TextBox ID="txtRPSTDCodeAlternate" CssClass="txtAR" runat="server" MaxLength="5"
                                                        Width="50px" TabIndex="52" AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                                    </asp:TextBox>
                                                </td>
                                                <td>
                                                    <asp:TextBox ID="txtRPPhoneNoAlternate" CssClass="txtAR" runat="server" MaxLength="10"
                                                        Width="97%" TabIndex="53" AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="vHCol">Fax
                                    </td>
                                    <td class="iCol">
                                        <asp:TextBox ID="txtRPFax" runat="server" MaxLength="9" CssClass="txtBPL" TabIndex="54" Width="97%"
                                            AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                        </asp:TextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="vHCol">E-Mail
                                    </td>
                                    <td class="iCol">
                                        <asp:TextBox ID="txtRPEmail" runat="server" MaxLength="75" CssClass="txtBPL" TabIndex="55" Width="97%"
                                            AutoComplete="Off">
                                        </asp:TextBox>
                                    </td>
                                </tr>
                                <tr runat="server" id="rowRPEmailAlternate">
                                    <td class="vHCol">E-Mail(Alternate)
                                    </td>
                                    <td class="iCol">
                                        <asp:TextBox ID="txtRPEmailAlternate" runat="server" MaxLength="75" CssClass="txtBPL"
                                            TabIndex="56" Width="97%" AutoComplete="Off">
                                        </asp:TextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="vHCol">Mobile No.
                                    </td>
                                    <td class="iCol">
                                        <asp:TextBox ID="txtRPMobileNumber" runat="server" MaxLength="10" CssClass="txtBPL" Width="97%"
                                            BackColor="#E5E5E5" AutoComplete="Off" TabIndex="57" onkeypress="return ValidateForOnlyNos(event);">
                                        </asp:TextBox>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="padding-top: 5px">
                                        <asp:HyperLink ID="hlnkTanRegistration" Text="Get Registration No" runat="server"
                                            Visible="false" NavigateUrl="~/OnlineTanRegistration/OnlineTANRegistration.aspx">
                                        </asp:HyperLink>
                                    </td>
                                </tr>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <table class="nTbl">
                <tr>
                    <td class="iCol">
                        <table>
                            <tr>
                                <td>
                                    <asp:Button ID="btnSave" runat="server" CssClass="cmnBtn" OnClick="btnSave_Click"
                                        TabIndex="58" OnClientClick="return Validation()" Text="Save"></asp:Button>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </contenttemplate>
    </asp:UpdatePanel>
</asp:Content>
