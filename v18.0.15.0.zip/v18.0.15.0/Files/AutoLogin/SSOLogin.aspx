﻿<%@ page language="C#" autoeventwireup="true" inherits="AutoLogin_SSOLogin, App_Web_ssologin.aspx.565b7090" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>SSO Login</title>
    <style type="text/css">
        body {
            font-size: 8pt;
            color: Black;
            font-family: Verdana Arial Tahoma;
            font-family: Tahoma;
            font-size: small;
            background: #d5dadd repeat-x left top;
        }

        .dialog {
            background-color: #f4f5f6;
            border: solid 1px gray;
            border-radius: 5px;
        }

        .dHeader {
            background: Black;
            color: White;
            font-size: 12pt;
            font-weight: bold;
            padding: 4px 4px 4px 10px;
            text-align: center;
            border-radius: 5px;
        }

        .Button {
            background: Black;
            border: solid 1px grey;
            font-family: Arial, sans-serif;
            font-size: 12px;
            font-weight: bold;
            color: White;
            height: 25px;
            cursor: hand;
            width: 95px;
            border-radius: 5px;
        }

            .Button:hover {
                background: lightgrey;
                border: outset 2px grey;
                color: Black;
            }
    </style>
    <script type="text/javascript">        
		function ImportantMessage() {
			alert("Branches are reminded that verification of TDS entries in Saral TDS\nis a time-bound activity.\n\nIt must invariably be completed within the same month\nto which the entries pertain so as to avoid discrepancies\nin TDS computation, deduction and subsequent reporting to the Income Tax Department.");
			return true;
        }
    </script>
</head>
<body>
    <form id="frmAutoLogin" runat="server">
        <asp:ScriptManager ID="ScriptManager1" runat="server">
        </asp:ScriptManager>
        <asp:UpdatePanel ID="deductionUpdatePanel" runat="server">
            <ContentTemplate>
                <asp:HiddenField ID="hdnDecrypted" runat="server" />
                <asp:HiddenField ID="hdnDecr" runat="server" />
                <asp:HiddenField ID="ispostback" runat="server" Value="0" />
                <asp:MultiView ID="mvAutoLogin" runat="server" ActiveViewIndex="0">
                    <asp:View ID="vwFinYear" runat="server">
                        <table style="width: 100%; height: 500px;" align="center">
                            <tr>
                                <td style="width: 100%;">
                                    <center>
                                        <div id="loginDiv" style="vertical-align: middle;">
                                            <div class="dHeader" style="width: 250px">
                                                SaralTDS Web
                                            </div>
                                            <div style="width: 250px">
                                                <table style="width: 250px">
                                                    <tr>
                                                        <td>
                                                            <asp:Label ID="lblDetails" runat="server" Text=""></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr id="trFinancialYear" runat="server">
                                                        <td style="width: 100%; text-align: center">
                                                            <asp:Label ID="lblYear" Text="Financial Year" runat="server"/>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%;">
                                                            <asp:DropDownList ID="ddlFinYear" runat="server" Font-Size="Large" Width="250px"
                                                                AutoPostBack="true" OnSelectedIndexChanged="ddlFinYear_SelectedIndexChanged">
                                                                <asp:ListItem Text="2026-27" Value="2026"></asp:ListItem>
                                                                <asp:ListItem Text="2025-26" Value="2025"></asp:ListItem>
                                                                <asp:ListItem Text="2024-25" Value="2024"></asp:ListItem>
                                                                <asp:ListItem Text="2023-24" Value="2023"></asp:ListItem>
                                                                <asp:ListItem Text="2022-23" Value="2022"></asp:ListItem>
                                                                <asp:ListItem Text="2021-22" Value="2021"></asp:ListItem>
                                                                <asp:ListItem Text="2020-21" Value="2020"></asp:ListItem>
                                                                <asp:ListItem Text="2019-20" Value="2019"></asp:ListItem>
                                                                <asp:ListItem Text="2018-19" Value="2018"></asp:ListItem>
                                                                <asp:ListItem Text="2017-18" Value="2017"></asp:ListItem>
                                                                <asp:ListItem Text="2016-17" Value="2016"></asp:ListItem>
                                                                <asp:ListItem Text="2015-16" Value="2015"></asp:ListItem>
                                                                <asp:ListItem Text="2014-15" Value="2014"></asp:ListItem>
                                                                <asp:ListItem Text="2013-14" Value="2013"></asp:ListItem>
                                                                <asp:ListItem Text="2012-13" Value="2012"></asp:ListItem>
                                                                <asp:ListItem Text="2011-12" Value="2011"></asp:ListItem>
                                                            </asp:DropDownList>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%; text-align: center; vertical-align: middle">
                                                            <asp:Button ID="btnLogin" runat="server" CssClass="Button" Text="Login"
                                                                Width="150px" OnClientClick="return ImportantMessage()" OnClick="btnLogin_Click" />
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </center>
                                </td>
                            </tr>
                        </table>
                    </asp:View>
                    <asp:View ID="vwSwitchBranch" runat="server">
                        <table cellpadding="0" cellspacing="0" width="100%" style="vertical-align: middle; height: 600px">
                            <tr>
                                <td align="center">
                                    <div>
                                        <div class="dialog" style="text-align: left; width: 332px;">
                                            <div class="dHeader">
                                                Select Branch for login
                                            </div>
                                            <div style="padding: 10px; border-top: solid 1px gray">
                                                <table width="100%">
                                                    <tr id="filterRow" runat="server">
                                                        <td>
                                                            <table width="100%">
                                                                <tr>
                                                                    <td style="width: 50px">Filter
                                                                    </td>
                                                                    <td>
                                                                        <input autocomplete="Off" name="regexp" style="border: 1px solid #9f9f9f; font-family: tahoma; width: 237px; text-align: left;"
                                                                            onkeyup="myfilter.set(this.value)" />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:ListBox ID="lstBranches" runat="server" Width="300px" Height="220px" Font-Size="10"></asp:ListBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <table width="100%">
                                                                <tr>
                                                                    <td align="center">
                                                                        <asp:Button ID="btnSelect" runat="server" Text="Select" CssClass="Button" Width="80px" />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </asp:View>
                </asp:MultiView>
            </ContentTemplate>
        </asp:UpdatePanel>
        <div style="width: 75%; padding-left: 150px; position: absolute; bottom: 50px;">
            <marquee id="mrq" onmouseover="this.stop()" onmouseout="this.start()" runat="server"
                style="font-weight: bold"></marquee>
        </div>
    </form>
</body>
</html>
