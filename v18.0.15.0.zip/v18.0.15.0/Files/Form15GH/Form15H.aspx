﻿<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Form15GH_Form15H, App_Web_form15h.aspx.a661c1ec" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">

    <script type="text/javascript">
        function Validation() {
            if (Number(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2025) {
                var IsUinManual = document.getElementById("<%=hdnIsUinManual.ClientID%>").value;
                var Name = document.getElementById("<%=txtName.ClientID%>").value;
                var DOB = document.getElementById("<%=txtAssesseeDOB.ClientID%>").value;
                var EstimatedIncPY = document.getElementById("<%=txtEstimatedIncPY.ClientID%>").value;
                var EstimatedInc = document.getElementById("<%=txtEstimatedInc.ClientID%>").value;
                var TotalForm = document.getElementById("<%=txtTotalForm.ClientID%>").value;
                var UIN = document.getElementById("<%=txtUIN.ClientID%>").value;
                var PaidDate = document.getElementById("<%=txtPaidDate.ClientID%>").value;
                var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
                if (!ValidateDeducteeName(document.getElementById("<%=hdnDeducteeID.ClientID%>"))) return false;
                if (Name == '' && DOB == '' && EstimatedIncPY == '' && EstimatedInc == '' && TotalForm == '' && PaidDate == '') {
                    alert("Enter All Fields.");
                    return false;
                }
                if (Name == "") {
                    alert("Specify valid Name.");
                    return false;
                }
                if (DOB == "") {
                    alert("Specify valid Date Of Birth.");
                    return false;
                }
                if (document.getElementById("<%=ddlTaxAssessedFlag.ClientID%>").value == "-1") {
                    alert("Select Country/Region");
                    return false;
                }
                if (document.getElementById("<%=ddlTaxAssessedFlag.ClientID%>").selectedOptions[0].text.toUpperCase() == "OTHERS"
                    && document.getElementById("<%=txtCountryOther.ClientID%>").value == "") {
                    alert("Specify Country (If others)");
                    return false;
                }
                if (EstimatedInc == '' || EstimatedInc <= 0) {
                    alert("Specify Estimated income for which this declaration is made.");
                    return false;
                }
                if (EstimatedIncPY == '' || EstimatedIncPY <= 0) {
                    alert("Specify Estimated total income of the Tax Year of the declarant.");
                    return false;
                }
                if (TotalForm == '' || TotalForm <= 0) {
                    alert("Specify Aggregate amt of inc. for which declaration is made during the tax year.");
                    return false;
                }
                if (IsUinManual == "1") {
                    if (UIN == "") {
                        alert("Specify the Unique Identification No.");
                        return false;
                    }
                    else {
                        if (UIN == "D000000000" || UIN == "d000000000") {
                            alert("Specify valid Unique Identification No.");
                            return false;
                        }
                        else {
                            var UINPattern = /^[Dd]{1}[0-9]{9}$/;
                            var matchArray = UIN.match(UINPattern);
                            if (matchArray == null) {
                                alert("Specify valid Unique Identification No. Ex.D000000001");
                                return false;
                            }
                        }
                    }
                }
                if (EstimatedIncPY < EstimatedInc) {
                    alert("Estimated total income cannot be less than Estimated income");
                    return false;
                }
                var paidDateText = document.getElementById("<%=txtPaidDate.ClientID%>").value;

                if (paidDateText != "") {

                    var parts = paidDateText.split("/");
                    var paidDate = new Date(
                        parts[2],
                        new Date(Date.parse(parts[1] + " 1, 2000")).getMonth(),
                        parts[0]
                    );

                    var finYear = Number(document.getElementById("<%=hdnFinYear.ClientID%>").value);

                    var fromDate = new Date(finYear, 3, 1);
                    var toDate = new Date(finYear + 1, 2, 31);

                    if (paidDate < fromDate || paidDate > toDate) {
                        alert("Date of declaration received should be within the Tax Year.");
                        return false;
                    }
                }
                else {
                    alert("Specify Date on Which Declaration is received.");
                    return false;
                }
                var today = new Date();
                today.setHours(0, 0, 0, 0);

                if (paidDate > today) {
                    alert("Date of declaration received cannot be a future date.");
                    return false;
                }

                var financialYearStart = new Date(finYear, 3, 1);       // 01-Apr-YYYY
                var financialYearEnd = new Date(finYear + 1, 2, 31);    // 31-Mar-YYYY+1

                // Financial year validation
                if (paidDate < financialYearStart || paidDate > financialYearEnd) {
                    alert("Date of declaration received should be within the selected Tax year.");
                    return false;
                }

                if (DOB) {
                    var parts = DOB.split("/"); // dd/MM/yyyy
                    var dobDate = new Date(parts[2], parts[1] - 1, parts[0]);

                    var today = new Date();
                    today.setHours(0, 0, 0, 0);

                    if (dobDate > today) {
                        alert("Date Of Birth cannot be future date.");
                        return false;
                    }
                }
            }
            else {
                var IsUinManual = document.getElementById("<%=hdnIsUinManual.ClientID%>").value;
                var Name = document.getElementById("<%=txtName.ClientID%>").value;
                var DOB = document.getElementById("<%=txtAssesseeDOB.ClientID%>").value;
                var EstimatedIncPY = document.getElementById("<%=txtEstimatedIncPY.ClientID%>").value;
                var EstimatedInc = document.getElementById("<%=txtEstimatedInc.ClientID%>").value;
                var AggregateAmount = document.getElementById("<%=txtAggregateAmount.ClientID%>").value;
                var TotalForm = document.getElementById("<%=txtTotalForm.ClientID%>").value;
                var DeclarationDate = document.getElementById("<%=txtDeclarationDate.ClientID%>").value;
                var UIN = document.getElementById("<%=txtUIN.ClientID%>").value;
                var IncPaid = document.getElementById("<%=txtIncPaid.ClientID%>").value;
                var PaidDate = document.getElementById("<%=txtPaidDate.ClientID%>").value;
                if (!ValidateDeducteeName(document.getElementById("<%=hdnDeducteeID.ClientID%>"))) return false;
                if (Name == '' && DOB == '' && EstimatedIncPY == '' && EstimatedInc == '' && AggregateAmount == '' && TotalForm == '' && DeclarationDate == '' && PaidDate == '') {
                    alert("Enter All Fields.");
                    return false;
                }
                if (Name == "") {
                    alert("Specify valid Name.");
                    return false;
                }
                if (DOB == "") {
                    alert("Specify valid Date Of Birth.");
                    return false;
                }
                if (document.getElementById("<%=ddlTaxAssessedFlag.ClientID%>").value == "-1") {
                    alert("Select whether you assessed to tax under the Income-tax Act,1961 Y/N");
                    return false;
                }
                if (document.getElementById("<%=ddlTaxAssessedFlag.ClientID%>").value == "Y") {
                    if (document.getElementById("<%=ddlAssessmentYear.ClientID%>").value == "0") {
                        alert("Select Latest Assessment Year for which assessed.");
                        return false;
                    }
                    else if ((document.getElementById("<%=ddlAssessmentYear.ClientID%>").value) > (document.getElementById("<%=hdnFinYear.ClientID%>").value)) {
                        var AY1 = Number(document.getElementById("<%=hdnFinYear.ClientID%>").value); // - Number(1);
                        var tmpAY = Number(AY1) + Number(1);
                        var strAY = String(tmpAY);
                        var AY2 = strAY.substring(2, 4);
                        alert("Latest Assessment Year is allowed upto AY " + AY1 + "-" + AY2 + ".");
                        return false;
                    }
                    else {
                        document.getElementById("<%=ddlAssessmentYear.ClientID%>").disabled = false;
                    }
                }
                if (EstimatedInc == "" || EstimatedInc == "0") {
                    alert("Specify valid Estimated income for which this declaration is made and should be greater than zero.");
                    return false;
                }
                if (EstimatedIncPY == "" || EstimatedIncPY == "0") {
                    alert("Specify valid Estimated total income of the P.Y. and should be greater than zero");
                    return false;
                }
                if (TotalForm == "") {
                    alert("Specify Total No. of Form No. 15H filed.");
                    return false;
                }
                if (AggregateAmount == "") {
                    alert("Specify valid Aggregate amount of income for which Form No. 15H filed.");
                    return false;
                }
                if (TotalForm != "" && TotalForm != "0") {
                    if (AggregateAmount == "0") {
                        alert("No. of Form 15G Filed is present. Aggregate Amount of Income should be greater than zero.");
                        return false;
                    }
                }
                if (AggregateAmount != "" && AggregateAmount != "0") {
                    if (TotalForm == "0") {
                        alert("Aggregate Amount is present. No. of Form 15G should be greater than zero.");
                        return false;
                    }
                }
                if (DeclarationDate == "") {
                    alert("Specify valid Date on which Declaration is received.");
                    return false;
                }
                if (IsUinManual == "1") {
                    if (UIN == "") {
                        alert("Specify the Unique Identification No.");
                        return false;
                    }
                    else {
                        if (UIN == "H000000000" || UIN == "h000000000") {
                            alert("Specify valid Unique Identification No.");
                            return false;
                        }
                        else {
                            var UINPattern = /^[H\h]{1}[0-9]{9}$/;
                            var matchArray = UIN.match(UINPattern);
                            if (matchArray == null) {
                                alert("Specify valid Unique Identification No. Ex.H000000001");
                                return false;
                            }
                        }
                    }
                }
                if (IncPaid == "") {
                    alert("Specify the Amount of Income Paid.");
                    return false;
                }
                if (PaidDate == "") {
                    alert("Specify valid Date on which the income has been paid/credited.");
                    return false;
                }
                if (DeclarationDate != "" && PaidDate != "") {
                    if (!ValidDate()) return false;
                    if (!ValidDateByFinyaer()) return false;
                }
                if (EstimatedIncPY != "") {
                    if (!ValidateSenior()) return false;
                }
                if (Number(EstimatedInc) > Number(EstimatedIncPY)) {
                    alert("Estimated Total Income of the P.Y. Should be same or greater than Estimated Income.");
                    return false;
                }
            }
            return true;
        }
        function ValidateDeducteeName(deducteeID) {
            if (deducteeID.value == "-1") {
                alert("Specify valid Deductee Name.");
                document.getElementById("<%=txtName.ClientID%>").focus();
                return false;
            }
            return true;
        }
        function ValidateSenior() {
            var Senior = 0;
            var SuperSenior = 0;
            var DOB = document.getElementById("<%=txtAssesseeDOB.ClientID%>").value;
            var EstimatedIncPY = document.getElementById("<%=txtEstimatedIncPY.ClientID%>").value;
            var finYear = Number(document.getElementById("<%=hdnFinYear.ClientID%>").value) + Number(1);
            var DOBMonth = parseInt(DOB.substring(3, 5), 10);
            var DOBYear = parseInt(DOB.substring(6, 10), 10);
            if ((finYear - DOBYear) >= 60 && (finYear - DOBYear) <= 80) {
                if ((finYear - DOBYear) == 80 && DOBMonth > 3) {
                    Senior = 1;
                }
                else if ((finYear - DOBYear) == 80 && DOBMonth < 4) {
                    SuperSenior = 2;
                }
                else {
                    Senior = 1;
                }
            }
            if ((finYear - DOBYear) > 80) {
                SuperSenior = 2;
            }
            if (EstimatedIncPY > 500000 && Senior == 1) {
                alert("Form 15H cannot be accepted if the estimated income exceeds Rs. 5.00 Lakhs in case of Senior/Super Senior Citizen, \nEnsure correct reporting as per IT Act.");
                return false;
            }
            else if (EstimatedIncPY > 500000 && SuperSenior == 2) {
                alert("Form 15H cannot be accepted if the estimated income exceeds Rs. 5.00 Lakhs in case of Senior/Super Senior Citizen, \nEnsure correct reporting as per IT Act.");
                return false;
            }
            else {
                return true;
            }
        }
        function ValidDateByFinyaer() {
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
            var finyearNub = Number(finYear) + Number(1)
            var declarationDate = document.getElementById("<%=txtDeclarationDate.ClientID%>").value.split('/');
            var paymentDate = document.getElementById("<%=txtPaidDate.ClientID%>").value.split('/');
            if (finYear > declarationDate[2]) {
                alert("Declaration Date within financial Year.");
                return false;
            }
            else if (finYear == declarationDate[2] && declarationDate[1] < 4) {
                alert("Declaration Date within financial Year.");
                return false;
            }
            else if (finyearNub == declarationDate[2] && declarationDate[1] > 3) {
                alert("Declaration Date within financial Year.");
                return false;
            }
            else {
                return true;
            }
            if (finYear > paymentDate[2]) {
                alert("Payment Date within financial Year.");
                return false;
            }
            else if (finYear == paymentDate[2] && paymentDate[1] < 4) {
                alert("Payment Date within financial Year.");
                return false;
            }
            else if (finyearNub == paymentDate[2] && paymentDate[1] > 3) {
                alert("Payment Date within financial Year.");
                return false;
            }
            else {
                return true;
            }
        }
        function ValidDate() {
            var Months = 'JanFebMarAprMayJunJulAugSepOctNovDec';
            var declarationDate = document.getElementById("<%=txtDeclarationDate.ClientID%>").value.split('/');
            var paymentDate = document.getElementById("<%=txtPaidDate.ClientID%>").value.split('/');
            var d2declarationDate = Months.substr((declarationDate[1] - 1) * 3, 3) + ' ' + declarationDate[0] + ', ' + declarationDate[2];
            var d1paymentDate = Months.substr((paymentDate[1] - 1) * 3, 3) + ' ' + paymentDate[0] + ', ' + paymentDate[2];
            d2declarationDate = Date.parse(d2declarationDate);
            d1paymentDate = Date.parse(d1paymentDate);
            if (d2declarationDate > d1paymentDate) {
                alert("Payment Date should be same or after the declaration date.");
                return false;
            }
            else
                return true;
        }
        function DOBDateFormat(ObjectName) {
            var stringValue;
            var finYear = Number(document.getElementById("<%=hdnFinYear.ClientID%>").value) + Number(1);
            var arrDate = new Array();
            var arrInput = new Array();
            var counter = 0;
            stringValue = ObjectName.value.trim()
            if (stringValue.length > 0) {
                if (stringValue.indexOf('/') > 0) {
                    arrInput = stringValue.split('/');
                }
                else if (stringValue.indexOf('\\') > 0) {
                    arrInput = stringValue.split('\\');
                }
                else if (stringValue.indexOf('.') > 0) {
                    arrInput = stringValue.split('.');
                }
                else if (stringValue.indexOf('-') > 0) {
                    arrInput = stringValue.split('-');
                }
                else if (stringValue.indexOf(',') > 0) {
                    arrInput = stringValue.split(',');
                }
                else if (stringValue.indexOf(' ') > 0) {
                    arrInput = stringValue.split(' ');
                }
                if (arrInput == '') {
                    alert("Date should be in dd/MM/yyyy");
                    ObjectName.select();
                    ObjectName.focus();
                    return;
                }
                for (i = 0; i < arrInput.length; i++) {
                    if (arrInput[i].trim() == '') {

                    }
                    else {
                        arrDate[counter++] = arrInput[i].trim();
                    }
                }
                if (arrDate.length != 3) {
                    alert('Not a valid date');
                    ObjectName.select();
                    ObjectName.focus();
                    return;
                }
                for (i = 0; i < arrDate.length; i++) {
                    if (isNaN(arrDate[i].trim())) {
                        alert('Not a valid date');
                        ObjectName.select();
                        ObjectName.focus();
                        return;
                    }
                }
                arrDate[0] = String(Number(arrDate[0]));
                arrDate[1] = String(Number(arrDate[1]));
                for (i = 0; i < arrDate.length; i++) {
                    if ((i == 0 || i == 1) && arrDate[i].trim().length == 1) {
                        arrDate[i] = '0' + arrDate[i].trim();
                    }
                    if (i == 2) {
                        if (arrDate[i].trim().length == 1) {
                            arrDate[i] = '200' + arrDate[i];
                        }
                        else if (arrDate[i].trim().length == 2) {
                            arrDate[i] = '20' + arrDate[i];
                        }
                        else if (arrDate[i].trim().length == 3) {
                            arrDate[i] = '2' + arrDate[i];
                        }
                    }
                }
                if (Number(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026){
                    for (i = 0; i < arrDate.length; i++) {
                        if ((finYear - arrDate[2]) == 60 && arrDate[1] > 3) {
                            alert("Enter Valid Date of Birth");
                            ObjectName.focus();
                            ObjectName.select();
                            return;
                        }
                        if ((finYear - arrDate[2]) < 60 || (arrDate[2] < 1900)
                            || (arrDate[0] < 1 || arrDate[0] > 31 || arrDate[1] < 1 || arrDate[1] > 12)
                            || ((arrDate[1] == 1 || arrDate[1] == 3 || arrDate[1] == 5 || arrDate[1] == 7 || arrDate[1] == 8 || arrDate[1] == 10 || arrDate[1] == 12) && arrDate[0] > 31)
                            || ((arrDate[1] == 04 || arrDate[1] == 06 || arrDate[1] == 9 || arrDate[1] == 11) && arrDate[0] > 30)
                            || ((arrDate[2] % 4) == 0 && arrDate[1] == 2 && arrDate[0] > 29)
                            || ((arrDate[2] % 4) != 0 && arrDate[1] == 2 && arrDate[0] > 28)) {
                            alert("Enter Valid Date of Birth");
                            ObjectName.focus();
                            ObjectName.select();
                            return;
                        }
                    }
                }
                ObjectName.value = arrDate[0] + '/' + arrDate[1] + '/' + arrDate[2];
            }
        }
        function GetDeducteeIdValue(source, eventArgs) {
            var content = eventArgs.get_value();
            var arr = new Array();
            arr = content.indexOf(';') != -1 ? content.split(';') : content.split('-');
            if (document.getElementById("<%=txtName.ClientID%>").value != "") {
                document.getElementById("<%=hdnDeducteeID.ClientID%>").value = arr[0];
                document.getElementById("<%=txtCustomerID.ClientID%>").value = arr[1];
                if (!GetQuarter()) return false;
            }
            if (document.getElementById("<%=hdnDeducteeID.ClientID%>").value != document.getElementById("<%=hdnDeducteeIDOld.ClientID%>").value) {
                document.getElementById("<%=txtUIN.ClientID%>").value = "";
                document.getElementById("<%=hdnUniqueIDNumber.ClientID%>").value = "0";
            }
        }
        function GetQuarter() {
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
            var quarter = document.getElementById("<%=hdnQuarter.ClientID%>").value;
            if (finYear < 2026) {
                if (quarter == 1) {
                    document.getElementById("<%=txtPaidDate.ClientID%>").value = "30/6/" + finYear;
                }
                else if (quarter == 2) {
                    document.getElementById("<%=txtPaidDate.ClientID%>").value = "30/9/" + finYear;
                }
                else if (quarter == 3) {
                    document.getElementById("<%=txtPaidDate.ClientID%>").value = "31/12/" + finYear;
                }
                else if (quarter == 4) {
                    document.getElementById("<%=txtPaidDate.ClientID%>").value = "31/3/" + (Number(finYear) + Number(1));
                }
            }
            return true;
        }
        function TaxAssessedStatus() {
            if (document.getElementById("<%=hdnFinYear.ClientID %>").value < 2026) {
                var ddlTaxAssessedFlag = document.getElementById("<%=ddlTaxAssessedFlag.ClientID %>");
                var ddlAssessmentYear = document.getElementById("<%=ddlAssessmentYear.ClientID %>");
                if (ddlTaxAssessedFlag.value == "Y") {
                    ddlAssessmentYear.disabled = false;
                    ddlAssessmentYear.selectedIndex = 0;
                }
                else {
                    ddlAssessmentYear.disabled = true;
                    ddlAssessmentYear.selectedIndex = 0;
                }
            }
        }
        function ValidateLoadAll() {
            return confirm("Loading all details will take time.\nRecommend to use search filters.\n\nDo you want to continue?");
        }
        function FormatSearch() {
            var SearchIncomeFrom = document.getElementById("<%=txtSearchIncomeFrom.ClientID%>");
            var SearchPan = document.getElementById("<%=txtSearchPAN.ClientID%>");
            var SearchIncomeTo = document.getElementById("<%=txtSearchIncomeTo.ClientID%>");
            var SearchDeclarationDateFrom = document.getElementById("<%=txtSearchDeclarationDateFrom.ClientID%>");
            var SearchDeclarationDateTo = document.getElementById("<%=txtSearchDeclarationDateTo.ClientID%>");
            var SearchName = document.getElementById("<%=txtSearchName.ClientID%>");
            var SearchCustomerID = document.getElementById("<%=txtSearchCustomerID.ClientID%>");

            if (SearchIncomeFrom.value.trim() == "" && SearchIncomeTo.value.trim() == "" && SearchDeclarationDateFrom.value.trim() == "" && SearchDeclarationDateTo.value.trim() == "" && SearchName.value.trim() == "" && SearchPan.value.trim() == "" && SearchCustomerID.value.trim() == "") {
                var confirmLoad;
                if (confirm("Loading all details will take time.\nRecommend to use search filters.\n\nDo you want to continue?") == true) {
                    return true;
                } else {
                    return false;
                }
            }
            else {
                if ((SearchIncomeFrom.value != "") && (SearchIncomeTo.value == "")) {
                    SearchIncomeTo.value = SearchIncomeFrom.value;
                }
                else if ((SearchIncomeFrom.value == "") && (SearchIncomeTo.value != "")) {
                    SearchIncomeFrom.value = SearchIncomeTo.value;
                }
                else if ((SearchIncomeFrom.value != "") && (SearchIncomeTo.value != "")) {
                    if (eval(SearchIncomeTo.value) < eval(SearchIncomeFrom.value)) {
                        var temp = SearchIncomeFrom.value;
                        SearchIncomeFrom.value = SearchIncomeTo.value;
                        SearchIncomeTo.value = temp;
                    }
                }
                if ((SearchDeclarationDateFrom.value.trim() != "") && (SearchDeclarationDateTo.value.trim() == "")) {
                    SearchDeclarationDateTo.value = SearchDeclarationDateFrom.value;
                }
                else if ((SearchDeclarationDateFrom.value.trim() == "") && (SearchDeclarationDateTo.value.trim() != "")) {
                    SearchDeclarationDateFrom.value = SearchDeclarationDateTo.value;
                }
                if (!CheckDate(SearchDeclarationDateFrom.value, SearchDeclarationDateTo.value)) {
                    var temp = SearchDeclarationDateTo.value;
                    SearchDeclarationDateTo.value = SearchDeclarationDateFrom.value;
                    SearchDeclarationDateFrom.value = temp;
                }
            }
        }
        function CheckDate(fromDate, toDate) {
            var fromDateDay = parseInt(fromDate.substring(0, 2), 10);
            var fromDateMonth = parseInt(fromDate.substring(3, 5), 10);
            var fromDateYear = parseInt(fromDate.substring(6, 10), 10);
            var toDatedDay = parseInt(toDate.substring(0, 2), 10);
            var toDatedMonth = parseInt(toDate.substring(3, 5), 10);
            var toDatedYear = parseInt(toDate.substring(6, 10), 10);
            var fromDateTocheck = new Date(fromDateYear, fromDateMonth - 1, fromDateDay);
            var toDateCheck = new Date(toDatedYear, toDatedMonth - 1, toDatedDay);
            if (toDateCheck < fromDateTocheck) {
                return false;
            }
            return true;
        }
        function ClearDeducteeName() {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) {
            }
            else {
                document.getElementById("<%=hdnDeducteeID.ClientID%>").value = "-1";
            }
        }
        function ValidateIncomeDetails() {
            var accId = document.getElementById("<%=txtAccID.ClientID%>").value;
            var Nature = document.getElementById("<%=txtNature.ClientID%>").value;
            var Section = document.getElementById("<%=ddlSection.ClientID%>").value;
            var Amount = document.getElementById("<%=txtAmt.ClientID%>").value;
            if (accId == "") {
                alert("Specify Identification number of relevant investment/account.");
                return false;
            }
            if (Nature == "") {
                alert("Specify nature of income.");
                return false;
            }
            if (Section == "-1") {
                alert("Specify section under which tax is deductible.");
                return false;
            }
            if (Amount == "") {
                alert("Specify Amount of income.");
                return false;
            }
            return true;
        }
        function DeleteCheck() {
            var txt;
            var r = confirm("This Records is uesd in Income Details. \n Do you want to delete all the Records.");
            if (r == true) {
                __doPostBack("yes");
            }
            return true;
        }
        function DeleteMessage(detail) {
            var Detailid = document.getElementById("<%=hdnDetailID.ClientID%>").value;

            if (confirm('Are you sure you want to delete?')) {
                if (detail == Detailid) {
                    if (confirm('You are using this record for editing. \n Do u Want to delete this record.?')) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                else {
                    return true;
                }
            }
            else {
                return false;
            }
        }
    </script>

    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>

    <script type="text/javascript" language="javascript" src="../JavaScript/TDSValidations.js"></script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="updPanel" runat="server">
        <ContentTemplate>
            <asp:HiddenField ID="hdnDetailID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnQuarter" runat="server" Value="0" />
            <asp:HiddenField ID="hdnCustomerID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnIncomeID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnFinYear" runat="server" Value="0" />
            <asp:HiddenField ID="hdnTan" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnBranchID" runat="server" Value="0" />
            <asp:HiddenField ID="hdnCusDetails" runat="server" />
            <asp:HiddenField ID="selectedPageSize" runat="server" />
            <asp:HiddenField ID="selectedPageIndex" runat="server" />
            <asp:HiddenField ID="hdnDeducteeID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnDeducteeIDOld" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnIsSearchActive" runat="server" Value="0" />
            <asp:HiddenField ID="hdnUniqueIDNumber" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnName" runat="server" />
            <asp:HiddenField ID="hdnNature" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnIsEReturnGenerated" Value="N" runat="server" />
            <asp:HiddenField ID="hdnIsUinManual" runat="server" Value="0" />
            <asp:Panel ID="pnlIncomeDetail" runat="server" Visible="false">
                <table>
                    <tr>
                        <td>
                            <asp:Label ID="LblCusInfo" runat="server" Text="Customer Details: "></asp:Label>
                        </td>
                        <td colspan="3">
                            <asp:Label ID="LblCusNamePan" runat="server"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 200px">Identification number of relevant investment/account, etc.
                        </td>
                        <td colspan="3">
                            <asp:TextBox ID="txtAccID" runat="server" TabIndex="3" CssClass="txtBML" Width="473px"
                                MaxLength="125"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>Nature of Income
                        </td>
                        <td colspan="3">
                            <asp:TextBox ID="txtNature" runat="server" TabIndex="4" CssClass="txtBML" Width="473px"
                                MaxLength="125"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>Section under Which tax is deductible
                        </td>
                        <td style="width: 140px">
                            <asp:DropDownList ID="ddlSection" runat="server" TabIndex="5" CssClass="mdropDownList" Style="width: 140px; height: 25px;"
                                AutoPostBack="True" OnSelectedIndexChanged="ddlSection_SelectedIndexChanged">
                                <asp:ListItem Text="194A" Value="194A"></asp:ListItem>
                                <asp:ListItem Text="194I" Value="194I"></asp:ListItem>
                                <asp:ListItem Text="192A" Value="192A"></asp:ListItem>
                                <asp:ListItem Text="193" Value="193"></asp:ListItem>
                                <asp:ListItem Text="194" Value="194"></asp:ListItem>
                                <asp:ListItem Text="194DA" Value="194DA"></asp:ListItem>
                                <asp:ListItem Text="194EE" Value="194EE"></asp:ListItem>
                                <asp:ListItem Text="194D" Value="194D"></asp:ListItem>
                                <asp:ListItem Text="194K" Value="194K"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                        <td style="width: 68px">Amount of income
                        </td>
                        <td>
                            <asp:TextBox ID="txtAmt" runat="server" TabIndex="6" CssClass="txtBPR" BackColor="#E5E5E5"
                                Width="131px" MaxLength="9" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <table cellpadding="0" cellspacing="0">
                                <tr>
                                    <td>
                                        <asp:Button ID="btnIncNew" Text="New" runat="server" CssClass="cmnBtn" Width="100px"
                                            UseSubmitBehavior="false" TabIndex="8" OnClick="btnIncNew_Click" />
                                        <asp:Button ID="btnIncSave" OnClick="btnIncSave_Click" Text="Save" runat="server"
                                            CssClass="cmnBtn" Width="100px" TabIndex="7" OnClientClick="javascript:return ValidateIncomeDetails();" />
                                        <asp:Button ID="btnIncOpenSearch" runat="server" Text="Search" TabIndex="20" Visible="false"
                                            CssClass="cmnBtn" />
                                        <asp:Button ID="btnIncClose" Text="Close" runat="server" CssClass="cmnBtn" Width="100px"
                                            TabIndex="9" OnClick="btnIncClose_Click" />
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <asp:Panel ID="Panel1" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel"
                                Visible="false">
                                <table width="100%">
                                    <tr>
                                        <td style="width: 80px">Name
                                        </td>
                                        <td style="width: 190px">
                                            <asp:TextBox ID="TextBox1" runat="server" Width="190px" TabIndex="20" CssClass="txtBPL"
                                                onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75"></asp:TextBox>
                                        </td>
                                        <td style="width: 50px"></td>
                                        <td style="width: 80px" colspan="2">PAN
                                        </td>
                                        <td style="width: 190px" colspan="3">
                                            <asp:TextBox ID="TextBox2" runat="server" Width="190px" TabIndex="20" CssClass="txtBPL"
                                                MaxLength="10"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Section
                                        </td>
                                        <td>
                                            <asp:DropDownList ID="ddlSearchSection" runat="server" TabIndex="5" CssClass="dropDownList"
                                                Style="width: 195px; height: 25px;">
                                                <asp:ListItem Text="SELECT" Value="-1"></asp:ListItem>
                                                <asp:ListItem Text="192A" Value="192A"></asp:ListItem>
                                                <asp:ListItem Text="194I" Value="194I"> </asp:ListItem>
                                                <asp:ListItem Text="193" Value="193"></asp:ListItem>
                                                <asp:ListItem Text="194" Value="194"></asp:ListItem>
                                                <asp:ListItem Text="194A" Value="194A"></asp:ListItem>
                                                <asp:ListItem Text="194DA" Value="194DA"></asp:ListItem>
                                                <asp:ListItem Text="194EE" Value="194EE"></asp:ListItem>
                                            </asp:DropDownList>
                                        </td>
                                        <td style="width: 50px"></td>
                                        <td>Amount of income
                                        </td>
                                        <td style="padding-left: 2px; font-size: 9px" align="right">From
                                        </td>
                                        <td style="width: 80px">
                                            <asp:TextBox ID="txtSearchAmtFrom" runat="server" Width="80px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="9" TabIndex="22"></asp:TextBox>
                                        </td>
                                        <td style="padding-left: 2px; font-size: 9px" align="right">To
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtSearchAmtTo" runat="server" Width="80px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="9" TabIndex="23"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="8">
                                            <table>
                                                <tr>
                                                    <td align="right">
                                                        <asp:Button ID="Button4" runat="server" Text="Search" CssClass="cmnBtn" TabIndex="30"
                                                            OnClientClick="javascript:return FormatSearch();" OnClick="btnSearch_Click" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="Button5" runat="server" Text="Show All" CssClass="cmnBtn" TabIndex="31"
                                                            OnClick="btnShowAll_Click" OnClientClick="javascript:return ValidateLoadAll();" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="Button6" runat="server" Text="Close" Width="80px" CssClass="cmnBtn"
                                                            TabIndex="32" OnClick="btnClose_Click" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </asp:Panel>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4" width="100%">
                            <table class="nTbl" id="tblrptInc" runat="server" visible="true" width="100%">
                                <tr>
                                    <td width="100%">
                                        <asp:Panel ID="navIncPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal" width="95%">
                                            <asp:Repeater ID="rptrForm15HIncome" runat="server" OnItemCommand="rptrForm15HIncome_ItemCommand"
                                                OnItemDataBound="rptrForm15HIncome_ItemDataBound" Visible="true">
                                                <HeaderTemplate>
                                                    <table id="NavTable" cellspacing="0" cellpadding="0">
                                                        <tr bgcolor="#EEEEEE">
                                                            <th colspan="2" id="thAction" style="border-left-width: 0" runat="server">
                                                                <asp:Label runat="server" ID="lblAction" Width="80px" Text="Action" />
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblUid" Width="100px" Text="Unique ID No."></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblIdAcc" Width="300px" Text="Identification number of relevant investment/account, etc."></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblNature" Width="150px" Text="Nature of Income"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblsection" Width="150px" Text="Section under which tax is deductible."></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblAmt" Width="120px" Text="Amount of Income"></asp:Label>
                                                            </th>
                                                        </tr>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr bgcolor="white">
                                                        <td style="border-left-width: 0" id="ActionMakerEdit" runat="server">
                                                            <asp:LinkButton ID="btnIncomeidEdit" runat="server" Text="Edit" CommandName="LoadData"
                                                                CommandArgument='<%#Eval("INCOMEID")%>' TabIndex="9"> </asp:LinkButton>
                                                        </td>
                                                        <td style="border-left-width: 0" id="ActionMakerDelete" runat="server">
                                                            <asp:LinkButton ID="btnIncomeidDelete" runat="server" Text="Delete" CommandName="DeleteData"
                                                                TabIndex="10" OnClientClick="return confirm('Are you sure you want to delete?');"
                                                                CommandArgument='<%#Eval("INCOMEID")%>'></asp:LinkButton>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("UNIQUEIDNUMBER")%>
                                                        </td>
                                                        <td style="text-align: left">
                                                            <%#Eval("IDENFICATIONNUM")%>
                                                        </td>
                                                        <td style="text-align: left;">
                                                            <%#Eval("NATUREOFINC")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("SECTIONNAME")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("AMTOFINC")%>
                                                        </td>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </table>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </asp:Panel>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlBasicDetails" runat="server" Visible="true">
                <table>
                    <tr>
                        <td style="width: 250px">Name
                        </td>
                        <td colspan="4" align="left">
                            <asp:TextBox ID="txtName" runat="server" TabIndex="1" onkeyup="ClearDeducteeName()"
                                CssClass="txtBML" Style="width: 708px; margin: 0; padding: 0"></asp:TextBox>
                            <cc1:AutoCompleteExtender ID="autoCompleteExtender" runat="server" MinimumPrefixLength="2"
                                ServicePath="~/WebServices/AutoCompleteService.asmx" TargetControlID="txtName"
                                CompletionInterval="700" EnableCaching="false" CompletionSetCount="50" DelimiterCharacters=""
                                ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="true" OnClientItemSelected="GetDeducteeIdValue">
                            </cc1:AutoCompleteExtender>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="5"></td>
                    </tr>
                    <tr>
                        <td>CustomerID
                        </td>
                        <td>
                            <asp:TextBox ID="txtCustomerID" runat="server" Width="200px" BackColor="#E5E5E5"
                                CssClass="txtBPR" Font-Bold="true" Enabled="false"></asp:TextBox>
                        </td>
                        <td style="width: 15px"></td>
                        <td style="width: 250px">Date of Birth (DD/MM/YYYY)
                        </td>
                        <td>
                            <asp:TextBox ID="txtAssesseeDOB" runat="server" Width="220px" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                BackColor="#E5E5E5" AutoComplete="Off" CssClass="txtBPR" TabIndex="2" onBlur="DOBDateFormat(this);"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="lblTaxAssessedFlag" runat="server" Text="Whether assessed to tax under the income-tax Act, 1961"></asp:Label>
                        </td>
                        <td style="width: 200px">
                            <asp:DropDownList ID="ddlTaxAssessedFlag" runat="server" TabIndex="3" CssClass="mdropDownList"
                                Style="width: 205px; height: 23px;" onchange="TaxAssessedStatus();" AutoPostBack="true" 
                                OnSelectedIndexChanged="ddlTaxAssessedFlag_SelectedIndexChanged">
                                <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                <asp:ListItem Text="Yes" Value="Y"></asp:ListItem>
                                <asp:ListItem Text="No" Value="N"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                        <td></td>
                        <td style="width: 250px" id="tdlblAssessmentYear" runat="server">
                            <asp:Label ID="lblAssessmentYear" runat="server" Text="If yes,latest assessment year for which assessed"></asp:Label>
                        </td>
                        <td id="tdtxtAssessmentYear" runat="server">
                            <asp:DropDownList ID="ddlAssessmentYear" runat="server" TabIndex="4" CssClass="mdropDownList"
                                Enabled="false" Style="width: 225px; height: 23px;">
                                <asp:ListItem Text="Select" Value="0"></asp:ListItem>
                                <asp:ListItem Text="2026-27" Value="2026"></asp:ListItem>
                                <asp:ListItem Text="2025-26" Value="2025"></asp:ListItem>
                                <asp:ListItem Text="2024-25" Value="2024"></asp:ListItem>
                                <asp:ListItem Text="2023-24" Value="2023"></asp:ListItem>
                                <asp:ListItem Text="2022-23" Value="2022"></asp:ListItem>
                                <asp:ListItem Text="2021-22" Value="2021"></asp:ListItem>
                                <asp:ListItem Text="2020-21" Value="2020"></asp:ListItem>
                                <asp:ListItem Text="2019-20" Value="2019"></asp:ListItem>
                                <asp:ListItem Text="2018-19" Value="2018"></asp:ListItem>
                                <asp:ListItem Text="2017-18" Value="2017"></asp:ListItem>
                                <asp:ListItem Text="2016-17" Value="2016"></asp:ListItem>
                                <asp:ListItem Text="2015-16" Value="2015"></asp:ListItem>
                                <asp:ListItem Text="2014-15" Value="2014"></asp:ListItem>
                                <asp:ListItem Text="2013-14" Value="2013"></asp:ListItem>
                                <asp:ListItem Text="2012-13" Value="2012"></asp:ListItem>
                                <asp:ListItem Text="2011-12" Value="2011"></asp:ListItem>
                                <asp:ListItem Text="2010-11" Value="2010"></asp:ListItem>
                                <asp:ListItem Text="2009-10" Value="2009"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                        <td style="width: 250px" id="tdlblCountryOther" runat="server" visible="false">
                            <asp:Label ID="lblCountryOther" runat="server" Text="Country (If others)"></asp:Label>
                        </td>
                        <td id="tdtxtCountryOther" runat="server" visible="false">
                            <asp:TextBox ID="txtCountryOther" runat="server" BackColor="#FFFFFF" TabIndex="4"
                                CssClass="txtBPR" Width="220px" MaxLength="100"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="lblEstimatedInc" runat="server" Text="Estimated income for which this declaration is made"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="txtEstimatedInc" runat="server" BackColor="#E5E5E5" TabIndex="5"
                                CssClass="txtBPR" Width="200px" MaxLength="9" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                        </td>
                        <td style="width: 15px"></td>
                        <td style="width: 250px">
                            <asp:Label ID="lblEstimatedIncPY" runat="server" Text="Estimated total income of the P.Y.(including income for which this declaration is
                            made)"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="txtEstimatedIncPY" runat="server" BackColor="#E5E5E5" TabIndex="6"
                                CssClass="txtBPR" Width="220px" MaxLength="9" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="lblTotalForm" runat="server" Text="Total No. of Form No. 15H filed"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="txtTotalForm" runat="server" BackColor="#E5E5E5" TabIndex="7" CssClass="txtBPR"
                                Width="200px" MaxLength="9" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                        </td>
                        <td style="width: 15px"></td>
                        <td style="width: 250px" id="tdlblAggregateAmount" runat="server">
                            <asp:Label ID="lblAggregateAmount" runat="server" Text="Aggregate amount of income for which Form No. 15H filed"></asp:Label>
                        </td>
                        <td id="tdtxtAggregateAmount" runat="server">
                            <asp:TextBox ID="txtAggregateAmount" runat="server" BackColor="#E5E5E5" TabIndex="8"
                                CssClass="txtBPR" Width="220px" MaxLength="9" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="lblDeclarationDate" runat="server" Text="Date on which Declaration is received(DD/MM/YYYY)"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="txtDeclarationDate" runat="server" Width="200px" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                BackColor="#E5E5E5" AutoComplete="Off" TabIndex="9" CssClass="txtBPR" onBlur="setDateFormat(this);"></asp:TextBox>
                        </td>
                        <td style="width: 15px"></td>
                        <td style="width: 250px">Unique Identification No.
                        </td>
                        <td>
                            <asp:TextBox ID="txtUIN" runat="server" CssClass="txtBML" BackColor="#E5E5E5" Width="100px"
                                MaxLength="10" Enabled="false" Font-Bold="true"></asp:TextBox>
                            <asp:Label ID="lblUIN" runat="server"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Label ID="lblIncPaid" runat="server" Text="Amount of Income Paid"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="txtIncPaid" runat="server" CssClass="txtBPR" BackColor="#E5E5E5"
                                Width="200px" MaxLength="9" TabIndex="10" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                        </td>
                        <td style="width: 15px"></td>
                        <td style="width: 250px">
                            <asp:Label ID="lblPaidDate" runat="server" Text="Date on which the income has been paid/credited(DD/MM/YYYY)"></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="txtPaidDate" runat="server" Width="220px" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                BackColor="#E5E5E5" AutoComplete="Off" CssClass="txtBPR"
                                onBlur="setDateFormat(this);"></asp:TextBox>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="5">
                            <table cellpadding="0" cellspacing="0">
                                <tr>
                                    <td>
                                        <asp:Button ID="btnNew" Text="New" runat="server" CssClass="cmnBtn" Width="100px"
                                            UseSubmitBehavior="false" TabIndex="12" OnClick="btnNew_Click" />
                                        <asp:Button ID="btnSave" Text="Save" runat="server" CssClass="cmnBtn" Width="100px"
                                            TabIndex="11" OnClick="btnSave_Click" OnClientClick="javascript:return Validation();" />
                                        <asp:Button ID="btnOpenSearch" runat="server" Text="Search" TabIndex="20" OnClick="btnOpenSearch_Click"
                                            Visible="true" CssClass="cmnBtn" />
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="5">
                            <asp:Label ID="lblNote" runat="server" Visible="false" ForeColor="#0000CC" Width="400px"></asp:Label>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="5">
                            <asp:Panel ID="pnlSearch" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel">
                                <table width="100%">
                                    <tr>
                                        <td style="width: 100px" colspan="2">Name
                                        </td>
                                        <td style="width: 195px" colspan="9">
                                            <asp:TextBox ID="txtSearchName" runat="server" Width="195px" TabIndex="20" CssClass="txtBPL"
                                                onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 100px" colspan="2">CustomerID
                                        </td>
                                        <td style="width: 195px" colspan="3">
                                            <asp:TextBox ID="txtSearchCustomerID" runat="server" Width="195px" TabIndex="20"
                                                CssClass="txtBPL" onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="20"></asp:TextBox>
                                        </td>
                                        <td style="width: 50px"></td>
                                        <td style="width: 100px" colspan="2">PAN
                                        </td>
                                        <td style="width: 195px" colspan="3">
                                            <asp:TextBox ID="txtSearchPAN" runat="server" Width="190px" TabIndex="21" CssClass="txtBPL"
                                                MaxLength="10"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Declared Income
                                        </td>
                                        <td style="padding-left: 2px; font-size: 9px" align="right">From
                                        </td>
                                        <td style="width: 8%">
                                            <asp:TextBox ID="txtSearchIncomeFrom" runat="server" Width="80px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="9" TabIndex="22" CssClass="txtBPR"></asp:TextBox>
                                        </td>
                                        <td style="padding-left: 3px; font-size: 9px" align="right">To
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtSearchIncomeTo" runat="server" Width="82px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="9" TabIndex="23" CssClass="txtBPR"></asp:TextBox>
                                        </td>
                                        <td style="width: 25px"></td>
                                        <td>Declaration Date
                                        </td>
                                        <td style="padding-left: 2px; font-size: 9px" align="right">From
                                        </td>
                                        <td style="width: 8%">
                                            <asp:TextBox ID="txtSearchDeclarationDateFrom" runat="server" Width="77px" CssClass="txtBPR"
                                                onBlur="setDateFormat(this);" TabIndex="24"></asp:TextBox>
                                        </td>
                                        <td style="padding-left: 2px; font-size: 9px" align="right">To
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtSearchDeclarationDateTo" runat="server" Width="80px" CssClass="txtBPR"
                                                onBlur="setDateFormat(this);" TabIndex="25"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="11">
                                            <table>
                                                <tr>
                                                    <td align="right">
                                                        <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="cmnBtn" TabIndex="30"
                                                            OnClientClick="return FormatSearch()" OnClick="btnSearch_Click" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnShowAll" runat="server" Text="Show All" CssClass="cmnBtn" TabIndex="31"
                                                            OnClientClick="return ValidateLoadAll()" OnClick="btnShowAll_Click" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnClose" runat="server" Text="Close" Width="80px" CssClass="cmnBtn"
                                                            TabIndex="32" OnClick="btnClose_Click" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </asp:Panel>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="5">
                            <table class="nTbl" id="tblrpt" runat="server" visible="false">
                                <tr>
                                    <td>
                                        <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal"  Width="1024px">
                                            <asp:Repeater ID="rptrForm15H" runat="server" OnItemCommand="rptrForm15H_ItemCommand"
                                                OnItemDataBound="rptrForm15H_ItemDataBound">
                                                <HeaderTemplate>
                                                    <table id="NavTable" cellspacing="0" cellpadding="0">
                                                        <tr bgcolor="#EEEEEE">
                                                            <th colspan="3" rowspan="2" id="thAction" style="border-left-width: 0" runat="server">
                                                                <asp:Label runat="server" ID="lblAction" Width="200px" Text="Action" />
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblName" Width="200px" Text="Name of the Assessee"></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblUniqueID" Width="100px" Text="Unique ID No."></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblDOB" Width="90px" Text="Date of Birth"></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblIncomeTaxAct" Width="200px" Text="Whether assessed to tax under the income-tax Act, 1961"></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblAssessmentYear" Width="200px" Text="If yes,latest assessment year for which assessed"></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblEstimatedInc" Width="200px" Text=" Estimated income for which this declaration is made"></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="txtEstimatedIncomePY" Width="300px" Text="Estimated total income of the P.Y.(including income for which this declaration is made)"></asp:Label>
                                                            </th>
                                                            <th colspan="2">
                                                                <asp:Label runat="server" ID="lblDetailForm15H" Width="400px" Text="Detail of Form No. other than this form filed during the previous year, if any"></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblDeclarationDate" Width="200px" Text="Date on which Declaration is received(DD/MM/YYYY)"></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblIncPaid" Width="120px" Text="Amount of Income Paid"></asp:Label>
                                                            </th>
                                                            <th rowspan="2">
                                                                <asp:Label runat="server" ID="lblPaidDate" Width="200px" Text="Date on which the income has been paid/credited(DD/MM/YYYY)"></asp:Label>
                                                            </th>
                                                        </tr>
                                                        <tr>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblTotalForm" Width="200px" Text="Total No. of Form No. 15H filed"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblAggregateAmount" Width="200px" Text="Aggregate amount of income for which Form No. 15H filed"></asp:Label>
                                                            </th>
                                                        </tr>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr bgcolor="white">
                                                        <td style="border-left-width: 0" id="ActionMakerEdit" runat="server">
                                                            <asp:LinkButton ID="btnEdit" runat="server" Text="Edit" CommandName="LoadData" CommandArgument='<%#Eval("DETAILID")%>'
                                                                TabIndex="13"> </asp:LinkButton>
                                                        </td>
                                                        <td style="border-left-width: 0" id="ActionMakerDelete" runat="server">
                                                            <asp:LinkButton ID="btnDelete" runat="server" Text="Delete" CommandName="DeleteData"
                                                                TabIndex="14" OnClientClick='<%#string.Format("javascript:return DeleteMessage(\"{0}\")", Eval("DETAILID"))%>'
                                                                CommandArgument='<%#Eval("DETAILID")%>'></asp:LinkButton>
                                                        </td>
                                                        <td style="border-left-width: 0" id="ActionMakerIncDetails" runat="server">
                                                            <asp:LinkButton ID="btnIncDetails" runat="server" Text="Income Details" CommandName="IncDetails"
                                                                CommandArgument='<%#Eval("DETAILID")+"µ"+Eval("ASSESSEENAME")+"╥"+Eval("PAN")+"µ"+Eval("UNIQUEIDNUMBER")%>'
                                                                TabIndex="15"> </asp:LinkButton>
                                                        </td>
                                                        <td>
                                                            <%#Eval("ASSESSEENAME")%>
                                                        </td>
                                                        <td>
                                                            <%#Eval("UNIQUEIDNUMBER")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("ASSESSEEDOB")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("TAXASSESSEDFLAG")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("LATESTASSTYR")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("ESTIMATEDINC")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("ESTIMATEDTOTALINCPRVYR")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("TOTALNOOFFORM15H")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("AGGREGATEAMTFORM15H")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("DECLARATIONDATE")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("INCOMEPAID")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("DATEINCPAID")%>
                                                        </td>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </table>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                            <asp:Repeater ID="rptrForm121" runat="server" OnItemCommand="rptrForm121_ItemCommand" 
                                                OnItemDataBound="rptrForm121_ItemDataBound">
                                                <HeaderTemplate>
                                                    <table id="NavTable" cellspacing="0" cellpadding="0">
                                                        <tr bgcolor="#EEEEEE">
                                                            <th colspan="2" id="thAction" style="border-left-width: 0" runat="server">
                                                                <asp:Label runat="server" ID="lblAction" Width="100px" Text="Action" />
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblName" Width="200px" Text="Name of the Assessee"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblUniqueID" Width="100px" Text="UIN"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblDOB" Width="90px" Text="Date of Birth"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblCountryName" Width="100px" Text="Country Name"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblEstIncDeclared" Width="150px" Text="Estimated Income Declared"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblEstTotalInc" Width="150px" Text=" Estimated Total Income"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblAggAmtofInc" Width="150px" Text="Aggregate Amount of Income"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblDeclarationDate" Width="200px" Text="Date on which Declaration is received(DD/MM/YYYY)"></asp:Label>
                                                            </th>
                                                            <th>
                                                                <asp:Label runat="server" ID="lblCOthers" Width="120px" Text="Country(If Others)"></asp:Label>
                                                            </th>
                                                        </tr>
                                                </HeaderTemplate>
                                                <ItemTemplate>
                                                    <tr bgcolor="white">
                                                        <td style="border-left-width: 0" id="ActionMakerEdit" runat="server">
                                                            <asp:LinkButton ID="btnEdit" runat="server" Text="Edit" CommandName="LoadData" CommandArgument='<%#Eval("DETAILID")%>'
                                                                TabIndex="13"> </asp:LinkButton>
                                                        </td>
                                                        <td style="border-left-width: 0" id="ActionMakerDelete" runat="server">
                                                            <asp:LinkButton ID="btnDelete" runat="server" Text="Delete" CommandName="DeleteData"
                                                                TabIndex="14" OnClientClick='<%#string.Format("javascript:return DeleteMessage(\"{0}\")", Eval("DETAILID"))%>'
                                                                CommandArgument='<%#Eval("DETAILID")%>'></asp:LinkButton>
                                                        </td>
                                                        <td>
                                                            <%#Eval("ASSESSEENAME")%>
                                                        </td>
                                                        <td>
                                                            <%#Eval("UNIQUEIDNUMBER")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("ASSESSEEDOB")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("LATESTASSTYR")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("ESTIMATEDINC")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("ESTIMATEDTOTALINCPRVYR")%>
                                                        </td>
                                                        <td style="text-align: right">
                                                            <%#Eval("AGGREGATEAMTFORM15H")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("DECLARATIONDATE")%>
                                                        </td>
                                                        <td style="text-align: center">
                                                            <%#Eval("TAXASSESSEDFLAG")%>
                                                        </td>
                                                    </tr>
                                                </ItemTemplate>
                                                <FooterTemplate>
                                                    </table>
                                                </FooterTemplate>
                                            </asp:Repeater>
                                        </asp:Panel>
                                        <table style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px" align="right">
                                            <tr>
                                                <td style="padding: 0px 0px 0px 0px">
                                                    <asp:Label ID="Label1" runat="server" Text="Records per page : " Font-Size="X-Small" />
                                                </td>
                                                <td style="width: 50px; padding-top: 2px;">
                                                    <asp:DropDownList ID="cmbGoTo" TabIndex="14" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                        CssClass="dropDownList" AutoPostBack="true" Font-Size="X-Small"
                                                        OnSelectedIndexChanged="cmbGoTo_SelectedIndexChanged">
                                                        <asp:ListItem Text="5" Value="5" />
                                                        <asp:ListItem Text="10" Value="10" />
                                                        <asp:ListItem Text="15" Value="15" />
                                                        <asp:ListItem Text="20" Value="20" />
                                                        <asp:ListItem Text="25" Value="25" />
                                                        <asp:ListItem Text="50" Value="50" />
                                                        <asp:ListItem Text="75" Value="75" />
                                                        <asp:ListItem Text="100" Value="100" />
                                                    </asp:DropDownList>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblGridStatus" runat="server" Style="float: left;" Text="" Font-Size="X-Small" />
                                                </td>
                                                <td>
                                                    <asp:Button ID="btnFirst" runat="server" Text="&lt;&lt;" Font-Names="Arial" Font-Overline="False"
                                                        Font-Size="X-Small" CssClass="navButton" Enabled="False" TabIndex="15" OnClick="btnFirst_Click"></asp:Button>
                                                </td>
                                                <td>
                                                    <asp:Button ID="btnPrevious" runat="server" Text="&lt;" Font-Names="Arial" Font-Overline="False"
                                                        Font-Size="X-Small" CssClass="navButton" Enabled="False" TabIndex="16" OnClick="btnPrevious_Click"></asp:Button>
                                                </td>
                                                <td>
                                                    <asp:TextBox ID="txtGoToPage" runat="server" Text="1" CssClass="navTextBox" AutoPostBack="True"
                                                        MaxLength="5" TabIndex="17" OnTextChanged="txtGoToPage_TextChanged"></asp:TextBox>
                                                </td>
                                                <td>
                                                    <asp:Button ID="btnNext" runat="server" Text="&gt;" Font-Names="Arial" Font-Overline="False"
                                                        Font-Size="X-Small" CssClass="navButton" TabIndex="18" OnClick="btnNext_Click"></asp:Button>
                                                </td>
                                                <td>
                                                    <asp:Button ID="btnLast" runat="server" Text="&gt;&gt;" Font-Names="Arial" Font-Overline="False"
                                                        Font-Size="X-Small" CssClass="navButton" TabIndex="19" OnClick="btnLast_Click"></asp:Button>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
        </ContentTemplate>
    </asp:UpdatePanel>
</asp:Content>
