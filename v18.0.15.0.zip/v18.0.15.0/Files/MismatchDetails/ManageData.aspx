<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="MismatchDetails_ManageData, App_Web_managedata.aspx.af1292ed" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <script src="../JavaScript/Validations.js" type="text/javascript" language="javascript"></script>
    <style type="text/css">
        .modalBackground {
            background-color: Gray;
            filter: alpha(opacity=70);
            opacity: 0.7;
        }

        .modalPopup {
            background-color: #ffffdd;
            border-width: 5px;
            border-style: solid;
            border-color: Gray;
            padding: 10px;
            width: 260px;
        }

        .style1 {
            width: 107px;
        }
    </style>
    <script type="text/javascript">
        function Validate() {
            var selectedIdex = document.getElementById("<%=lstTypeOfManageData.ClientID%>").value;
            switch (selectedIdex) {
                case "0":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select quarter"); return false; } break;
                case "4":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select quarter"); return false; } break;
                case "1":
                    var month = document.getElementById("<%=ddlMonth.ClientID%>");
                    var uploadFile = document.getElementById("<%=uploadfile.ClientID%>");
                    var file = uploadFile.value.trim(); ext = ".zip"; fileName = ".zip"; var validExtensions = new Array(ext); var allowSubmit = false;
                    if (file.indexOf("\\") == -1) { alert("Select a file."); return false; }
                    else {
                        var ext = file.slice(file.lastIndexOf(".")).toLowerCase();
                        for (var i = 0; i < validExtensions.length; i++) { if (validExtensions[i] == ext) { allowSubmit = true; } }
                    }
                    if (allowSubmit == false) { alert("Please select " + fileName + " file."); return false; }
                    if (month.value == "-1") { alert("Select Month"); return false; } break;
                case "2":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select quarter"); return false; } break;
                case "3":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select quarter"); return false; } break;
                case "5":
                    var month = document.getElementById("<%=ddlMonth.ClientID%>");
                    var challanPaidDate = document.getElementById("<%=txtPaidDate.ClientID%>");
                    if (month.value == "-1") { alert("Select Month"); return false; }
                    if (challanPaidDate.value == "") { alert("Enter Challan Paid Date"); return false; }
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Link") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Linking...";
                    }
                    break;
                case "6":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select quarter"); return false; }
                    break;
                case "9":
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Upload") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Please Wait...";
                    }
                    break;
                case "10":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select Quarter"); return false; }
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Update") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Please Wait...";
                    }
                    break;
                case "11":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select Quarter"); return false; }
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Update") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Please Wait...";
                    }
                    break;
                case "12":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select Quarter"); return false; }
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Update") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Please Wait...";
                    }
                    break;
                case "13":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select Quarter"); return false; }
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Update") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Please Wait...";
                    }
                    break;
                case "14":
                    var quarter = document.getElementById("<%=ddlQuarter.ClientID%>");
                    if (quarter.value == "-1") { alert("Select Quarter"); return false; }
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Update") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Please Wait...";
                    }
                    break;
               case "15":
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Upload") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Please Wait...";
                    }
                    break;
                case "16":
                    if (document.getElementById("<%=btnLink.ClientID%>").value == "Upload") {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Please Wait...";
                    }
                    if (validateFileUpload())
                        return true;
                    else {
                        document.getElementById("<%=btnLink.ClientID%>").value = "Upload";
                        return false;
                    }
                    break;
            }
            return true;
        }
        function DisplayControls(objValue) { document.getElementById("<%=lstTypeOfManageData.ClientID%>").innerHTML = "Selected Type : " + " " + "<b>" + document.getElementById("<%=lstTypeOfManageData.ClientID%>")[selectedIdex].text + "</b>"; }
        function SelectUnselectAll(objValue) {
            var selectedIdex = document.getElementById("<%=lstTypeOfManageData.ClientID%>").selectedIndex;
            var selectedValue = document.getElementById("<%=lstTypeOfManageData.ClientID%>").value;
            var trQuarter = document.getElementById("<%=trQuarter.ClientID%>");
            var trMonth = document.getElementById("<%=trMonth.ClientID%>");
            var trDate = document.getElementById("<%=trDate.ClientID%>");
            var trCheckkStatus = document.getElementById("<%=trCheckkStatus.ClientID%>");
            var trBranchCode = document.getElementById("<%=trBranchCode.ClientID%>");
            var trUploadFile = document.getElementById("<%=trUploadFile.ClientID%>");
            var btnlink = document.getElementById("<%=btnLink.ClientID%>");
            var hdnPreviewClick = document.getElementById("<%=hdnPreviewClick.ClientID%>");
            var ddlQuarter = document.getElementById("<%=ddlQuarter.ClientID%>");
            var rowNote = document.getElementById("<%=rowNote.ClientID%>");
            var hlnkRecalculate = document.getElementById("<%=hlnkRecalculate.ClientID%>");
            var hlnkRecalculateExcel = document.getElementById("<%=hlnkRecalculateExcel.ClientID%>");
            var hlnkAutoLinkLog = document.getElementById("<%=hlnkAutoLinkLog.ClientID%>");
            var trLinkDedAmount = document.getElementById("<%=trLinkDedAmount.ClientID%>");
            var trLinkSection = document.getElementById("<%=trLinkSection.ClientID%>");
            var trFormType = document.getElementById("<%=trFormType.ClientID%>");
            var trLinkChallan = document.getElementById("<%=trLinkChallan.ClientID%>");
            var trFormSequence = document.getElementById("<%=trFormSequence.ClientID%>");
            var trCorrectMasterOption = document.getElementById("<%=trCorrectMasterOption.ClientID%>");
            var trCorrectMasterBranch = document.getElementById("<%=trCorrectMasterBranch.ClientID%>");
            var trRT = document.getElementById("<%=rowRT.ClientID%>");
            var hlnkRemoveHigherRate = document.getElementById("<%=hlnkRemoveHigherRate.ClientID%>");
            var hlnkUpdateITRate194 = document.getElementById("<%=hlnkUpdateITRate194.ClientID%>");
            var hlnkUpdateCashDraw = document.getElementById("<%=hlnkUpdateCashDraw.ClientID%>");
            var hlnkRemove197Cert = document.getElementById("<%=hlnkRemove197Cert.ClientID%>");
            var hlnkHTMLReport = document.getElementById("<%=hlnkHTMLReport.ClientID%>");
            var hlnkExcelReport = document.getElementById("<%=hlnkExcelReport.ClientID%>");
            var hlnkCRNUpdateLog = document.getElementById("<%=hlnkCRNUpdateLog.ClientID%>");
            var hlnkRTDownload = document.getElementById("<%=hlnkRTDownload.ClientID%>");
            var trLinkZeroTDS = document.getElementById("<%=trLinkZeroTDS.ClientID%>");
            var txtBranchcode = document.getElementById("<%=txtBranchCode.ClientID%>");

            if (txtBranchcode != null) txtBranchcode.value = '';
            if (trLinkZeroTDS != null) HideRow(trLinkZeroTDS);
            
            btnlink.value = "LInk";
            switch (selectedValue) {
                case "0": if (trLinkZeroTDS != null) DisplayRow(trLinkZeroTDS);
                case "4":
                    if (trFormSequence != null)
                        HideRow(trFormSequence);
                    if (trLinkSection != null)
                        HideRow(trLinkSection);
                    if (trFormType != null)
                        HideRow(trFormType);
                    if (trLinkChallan != null)
                        HideRow(trLinkChallan);
                    if (trCorrectMasterOption != null)
                        HideRow(trCorrectMasterOption);
                    if (trCorrectMasterBranch != null)
                        HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trMonth); HideRow(trUploadFile); DisplayRow(trQuarter); DisplayRow(trBranchCode); HideRow(rowNote); btnlink.value = "Link";
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = ''; 
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    hdnPreviewClick.value = "0"; HideRow(trRT); break;
                case "1":
                    if (trFormSequence != null)
                        HideRow(trFormSequence);
                    if (trLinkSection != null)
                        HideRow(trLinkSection);
                    if (trFormType != null)
                        HideRow(trFormType);
                    if (trLinkChallan != null)
                        HideRow(trLinkChallan);
                    if (trCorrectMasterOption != null)
                        HideRow(trCorrectMasterOption);
                    if (trCorrectMasterBranch != null)
                        HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trQuarter); HideRow(trBranchCode); HideRow(rowNote); DisplayRow(trMonth); DisplayRow(trBranchCode); DisplayRow(trUploadFile); btnlink.value = "Link";
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    hdnPreviewClick.value = "0"; HideRow(trRT); break;
                case "2":
                    if (trFormSequence != null)
                        HideRow(trFormSequence);
                    if (trLinkSection != null)
                        HideRow(trLinkSection);
                    if (trFormType != null)
                        HideRow(trFormType);
                    if (trLinkChallan != null)
                        HideRow(trLinkChallan);
                    if (trCorrectMasterOption != null)
                        HideRow(trCorrectMasterOption);
                    if (trCorrectMasterBranch != null)
                        HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); DisplayRow(trQuarter); HideRow(trBranchCode); HideRow(trMonth); HideRow(rowNote); HideRow(trUploadFile);
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    if (hdnPreviewClick.value == "1") { btnlink.value = "Update"; ddlQuarter.disabled = true; }
                    else { btnlink.value = "Preview"; ddlQuarter.disabled = false; } HideRow(trRT); break;
                case "3":
                    if (trFormSequence != null)
                        HideRow(trFormSequence);
                    if (trLinkSection != null)
                        HideRow(trLinkSection);
                    if (trFormType != null)
                        HideRow(trFormType);
                    if (trLinkChallan != null)
                        HideRow(trLinkChallan);
                    if (trCorrectMasterOption != null)
                        HideRow(trCorrectMasterOption);
                    if (trCorrectMasterBranch != null)
                        HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trMonth); HideRow(trRT); HideRow(trUploadFile); DisplayRow(rowNote); DisplayRow(trQuarter); DisplayRow(trBranchCode); btnlink.value = "Update";
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';break;
                case "5":
                    HideRow(trDate); HideRow(trQuarter); HideRow(trBranchCode); HideRow(rowNote);
                    if (trFormSequence != null)
                        DisplayHideFormSequence();
                    if (trLinkSection != null)
                        DisplayRow(trLinkSection);
                    if (trFormType != null)
                        DisplayRow(trFormType);
                    if (trLinkChallan != null)
                        DisplayRow(trLinkChallan);
                    if (trCorrectMasterOption != null)
                        HideRow(trCorrectMasterOption);
                    if (trCorrectMasterBranch != null)
                        HideRow(trCorrectMasterBranch);
                    DisplayRow(trLinkDedAmount); DisplayRow(trCheckkStatus); DisplayRow(trMonth); HideRow(trRT); DisplayRow(trDate); DisplayRow(trBranchCode); HideRow(trUploadFile); btnlink.value = "Link";
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    hdnPreviewClick.value = "0"; break;
                case "6":
                    HideRow(trDate); DisplayRow(trQuarter); HideRow(trBranchCode); HideRow(rowNote); HideRow(trRT);
                    if (trFormSequence != null)
                        HideRow(trFormSequence);
                    if (trLinkSection != null)
                        HideRow(trLinkSection);
                    if (trFormType != null)
                        HideRow(trFormType);
                    if (trLinkChallan != null)
                        HideRow(trLinkChallan);
                    if (trCorrectMasterOption != null)
                        HideRow(trCorrectMasterOption);
                    if (trCorrectMasterBranch != null)
                        HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(trUploadFile); btnlink.value = "Link";
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    hdnPreviewClick.value = "0"; btnlink.value = "Update";
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    break;
                case "7":
                    HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); DisplayRow(trCorrectMasterOption); DisplayRow(trCorrectMasterBranch); HideRow(trRT);
                    if (trQuarter != null)
                        HideRow(trQuarter);
                    if (trFormSequence != null)
                        HideRow(trFormSequence);
                    if (trLinkSection != null)
                        HideRow(trLinkSection);
                    if (trFormType != null)
                        HideRow(trFormType);
                    if (trLinkChallan != null)
                        HideRow(trLinkChallan);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(trUploadFile); btnlink.value = "Link";
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    hdnPreviewClick.value = "0"; btnlink.value = "Update";
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    break;
                case "8":
                    HideRow(trQuarter); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); HideRow(trCorrectMasterOption); HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trBranchCode); HideRow(trLinkChallan); HideRow(trFormType); HideRow(trRT);
                    HideRow(trFormSequence); HideRow(trLinkSection); DisplayRow(trUploadFile); btnlink.value = "Upload";
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    hdnPreviewClick.value = "0";
                    break;
                case "9":
                    HideRow(trQuarter); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); HideRow(trCorrectMasterOption); HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trBranchCode); HideRow(trLinkChallan); HideRow(trFormType); HideRow(trRT);
                    HideRow(trFormSequence); HideRow(trLinkSection); DisplayRow(trUploadFile); btnlink.value = "Upload";
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    break;
                case "10":
                    DisplayRow(trQuarter); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); HideRow(trCorrectMasterOption); HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trBranchCode); HideRow(trLinkChallan); HideRow(trFormType); HideRow(trRT);
                    HideRow(trFormSequence); HideRow(trLinkSection); HideRow(trUploadFile); btnlink.value = "Update";
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    break;
                case "11":
                    DisplayRow(trQuarter); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); HideRow(trCorrectMasterOption); HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trBranchCode); HideRow(trLinkChallan); HideRow(trFormType); HideRow(trRT);
                    HideRow(trFormSequence); HideRow(trLinkSection); HideRow(trUploadFile); btnlink.value = "Update";
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    break;
                case "12":
                    DisplayRow(trQuarter); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); HideRow(trCorrectMasterOption); HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trBranchCode); HideRow(trLinkChallan); HideRow(trFormType); HideRow(trRT);
                    HideRow(trFormSequence); HideRow(trLinkSection); HideRow(trUploadFile); btnlink.value = "Update"; if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    break;
                case "13":
                    DisplayRow(trQuarter); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); HideRow(trCorrectMasterOption); HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trBranchCode); HideRow(trLinkChallan); HideRow(trFormType); HideRow(trRT);
                    HideRow(trFormSequence); HideRow(trLinkSection); HideRow(trUploadFile); btnlink.value = "Update"; if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    break;
                case "14":
                    DisplayRow(trQuarter); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); HideRow(trCorrectMasterOption); HideRow(trCorrectMasterBranch);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trDate); HideRow(trBranchCode); HideRow(trLinkChallan); HideRow(trFormType); HideRow(trRT);
                    HideRow(trFormSequence); HideRow(trLinkSection); HideRow(trUploadFile); btnlink.value = "Update"; if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    break;
                case "15":
                    HideRow(trDate); HideRow(trBranchCode); HideRow(rowNote); HideRow(trCorrectMasterOption); HideRow(trCorrectMasterBranch); HideRow(trRT);
                    if (trQuarter != null)
                        HideRow(trQuarter);
                    if (trFormSequence != null)
                        HideRow(trFormSequence);
                    if (trLinkSection != null)
                        HideRow(trLinkSection);
                    if (trFormType != null)
                        HideRow(trFormType);
                    if (trLinkChallan != null)
                        HideRow(trLinkChallan);
                    HideRow(trLinkDedAmount); HideRow(trCheckkStatus); HideRow(trMonth); HideRow(trDate); HideRow(trBranchCode); DisplayRow(trUploadFile); btnlink.value = "Link";
                    if (hlnkRecalculate != null) hlnkRecalculate.innerHTML = '';
                    if (hlnkRecalculateExcel != null) hlnkRecalculateExcel.innerHTML = '';
                    hdnPreviewClick.value = "0"; btnlink.value = "Upload";
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkRTDownload != null) hlnkRTDownload.innerHTML = '';
                    break;
                case "16":
                    if (trQuarter != null) HideRow(trQuarter);
                    if (trMonth != null) HideRow(trMonth);
                    if (trDate != null) HideRow(trDate);
                    if (trCheckkStatus != null) HideRow(trCheckkStatus);
                    if (trBranchCode != null) HideRow(trBranchCode);
                    if (trUploadFile != null) HideRow(trUploadFile);
                    //if (btnlink != null) HideRow(btnlink);
                    if (hdnPreviewClick != null) HideRow(hdnPreviewClick);
                    //if (ddlQuarter != null) HideRow(ddlQuarter);
                    if (rowNote != null) HideRow(rowNote);
                    if (hlnkRecalculate != null) HideRow(hlnkRecalculate);
                    if (hlnkRecalculateExcel != null) HideRow(hlnkRecalculateExcel);
                    if (hlnkAutoLinkLog != null) HideRow(hlnkAutoLinkLog);
                    if (trLinkDedAmount != null) HideRow(trLinkDedAmount);
                    if (trLinkSection != null) HideRow(trLinkSection);
                    if (trFormType != null) HideRow(trFormType);
                    if (trLinkChallan != null) HideRow(trLinkChallan);
                    if (trFormSequence != null) HideRow(trFormSequence);
                    if (trCorrectMasterOption != null) HideRow(trCorrectMasterOption);
                    if (trCorrectMasterBranch != null) HideRow(trCorrectMasterBranch);
                    if (hlnkRemoveHigherRate != null) HideRow(hlnkRemoveHigherRate);
                    if (hlnkUpdateITRate194 != null) HideRow(hlnkUpdateITRate194);
                    if (hlnkUpdateCashDraw != null) HideRow(hlnkUpdateCashDraw);
                    if (hlnkRemove197Cert != null) HideRow(hlnkRemove197Cert);
                    if (hlnkHTMLReport != null) HideRow(hlnkHTMLReport);
                    if (hlnkExcelReport != null) HideRow(hlnkExcelReport);
                    if (hlnkCRNUpdateLog != null) HideRow(hlnkCRNUpdateLog);

                    DisplayRow(trUploadFile); btnlink.value = "Upload";
                    if (hlnkAutoLinkLog != null) hlnkAutoLinkLog.innerHTML = '';
                    if (hlnkRemoveHigherRate != null) hlnkRemoveHigherRate.innerHTML = '';
                    if (hlnkUpdateITRate194 != null) hlnkUpdateITRate194.innerHTML = '';
                    if (hlnkUpdateCashDraw != null) hlnkUpdateCashDraw.innerHTML = '';
                    if (hlnkRemove197Cert != null) hlnkRemove197Cert.innerHTML = '';
                    if (hlnkHTMLReport != null) hlnkHTMLReport.innerHTML = '';
                    if (hlnkExcelReport != null) hlnkExcelReport.innerHTML = '';
                    if (hlnkCRNUpdateLog != null) hlnkCRNUpdateLog.innerHTML = '';
                    break;
            }
            document.getElementById("<%=lblManagedType.ClientID%>").innerHTML = "Selected Type : " + " " + "<b>" + document.getElementById("<%=lstTypeOfManageData.ClientID%>")[selectedIdex].text + "</b>";
        }
        function HideRow(row) { row.style.display = 'none'; } function DisplayRow(row) { row.style.display = ''; }
       
        function DisplayHideFormSequence() {
            var formTypeSelectedIndex = document.getElementById("<%=ddlFormType.ClientID%>").selectedIndex;
            var trFormSequence = document.getElementById("<%=trFormSequence.ClientID%>");
            var ddlFormSequence = document.getElementById("<%=ddlFormSequence.ClientID%>");
            if (formTypeSelectedIndex != "0") {
                if (trFormSequence != null) {
                    ddlFormSequence.selectedIndex = 0;
                    HideRow(trFormSequence);
                }
            }
            else {
                DisplayRow(trFormSequence);
            }
        }
        function SelectAllCheckBox() {
            var x = document.getElementsByClassName("chkBoxDed");
            var i;
            for (i = 0; i <= x.length; i++) {
                if (i < 10) {
                    i = '0' + i;
                }
                el = document.getElementById('ctl00_contentPlaceHolderBody_rptrDeduction_ctl' + i + '_chkSelect');
                if (el != null) {
                    el.checked = true;
                }
            }
            return false;
        }
        function UnSelectAllCheckBox() {
            var x = document.getElementsByClassName("chkBoxDed");
            var i;
            for (i = 0; i <= x.length; i++) {
                if (i < 10) {
                    i = '0' + i;
                }
                el = document.getElementById('ctl00_contentPlaceHolderBody_rptrDeduction_ctl' + i + '_chkSelect');
                if (el != null) {
                    el.checked = false;
                }
            }
            return false;
        }
        function ConfirmDelete() {
            if (confirm("Do you want to Delete?"))
                return true;
            else
                return false;
        }
        function validateFileUpload() {
            debugger;
            var fileUpload = document.getElementById("<%=uploadfile.ClientID%>");
            if (fileUpload.files.length == 0) {
                alert("Please select a .txt file.");
                return false;
            }
            var file = fileUpload.files[0];
            var fileName = file.name;
            var ext = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
            var allowedExtensions = ["txt"];

            if (allowedExtensions.indexOf(ext) === -1) {
                alert("Please select a .txt file.");
                return false;
            }
            return true;
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:HiddenField ID="hdnPreviewClick" runat="server" Value="0" />
    <asp:HiddenField ID="hdnSelectedQuarter" runat="server" Value="-1" />
    <table>
        <tr>
            <asp:Label ID="lblManagedType" runat="server" Text="Selected Type : Zero Tds Linking"></asp:Label>
        </tr>
        <tr>
            <td>
                <asp:ListBox ID="lstTypeOfManageData" runat="server" Width="190px" Height="225px"
                    onchange="SelectUnselectAll(); " OnSelectedIndexChanged="lstTypeOfManageData_SelectedIndexChanged" AutoPostBack="true">
                    <asp:ListItem Text="Zero Tds Linking" Value="0" Selected="True"></asp:ListItem>
                    <asp:ListItem Text="Auto Linking" Value="1"></asp:ListItem>
                    <asp:ListItem Text="Interest Amount Recalculation" Value="2"></asp:ListItem>
                    <asp:ListItem Text="Update UIN" Value="3"></asp:ListItem>
                    <asp:ListItem Text="Link BGL code to ZeroTDS" Value="4"></asp:ListItem>
                    <asp:ListItem Text="Auto Link" Value="5"></asp:ListItem>
                    <asp:ListItem Text="Update Income Tax Rate (194A)" Value="6"></asp:ListItem>
                    <asp:ListItem Text="Correct Master Data" Value="7"></asp:ListItem>
                    <asp:ListItem Text="197 certificate verification upload" Value="8"></asp:ListItem>
                    <asp:ListItem Text="Update CIN" Value="9"></asp:ListItem>
                    <asp:ListItem Text="Remove Higher Rate Remark, Deduction with PAN" Value="10"></asp:ListItem>
                    <asp:ListItem Text="Update IT Rate - 194A, on TDS Mismatch" Value="11"></asp:ListItem>
                    <asp:ListItem Text="Update Cash Drawn for 194N/194NF" Value="12"></asp:ListItem>
                    <asp:ListItem Text="Remove 15GH Certificate, Deduction with Higher Tax Rate" Value="13"></asp:ListItem>
                    <asp:ListItem Text="Negative Interest Adjustment" Value="14"></asp:ListItem>
                    <asp:ListItem Text="Update CRN" Value="15"></asp:ListItem>
                    <asp:ListItem Text="Reversal Transaction" Value="16"></asp:ListItem>
                </asp:ListBox>
            </td>
            <td valign="top" style="width: 100%;">
                <table>
                    <tr id="trQuarter" runat="server">
                        <td align="right">
                            <asp:Label ID="lblQuarter" runat="server" Text="Quarter : "></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlQuarter" runat="server" CssClass="mdropDownList" Width="125px">
                                <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                <asp:ListItem Text="Quarter1" Value="1"></asp:ListItem>
                                <asp:ListItem Text="Quarter2" Value="2"></asp:ListItem>
                                <asp:ListItem Text="Quarter3" Value="3"></asp:ListItem>
                                <asp:ListItem Text="Quarter4" Value="4"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr id="trMonth" runat="server">
                        <td align="right">
                            <asp:Label ID="lblMonth" runat="server" Text="Select Deducted Month : "></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlMonth" runat="server" CssClass="mdropDownList" Width="125px">
                                <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                <asp:ListItem Text="April" Value="4"></asp:ListItem>
                                <asp:ListItem Text="May" Value="5"></asp:ListItem>
                                <asp:ListItem Text="June" Value="6"></asp:ListItem>
                                <asp:ListItem Text="July" Value="7"></asp:ListItem>
                                <asp:ListItem Text="August" Value="8"></asp:ListItem>
                                <asp:ListItem Text="September" Value="9"></asp:ListItem>
                                <asp:ListItem Text="October" Value="10"></asp:ListItem>
                                <asp:ListItem Text="November" Value="11"></asp:ListItem>
                                <asp:ListItem Text="December" Value="12"></asp:ListItem>
                                <asp:ListItem Text="January" Value="1"></asp:ListItem>
                                <asp:ListItem Text="February" Value="2"></asp:ListItem>
                                <asp:ListItem Text="March" Value="3"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr id="trLinkChallan" runat="server">
                        <td align="right">
                            <asp:Label ID="lblChallan" runat="server" Text="Link With :"></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlChallanType" runat="server" CssClass="mdropDownList" Width="185px">
                                <asp:ListItem Text="Autogenerated Challans" Value="1"></asp:ListItem>
                                <asp:ListItem Text="All Challans" Value="2"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr id="trDate" runat="server">
                        <td align="right">
                            <asp:Label ID="lblPaidDate" runat="server" Text="Challan Paid Date : "></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="txtPaidDate" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                runat="server" Width="195px" BackColor="#E5E5E5" AutoComplete="Off" CssClass="txtBPR"
                                TabIndex="4" onBlur="setDateFormat(this);"></asp:TextBox>
                        </td>
                    </tr>
                    <tr id="trBranchCode" runat="server">
                        <td align="right">
                            <asp:Label ID="lblBranchCode" runat="server" Text="Branch Code : "></asp:Label>
                        </td>
                        <td>
                            <asp:TextBox ID="txtBranchCode" runat="server" CssClass="txtBPL"></asp:TextBox>
                        </td>
                    </tr>
                    <tr id="trUploadFile" runat="server">
                        <td align="right">
                            <asp:Label ID="lblUploadFile" runat="server" Text="Upload File :"></asp:Label>
                        </td>
                        <td>
                            <asp:FileUpload ID="uploadfile" runat="server" CssClass="browsBtn" />
                        </td>
                    </tr>
                    <tr id="trFormType" runat="server">
                        <td align="right">
                            <asp:Label ID="lblFormType" runat="server" Text="Form Type :"></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlFormType" runat="server" CssClass="mdropDownList" Width="125px"
                                onchange="DisplayHideFormSequence();">
                                <asp:ListItem Text="All" Value="-1"></asp:ListItem>
                                <asp:ListItem Text="24Q" Value="1"></asp:ListItem>
                                <asp:ListItem Text="26Q" Value="2"></asp:ListItem>
                                <asp:ListItem Text="27Q" Value="3"></asp:ListItem>
                                <asp:ListItem Text="27EQ" Value="4"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr id="trFormSequence" runat="server">
                        <td align="right">
                            <asp:Label ID="lblFormSequence" runat="server" Text="Form Sequence :"></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlFormSequence" runat="server" CssClass="mdropDownList" Width="125px">
                                <asp:ListItem Text="24Q,26Q,27Q,27EQ" Value="1234"></asp:ListItem>
                                <asp:ListItem Text="26Q,27Q,27EQ,24Q" Value="2341"></asp:ListItem>
                                <asp:ListItem Text="27EQ,27Q,24Q,26Q" Value="4312"></asp:ListItem>
                                <asp:ListItem Text="24Q,27Q,27EQ,26Q" Value="1342"></asp:ListItem>
                                <asp:ListItem Text="26Q,24Q,27Q,27EQ" Value="2134"></asp:ListItem>
                                <asp:ListItem Text="27EQ,27Q,26Q,24Q" Value="4321"></asp:ListItem>
                                <asp:ListItem Text="27Q,26Q,24Q,27EQ" Value="3214"></asp:ListItem>
                                <asp:ListItem Text="26Q,27Q,24Q,27EQ" Value="2314"></asp:ListItem>
                                <asp:ListItem Text="24Q,27Q,26Q,27EQ" Value="1324"></asp:ListItem>
                                <asp:ListItem Text="27EQ,24Q,27Q,26Q" Value="4132"></asp:ListItem>
                                <asp:ListItem Text="27Q,24Q,26Q,27EQ" Value="3124"></asp:ListItem>
                                <asp:ListItem Text="26Q,27EQ,24Q,27Q" Value="2413"></asp:ListItem>
                                <asp:ListItem Text="27Q,27EQ,24Q,26Q" Value="3412"></asp:ListItem>
                                <asp:ListItem Text="27EQ,26Q,27Q,24Q" Value="4231"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr id="trLinkDedAmount" runat="server">
                        <td align="right">Link Deducted Amount:
                        </td>
                        <td align="left">
                            <asp:RadioButton ID="rbtnHigh" runat="server" Text="Higher to Lower" GroupName="Form16"
                                Checked="true" />
                            <asp:RadioButton ID="rbtnLow" runat="server" Text="Lower to Higher" GroupName="Form16"
                                Visible="true" />
                        </td>
                    </tr>
                    <tr id="trLinkSection" runat="server">
                        <td align="right">Link :
                        </td>
                        <td align="left">
                            <asp:RadioButton ID="rdbSectionWise" runat="server" Text="Section Wise" GroupName="Form17"
                                Checked="true" />
                            <asp:RadioButton ID="rdbAcrossSection" runat="server" Text="Across Sections" GroupName="Form17"
                                Visible="true" />
                        </td>
                    </tr>
                    <tr id="trCheckkStatus" runat="server">
                        <td align="right">
                            <asp:CheckBox ID="chkStatus" runat="server" Checked="true"></asp:CheckBox>
                        </td>
                        <td align="left">
                            <asp:Label ID="lblCompanyStatus" runat="server" Text="Ignore Company/Non-Company Status"></asp:Label>
                        </td>
                    </tr>
                    <tr id="trCorrectMasterOption" runat="server">
                        <td colspan="2">
                            <asp:RadioButton ID="rbtnEmployee" runat="server" Text="Employee" GroupName="EmpnonEmp"
                                Checked="true" />
                            <asp:RadioButton ID="rbtnNonEmployee" runat="server" Text="Non Employee" GroupName="EmpnonEmp"
                                Visible="true" />
                        </td>
                    </tr>
                    <tr id="trCorrectMasterBranch" runat="server">
                        <td colspan="2">
                            <asp:Label ID="lblBranchC" runat="server" Text="Branch Code : "></asp:Label>
                            <asp:TextBox ID="txtBranch" runat="server" CssClass="txtBPL"></asp:TextBox>
                        </td>
                    </tr>
                    <tr id="trLinkZeroTDS" runat="server">
                        <td align="right">Link :
                        </td>
                        <td align="left">
                            <asp:RadioButton ID="rdbMonthWise" runat="server" Text="Month Wise" GroupName="ZeroTDS" Checked="true" />
                            <asp:RadioButton ID="rdbQuarterWise" runat="server" Text="Quarter Wise" GroupName="ZeroTDS" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Button ID="btnLink" runat="server" Text="Link" CssClass="cmnBtn" OnClientClick="return Validate();"
                                OnClick="btnLink_Click" />
                        </td>
                        <td>
                            <asp:HyperLink ID="hlnkRecalculate" runat="server" Target="_blank" Text="" Visible="false"> </asp:HyperLink>
                            &nbsp
                            <asp:HyperLink ID="hlnkRecalculateExcel" runat="server" Target="_blank" Text="" Visible="false"> </asp:HyperLink>
                            &nbsp
                            <asp:HyperLink ID="hlnkAutoLinkLog" runat="server" Target="_blank" Text="" Visible="false"> </asp:HyperLink>
                             &nbsp
                            <asp:HyperLink ID="hlnkCRNUpdateLog" runat="server" Target="_blank" Text="" Visible="false"> </asp:HyperLink>
                             &nbsp
                            <asp:HyperLink ID="hlnkRTDownload" runat="server" Target="_blank" Text="" Visible="false" ForeColor="Blue"> </asp:HyperLink>
                        </td>
                    </tr>
                    <tr id="trhlnk" runat="server">
                        <td colspan="3">
                            <asp:HyperLink ID="hlnkRemoveHigherRate" runat="server" Target="_blank" Text="" Visible="true" ForeColor="Blue"> </asp:HyperLink>
                            &nbsp
                            <asp:HyperLink ID="hlnkUpdateITRate194" runat="server" Target="_blank" Text="" Visible="true" ForeColor="Blue"> </asp:HyperLink>
                            &nbsp
                            <asp:HyperLink ID="hlnkUpdateCashDraw" runat="server" Target="_blank" Text="" Visible="true" ForeColor="Blue"> </asp:HyperLink>
                            &nbsp
                            <asp:HyperLink ID="hlnkRemove197Cert" runat="server" Target="_blank" Text="" Visible="true" ForeColor="Blue"> </asp:HyperLink>
                            &nbsp&nbsp&nbsp
                            <asp:HyperLink ID="hlnkHTMLReport" runat="server" Target="_blank" Text="" Visible="true" ForeColor="Blue"> </asp:HyperLink>
                            &nbsp&nbsp&nbsp&nbsp
                            <asp:HyperLink ID="hlnkExcelReport" runat="server" Target="_blank" Text="" Visible="true" ForeColor="Blue"> </asp:HyperLink>
                        </td>
                    </tr>
                    <tr id="rowNote" runat="server">
                        <td colspan="2">
                            <asp:Label ID="lblNote" runat="server" Text="Note : UIN and Amount update will not be done for branches who have already done eReturn."
                                ForeColor="#0000CC" Width="400px"></asp:Label>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr id="rowRT" runat="server" style="display:none">
            <td runat="server" colspan="6">
                <asp:Panel ID="pnReverseTransation" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                    BorderStyle="Solid" BorderWidth="1px" BorderColor="Gray">
                    <asp:Repeater ID="rptrDeduction" runat="server" OnItemDataBound="rptrDeduction_ItemDataBound">
                        <HeaderTemplate>
                            <table id="NavTable" border="1">
                                <tr bgcolor="#EEEEEE">
                                    <th></th>
                                    <th style="display: none">DeductionID
                                    </th>
                                    <th>
                                        <asp:Label ID="lblParentBCode" runat="server" Text="RO Code" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblChildBCode" runat="server" Text="Branch Code" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblName" runat="server" Text="Name" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblPan" runat="server" Text="PAN" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblSection" runat="server" Text="Section" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblFormQuarter" runat="server" Text="Form-Quarter" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblDedslno" runat="server" Text="Deduction Serial No." Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblAmtOfPayment" runat="server" Text="Amount of Payment" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblPaidDate" runat="server" Text="Paid/Credited Date" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblTDS" runat="server" Text="Total TDS" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblTaxDeductedDate" runat="server" Text="Deducted Date" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblITRate" runat="server" Text="IncomeTax Rate" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblITAmount" runat="server" Text="IncomeTax" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblAccNo" runat="server" Text="Account Number" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblDDNo" runat="server" Text="DD No." Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblChallanSlNo" runat="server" Text="Challan Serial No." Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblChallanAmt" runat="server" Text="Challan Amount" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblBsrCode" runat="server" Text="BSR Code" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblChallanDate" runat="server" Text="Challan Date" Width="100px"></asp:Label>
                                    </th>
                                    <th>
                                        <asp:Label ID="lblCDNo" runat="server" Text="CD No." Width="100px"></asp:Label>
                                    </th>
                                </tr>
                        </HeaderTemplate>
                        <ItemTemplate>
                            <tr bgcolor="white">
                                <td>
                                    <asp:CheckBox ID="chkSelect" runat="server" CssClass="chkBoxDed" />
                                </td>
                                <td style="display: none">
                                    <asp:Label ID="lblDeductionID" runat="server" Text='<%# Eval("DeductionId")%>'></asp:Label>
                                </td>
                                <td style="text-align: center">
                                    <%#Eval("ParentBranchCode")%>
                                </td>
                                <td style="text-align: center">
                                    <%#Eval("ChildBranchCode")%>
                                </td>
                                <td>
                                    <%# Eval("Name")%>
                                </td>
                                <td>
                                    <asp:Label ID="lblDedPan" runat="server" Text='<%# Eval("PAN")%>'></asp:Label>
                                </td>
                                <td style="text-align: left">
                                    <asp:Label ID="lblSectionName" Text='<%#Eval("SectionName")%>' runat="server"></asp:Label>
                                </td>
                                <td style="text-align: center">
                                    <%#Eval("FormQuarter") %>
                                </td>
                                <td style="text-align: left">
                                    <%#Eval("DeductionSerialNo") %>
                                </td>
                                <td style="text-align: right">
                                    <%#Eval("PaymentMade") %>
                                </td>
                                <td style="text-align: right">
                                    <%#Eval("PaymentDate") %>
                                </td>
                                <td style="text-align: right">
                                    <%#Eval("TotalDeducted") %>
                                </td>
                                <td style="text-align: right">
                                    <%#Eval("DeductedDate") %>
                                </td>
                                <td style="text-align: right">
                                    <%#Eval("IncomeTaxRate")%>
                                </td>
                                <td style="text-align: right">
                                    <%#Eval("IncomeTax")%>
                                </td>
                                <td style="text-align: center">
                                    <%#Eval("AccountNumber")%>
                                </td>
                                <td style="text-align: left">
                                    <%#Eval("DDNo")%>
                                </td>
                                <td style="text-align: left">
                                    <%#Eval("ChallanSerialNo")%>
                                </td>
                                <td style="text-align: right">
                                    <%#Eval("ChallanTotal")%>
                                </td>
                                <td style="text-align: center">
                                    <%#Eval("BSRCode")%>
                                </td>
                                <td style="text-align: right">
                                    <%#Eval("ChallanPaidDate")%>
                                </td>
                                <td style="text-align: left">
                                    <%#Eval("CDNo")%>
                                </td>
                            </tr>
                        </ItemTemplate>
                        <FooterTemplate>
                            </table>
                        </FooterTemplate>
                    </asp:Repeater>
                </asp:Panel>
                <table style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px">
                    <tr>
                        <td>
                            <asp:Label ID="lblCorrSel" runat="server" Text="Select :"></asp:Label>
                        </td>
                        <td>
                            <asp:LinkButton ID="lnkbtnCheckAll" runat="server" Text="All" OnClientClick="return SelectAllCheckBox();"></asp:LinkButton>
                        </td>
                        <td>
                            <asp:Label ID="lblCorrPipe" runat="server" Text="|"></asp:Label>
                        </td>
                        <td>
                            <asp:LinkButton ID="lnkbtnUnCheckAll" runat="server" Text="None" OnClientClick="return UnSelectAllCheckBox();"
                                CausesValidation="true"></asp:LinkButton>
                        </td>
                        <td style="width:60px;">
                        </td>
                        <td>
                            <asp:Button ID="bntDelete" runat="server" Text="Delete" CssClass="cmnBtn" OnClick="bntDelete_Click" onclientclick="return ConfirmDelete();"/>
                        </td>
                        <td style="width:20px;">
                        </td>
                        <td>
                            <asp:Button ID="bntDeleteAll" runat="server" Text="Delete All" CssClass="cmnBtn" OnClick="bntDeleteAll_Click"  onclientclick="return ConfirmDelete();"/>
                        </td>
                        <td style="width:30px;">
                        </td>
                        <td>
                            <asp:Label ID="lblDedCount" runat="server" Text="" style="color:blue"></asp:Label>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</asp:Content>
