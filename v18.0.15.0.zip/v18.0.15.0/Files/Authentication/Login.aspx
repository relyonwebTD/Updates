﻿<%@ page language="C#" autoeventwireup="true" inherits="Authentication_Login, App_Web_login.aspx.e7d8667b" stylesheettheme="" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Welcome to SaralTDS Web</title>
    <link href="../App_Themes/Standard/Captcha.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="data:,"/>
    <script language="javascript" type="text/javascript" src="../JavaScript/Validations.js"></script>
    <script type="text/javascript">        
        function GetResult(returnValue, context) {
            var a = returnValue.split(',');
            if (a[0].trim() == "1") {
                document.getElementById("<%=txtPassword.ClientID%>").value = a[1];
                document.getElementById("<%=txtCaptcha.ClientID%>").value = "";
                __doPostBack('Sender', 'Login')
            }
            else {
                document.getElementById("<%=lblCaptchaImage.ClientID%>").innerHTML = a[1];
            }
        }
        function SendRequest(obj) { CallServer(obj); }
        function GetDetails(obj) {
            if (obj != null) {
                if (obj.value != "") {
                    var encPassword = encryptCodes(obj.value, "saraltds");
                    SendRequest(encPassword);
                    //                    var decPassword = decryptCodes(encPassword, "saraltds");
                    //                    SendRequest(obj.value);
                }
            }
            else {
                SendRequest(null);
            }
        }

        function encryptCodes(content, passcode) {
            var calAscii = "";
            var passLen = passcode.length;
            for (var i = 0; i < content.length; i++) {
                var passOffset = i % passLen;
                calAscii = calAscii + (content.charCodeAt(i) + passcode.charCodeAt(passOffset)) + (i == content.length - 1 ? "" : ",");
            }
            return calAscii;
        }

        function decryptCodes(content, passcode) {
            var result = [];
            var str = '';
            var codesArr = content.split(',');
            var passLen = passcode.length;
            for (var i = 0; i < codesArr.length; i++) {
                var passOffset = i % passLen;
                var calAscii = (codesArr[i] - passcode.charCodeAt(passOffset));
                var ch = String.fromCharCode(calAscii);
                str += ch;
            }
            return str;
        }

        function CheckJSValidity() {
            var ua = window.navigator.userAgent
            var msie = ua.indexOf("MSIE ");
            var ieVersion = 0;
            var versionLen = 0;
            if (msie < 0) {
                msie = ua.indexOf("rv");
                ieVersion = parseInt(ua.substring(msie + 3, ua.indexOf(".", msie)));
                versionLen = ieVersion == 11 ? 3 : 0;
            }
            else {
                ieVersion = parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
                versionLen = 5;
            }
            if (versionLen == 3 || versionLen == 5)
                document.getElementById("<%=divComp.ClientID%>").style.display = 'none';
            else if (versionLen == 0)
                document.getElementById("<%=divComp.ClientID%>").style.display = 'none';
            document.getElementById("jsEnabled").style.visibility = 'visible';
            if (document.getElementById("txtUsername") != null) {
                document.getElementById("txtUsername").focus();
            }
        }
        function filterlist(selectobj) {
            this.selectobj = selectobj;
            this.flags = 'i';
            this.match_text = true;
            this.match_value = false;
            this.show_debug = false;
            this.init = function () {
                if (!this.selectobj) return this.debug('selectobj not defined');
                if (!this.selectobj.options) return this.debug('selectobj.options not defined');
                this.optionscopy = new Array();
                if (this.selectobj && this.selectobj.options) {
                    for (var i = 0; i < this.selectobj.options.length; i++) {
                        this.optionscopy[i] = new Option();
                        this.optionscopy[i].text = selectobj.options[i].text;
                        if (selectobj.options[i].value) {
                            this.optionscopy[i].value = selectobj.options[i].value;
                        } else {
                            this.optionscopy[i].value = selectobj.options[i].text;
                        }

                    }
                }
            }
            this.reset = function () { this.set(''); }
            this.set = function (pattern) {
                var loop = 0, index = 0, regexp, e;
                if (!this.selectobj) return this.debug('selectobj not defined');
                if (!this.selectobj.options) return this.debug('selectobj.options not defined');
                this.selectobj.options.length = 0;
                try {
                    regexp = new RegExp(pattern, this.flags);
                } catch (e) {
                    if (typeof this.hook == 'function') {
                        this.hook();
                    }
                    return;
                }
                for (loop = 0; loop < this.optionscopy.length; loop++) {
                    var option = this.optionscopy[loop];
                    if ((this.match_text && regexp.test(option.text)) || (this.match_value && regexp.test(option.value))) {
                        this.selectobj.options[index++] = new Option(option.text, option.value, false);
                    }
                }
                if (typeof this.hook == 'function') {
                    this.hook();
                }
            }
            this.set_ignore_case = function (value) {
                if (value) {
                    this.flags = 'i';
                } else {
                    this.flags = '';
                }
            }
            this.debug = function (msg) {
                if (this.show_debug) {
                    alert('FilterList: ' + msg);
                }
            }
            this.init();
        }
        function Validate() {
            if (document.getElementById("<%=txtUsername.ClientID%>").value.length == 0) {
                alert("Username cannot be empty");
                document.getElementById("<%=txtUsername.ClientID%>").focus();
                return false;
            }
            if (document.getElementById("<%=txtPassword.ClientID%>").value.length == 0) {
                alert("Password cannot be empty");
                document.getElementById("<%=txtPassword.ClientID%>").focus();
                return false;
            }
            if (document.getElementById("<%=hdnIs24G.ClientID%>").value == "1" || document.getElementById("<%=hdnCaptchaEnable.ClientID%>").value == "1") {
                var lblCaptcha = document.getElementById("<%=lblCaptchaImage.ClientID%>").innerHTML;
                var txtCaptcha = document.getElementById("<%=txtCaptcha.ClientID%>").value;
                if (!txtCaptcha.match(lblCaptcha)) {
                    alert("Entered code does not match");
                    document.getElementById("<%=txtCaptcha.ClientID%>").focus();
                    return false;
                }
            }
            if (document.getElementById("<%=hdnIsJK.ClientID%>").value == "1") {
                alert("Branches are reminded that verification of TDS entries in Saral TDS\nis a time-bound activity.\n\nIt must invariably be completed within the same month\nto which the entries pertain so as to avoid discrepancies\nin TDS computation, deduction and subsequent reporting to the Income Tax Department.");               
            }
            GetDetails(document.getElementById("<%=txtPassword.ClientID%>"));
            return false;
        }
        function ValidateForgotPsswd() {
            if (document.getElementById('txtUsername').value.length == 0) {
                alert("Enter Valid Username.");
                document.getElementById('txtUsername').focus();
                return false;
            }
        }
        function capLock(e) {
            kc = e.keyCode ? e.keyCode : e.which;
            sk = e.shiftKey ? e.shiftKey : ((kc == 16) ? true : false);
            if (((kc >= 65 && kc <= 90) && !sk) || ((kc >= 97 && kc <= 122) && sk))
                document.getElementById('CapOn').style.visibility = 'visible';
            else
                document.getElementById('CapOn').style.visibility = 'hidden';
        }
        function mischandler() {
            return false;
        }
        function mousehandler(e) {
            var isNS = 0;
            var myevent = (isNS) ? e : event;
            var eventbutton = (isNS) ? myevent.which : myevent.button;
            if ((eventbutton == 2) || (eventbutton == 3)) return false;
        }
        document.oncontextmenu = mischandler;
        document.onmousedown = mousehandler;
        document.onmouseup = mousehandler;
        var isCtrl = false;
        document.onkeyup = function (e) {
            e = window.event.keyCode;
            if (window.event.ctrlKey)
                return false;
        }
        document.onkeydown = function (e) {
            e = window.event.keyCode;
            if (window.event.ctrlKey)
                return false;
        }
        function ShowControls() {
            var Is24G = document.getElementById("<%=hdnIs24G.ClientID%>").value;
            var rowCaptcha = document.getElementById("<%=trCaptcha.ClientID%>");
            var rowCaptchaText = document.getElementById("<%=trCaptchaText.ClientID%>");
            var ImgRefresh = document.getElementById("<%=ImgRefresh.ClientID%>");
            var txtCaptcha = document.getElementById("<%=txtCaptcha.ClientID%>");
            var CaptchaEnable = document.getElementById("<%=hdnCaptchaEnable.ClientID%>").value;
            if (Is24G == "1" || CaptchaEnable == "1") {
                if (rowCaptcha != null) {
                    rowCaptcha.style.display = '';
                    rowCaptchaText.style.display = '';
                    ImgRefresh.disabled = false;
                    txtCaptcha.disabled = false;
                }
            }
            else
                if (rowCaptcha != null) {
                    rowCaptcha.style.display = 'none';
                    rowCaptchaText.style.display = 'none';
                    ImgRefresh.disabled = true;
                    txtCaptcha.disabled = true;
                }
        }
        function SetBackground() {
            if (document.getElementById("<%=hdnTheme.ClientID%>").value == "1") {
                lgbody.style.background = "#d5dadd repeat-x left top";
            }
            else if (document.getElementById("<%=hdnTheme.ClientID%>").value == "2") {
                lgbody.style.background = "#c5d1e2 repeat-x left top";
            }
            else {
                lgbody.style.background = "#e2c28e repeat-x left top";
            }
        }
        function textValidate(txt) {
            var numCheck = /^[a-zA-Z0-9()_ -]+$/;
            if (!numCheck.test(txt)) {
                document.getElementById("<%=txtSearch.ClientID%>").value = "";
              return false;
            }
            return true;
        }
        function validateBranchCode() {
            var bCode = document.getElementById('<%= txtSearch.ClientID %>');
            var branch = bCode.value.trim();
            var regex = /^[a-zA-Z0-9_]+$/;

            if (!regex.test(branch)) {
                bCode.value = branch.replace(/[^a-zA-Z0-9_ -]/g, '');
            }
        }
    </script>
    <meta http-equiv="Page-Exit" content="progid:DXImageTransform.Microsoft.Fade(duration=.25)" />
</head>
<body id="lgbody" onload="CheckJSValidity();" oncontextmenu="alert('Right Click Disabled!');return false;">
    <form id="formLogin" runat="server" defaultbutton="btnLogin">
        <noscript>
            <div id="jsDisabled" style='margin: 8px 0px'>
                <div style='padding-left: 0px; padding-right: 0px; padding-top: 0px; background-position: left bottom; padding-bottom: 3px; background-repeat: repeat-x'>
                    <div style='border: #FF0000 1px solid; padding: 3px;'>
                        <div style='background-color: #C11B17; padding: 5px; font-size: 13px; overflow: hidden; color: #FFFFFF; font-family: Verdana,Tahoma, Arial, Helvetica, sans-serif; text-align: center'>
                            Your browser does not support JavaScript or it may be disabled!
                        </div>
                    </div>
                </div>
            </div>
        </noscript>
        <div style="display: none; text-align: center; font-weight: bold; font-size: medium; padding-top: 5px"
            id="divComp" runat="server">
            <asp:Label ID="lblCompatiablity" runat="server" Text="Enable compatibility view in your browser for best result."
                ForeColor="Red"></asp:Label>
        </div>
        <div style="text-align: right; font-weight: bold; font-size: medium; padding-top: 5px"
            id="divSelectTheme" runat="server">
            <asp:Button ID="btnGray" Width="20px" Height="20px" runat="server" BackColor="Gray"
                Style="border-radius: 5px;" OnClick="btnGray_Click" />
            <asp:Button ID="btnBlue" Width="20px" Height="20px" runat="server" BackColor="MidnightBlue"
                Style="border-radius: 5px;" OnClick="btnBlue_Click" />
            <asp:Button ID="btnOrange" Width="20px" Height="20px" runat="server" BackColor="Orange"
                Style="border-radius: 5px;" OnClick="btnOrange_Click" />
        </div>
        <div style="text-align: right; font-weight: bold; font-size: medium; padding-top: 5px"
            id="divReleaseNote" runat="server">
            <asp:HyperLink ID="lblReleaseNote" Text="Release Note" runat="server"
                Target="_blank" NavigateUrl="~/ReleaseNote/ReleaseNote.htm"></asp:HyperLink>
        </div>
        <asp:HiddenField ID="hdnIs24G" runat="server" Value="0" />
        <asp:HiddenField ID="hdnTheme" runat="server" Value="0" />
        <asp:HiddenField ID="hdnCaptchaEnable" runat="server" Value="0" />
        <asp:HiddenField ID="hdnIsSIB" runat="server" Value="0" />
        <asp:HiddenField ID="hdnIsBOB" runat="server" Value="0"/> 
        <asp:HiddenField ID="hdnIsIB" runat="server" Value="0"/>
        <asp:HiddenField ID="hdnIsBOM" runat="server" Value="0"/>
        <asp:HiddenField ID="hdnIsJK" runat ="server" Value="0" />
        <div id="jsEnabled" style="visibility: visible">
            <table style="width: 100%; height: 500px;" align="center">
                <tr>
                    <td style="width: 100%;">
                        <center>
                            <div id="loginDiv" style="vertical-align: middle;">
                                <asp:MultiView ID="mvwAuthentication" runat="server" ActiveViewIndex="1">
                                    <asp:View ID="vwBranches" runat="server">
                                        <div id="sbdialog" runat="server" style="text-align: left; width: 532px;">
                                            <div id="sbheader" runat="server">
                                                Select Branch for login
                                            </div>
                                            <div style="padding: 10px; border-top: solid 1px gray">
                                                <table width="100%">
                                                    <tr id="filterRow" runat="server">
                                                        <td>
                                                            <table width="100%">
                                                                <tr>
                                                                    <td>
                                                                        <table>
                                                                            <tr>
                                                                                <td style="width: 50px" valign="top">Filter
                                                                                </td>
                                                                                <td style="width: 350px">
                                                                                    <asp:TextBox ID="txtSearch" runat="server" autocomplete="Off" Style="border: 1px solid #9f9f9f; font-family: tahoma; text-align: left; width: 330px; border-radius: 5px;"
                                                                                        onkeyup="myfilter.set(this.value)" oninput="validateBranchCode()"/>
                                                                                </td>
                                                                                <td valign="bottom">&nbsp
                                                                                <asp:ImageButton ID="imgSearch" runat="server" ImageUrl="~/App_Themes/Standard/Images/Search.gif"
                                                                                    Visible="false" Height="16px" ToolTip="Search" OnClick="imgSearch_Click" />
                                                                                    <asp:ImageButton ID="ImgClear" runat="server" ImageUrl="~/App_Themes/Standard/Images/ShowAll.gif"
                                                                                        ToolTip="Show All" OnClick="ImgClear_Click" Visible="false" />
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <asp:Label ID="lblNote" runat="server" Text="Click on search after entering in Filter"
                                                                            Visible="false"></asp:Label>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <asp:ListBox ID="lstBranches" runat="server" Width="500px" Style="border-radius: 5px;"
                                                                Height="220px" Font-Size="10"></asp:ListBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <table width="100%">
                                                                <tr>
                                                                    <td align="center">
                                                                        <asp:Button ID="btnSelect" runat="server" Text="Select" Width="80px" OnClick="btnSelect_Click" />
                                                                    </td>
                                                                    <td align="center">
                                                                        <asp:Button ID="btnBack" runat="server" Text="Back" Width="80px" OnClick="btnBack_Click" />
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <script type="text/javascript">
                                            var myfilter = new filterlist(document.getElementById("lstBranches"));
                                        </script>
                                    </asp:View>
                                    <asp:View ID="vwLogin" runat="server" EnableViewState="False">
                                        <div id="lgdialog" runat="server" style="text-align: left; width: 332px;">
                                            <div id="lgheader" runat="server">
                                                <asp:Label ID="lblVersion" Text="SaralTDS Web" runat="server"></asp:Label>
                                            </div>
                                            <div style="padding: 10px; border-top: solid 1px gray">
                                                <table style="width: 100%">
                                                    <tr id="trFinancialYear" runat="server">
                                                        <td style="width: 100%; text-align: center">
                                                            <asp:Label ID="lblYear" Text="Financial Year" runat="server"/>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%;">
                                                            <asp:DropDownList ID="ddlFinYear" runat="server" Font-Size="Large" Style="border-radius: 5px;"
                                                                Width="100%" TabIndex="1" AutoPostBack="True" OnSelectedIndexChanged="ddlFinYear_SelectedIndexChanged">
                                                                <asp:ListItem Text="2009-10" Value="2009"></asp:ListItem>
                                                                <asp:ListItem Text="2010-11" Value="2010"></asp:ListItem>
                                                                <asp:ListItem Text="2011-12" Value="2011"></asp:ListItem>
                                                                <asp:ListItem Text="2012-13" Value="2012"></asp:ListItem>
                                                                <asp:ListItem Text="2013-14" Value="2013"></asp:ListItem>
                                                                <asp:ListItem Text="2014-15" Value="2014"></asp:ListItem>
                                                                <asp:ListItem Text="2015-16" Value="2015"></asp:ListItem>
                                                                <asp:ListItem Text="2016-17" Value="2016"></asp:ListItem>
                                                                <asp:ListItem Text="2017-18" Value="2017"></asp:ListItem>
                                                                <asp:ListItem Text="2018-19" Value="2018"></asp:ListItem>
                                                                <asp:ListItem Text="2019-20" Value="2019"></asp:ListItem>
                                                                <asp:ListItem Text="2020-21" Value="2020"></asp:ListItem>
                                                                <asp:ListItem Text="2021-22" Value="2021"></asp:ListItem>
                                                                <asp:ListItem Text="2022-23" Value="2022"></asp:ListItem>
                                                                <asp:ListItem Text="2023-24" Value="2023"></asp:ListItem>
                                                                <asp:ListItem Text="2024-25" Value="2024"></asp:ListItem>
                                                                <asp:ListItem Text="2025-26" Value="2025"></asp:ListItem>
                                                                <asp:ListItem Text="2026-27" Value="2026"></asp:ListItem>
                                                            </asp:DropDownList>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%; text-align: center">Username
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%">
                                                            <asp:TextBox ID="txtUsername" runat="server" Font-Size="Large" Style="border-radius: 5px;"
                                                                autocomplete="Off" Width="300px" BorderStyle="Groove" TabIndex="2"
                                                                EnableViewState="False" MaxLength="20"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%; text-align: center">Password
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%">
                                                            <asp:TextBox ID="txtPassword" runat="server" Font-Size="Large" Style="border-radius: 5px;"
                                                                onkeypress="capLock(event)" TabIndex="3" autocomplete="Off" Width="300px" BorderStyle="Groove"
                                                                TextMode="Password" EnableViewState="False"></asp:TextBox>
                                                        </td>
                                                    </tr>
                                                    <tr id="trCaptchaText" runat="server">
                                                        <td style="width: 100%; text-align: center; height: 10px">
                                                            <asp:Label ID="lblCaptchaText" runat="server" Text="Type the characters you see in the picture below"></asp:Label>
                                                        </td>
                                                    </tr>
                                                    <tr id="trCaptcha" runat="server">
                                                        <td>
                                                            <table>
                                                                <tr>
                                                                    <td>
                                                                        <asp:TextBox ID="txtCaptcha" runat="server" Font-Size="Large" autocomplete="Off"
                                                                            TabIndex="4" MaxLength="6" Width="130px" BorderStyle="Groove" Style="border-radius: 5px;"
                                                                            EnableViewState="False"></asp:TextBox>
                                                                    </td>
                                                                    <td>
                                                                        <div id="aaa" class="captcha" style="text-align: center; background-image: url(../App_Themes/Standard/Images/captcha.jpg); border-width: 1px; border-style: solid; width: 100px; height: 25px;">
                                                                            <asp:Label ID="lblCaptchaImage" runat="server" Font-Names="Times New Roman" Font-Bold="true"
                                                                                Font-Size="22px"></asp:Label>
                                                                        </div>
                                                                    </td>
                                                                    <td style="padding-left: 10px">
                                                                        <asp:ImageButton ID="ImgRefresh" runat="server" ImageUrl="~/App_Themes/Standard/Images/refresh.jpg"
                                                                            OnClientClick="GetDetails(null);return false" Width="18px" Height="18px" TabIndex="5"></asp:ImageButton>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%;">
                                                            <asp:CheckBox ID="chkRememberMe" runat="server" Visible="false" Text="Remember me" />
                                                            <asp:Label ID="lblErrorMsg" runat="server" ForeColor="Red"></asp:Label>
                                                            <div id="CapOn" style="visibility: hidden">
                                                                <asp:Label ID="Label1" runat="server" Text="Caps Lock is On.!" ForeColor="Red"></asp:Label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%; padding-bottom: 5px;">
                                                            <asp:CheckBox ID="chkForceLogin" runat="server" Visible="false" Text="Force Login" />
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%; text-align: center; vertical-align: middle">
                                                            <asp:Button ID="btnLogin" runat="server" OnClientClick="return Validate()" TabIndex="6"
                                                                Text="Login" Width="80px" />
                                                            <asp:Button ID="btnForgotPassword" runat="server" OnClientClick="return ValidateForgotPsswd()"
                                                                Style="background-color: transparent; color: Blue; border-color: transparent; cursor: pointer; text-decoration: underline"
                                                                Text="Forgot Password" OnClick="btnForgotPassword_Click1"
                                                                Width="115px" />
                                                        </td>
                                                    </tr>
                                                    <tr id="trForgetPassword" runat="server">
                                                        <td style="width: 100%; text-align: center; vertical-align: middle"></td>
                                                    </tr>
                                                    <tr>
                                                        <td style="width: 100%; text-align: center; vertical-align: middle">
                                                            <asp:Label ID="lblInvalidBrowser" runat="server" Text="Internet Explorer version 6.0 or later is required"
                                                                Style="display: none" EnableViewState="False" />
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    </asp:View>
                                </asp:MultiView>
                            </div>
                        </center>
                    </td>
                </tr>
            </table>
        </div>        
        <div style="width: 75%; padding-left: 150px; position: absolute; bottom: 50px;">
            <marquee id="mrq" onmouseover="this.stop()" onmouseout="this.start()" runat="server"
                style="font-weight: bold"></marquee>
        </div>
        <div style="width: auto; position: absolute; bottom: 0;">
            <div style="float: right; padding-top: 11px; padding-right: 3px; padding-bottom: 5px;">
                <asp:Label ID="lblPoweredBy" runat="server" Text='© 2026 Powered by Relyon Softech Ltd.'></asp:Label>
            </div>
        </div>
    </form>
</body>
</html>
