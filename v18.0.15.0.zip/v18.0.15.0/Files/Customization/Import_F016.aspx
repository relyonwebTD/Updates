﻿<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Customization_Import_F016, App_Web_import_f016.aspx.31c51fb" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style type="text/css">
        .modalBackground {
            background-color: Gray;
            filter: alpha(opacity=70);
            opacity: 0.7;
        }

        .modalPopup {
            background-color: #ffffdd;
            border-width: 5px;
            border-style: solid;
            border-color: Gray;
            padding: 10px;
            width: 260px;
        }

        .style1 {
            width: 107px;
        }
        /* Full-page transparent dark background to block interaction */
        .overlay-bg {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background-color: rgba(0, 0, 0, 0.2); /* Slightly dark background */
            z-index: 9998; /* Just under the popup */
        }

        /* Your existing loader box */
        .PrProgress1 {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 9999; /* Above the overlay */
            background-color: white;
            border-radius: 8px;
            text-align: center;
        }
    </style>

    <script type="text/javascript">
        window.addEventListener('load', function () {
            var filePath = '<%= ResolveUrl("~/UserFiles/JKImport/importing.txt") %>';

            fetch(filePath, { method: 'HEAD' })
                .then(function (response) {
                    if (response.ok) {
                        alert("Import is in progress. Redirecting to home page...");
                        window.location.href = '<%= ResolveUrl("~/Shared/Home.aspx") %>';
                    }
                })
                .catch(function (error) {
                    console.error("File not found or error:", error);
                });
        });

        function ShowErrorLabel() {
            alert("Failed during Import. Please click the 'View Error(s)' link for more details");
        }
        function Validation() {
            var ddlForm = document.getElementById("<%=ddlForm.ClientID%>");
            var ddlMonth = document.getElementById("<%=ddlMonth.ClientID%>");
            if (ddlForm.selectedIndex == 0) { alert("Please Select Form."); ddlForm.focus(); return false; }            
            if ((ddlForm.options[ddlForm.selectedIndex].text == "Form 121" || ddlForm.options[ddlForm.selectedIndex].text == "Form15G" ||
                ddlForm.options[ddlForm.selectedIndex].text == "Form15H") && ddlMonth.selectedIndex == 0) {
                alert("Please Select Quarter.");
                ddlMonth.focus();
                return false;
            }
            if (ddlMonth.selectedIndex == 0) { alert("Please Select Month."); ddlMonth.focus(); return false; }
            var uploadFile = document.getElementById("<%=uploadfile.ClientID%>");
            var file = uploadFile.value.trim();
            ext = ".ZIP";
            var validExtensions = new Array(ext);
            var allowSubmit = false;
            if (file.indexOf("\\") == -1) { alert("Select only zip File."); return false; }
            else {
                var ext = file.slice(file.lastIndexOf(".")).toLowerCase();
                for (var i = 0; i < validExtensions.length; i++) {
                    if (validExtensions[i] == ext) { allowSubmit = true; }
                }
            }
            if (document.getElementById("<%=btnImport.ClientID %>").value == "Import") {
                document.getElementById("<%=btnImport.ClientID %>").value = "Please Wait...";
                if (document.getElementById("<%=hlnkOpenErrors.ClientID%>") != null) {
                    document.getElementById("<%=hlnkOpenErrors.ClientID%>").style.display = 'none';
                } return true;
            }
        }

        function CheckExisting() {
            var r = confirm("For selected month, data is found available.\nRecords in given import file will be added to existing data.\nDo ensure same data is not imported again. It will lead to duplication of records.");
            if (r == false) {
                __doPostBack('CheckExisting', 'NO');
            }
            else {
                __doPostBack('CheckExisting', 'YES');
            }
            return true;
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="updatePanel" runat="server">
        <ContentTemplate>
        <asp:Timer ID="Timer1" runat="server" Interval="1000" OnTick="Timer1_Tick" Enabled="false" />
            <table>
                <tr>
                    <td>
                        <table>
                            <tr>
                                <td>
                                    <table>
                                        <tr>
                                            <td>
                                                File Type:
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rdbDeductions" runat="server"  AutoPostBack="True" Text="Deductions" GroupName="FileType"
                                                    Checked="true" oncheckedchanged="rdbDeductions_CheckedChanged" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rdbNonTDS" runat="server" AutoPostBack="True" Text="Other Than Term Deposit" GroupName="FileType"
                                                    Checked="false" oncheckedchanged="rdbNonTDS_CheckedChanged" />
                                            </td>
                                            <td>
                                                &nbsp;
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <table cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td style="width: 80px">
                                                Form:
                                            </td>
                                            <td>
                                                <asp:DropDownList ID="ddlForm" runat="server" CssClass="dropDownList" Width="155px"
                                                    AutoPostBack="True" OnSelectedIndexChanged="ddlForm_SelectedIndexChanged">
                                                    <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <table cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td style="width: 80px">
                                                <asp:label ID="lblMonth" Text="Month:" runat="server"></asp:label>
                                            </td>
                                            <td>
                                                <asp:DropDownList ID="ddlMonth" runat="server" CssClass="dropDownList" Width="155px"
                                                    AutoPostBack="True" OnSelectedIndexChanged="ddlMonth_SelectedIndexChanged">
                                                    <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                                    <asp:ListItem Text="April" Value="4"></asp:ListItem>
                                                    <asp:ListItem Text="May" Value="5"></asp:ListItem>
                                                    <asp:ListItem Text="June" Value="6"></asp:ListItem>
                                                    <asp:ListItem Text="July" Value="7"></asp:ListItem>
                                                    <asp:ListItem Text="August" Value="8"></asp:ListItem>
                                                    <asp:ListItem Text="September" Value="9"></asp:ListItem>
                                                    <asp:ListItem Text="October" Value="10"></asp:ListItem>
                                                    <asp:ListItem Text="November" Value="11"></asp:ListItem>
                                                    <asp:ListItem Text="December" Value="12"></asp:ListItem>
                                                    <asp:ListItem Text="January" Value="1"></asp:ListItem>
                                                    <asp:ListItem Text="February" Value="2"></asp:ListItem>
                                                    <asp:ListItem Text="March" Value="3"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <table cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td style="width: 80px">
                                                UpLoad File
                                            </td>
                                            <td>
                                                <asp:FileUpload ID="uploadfile" runat="server" CssClass="browsBtn" />
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr id="rowCheckBox" runat="server" visible="false">
                                <td>
                                    <table style="width: 500px" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td>
                                                <asp:CheckBox ID="chkPAN" runat="server" Text="Update PAN in existing master even when different (RECOMMENDED)."
                                                    Checked="true" />
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>
                        <table>
                            <tr id="rowStatus" runat="server" visible="false">
                                <td>
                                    <span style="color: black; font-weight: bold;">Status:</span>
                                </td>
                                <td colspan="3">
                                    <asp:Label ID="lblStatus" runat="server" Style="color: blue" Text=" "></asp:Label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                </td>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                </td>
                                <td>
                                    <asp:HyperLink ID="hlnkOpenWarning" runat="server" Target="_blank" Text="" Visible="false"> </asp:HyperLink>
                                    &nbsp;
                                </td>                                
                            </tr>
                        </table>
                    </td>
                </tr>
                <table>
                    <tr>
                        <td>
                            <asp:Button ID="btnImport" runat="server" CssClass="cmnBtn" Enabled="true" OnClick="btnImport_Click" OnClientClick="return Validation();" Text="Import" Width="114px" />
                        </td>
                        <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <asp:HyperLink ID="hlnkOpenErrors" runat="server" Target="_blank" Text="" Visible="true"> </asp:HyperLink>
                        </td>
                        <td>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <asp:HyperLink ID="hlnkImportLogs" runat="server" Target="_blank" Text="" Visible="false"> </asp:HyperLink>
                        </td>
                    </tr>
                </table>
                <tr>
                </tr>
            </table>
            <div id="overlayBackground" style="display: none;" runat="server"
                 class="overlay-bg">
                <div id="pnlPopup1" class="PrProgress1" runat="server">
                    <div id="innerPopup" class="PrContainer">
                        <div class="PrHeader">
                            Please wait...
                        </div>
                        <div class="PrBody">
                            <img width="220px" height="19px" src="../App_Themes/Standard/Images/activity.gif" alt="loading..." />
                            <br /><br />
                            <asp:Label ID="lblStatus1" runat="server" Text="Loading..."></asp:Label>
                        </div>
                    </div>
                </div>
            </div>
        </ContentTemplate>
        <Triggers>
            <asp:PostBackTrigger ControlID="btnImport" />
        </Triggers>
    </asp:UpdatePanel>
</asp:Content>
