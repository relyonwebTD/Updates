<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Correction_Deductor, App_Web_deductor.aspx.4fd6750c" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">

    <script type="text/javascript" language="javascript">
        function EnableDisableControls() {
            if (document.getElementById("<%=cmbDeductorType.ClientID %>").value != "-1") {
                switch (document.getElementById("<%=cmbDeductorType.ClientID %>").value) {
                    case "1": //Autonomous Body(Central government)
                    case "7": //Statutory Body(Central government)
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtPAOCode.ClientID %>").value = "";
                        document.getElementById("<%=txtPAORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=txtDDOCode.ClientID %>").value = "";
                        document.getElementById("<%=txtDDORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").disabled = true;
                        document.getElementById("<%=txtPAOCode.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtDDOCode.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").style.backgroundColor = "#E5E5E5";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").disabled = false;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").disabled = false;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtAIN.ClientID %>").style.backgroundColor = "White";
                        break;
                    case "2": //Autonomous Body(State government)
                    case "5": //Local Authority(StateGovernment)
                    case "8": //Statutory Body(State government)
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtPAOCode.ClientID %>").value = "";
                        document.getElementById("<%=txtPAORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=txtDDOCode.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").value = "";
                        document.getElementById("<%=txtDDORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").style.backgroundColor = "#E5E5E5";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").disabled = false;
                        document.getElementById("<%=txtPAOCode.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtDDOCode.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").disabled = false;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").disabled = false;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtAIN.ClientID %>").style.backgroundColor = "White";
                        break;
                    case "3": //Central Government
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtPAOCode.ClientID %>").value = "";
                        document.getElementById("<%=txtPAORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=txtDDOCode.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").value = "";
                        document.getElementById("<%=txtDDORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").disabled = true;
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtPAOCode.ClientID %>").disabled = false;
                        document.getElementById("<%=txtDDOCode.ClientID %>").disabled = false;
                        document.getElementById("<%=txtPAOCode.ClientID %>").style.background = "#E5E5E5";
                        document.getElementById("<%=txtDDOCode.ClientID %>").style.backgroundColor = "#E5E5E5";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").style.backgroundColor = "#E5E5E5";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").disabled = false;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").disabled = false;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtAIN.ClientID %>").style.backgroundColor = "#E5E5E5";
                        break;
                    case "4": //LocalAuthority(CentralGovernment)
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtPAOCode.ClientID %>").value = "";
                        document.getElementById("<%=txtPAORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=txtDDOCode.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").value = "";
                        document.getElementById("<%=txtDDORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").disabled = true;
                        document.getElementById("<%=txtPAOCode.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtDDOCode.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").disabled = false;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").disabled = false;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtAIN.ClientID %>").style.backgroundColor = "White";
                        break;
                    case "6": //State Government
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtPAOCode.ClientID %>").value = "";
                        document.getElementById("<%=txtPAORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=txtDDOCode.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").selectedIndex = 0;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").value = "";
                        document.getElementById("<%=txtDDORegnNo.ClientID %>").value = "";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").style.backgroundColor = "#E5E5E5";
                        document.getElementById("<%=txtPAOCode.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtDDOCode.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddState.ClientID %>").disabled = false;
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").disabled = true;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").disabled = true;
                        document.getElementById("<%=txtMinOtherName.ClientID %>").style.backgroundColor = "White";
                        document.getElementById("<%=txtAIN.ClientID %>").style.backgroundColor = "#E5E5E5";
                        break;
                }
            }
            else {
                document.getElementById("<%=cmbGovtAddState.ClientID %>").selectedIndex = 0;
                document.getElementById("<%=txtPAOCode.ClientID %>").value = "";
                document.getElementById("<%=txtPAORegnNo.ClientID %>").value = "";
                document.getElementById("<%=txtDDOCode.ClientID %>").value = "";
                document.getElementById("<%=txtDDORegnNo.ClientID %>").value = "";
                document.getElementById("<%=cmbGovtAddMinistry.ClientID %>").selectedIndex = 0;
                document.getElementById("<%=txtMinOtherName.ClientID %>").value = "";
                document.getElementById("<%=txtAIN.ClientID %>").style.backgroundColor = "White";
            }
        }
        function Validation() {
            if (!ValidateLength(document.getElementById("<%=txtDeductorName.ClientID%>"), "Deductor Name", 75, true)) return false;
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2025) {
                if (document.getElementById("<%=txtBranch.ClientID%>").value.trim() == "") {
                    alert("Specify Country/Region");
                    return false;
                }
            }
            if (!ValidateLength(document.getElementById("<%=txtAddress1.ClientID%>"), "Deductor Flat/Door/Block No.", 25, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtAddress3.ClientID%>"), "Deductor Street/Road Name", 25, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtAddress5.ClientID%>"), "Deductor City", 25, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtPincode.ClientID%>"), "Deductor Pincode", 6, true)) return false;
            if (!ValidateDropDown(document.getElementById("<%=cmbState.ClientID%>"), "Deductor State")) return false;
            if (InputValidations(document.getElementById("<%=txtDeductorName.ClientID%>")) == false) return false;
            if (InputValidations(document.getElementById("<%=txtBranch.ClientID%>")) == false) return false;
            if (InputValidations(document.getElementById("<%=txtRPName.ClientID%>")) == false) return false;
            if (InputValidations(document.getElementById("<%=txtRPDesignation.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress1.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress2.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress3.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress4.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtAddress5.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress1.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress2.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress3.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress4.ClientID%>")) == false) return false;
            if (InputValidationsForAddress(document.getElementById("<%=txtRPAddress5.ClientID%>")) == false) return false;

            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2009 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                if (document.getElementById("<%=txtSTDCode.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtTelephone.ClientID%>"), "Phone No.", 10, true)) return false;
                }
                else if (document.getElementById("<%=txtTelephone.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtSTDCode.ClientID%>"), "STD Code", 5, true)) return false;
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026) {
                if (!ValidateLength(document.getElementById("<%=txtSTDCode.ClientID%>"), "STD Code", 5, true)) return false;
                if (!ValidateLength(document.getElementById("<%=txtTelephone.ClientID%>"), "Phone No.", 10, true)) return false;
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012) {
                if (document.getElementById("<%=txtSTDCodeAlternate.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtTelephoneAlternate.ClientID%>"), "Alternate Phone No.", 10, true)) return false;
                }
                else if (document.getElementById("<%=txtTelephoneAlternate.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtSTDCodeAlternate.ClientID%>"), "Alternate STD Code", 5, true)) return false;
                }
            }
            if (document.getElementById("<%=txtEmail.ClientID%>").value.length > 0) {
                if (!ValidateEmail(document.getElementById("<%=txtEmail.ClientID%>"))) return false;
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012 && document.getElementById("<%=txtEmailAlternate.ClientID%>").value != "") {
                if (!ValidateEmail(document.getElementById("<%=txtEmailAlternate.ClientID%>"))) return false;
            }
            var cmbStatus = document.getElementById("<%=cmbStatus.ClientID%>");
            if (cmbStatus.value == "1") {
                if (document.getElementById("<%=txtPAN.ClientID%>").value.toUpperCase() == "PANNOTREQD") { ; }
                else { if (!ValidatePAN(document.getElementById("<%=txtPAN.ClientID%>"), "Deductor PAN", 10, true)) return false; }
            }
            else { if (!ValidatePAN(document.getElementById("<%=txtPAN.ClientID%>"), "Deductor PAN", 10, true)) return false; }
            if (!ValidateDropDown(document.getElementById("<%=cmbStatus.ClientID%>"), "Status")) return false;
            if (!ValidateDropDown(document.getElementById("<%=cmbDeductorType.ClientID%>"), "Deductor Type")) return false;
            if ((document.getElementById("<%=hdnDeductorTypeID.ClientID%>").value == "3" ||
                document.getElementById("<%=hdnDeductorTypeID.ClientID%>").value == "6")
                && (document.getElementById("<%=cmbDeductorType.ClientID%>").value != "3" &&
                    document.getElementById("<%=cmbDeductorType.ClientID%>").value != "6")) {
                alert("For the selected Status,Deductor Type can only be\nState Government or Central Government.");
                document.getElementById("<%=cmbDeductorType.ClientID%>").focus();
                return false;
            }
            else {
                if ((document.getElementById("<%=hdnDeductorTypeID.ClientID%>").value != "3"
                    && document.getElementById("<%=hdnDeductorTypeID.ClientID%>").value != "6")
                    && (document.getElementById("<%=cmbDeductorType.ClientID%>").value == "3" || document.getElementById("<%=cmbDeductorType.ClientID%>").value == "6")) {
                    alert("For the selected Status,Deductor Type should be\nother than State Government or Central Government.");
                    document.getElementById("<%=cmbDeductorType.ClientID%>").focus();
                    return false;
                }
                if (document.getElementById("<%=cmbDeductorType.ClientID%>").value == "3") {
                    if (!ValidateLength(document.getElementById("<%=txtPAOCode.ClientID%>"), "PAOCode", 14, true)) return false;
                    if (!ValidateLength(document.getElementById("<%=txtDDOCode.ClientID%>"), "DDOCode", 20, true)) return false;
                    if (!ValidateDropDown(document.getElementById("<%=cmbGovtAddMinistry.ClientID%>"), "Ministry")) return false;
                }
                else if (document.getElementById("<%=cmbDeductorType.ClientID%>").value == "2" || document.getElementById("<%=cmbDeductorType.ClientID%>").value == "5" || document.getElementById("<%=cmbDeductorType.ClientID%>").value == "6" || document.getElementById("<%=cmbDeductorType.ClientID%>").value == "8") {
                    if (!ValidateDropDown(document.getElementById("<%=cmbGovtAddState.ClientID%>"), "State for selected Deductor Type")) return false;
                }
                else if (document.getElementById("<%=cmbDeductorType.ClientID%>").value == "1" || document.getElementById("<%=cmbDeductorType.ClientID%>").value == "7") {
                    if (!ValidateDropDown(document.getElementById("<%=cmbGovtAddMinistry.ClientID%>"), "Ministry for selected Deductor Type")) return false;
                }
                if (document.getElementById("<%=cmbDeductorType.ClientID%>").value == 99) {
                    if (!ValidateLength(document.getElementById("<%=txtMinOtherName.ClientID%>"), "Ministry Other Name", 75, true)) return false;
                }
                if (document.getElementById("<%=txtAIN.ClientID%>").value.length > 0 && document.getElementById("<%=txtAIN.ClientID%>").value.length < 7) {
                    alert("AIN should be of 7 digits");
                    document.getElementById("<%=txtAIN.ClientID%>").focus();
                    return false;
                }
                if (document.getElementById("<%=cmbDeductorType.ClientID%>").value == "3" || document.getElementById("<%=cmbDeductorType.ClientID%>").value == "6") {
                    if (document.getElementById("<%=txtAIN.ClientID%>").value == "") {
                        alert("AIN is Mandatory for the Deductor Type Central and State Government")
                        document.getElementById("<%=txtAIN.ClientID%>").focus();
                        return false;
                    }
                }
            }
            if (!ValidateLength(document.getElementById("<%=txtRPName.ClientID%>"), "Responsible Person Name", 75, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPDesignation.ClientID%>"), "Responsible Person Designation", 20, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPAddress1.ClientID%>"), "Responsible Person Flat/Door/Block No", 25, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPAddress5.ClientID%>"), "Responsible Person City", 25, true)) return false;
            if (!ValidateResponsiblePAN(document.getElementById("<%=txtRPPAN.ClientID%>"), "Responsible Person PAN", 10, true)) return false;
            if (!ValidateDropDown(document.getElementById("<%=cmbRPState.ClientID%>"), "Responsible Person State")) return false;
            if (!ValidateLength(document.getElementById("<%=txtRPPincode.ClientID%>"), "Responsible Person Pincode", 6, true)) return false;
            if (document.getElementById("<%=txtRPMobileNumber.ClientID%>").value.length > 0) {
                if (!ValidateLength(document.getElementById("<%=txtRPMobileNumber.ClientID%>"), "Mobile No.", 10, true)) return false;
            }
            if (document.getElementById("<%=hdnFinYear.ClientID%>").value != "2009") {
                if (document.getElementById("<%=txtEmail.ClientID%>").value.length == 0 &&
                    document.getElementById("<%=txtRPEmail.ClientID%>").value.length == 0) {
                    alert("Specify ANY ONE of the below \n" +
                        "1. Deductor Email id.\n" +
                        "2. Responsible person Email id.")
                    document.getElementById("<%=txtEmail.ClientID%>").focus();
                    return false;
                }
                if (document.getElementById("<%=txtRPMobileNumber.ClientID%>").value == "" &&
                    document.getElementById("<%=cmbDeductorType.ClientID%>").value != "3" &&
                    document.getElementById("<%=cmbDeductorType.ClientID%>").value != "6") {
                    alert("Specify Responsible Person Mobile No.");
                    document.getElementById("<%=txtRPMobileNumber.ClientID%>").focus();
                    return false;
                }
                if (document.getElementById("<%=txtTelephone.ClientID%>").value.length == 0 &&
                    document.getElementById("<%=txtRPPhoneNumber.ClientID%>").value.length == 0 &&
                    document.getElementById("<%=txtRPMobileNumber.ClientID%>").value.length == 0) {
                    alert("Specify ANY ONE of the below \n" +
                        "1. Deductor Telephone number with STD Code.\n" +
                        "2. Responsible person Telephone number with STD Code.\n" +
                        "3. Responsible person Mobile number.")
                    document.getElementById("<%=txtSTDCode.ClientID%>").focus();
                    return false;
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2009 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                if (document.getElementById("<%=txtRPSTDCode.ClientID%>").value.length > 0) {
                if (!ValidateLength(document.getElementById("<%=txtRPPhoneNumber.ClientID%>"), "Responsible Person Phone No.", 10, true)) return false;
                }
                else if (document.getElementById("<%=txtRPPhoneNumber.ClientID%>").value.length > 0) {
                   if (!ValidateLength(document.getElementById("<%=txtRPSTDCode.ClientID%>"), "Responsible Person STD Code", 5, true)) return false;
               }
           }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026) {
                if (!ValidateLength(document.getElementById("<%=txtRPPhoneNumber.ClientID%>"), "Responsible Person Phone No.", 10, true)) return false;
                if (!ValidateLength(document.getElementById("<%=txtRPSTDCode.ClientID%>"), "Responsible Person STD Code", 5, true)) return false;
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012) {
                if (document.getElementById("<%=txtRPSTDCodeAlternate.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtRPPhoneNumberAlternate.ClientID%>"), "Alternate Phone No.", 10, true)) return false;
                }
                else if (document.getElementById("<%=txtRPPhoneNumberAlternate.ClientID%>").value.length > 0) {
                    if (!ValidateLength(document.getElementById("<%=txtRPSTDCodeAlternate.ClientID%>"), "Alternate STD Code", 5, true)) return false;
                }
            }
            if (document.getElementById("<%=txtRPEmail.ClientID%>").value != "") {
                if (!ValidateEmail(document.getElementById("<%=txtRPEmail.ClientID%>"))) return false;
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2026) {
                 if (document.getElementById("<%=txtRPCountryRegion.ClientID%>").value == "") {
                     alert("Specify Responsible Person Country/Region");
                     return false;
                 }
             }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2012 && document.getElementById("<%=txtRPEmailAlternate.ClientID%>").value != "") {
                if (!ValidateEmail(document.getElementById("<%=txtRPEmailAlternate.ClientID%>"))) return false;
            }
            var GSTIN = document.getElementById("<%=txtGSTIN.ClientID%>").value.trim();
            if (GSTIN.length > 0) {
                if (GSTIN.length == 15) {
                    if (Number(GSTIN.substring(0, 2)) > 37 || Number(GSTIN.substring(0, 2)) == 0) {
                        alert("First 2 characters of the GSTIN(State code) should be between 01 and 37");
                        return false;
                    }
                    if (!ValidateAssesseePAN(GSTIN.substring(2, 12), "PAN", 10, true)) {
                        alert("PAN specified in GSTIN is Invalid.");
                        return false;
                    }
                    if (GSTIN.substring(13, 14).toUpperCase() != 'Z') {
                        alert("14th character of GSTIN should be \"Z\"");
                        return false;
                    }
                }
                var pattern = /^([0-9]){2}([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}([1-9A-Za-z]){1}([Z]){1}([a-zA-Z0-9]){1}?$/;
                var matchArray = GSTIN.match(pattern);
                if (matchArray == null) {
                    alert("Specify valid GSTIN.\nGSTIN should be in the following format.\n1.Characters 1 and 2 represents a valid state code.\n2.Characters 3 through 12 should represent a valid PAN.\n3.Character 13 represents numeric value of entities having same PAN in the state.\n4.Character 14 should always be the alphabet \"Z\" by default.\n5.Character 15 represents a checksum value which can be alphanumeric.");
                    return false;
                }
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtDeductorName.ClientID%>").value)) {
                document.getElementById("<%=txtDeductorName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress1.ClientID%>").value)) {
                document.getElementById("<%=txtAddress1.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress2.ClientID%>").value)) {
                document.getElementById("<%=txtAddress2.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress3.ClientID%>").value)) {
                document.getElementById("<%=txtAddress3.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress4.ClientID%>").value)) {
                document.getElementById("<%=txtAddress4.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress5.ClientID%>").value)) {
                document.getElementById("<%=txtAddress5.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPName.ClientID%>").value)) {
                document.getElementById("<%=txtRPName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress1.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress1.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress2.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress2.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress3.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress3.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress4.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress4.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress5.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress5.ClientID%>").value = "";
                return false;
            }
        }
        function ValidateTANUpdate() {
            if (ValidateHtmlTags(document.getElementById("<%=txtDeductorName.ClientID%>").value)) {
                document.getElementById("<%=txtDeductorName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress1.ClientID%>").value)) {
                document.getElementById("<%=txtAddress1.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress2.ClientID%>").value)) {
                document.getElementById("<%=txtAddress2.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress3.ClientID%>").value)) {
                document.getElementById("<%=txtAddress3.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress4.ClientID%>").value)) {
                document.getElementById("<%=txtAddress4.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress5.ClientID%>").value)) {
                document.getElementById("<%=txtAddress5.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPName.ClientID%>").value)) {
                document.getElementById("<%=txtRPName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress1.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress1.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress2.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress2.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress3.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress3.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress4.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress4.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtRPAddress5.ClientID%>").value)) {
                document.getElementById("<%=txtRPAddress5.ClientID%>").value = "";
                return false;
            }
            if (!ValidateTAN(document.getElementById("<%=txtUpdateTAN.ClientID%>"), "Deductor TAN", 10, true)) return false;
            else return true;
        }
        function ValidateCancellationStatement() {
            if (document.getElementById("<%=ddlTypeOfUpdate.ClientID%>").value == "2") {
                alert("Cancellation of statement is not allowed.");
                return false;
            }
            return true;
        }
        function ConfirmUndo() {
            return confirm("Are you sure you want to undo the changes?");
        }
        function DisplayControls() {
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>");
            var rowRPSTDAlternate = document.getElementById("<%=rowRPSTDAlternate.ClientID%>");
            var rowRPEmailAlternate = document.getElementById("<%=rowRPEmailAlternate.ClientID%>");
            var rowSTDAlternate = document.getElementById("<%=rowSTDAlternate.ClientID%>");
            var rowEmailAlternate = document.getElementById("<%=rowEmailAlternate.ClientID%>");
            if (Return(finYear.value) > 2012) {
                if (rowRPSTDAlternate != null) rowSTDAlternate.style.display = '';
                if (rowEmailAlternate != null) rowEmailAlternate.style.display = '';
                if (rowRPSTDAlternate != null) rowRPSTDAlternate.style.display = '';
                if (rowRPEmailAlternate != null) rowRPEmailAlternate.style.display = '';
            }
            else {
                if (rowRPSTDAlternate != null) rowSTDAlternate.style.display = 'none';
                if (rowEmailAlternate != null) rowEmailAlternate.style.display = 'none';
                if (rowRPSTDAlternate != null) rowRPSTDAlternate.style.display = 'none';
                if (rowRPEmailAlternate != null) rowRPEmailAlternate.style.display = 'none';
            }
        }
        function ValidateResponsiblePAN(objName, objCaption, maxLen, isReq) {
            var value = objName.value;
            if (isReq) {
                if (value.trim().length == 0) {
                    alert("Specify " + objCaption);
                    if (objName.isDisabled != true) {
                        objName.focus();
                    }
                    return false;
                }
            }
            if (value.trim().length > 0) {
                for (var i = 0; i < value.length; i++) {
                    if (value.charAt(i) == ' ') {
                        alert(objCaption + " does not \nallow Blank Spaces. (Ex: AAAAA1234A)");
                        objName.focus();
                        return false;
                    }
                }
                for (var i = 0; i < 5; i++) {
                    if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z')) { ; }
                    else {
                        alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
                        if (document.getElementsByName(objName.name)) { objName.focus(); }
                        return false;
                    }
                }
                if (value.charAt(3).toUpperCase() == 'P') { ; }
                else {
                    alert("Specify PAN of 'Individual' in\n" + objCaption + " Field. (Ex: AAAPA1234A)")
                    if (document.getElementsByName(objName.name)) { objName.focus(); }
                    return false;
                }
                for (var i = 5; i < 9; i++) {
                    if (value.charAt(i) >= '0' && value.charAt(i) <= '9') { ; }
                    else {
                        alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
                        objName.focus();
                        return false;
                    }
                }
                if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) { ; }
                else {
                    alert("Specify a valid Character value in\n" + objCaption + " Field. (Ex: AAAAA1234A)")
                    objName.focus();
                    return false;
                }
                if (value.charAt(3).toUpperCase() != 'P' && value.charAt(3).toUpperCase() != 'H' && value.charAt(3).toUpperCase() != 'C' && value.charAt(3).toUpperCase() != 'J' && value.charAt(3).toUpperCase() != 'F' && value.charAt(3).toUpperCase() != 'A' && value.charAt(3).toUpperCase() != 'T' && value.charAt(3).toUpperCase() != 'B' && value.charAt(3).toUpperCase() != 'L' && value.charAt(3).toUpperCase() != 'G') {
                    alert("Specify valid PAN.");
                    objName.focus();
                    return false;
                }
                return true;
            }
        }
    </script>

    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:HiddenField ID="hdnDeductorID" runat="server" Value="-1" />
    <asp:HiddenField ID="hdnFinYear" runat="server" Value="-1" />
    <asp:HiddenField ID="hdnIsCorrStatementGenerated" runat="server" Value="-1" />
    <asp:HiddenField ID="hdnIsCorrEReturnValid" runat="server" Value="-1" />
    <asp:HiddenField ID="hdnDeductorTypeID" runat="server" Value="-1" />
    <asp:HiddenField ID="hdnisUpdated" runat="server" Value="0" />
    <asp:UpdatePanel ID="up1" runat="server">
        <ContentTemplate>
            <asp:MultiView ID="mvDeductor" runat="server" ActiveViewIndex="0">
                <asp:View ID="vwType" runat="server">
                    <table>
                        <tr>
                            <td>Type of Update
                            </td>
                            <td>
                                <asp:DropDownList ID="ddlTypeOfUpdate" runat="server" Width="200px" BackColor="#E5E5E5"
                                    Font-Size="9">
                                    <asp:ListItem Text="Other Details" Value="1"></asp:ListItem>
                                    <asp:ListItem Text="TAN Update" Value="2"></asp:ListItem>
                                </asp:DropDownList>
                            </td>
                        </tr>
                        <tr style="height: 5px">
                            <td></td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Button ID="btnNext" runat="server" CssClass="cmnBtn" Text="Next" OnClientClick="return ValidateCancellationStatement();"
                                    OnClick="btnNext_Click" />
                            </td>
                            <td>
                                <asp:Button ID="btnBack" runat="server" CssClass="cmnBtn" Text="Back" OnClick="btnBack_Click" />
                            </td>
                        </tr>
                    </table>
                </asp:View>
                <asp:View ID="vwDeductor" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td valign="top">
                                <table class="nTbl" width="100%">
                                    <tr>
                                        <td>
                                            <b>Deductor Details</b>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td valign="top" style="width: 50%">
                                            <table class="eCol" style="width: 90%">
                                                <tr>
                                                    <td class="vHCol">Name
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtDeductorName" runat="server" CssClass="txtBML" AutoComplete="Off"
                                                            TabIndex="2" MaxLength="75" onkeypress="return ValidateDelimiter(this,event);"
                                                            onchange="return InputValidations(this);" Width="100%">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr id="rowBranchDivision" runat="server">
                                                    <td class="vHCol"> 
                                                        <asp:Label ID="lblBranchDevision" Text="Branch/Division" runat="server"></asp:Label>
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtBranch" runat="server" TabIndex="3" CssClass="txtBML" ReadOnly="True"
                                                            onchange="return InputValidations(this);" Width="100%"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Flat /Door / Block No.
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtAddress1" runat="server" CssClass="txtBML" MaxLength="25" TabIndex="4"
                                                            AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);"
                                                            Width="100%">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Building Name
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtAddress2" runat="server" CssClass="txtBPL" MaxLength="25" TabIndex="5" Width="100%"
                                                            AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Street / Road Name
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtAddress3" runat="server" CssClass="txtBML" MaxLength="25" TabIndex="6"
                                                            Width="100%" AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);"
                                                            onchange="return InputValidationsForAddress(this);">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Area
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtAddress4" runat="server" CssClass="txtBPL" MaxLength="25" TabIndex="7" Width="100%"
                                                            AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">City
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtAddress5" runat="server" MaxLength="25" CssClass="txtBML" TabIndex="8"
                                                            Width="100%" onkeypress="return ValidateForAlphaNumeric(event);" onchange="return InputValidationsForAddress(this);">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Pincode
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtPincode" runat="server" CssClass="txtBML" MaxLength="6" TabIndex="9"
                                                            Width="100%" AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">State
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:DropDownList ID="cmbState" runat="server" Width="100%" BackColor="#E5E5E5"
                                                            TabIndex="10" Font-Size="9">
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Address Change
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:DropDownList ID="cmbAddressChange" runat="server" Width="100%" TabIndex="11"
                                                            BackColor="#E5E5E5" Font-Size="9">
                                                            <asp:ListItem Text="No" Value="False"></asp:ListItem>
                                                            <asp:ListItem Text="Yes" Value="True"></asp:ListItem>
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">STD Code - Phone No.
                                                    </td>
                                                    <td class="iCol" width="200px">
                                                        <table class="nTbl" cellpadding="0px" cellspacing="0px" border="0px">
                                                            <tr>
                                                                <td width="50px">
                                                                    <asp:TextBox ID="txtSTDCode" CssClass="txtAR" runat="server" Width="50px" MaxLength="5"
                                                                        AutoComplete="Off" TabIndex="12" onkeypress="return ValidateForOnlyNos(event);">
                                                                    </asp:TextBox>
                                                                </td>
                                                                <td>
                                                                    <asp:TextBox ID="txtTelephone" CssClass="txtAR" runat="server" Width="97%" MaxLength="10"
                                                                        AutoComplete="Off" TabIndex="13" onkeypress="return ValidateForOnlyNos(event);">
                                                                    </asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr runat="server" id="rowSTDAlternate">
                                                    <td class="vHCol">STD Code - Phone No.(Alternate)
                                                    </td>
                                                    <td class="iCol" width="200px">
                                                        <table class="nTbl" cellpadding="0px" cellspacing="0px" border="0px">
                                                            <tr>
                                                                <td width="50px">
                                                                    <asp:TextBox ID="txtSTDCodeAlternate" CssClass="txtAR" runat="server" Width="50px"
                                                                        MaxLength="5" AutoComplete="Off" TabIndex="12" onkeypress="return ValidateForOnlyNos(event);">
                                                                    </asp:TextBox>
                                                                </td>
                                                                <td>
                                                                    <asp:TextBox ID="txtTelephoneAlternate" CssClass="txtAR" runat="server" Width="97%"
                                                                        MaxLength="10" AutoComplete="Off" TabIndex="13" onkeypress="return ValidateForOnlyNos(event);">
                                                                    </asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">E-Mail
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtEmail" runat="server" CssClass="txtBPL" MaxLength="75" TabIndex="15"
                                                            Width="100%" AutoComplete="Off">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr runat="server" id="rowEmailAlternate">
                                                    <td class="vHCol">E-Mail(Alternate)
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtEmailAlternate" runat="server" CssClass="txtBPL" MaxLength="75"
                                                            TabIndex="15" Width="100%" AutoComplete="Off">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">PAN
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtPAN" runat="server" MaxLength="10" CssClass="txtBML" TabIndex="17"
                                                            AutoComplete="Off" onBlur="ConvertToUC(this);" Width="100%">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td valign="top">
                                            <table class="eCol" style="width: 90%">
                                                <tr>
                                                    <td class="vHCol">TAN&nbsp;&nbsp;
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtTAN" runat="server" TabIndex="18" CssClass="txtBML" MaxLength="10"
                                                            AutoComplete="Off" Enabled="false" Width="100%"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr style="width: 100%">
                                                    <td class="vHCol">
                                                        <asp:Label ID="lblFinYear" Text="Financial Year" runat="server"></asp:Label>
                                                    </td>
                                                    <td class="iCol" width="200px">
                                                        <table cellpadding="0" cellspacing="0" class="nTbl">
                                                            <tr>
                                                                <td>
                                                                    <asp:TextBox ID="txtFromFY" CssClass="txtAR" runat="server" Width="95%" ReadOnly="True"
                                                                        TabIndex="20">                                                                            
                                                                    </asp:TextBox>
                                                                </td>
                                                                <td>
                                                                    <asp:TextBox ID="txtToFY" CssClass="txtAR" runat="server" ReadOnly="True" Width="97%"
                                                                        TabIndex="21">
                                                                    </asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Asst. Year
                                                    </td>
                                                    <td class="iCol" width="200px">
                                                        <table class="nTbl" cellpadding="0" cellspacing="0">
                                                            <tr>
                                                                <td>
                                                                    <asp:TextBox ID="txtFromAY" CssClass="txtAR" runat="server" ReadOnly="True" Width="95%"
                                                                        TabIndex="22">
                                                                    </asp:TextBox>
                                                                </td>
                                                                <td>
                                                                    <asp:TextBox ID="txtToAY" CssClass="txtAR" runat="server" ReadOnly="True" Width="97%"
                                                                        TabIndex="23">
                                                                    </asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">GSTIN
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:TextBox ID="txtGSTIN" runat="server" Width="100%" onBlur="ConvertToUC(this);"
                                                            MaxLength="15" TabIndex="21" CssClass="txtBPL" ToolTip="GSTIN should be in the following format
1.Characters 1 and 2 represents a valid state code.
2.Characters 3 through 12 should represent a valid PAN.
3.Character 13 represents numeric value of entities having same PAN in the state.
4.Character 14 should always be the alphabet 'Z' by default.
5.Character 15 represents a checksum value which can be alphanumeric."></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Status
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:DropDownList ID="cmbStatus" runat="server" BackColor="#E5E5E5" TabIndex="28"
                                                            AutoPostBack="true" Width="100%" Font-Size="9" OnSelectedIndexChanged="cmbStatus_SelectedIndexChanged">
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Deductor Type
                                                    </td>
                                                    <td class="iCol">
                                                        <asp:DropDownList ID="cmbDeductorType" runat="server" TabIndex="29" BackColor="#E5E5E5"
                                                            OnChange="EnableDisableControls();" Width="100%" Font-Size="9">
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="nTbl" style="padding-top: 5px" colspan="2" id="govtDetails">
                                                        <div id="rndPanelGovAddList1">
                                                            <div class="dialog" style="width: 100%;">
                                                                <div class="dHeader">
                                                                    Govt. AddL. Details
                                                                </div>
                                                                <div style="padding: 20px; border-top: solid 1px gray">
                                                                    <asp:Panel ID="rndPanelGovAddList" runat="server">
                                                                        <table width="100%">
                                                                            <tr>
                                                                                <td align="left" width="40px" class="vHCol">State
                                                                                </td>
                                                                                <td class="iCol">
                                                                                    <asp:DropDownList ID="cmbGovtAddState" runat="server" BackColor="#E5E5E5" Width="100%"
                                                                                        TabIndex="30" Font-Size="9">
                                                                                    </asp:DropDownList>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="left" width="40px" class="vHCol">AIN
                                                                                </td>
                                                                                <td class="iCol">
                                                                                    <asp:TextBox ID="txtAIN" runat="server" CssClass="txtBPL" Width="96%" TabIndex="30"
                                                                                        MaxLength="7" onkeypress="return ValidateForOnlyNos(event);" Font-Size="9">
                                                                                    </asp:TextBox>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>PAO Code
                                                                                </td>
                                                                                <td class="iCol">
                                                                                    <table cellpadding="0" cellspacing="0" width="100%">
                                                                                        <tr>
                                                                                            <td>
                                                                                                <asp:TextBox ID="txtPAOCode" CssClass="txtBPL" runat="server" MaxLength="20" Width="60px"
                                                                                                    TabIndex="31" onkeypress="return ValidateForAlphaNumeric(event);">
                                                                                                </asp:TextBox>
                                                                                            </td>
                                                                                            <td width="120px" align="center">&nbsp;Regn. No.
                                                                                            </td>
                                                                                            <td>
                                                                                                <asp:TextBox ID="txtPAORegnNo" CssClass="txtBPL" runat="server" MaxLength="7" Width="60px"
                                                                                                    TabIndex="32" onkeypress="return ValidateForAlphaNumeric(event);">
                                                                                                </asp:TextBox>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>DDO Code
                                                                                </td>
                                                                                <td class="iCol">
                                                                                    <table cellpadding="0" cellspacing="0" width="100%">
                                                                                        <tr>
                                                                                            <td>
                                                                                                <asp:TextBox ID="txtDDOCode" CssClass="txtBPL" runat="server" MaxLength="20" Width="60px"
                                                                                                    TabIndex="33" onkeypress="return ValidateForAlphaNumeric(event);">
                                                                                                </asp:TextBox>
                                                                                            </td>
                                                                                            <td align="center" width="120px">Regn. No.
                                                                                            </td>
                                                                                            <td>
                                                                                                <asp:TextBox ID="txtDDORegnNo" CssClass="txtBPL" runat="server" MaxLength="10" Width="60px"
                                                                                                    TabIndex="34" onkeypress="return ValidateForAlphaNumeric(event);">
                                                                                                </asp:TextBox>
                                                                                            </td>
                                                                                        </tr>
                                                                                    </table>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>Ministry
                                                                                </td>
                                                                                <td class="iCol">
                                                                                    <asp:DropDownList ID="cmbGovtAddMinistry" runat="server" BackColor="#E5E5E5" TabIndex="35"
                                                                                        Width="100%" Font-Size="9">
                                                                                    </asp:DropDownList>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td align="left">Other Name
                                                                                </td>
                                                                                <td class="iCol">
                                                                                    <asp:TextBox ID="txtMinOtherName" runat="server" MaxLength="75" CssClass="txtBPL"
                                                                                        TabIndex="36" onkeypress="return ValidateDelimiter(this,event);">
                                                                                    </asp:TextBox>
                                                                                </td>
                                                                            </tr>
                                                                        </table>
                                                                    </asp:Panel>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <table class="nTbl">
                            <caption>
                                <tr>
                                    <td>
                                        <b>Responsible Person Details</b>
                                    </td>
                                </tr>
                                <tr>
                                    <td valign="top">
                                        <table class="eCol" style="width: 90%">
                                            <tr>
                                                <td class="vHCol">Name
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPName" runat="server" BackColor="#E5E5E5" MaxLength="75" CssClass="txtBML"
                                                        Width="100%" TabIndex="37" AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);"
                                                        onchange="return InputValidations(this);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">Designation
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPDesignation" runat="server" BackColor="#E5E5E5" MaxLength="20" Width="100%"
                                                        AutoComplete="Off" TabIndex="38" CssClass="txtBML" onkeypress="return ValidateDelimiter(this,event);"
                                                        onchange="return InputValidations(this);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">Flat /Door / Block No.
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPAddress1" runat="server" BackColor="#E5E5E5" MaxLength="25" Width="100%"
                                                        AutoComplete="Off" TabIndex="40" CssClass="txtBML" onkeypress="return ValidateDelimiter(this,event);"
                                                        onchange="return InputValidationsForAddress(this);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">Building Name
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPAddress2" runat="server" MaxLength="25" CssClass="txtBPL" TabIndex="41" Width="100%"
                                                        AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">Street / Road Name
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPAddress3" runat="server" MaxLength="25" CssClass="txtBPL" TabIndex="42" Width="100%"
                                                        AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">Area
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPAddress4" runat="server" MaxLength="25" CssClass="txtBPL" TabIndex="43" Width="100%"
                                                        AutoComplete="Off" onkeypress="return ValidateDelimiter(this,event);" onchange="return InputValidationsForAddress(this);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">City
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPAddress5" runat="server" MaxLength="25" CssClass="txtBML" TabIndex="44" Width="100%"
                                                        AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);" onchange="return InputValidationsForAddress(this);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">PAN
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPPAN" runat="server" MaxLength="10" CssClass="txtBML" TabIndex="44"
                                                        AutoComplete="Off" onBlur="ConvertToUC(this);" Width="100%"></asp:TextBox>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td valign="top">
                                        <table class="eCol" style="width: 90%">
                                            <tr>
                                                <td class="vHCol">State
                                                </td>
                                                <td class="iCol">
                                                    <asp:DropDownList ID="cmbRPState" runat="server" BackColor="#E5E5E5" Font-Size="9"
                                                        TabIndex="47" Width="100%">
                                                    </asp:DropDownList>
                                                </td>
                                            </tr>
                                            <tr id="trRPCountryRegion" runat="server" visible="false">
                                                <td class="vHcol">Country/Region</td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPCountryRegion" runat="server" CssClass="txtBML" MaxLength="25"
                                                        Width="98%" onkeypress="return ValidateForAlphaNumeric(event);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">Pincode
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPPincode" runat="server" AutoComplete="Off" BackColor="#E5E5E5"
                                                        CssClass="txtBML" MaxLength="6" onkeypress="return ValidateForOnlyNos(event);"
                                                        TabIndex="48" Width="100%">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">Address Change
                                                </td>
                                                <td class="iCol">
                                                    <asp:DropDownList ID="cmbRPAddressChange" runat="server" BackColor="#E5E5E5" Font-Size="9"
                                                        TabIndex="49" Width="100%">
                                                        <asp:ListItem Text="No" Value="False"></asp:ListItem>
                                                        <asp:ListItem Text="Yes" Value="True"></asp:ListItem>
                                                    </asp:DropDownList>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">STD Code - Phone No.
                                                </td>
                                                <td class="iCol" width="200px">
                                                    <table border="0px" cellpadding="0px" cellspacing="0px" width="100%">
                                                        <tr>
                                                            <td width="50px">
                                                                <asp:TextBox ID="txtRPSTDCode" runat="server" AutoComplete="Off" CssClass="txtAR"
                                                                    MaxLength="5" onkeypress="return ValidateForOnlyNos(event);" TabIndex="50" Width="50px">                                                                                    </asp:TextBox>
                                                            </td>
                                                            <td>
                                                                <asp:TextBox ID="txtRPPhoneNumber" runat="server" AutoComplete="Off" CssClass="txtAR"
                                                                    MaxLength="10" onkeypress="return ValidateForOnlyNos(event);" TabIndex="51" Width="97%">
                                                                </asp:TextBox>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr runat="server" id="rowRPSTDAlternate">
                                                <td class="vHCol">STD Code - Phone No.(Alternate)
                                                </td>
                                                <td class="iCol" width="200px">
                                                    <table border="0px" cellpadding="0px" cellspacing="0px" width="100%">
                                                        <tr>
                                                            <td width="50px">
                                                                <asp:TextBox ID="txtRPSTDCodeAlternate" runat="server" AutoComplete="Off" CssClass="txtAR"
                                                                    MaxLength="5" onkeypress="return ValidateForOnlyNos(event);" TabIndex="50" Width="50px">                                                                                    </asp:TextBox>
                                                            </td>
                                                            <td>
                                                                <asp:TextBox ID="txtRPPhoneNumberAlternate" runat="server" AutoComplete="Off" CssClass="txtAR"
                                                                    MaxLength="10" onkeypress="return ValidateForOnlyNos(event);" TabIndex="51" Width="97%">
                                                                </asp:TextBox>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">Mobile No.
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPMobileNumber" runat="server" MaxLength="10" CssClass="txtBPL" Width="100%"
                                                        AutoComplete="Off" TabIndex="51" onkeypress="return ValidateForOnlyNos(event);">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="vHCol">E-Mail
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPEmail" runat="server" AutoComplete="Off" CssClass="txtBPL"
                                                        MaxLength="75" TabIndex="52" Width="100%">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                            <tr runat="server" id="rowRPEmailAlternate">
                                                <td class="vHCol">E-Mail(Alternate)
                                                </td>
                                                <td class="iCol">
                                                    <asp:TextBox ID="txtRPEmailAlternate" runat="server" AutoComplete="Off" CssClass="txtBPL"
                                                        MaxLength="75" TabIndex="52" Width="100%">
                                                    </asp:TextBox>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </caption>
                        </table>
                    </table>
                    <table>
                    </table>
                    <table class="nTbl">
                        <tr>
                            <td class="iCol">
                                <table>
                                    <tr>
                                        <td>
                                            <asp:Button ID="btnSave" runat="server" CssClass="cmnBtn" OnClick="btnSave_Click"
                                                OnClientClick="return Validation();" Text="Update" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnUndo" runat="server" CssClass="cmnBtn" OnClick="btnUndo_Click"
                                                OnClientClick="return ConfirmUndo();" Text="Undo" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnClose" runat="server" CssClass="cmnBtn" OnClick="btnClose_Click"
                                                Text="Close" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </asp:View>
                <asp:View ID="vwTAN" runat="server">
                    <table>
                        <tr>
                            <td>TAN
                            </td>
                            <td>
                                <asp:TextBox ID="txtUpdateTAN" runat="server" TabIndex="18" CssClass="txtBML" MaxLength="10"
                                    AutoComplete="Off" onBlur="ConvertToUC(this);"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Button ID="btnUpdateTAN" runat="server" CssClass="cmnBtn" Text="Update" OnClientClick="return ValidateTANUpdate();"
                                    OnClick="btnUpdateTAN_Click" />
                            </td>
                            <td>
                                <asp:Button ID="btnUndoTANUpdate" runat="server" CssClass="cmnBtn" Text="Undo" OnClientClick="return ConfirmUndo();"
                                    OnClick="btnUndoTANUpdate_Click" />
                            </td>
                            <td>
                                <asp:Button ID="btnCloseTANUpdate" runat="server" CssClass="cmnBtn" Text="Close"
                                    OnClick="btnCloseTANUpdate_Click" />
                            </td>
                        </tr>
                    </table>
                </asp:View>
            </asp:MultiView>
        </ContentTemplate>
    </asp:UpdatePanel>
</asp:Content>
