<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Correction_Status, App_Web_status.aspx.4fd6750c" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style type="text/css">
        .modalBackground
        {
            background-color: Gray;
            filter: alpha(opacity=70);
            opacity: 0.7;
        }
        .modalPopup
        {
            background-color: #ffffdd;
            border-width: 5px;
            border-style: solid;
            border-color: Gray;
            padding: 10px;
            width: 420px;
        }
    </style>
    <script src="../JavaScript/Validations.js" type="text/javascript" language="javascript"></script>
    <script language="javascript" type="text/javascript">
        function SetText() {
            if (document.getElementById("<%=btnUpdate.ClientID%>").value == "Update") {
                document.getElementById("<%=btnUpdate.ClientID%>").value = "Please wait...";
                return true;
            }
            return false;
        }
        function Validation(btnText) {
            var recordCount = document.getElementById("<%=hdnDeletedRecordsCount.ClientID%>").value;
            if (Return(recordCount) > 0) {
                alert("Deletion of Deduction is not allowed.\n\nSelect such records for 'Update', Set values of Amount of Payment, TDS Amount and Tax Rate to zero.");
                return false;
            }
            if (btnText.value == "Upload") {
                if (document.getElementById("<%=fupCorrection.ClientID%>").value.length == 0) {
                    alert("Select a file to upload.");
                    return false;
                }
            }
            else if (btnText.value == "Save") { }
            else if (btnText.value == "e-Return") {
                //                if (document.getElementById("<%=hdnProcess.ClientID%>").value == 1) {
                //                    alert("eReturn is being generated. Please wait...");
                //                    return false;
                //                }
                if (document.getElementById("<%=hdnC9Found.ClientID%>").value == "1") { if (!confirm("Records found with C9 Correction. Addition of new Challans in\n Correction Statement(s) has been discontinued.\n\n Do you want to Continue with eReturn?")) return false; }
                btnText.value = "Please Wait..."
                document.getElementById("<%=hdnProcess.ClientID%>").value = 1;
                document.getElementById("<%=lblProcess.ClientID%>").innerHTML = "eReturn generation and validation will take some time. Please wait..";
                return true;
            }
            else return false;
        }
        function ConfirmStartAgain() {
            var IsCorrectionStarted = document.getElementById("<%=hdnIsCorrectionStarted.ClientID%>").value;
            if (document.getElementById("<%=hdnIsValidEReturn.ClientID%>").value == 1) { return confirm("Correction have been made eReturn is Successfully generated.\nIt is HIGHLY RECOMMENDED to click on 'Update' in 'Generate Correction Statement'.\nContinuing without this will cause subsequent Correction return will be Rejected.\n\nDo you want to continue?"); }
            else if (IsCorrectionStarted == "1") { return confirm("Corrections have been made.\nContinuing with 'Clear & Start Again' will remove all such corrections.\n\nDo you want to continue?"); }
            else { return confirm("Are you sure you want to Clear and Start Again ?"); }
        }
        function ValidateReport() {
            if (!ValidateLength(document.getElementById("<%=txtMediaUsed.ClientID%>"), "Media used for the return of the statement.", 20, true)) return false;
            if (!ValidateLength(document.getElementById("<%=txtNoOfMedia.ClientID%>"), "Total No. of Media enclosed.", 20, true)) return false;
            else { return true; }
        }
        function GetResult(returnValue, context) {
            if (returnValue.length > 4) {
                var array = returnValue.split("|");
                document.getElementById("<%=txtMediaUsed.ClientID%>").value = array[0];
                document.getElementById("<%=txtNoOfMedia.ClientID%>").value = array[1];
                document.getElementById("<%=txtPlace.ClientID%>").value = array[2];
                document.getElementById("<%=txtDate.ClientID%>").value = array[3];
            }
        }
        function SendRequest() {
            document.getElementById("<%=txtMediaUsed.ClientID%>").value = "";
            document.getElementById("<%=txtNoOfMedia.ClientID%>").value = "";
            document.getElementById("<%=txtPlace.ClientID%>").value = "";
            document.getElementById("<%=txtDate.ClientID%>").value = "";
            CallServer();
            return false;
        }
        function ValidateAckNo(ackNo, alertMsg) {
            if (ackNo.value == "") {
                alert("Specify " + alertMsg);
                ackNo.focus();
                return false;
            }
            else if ((ackNo.value != "") && (ackNo.value.length != 15)) {
                alert("Specify 15 digit Original RRR No.(PRN).");
                ackNo.focus();
                return false;
            }
            return true;
        }
        function doPostBack() {
            //var res = confirm(" TAN in the Submitted file do not match with Deductor's TAN.\nIf you have filed a cancellation return earlier, Click Ok \n If not, Select proper file,\n Click Cancel to stop process");
            //if (res) { __doPostBack('contentPlaceHolderBody', 'postback'); }
            //else { return false; }
            alert("TAN in the Submitted file do not match with Deductor's TAN.\nKindly select correct file and upload.");
            return false;
        }
        function ShowConfirmForTAN() {
            var deductorTAN = document.getElementById("<%=hdnDeductorTAN.ClientID%>");
            var tdsTAN = document.getElementById("<%=hdntdsTAN.ClientID%>");
            var msg = confirm("TAN in datafile and TAN in Submitted file do not match.\n\nTAN in datafile : " + deductorTAN.value + "\nTAN in .TDS file : " + tdsTAN.value + "\n\nIf you have filed a cancellation return earlier, Click Yes\nIf not, Select proper data file or .TDS file,\nClick No to stop process and select proper file.");
            if (msg) { __doPostBack('body', 'TAN'); }
            else { return false; }
        }
        function ShowConfirmForFile() {
            var days = document.getElementById("<%=hdnNoOfDays.ClientID%>");
            var msg = "";
            if (Number(days.value) >= 2 && Number(days.value) <= 15) { msg = "Selected .TDS file is 3 or more days old.\nDo you want to continue using this file for correction preparation?"; }
            else if (Number(days.value) >= 15) { msg = "Selected .TDS file is 15 or more days old.\nIt is HIGHLY RECOMMENDED to download latest .TDS file from NSDL \nwebsite.\nKindly use 'Request for -> TDS/TCS Statement' feature provided in 'TAN Account' under 'Tax Related' Menu.\n\nDo you want to continue using this file for correction preparation?"; }
            var res = confirm(msg);
            if (res) { __doPostBack('body', 'doPostBack'); }
            else { return true; }
        }
        function ShowConfirmForRRNo() {
            var result = confirm("Revised RRR No. specifed in selected .TDS file has been already used.\n\nIt is HIGHLY RECOMMENDED to download latest .TDS file from NSDL website\nDo you want to continue using this file for correction preparation?");
            if (result) { __doPostBack('body', 'ReviseRRNo'); }
            else { return true; }
        }
        function EnableDisableUpload(obj) {
            fileUpload = document.getElementById("<%=fileUpload.ClientID%>");
            if (obj.checked) {
                fileUpload.value = '';
                fileUpload.disabled = true;
            }
            else { fileUpload.disabled = false; }
        }
        function DefaultValidation(btnText) {
            if (btnText.value == "Upload") {
                if (document.getElementById("<%=fupFvuFile.ClientID%>").value.length == 0) {
                    alert("Select a file to upload.");
                    return false;
                }
            }
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:HiddenField ID="hdnFinYear" runat="server" />
    <asp:HiddenField ID="hdnReviseNumber" runat="server" Value="" />
    <asp:HiddenField ID="hdnIsValidEReturn" runat="server" Value="" />
    <asp:HiddenField ID="hdnAckNo" runat="server" Value="" />
    <asp:HiddenField ID="hdnProcess" runat="server" Value="0" />
    <asp:HiddenField ID="hdntdsTAN" runat="server" Value="" />
    <asp:HiddenField ID="hdnDeductorTAN" runat="server" Value="" />
    <asp:HiddenField ID="hdnNoOfDays" runat="server" Value="0" />
    <asp:HiddenField ID="hdnOrgPRN" runat="server" Value="" />
    <asp:HiddenField ID="hdnPrePRN" runat="server" Value="" />
    <asp:HiddenField ID="hdnFiledDate" runat="server" Value="" />
    <asp:HiddenField ID="hdnDeletedRecordsCount" runat="server" Value="0" />
    <asp:HiddenField ID="hdnIsCorrectionStarted" runat="server" Value="0" />
    <asp:HiddenField ID="hdnC9Found" runat="server" Value="0" />
    <asp:HiddenField ID="hdnisUpdated" runat="server" Value="0" />
    <triggers>
            <asp:PostBackTrigger ControlID="btnCorrectioneReturn" />
        </triggers>
    <asp:UpdatePanel ID="UpdatePanel1" runat="server">
        <ContentTemplate>
            <asp:Timer ID="timer1" runat="server" Interval="60000" OnTick="timer1_OnTick">
            </asp:Timer>
        </ContentTemplate>
    </asp:UpdatePanel>
    <asp:Panel ID="pnlPopUp27A" runat="server" BackColor="White" CssClass="modalPopup"
        Style="display: none">
        <table>
            <tr>
                <td style="width: 300px">
                    Media used for the return of statement
                </td>
                <td>
                    <asp:TextBox ID="txtMediaUsed" runat="server" CssClass="txtBML" Width="150px" AutoComplete="Off"
                        MaxLength="20"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td>
                    Total No. of computer media Enclosed
                </td>
                <td>
                    <asp:TextBox ID="txtNoOfMedia" runat="server" CssClass="txtBMR" Width="150px" AutoComplete="Off"
                        MaxLength="20" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td>
                    Place
                </td>
                <td>
                    <asp:TextBox ID="txtPlace" runat="server" MaxLength="50" CssClass="txtBPL" Width="150px"
                        AutoComplete="Off"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td>
                    Date
                </td>
                <td>
                    <asp:TextBox ID="txtDate" runat="server" onBlur="setDateFormat(this);" CssClass="txtBPR"
                        Width="150px" AutoComplete="Off"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <table width="100%">
                        <tr>
                            <td>
                                <center>
                                    <br />
                                    <asp:Button ID="btnPreview" runat="server" Text="Preview" CssClass="cmnBtn" OnClientClick="return ValidateReport();"
                                        OnClick="btnPreview_Click" />
                                    <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="cmnBtn" />
                                </center>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </asp:Panel>
    <table id="tableCorrUpload" runat="server">
        <tr>
            <td style="width: 140px">
                Correction Status
            </td>
            <td>
                <asp:Label ID="lblStatus" runat="server" Text="Not Done" Font-Bold="true" ForeColor="Red"></asp:Label>
            </td>
            <td style="width: 20px">
            </td>
            <td style="width: 130px">
                Correction Count
            </td>
            <td>
                <asp:Label ID="lblCorrCount" runat="server" Font-Bold="true" ForeColor="Red"></asp:Label>
            </td>
            <td style="width: 170px; text-align: right">
                <asp:Button ID="btnStart" runat="server" CssClass="cmnBtn" Text="Clear & Start again"
                    Width="150px" Visible="false" OnClientClick="return ConfirmStartAgain();" OnClick="btnStart_Click"
                    Height="20px" />
            </td>
        </tr>
    </table>
    <table width="100%">
        <tr id="rowUpload" runat="server">
            <td>
                TDS File Path
            </td>
            <td colspan="3">
                <asp:FileUpload ID="fupCorrection" CssClass="browsBtn" Width="460px" runat="server" />
            </td>
            <td>
                <asp:Button ID="btnUpload" runat="server" CssClass="cmnBtn" Text="Upload" OnClick="btnUpload_Click"
                    OnClientClick="return Validation(this);" Height="22px" />
            </td>
        </tr>
        <tr>
            <td>
                <asp:LinkButton ID="lnkErrors" runat="server" Visible="false" ForeColor="Blue" OnClick="lnkErrors_Click"> </asp:LinkButton>
            </td>
        </tr>
        <tr id="rowInfo" runat="server">
            <td colspan="5">
                <fieldset id="Fieldset1" runat="server" style="border-color: Gray; border-style: solid;
                    width: 80%">
                    <legend style="font-size: small" runat="server" id="fileInfo">File Information</legend>
                    <table cellpadding="2" cellspacing="2" width="100%">
                        <tr>
                            <td>
                                <table>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lblMsg" runat="server" Text="" ForeColor="Red" Font-Size="Small" />
                                        </td>
                                        <td colspan="3"></td>
                                    </tr>
                                    <tr>
                                        <td style="width: 140px; display: none">
                                            Filed Date :
                                        </td>
                                        <td colspan="3" style="width: 125px; display: none">
                                            <asp:Label ID="lblDate" runat="server" Text="NA" ForeColor="Red"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lblFinorTaxYear" runat="server" Text=""/>
                                        </td>
                                        <td colspan="3">
                                            <asp:Label ID="lblFinYear" runat="server" Text="NA" ForeColor="Red" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Original PRN :
                                        </td>
                                        <td colspan="3">
                                            <asp:Label ID="lblOrgPRN" runat="server" Text="NA" ForeColor="Red" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Previous PRN :
                                        </td>
                                        <td colspan="3">
                                            <asp:Label ID="lblPrePRN" runat="server" Text="NA" ForeColor="Red" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td></td>
                            <td>
                                <table>
                                    <tr>
                                        <td style="width: 140px">
                                            TAN :
                                        </td>
                                        <td colspan="3">
                                            <asp:Label ID="lblTAN" runat="server" Text="NA" ForeColor="Red" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Form :
                                        </td>
                                        <td colspan="3">
                                            <asp:Label ID="lblForm" runat="server" Text="NA" ForeColor="Red" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Quarter :
                                        </td>
                                        <td colspan="3">
                                            <asp:Label ID="lblQuarter" runat="server" Text="NA" ForeColor="Red" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            Challans :
                                        </td>
                                        <td colspan="3">
                                            <asp:Label ID="lblChallanCount" runat="server" Text="NA" ForeColor="Red" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Label ID="lblDisplayType" runat="server" Text="Deductions :" ForeColor="Black" />
                                        </td>
                                        <td colspan="3">
                                            <asp:Label ID="lblDeductionCount" runat="server" Text="NA" ForeColor="Red" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </fieldset>
            </td>
        </tr>
    </table>
    <hr />
    <asp:Panel ID="pnlCorrection" runat="server">
        <table>
            <tr>
                <td>
                    <asp:Button ID="btnDeductor" runat="server" CssClass="cmnBtn" Text="Deductor" OnClick="btnDeductor_Click" />
                </td>
                <td>
                    <asp:Button ID="btnChallan" runat="server" CssClass="cmnBtn" Text="Challan" OnClick="btnChallan_Click" />
                </td>
                <td>
                    <asp:Button ID="btnMaster" runat="server" CssClass="cmnBtn" Text="Master" OnClick="btnMaster_Click" />
                </td>
                <td>
                    <asp:Button ID="btnPANUpdate" runat="server" CssClass="cmnBtn" Text="PAN Update"
                        OnClick="btnPANUpdate_Click" />
                </td>
                <td>
                    <asp:Button ID="btnDeduction" runat="server" CssClass="cmnBtn" Text="Deduction" OnClick="btnDeduction_Click" />
                </td>
                <td>
                    <asp:Button ID="btnDisplayLinkedChallans" runat="server" Text="Display Linked Challans"
                        CssClass="cmnBtn" OnClick="btnDisplayLinkedChallans_Click" Width="160px" />
                </td>
                <td>
                    <asp:Button ID="btnSalary" runat="server" CssClass="cmnBtn" Text="Salary" OnClick="btnSalary_Click" />
                </td>
                <td>
                    <asp:Button ID="btnDefaultData" runat="server" CssClass="cmnBtn" Text="Default Data"
                        OnClick="btnDefaultData_Click" Visible="false" />
                </td>
            </tr>
        </table>
        <hr />
        <b>Correction Statement</b>
        <table width="100%">
            <tr>
                <td class="nTbl">
                    <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" ScrollBars="Vertical" Width="100%">
                        <asp:Repeater ID="rptCorrectionSummary" runat="server">
                            <HeaderTemplate>
                                <table id="NavTable" cellspacing="0" cellpadding="0" width="98%">
                                    <tr bgcolor="#EEEEEE">
                                        <th>
                                            Category
                                        </th>
                                        <th>
                                            Description
                                        </th>
                                    </tr>
                            </HeaderTemplate>
                            <ItemTemplate>
                                <tr bgcolor="white">
                                    <td>
                                        <asp:Label ID="lblCategory" runat="server" Text='<%# Eval("Category")%>'></asp:Label>
                                    </td>
                                    <td>
                                        <%#Eval("Description") %>
                                    </td>
                                </tr>
                            </ItemTemplate>
                            <FooterTemplate>
                                </table>
                            </FooterTemplate>
                        </asp:Repeater>
                    </asp:Panel>
                </td>
            </tr>
        </table>
        <hr />
        <tr>
            <td colspan="2">
                <table cellpadding="0" cellspacing="0">
                    <tr>
                        <td style="width: 240px">
                            Challan Input File Name With Path
                        </td>
                        <td width="400px" align="left">
                            <asp:FileUpload ID="fileUpload" runat="server" Width="80%" CssClass="browsBtn" />
                        </td>
                        <td>
                            <asp:CheckBox ID="chkCIN" runat="server" Text="Get CIN from TIN" onclick="EnableDisableUpload(this)"
                                Visible="false" />
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <table style="width: 100%">
            <tr>
                <td>
                    <asp:Button ID="btnCorrectioneReturn" runat="server" CssClass="cmnBtn" Text="e-Return"
                        OnClick="btnCorrectioneReturn_Click" OnClientClick="return Validation(this);" />
                </td>
                <td>
                    <asp:Button ID="btnGetFiles" runat="server" CssClass="cmnBtn" Text="Get Files" OnClick="btnGetFiles_Click" />
                </td>
                <td>
                    <asp:HyperLink ID="lnkForm27A" runat="server" Text="Form 27A" Font-Bold="true" Target="_blank"
                        Visible="False" />
                </td>
                <td align="center">
                    <table width="100%">
                        <tr>
                            <td style="width: 120px">
                                <asp:HyperLink ID="hlnkOpenOutput" runat="server" Text="Open Output" Target="_blank"
                                    Visible="False">
                                </asp:HyperLink>
                            </td>
                            <td align="left">
                                <asp:HyperLink ID="hlnkDownloadFvu" runat="server" Target="_blank" Visible="False"
                                    Font-Bold="True">[hlnkDownloadFvu]</asp:HyperLink>
                            </td>
                            <td align="left">
                                <asp:HyperLink ID="hlnkDownloadFVUZip" runat="server" Target="_blank" Visible="False"
                                    Font-Bold="True">Download .ZIP FVU File</asp:HyperLink>
                            </td>
                            <td>
                                <asp:HyperLink ID="hlnkStatisticsRpt" runat="server" Target="_blank" Visible="False" />
                            </td>
                            <td>
                                <asp:HyperLink ID="hlnkHtmlError" runat="server" Target="_blank" Visible="False"
                                    ForeColor="Red">
                                </asp:HyperLink>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <asp:Label ID="lblProcess" Text="" runat="server" ForeColor="Red"></asp:Label>
                            </td>
                        </tr>
                    </table>
                </td>
                <td>
                </td>
                <td align="right">
                    <asp:Button ID="btnUpdate" runat="server" ForeColor="Red" CssClass="cmnBtn" Text="Update"
                        OnClientClick="return SetText();" OnClick="btnUpdate_Click" />
                </td>
            </tr>
        </table>
    </asp:Panel>
    <table id="tableDefaultData" runat="server" visible="false">
        <tr>
            <td>
                Upload File
            </td>
            <td>
                <asp:FileUpload ID="fupFvuFile" runat="server" Width="500px" CssClass="browsBtn" />
            </td>
            <td colspan="2">
                <asp:Button ID="btnDefaultUplaod" runat="server" Text="Upload" CssClass="cmnBtn"
                    OnClick="btnDefaultUpload_Click" OnClientClick="return DefaultValidation(this);" />
            </td>
        </tr>
        <tr>
            <td>
                <asp:Button ID="btnDefaultClose" runat="server" Text="Close" CssClass="cmnBtn" OnClick="btnDefaultClose_Click" />
            </td>
        </tr>
    </table>
</asp:Content>
