﻿<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Correction_NonEmployee, App_Web_nonemployee.aspx.4fd6750c" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
        <style type="text/css">
        .modalBackground {
            background-color: Gray;
            filter: alpha(opacity=70);
            opacity: 0.7;
        }

        .modalPopup {
            background-color: #ffffdd;
            border-width: 5px;
            border-style: solid;
            border-color: Gray;
            padding: 10px;
            width: 260px;
        }

        .style1 {
            width: 107px;
        }
        .PrProgress1 {
            position: fixed; /* Fix the element relative to the viewport */
            top: 50%; /* Center vertically */
            left: 50%; /* Center horizontally */
            transform: translate(-50%, -50%); /* Adjust for the element's size */
            z-index: 1000; /* Ensure it appears above other elements */
            /*background: rgba(255, 255, 255, 0.9);*/ /* Optional: Semi-transparent background */
            /*border: 1px solid #ccc;*/ /* Optional: Add a border for visibility */
            padding: 20px; /* Optional: Add padding for spacing inside the loader */
            border-radius: 8px; /* Optional: Rounded corners */
            text-align: center; /* Center-align content inside the loader */
            /*box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);*/ /* Optional: Add shadow for a floating effect */
        }
    </style>
    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>
    <script type="text/javascript" language="javascript">
        function OnNewRecord() {
            document.getElementById("<%=hdnDefaultPan.ClientID%>").value = "PAN";
            var defaultPAN = document.getElementById("<%=hdnDefaultPan.ClientID%>");
            var ddlPan = document.getElementById("<%=ddlPan.ClientID%>");
            document.getElementById("<%=hdnDeducteeSlNo.ClientID%>").value = "-1";
            document.getElementById("<%=txtSlNo.ClientID%>").value = "";
            document.getElementById("<%=ddlSalutation.ClientID%>").selectedIndex = 0;
            document.getElementById("<%=txtName.ClientID%>").value = "";
            document.getElementById("<%=txtAddress1.ClientID%>").value = "";
            document.getElementById("<%=txtAddress2.ClientID%>").value = "";
            document.getElementById("<%=txtAddress3.ClientID%>").value = "";
            document.getElementById("<%=txtAddress4.ClientID%>").value = "";
            document.getElementById("<%=txtCity.ClientID%>").value = "";
            document.getElementById("<%=txtPinCode.ClientID%>").value = "";
            document.getElementById("<%=txtPhoneNumber.ClientID%>").value = "";
            document.getElementById("<%=txtEmailAddress.ClientID%>").value = "";
            document.getElementById("<%=ddlState.ClientID%>").selectedIndex = 0;
            document.getElementById("<%=chkForm26.ClientID%>").checked = true;
            document.getElementById("<%=chkForm27.ClientID%>").checked = true;
            document.getElementById("<%=ddlCode.ClientID%>").selectedIndex = 0;
            if (document.getElementById("<%=hdnFinYear.ClientID%>").value != "2009") { document.getElementById("<%=chkIsTransporter.ClientID%>").checked = false; }
            document.getElementById("<%=txtName.ClientID%>").focus();
            if (defaultPAN.value != "" || defaultPAN.value != "PAN") {
                if (defaultPAN.value == "PANNOTAVBL") { document.getElementById("<%=ddlPan.ClientID%>").selectedIndex = 3; }
                else if (defaultPAN.value == "PANINVALID") { document.getElementById("<%=ddlPan.ClientID%>").selectedIndex = 2; }
                else if (defaultPAN.value == "PANAPPLIED") { document.getElementById("<%=ddlPan.ClientID%>").selectedIndex = 1; }
                document.getElementById("<%=txtPanReference.ClientID%>").style.backgroundColor = "white";
                document.getElementById("<%=txtPanReference.ClientID%>").disabled = true;
            }
            else {
                document.getElementById("<%=ddlPan.ClientID%>").selectedIndex = 0;
                document.getElementById("<%=txtPanReference.ClientID%>").style.backgroundColor = "#E5E5E5";
                document.getElementById("<%=txtPanReference.ClientID%>").disabled = false;
            }
            if (defaultPAN.value == "PAN") {
                document.getElementById("<%=ddlPan.ClientID%>").selectedIndex = 0;
                document.getElementById("<%=txtPanReference.ClientID%>").disabled = false;
                document.getElementById("<%=txtPanReference.ClientID%>").style.backgroundColor = "#E5E5E5";
            }
            document.getElementById("<%=ddlPan.ClientID%>").disabled = false;
            document.getElementById("<%=txtPanReference.ClientID%>").value = "";
        }
        function Validation() {          
            if (!ValidateLength(document.getElementById("<%=txtName.ClientID%>"), "NonEmployee Name", 75, true)) return false;
            if (!ValidateDropDown(document.getElementById("<%=ddlState.ClientID%>"), "State")) return false;
            if (!ValidateLength(document.getElementById("<%=txtPinCode.ClientID%>"), "PinCode", 6, false)) return false;
            if (document.getElementById("<%=txtEmailAddress.ClientID%>").value != "") { if (!ValidateEmail(document.getElementById("<%=txtEmailAddress.ClientID%>"))) return false; }
            if (document.getElementById("<%=txtChangedPanReference.ClientID%>") != null) { if (document.getElementById("<%=txtChangedPanReference.ClientID%>").value != "" && document.getElementById("<%=ddlPan.ClientID%>").value == "PAN") { if (!ValidatePAN(document.getElementById("<%=txtChangedPanReference.ClientID%>"), "PAN", 10, true)) return false; } }
            if (document.getElementById("<%=txtPanReference.ClientID%>") != null) { if (document.getElementById("<%=txtPanReference.ClientID%>").value != "" && document.getElementById("<%=ddlPan.ClientID%>").value == "PAN") { if (!ValidatePAN(document.getElementById("<%=txtPanReference.ClientID%>"), "PAN", 10, true)) return false; } }
            if (isNaN(document.getElementById("<%=txtPhoneNumber.ClientID %>").value)) {
                alert("Phone No. should be Numbers only");
                return false;
            }           
            if (isNaN(document.getElementById("<%=txtPinCode.ClientID %>").value)) {
                alert("Pincode should be Numbers only");
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtName.ClientID%>").value)) {
                document.getElementById("<%=txtName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress1.ClientID%>").value)) {
                document.getElementById("<%=txtAddress1.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress2.ClientID%>").value)) {
                document.getElementById("<%=txtAddress2.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress3.ClientID%>").value)) {
                document.getElementById("<%=txtAddress3.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtAddress4.ClientID%>").value)) {
                document.getElementById("<%=txtAddress4.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtCity.ClientID%>").value)) {
                document.getElementById("<%=txtCity.ClientID%>").value = "";
                return false;
            }           
        }
        function ValidatePANUpdate() {            
            if (document.getElementById("<%=txtChangedPanReference.ClientID%>").value == "") {
                alert('Enter PAN to Update.');
                return false;
            }
           <%-- if (document.getElementById("<%=txtChgName.ClientID%>").value == "") {
                alert('Enter Changed Name.');
                return false;
            }--%>
            <%-- if (document.getElementById("<%=hdnDeducteeSlNo.ClientID%>").value == "-1") {                             
            }
            else--%>
            var txtPAN = document.getElementById("<%=txtPanReference.ClientID%>");
            var txtName = document.getElementById("<%=txtName.ClientID%>");
            var ddlPAN = document.getElementById("<%=ddlPan.ClientID%>");
            if (txtPAN.value == "" && txtName.value == "" && ddlPAN.selectedIndex == 0) {
                alert("Specify Nonemployee Name.");
                return false;
            }
            //if (document.getElementById("<%=ddlPan.ClientID%>").value == "PAN") { if (!ValidatePAN(document.getElementById("<%=txtChangedPanReference.ClientID%>"), "PAN", 10, true)) return false; }
            //if (ddlPAN.selectedIndex > 0) {
            //    alert("PAN other than PANAPPLIED, PANINVALID and PANNOTAVBL will be verified.\nSpecify PAN if available.");
            //    return false;
            //}
            <%--if (document.getElementById("<%=hdnSelectedDedSlno.ClientID%>").value != "") {
                if (confirm("Do you want to Update the PAN for other records.") == true) {
                    document.getElementById("<%=hdnMultiplePanOpt.ClientID%>").value = 1;
                }
                else {
                    document.getElementById("<%=hdnMultiplePanOpt.ClientID%>").value = 0;
                }
            }--%>
            if (ValidateHtmlTags(document.getElementById("<%=txtChgName.ClientID%>").value)) {
                document.getElementById("<%=txtChgName.ClientID%>").value = "";
                return false;
            }
            return ValidatePAN(document.getElementById("<%=txtChangedPanReference.ClientID%>"), "PAN", 10, false)            
        }
        function UnSelectAll() {
            var x = document.getElementsByClassName("panCheckBox");
            var i;
            for (i = 0; i <= x.length; i++) {
                if (i < 10) {
                    i = '0' + i;
                }
                el = document.getElementById('ctl00_contentPlaceHolderBody_rptrExistingNonEmployees_ctl' + i + '_chkExistingNonEmployeesSelect');
                if (el != null && el.disabled == false) {
                    el.checked = false;
                }
            }
            return false;
        }
        function SelectAll() {
            var x = document.getElementsByClassName("panCheckBox");
            var i;
            for (i = 0; i <= x.length; i++) {
                if (i < 10) {
                    i = '0' + i;
                }
                el = document.getElementById('ctl00_contentPlaceHolderBody_rptrExistingNonEmployees_ctl' + i + '_chkExistingNonEmployeesSelect');
                if (el != null && el.disabled == false) {
                    el.checked = true;
                }
            }
            return false;
        }
        function OnDelete() {
            if (document.getElementById("<%=hdnDeductionSerialNo.ClientID%>").value == "-1") {
                alert('Select a record to remove.');
                return false;
            }
            else if (document.getElementById("<%=hdnCorrectionID.ClientID%>").value != "0") {
                return confirm('This Record was added from Correction Request\n\nTicket No : ' + document.getElementById("<%=hdnCorrectionID.ClientID%>").value + '\n\n All the records with this request will be removed\n\n Do u want to continue ?');
            }
            else { return confirm('Are you sure you want to remove the record ?'); }
        }
        function CheckDuplicatePan() { if (confirm("Are you Sure you want to Save Duplicate Pan?")) { __doPostBack("updatePanel", "DuplicatePan"); } }
        function ChangeControlProperty() {
            document.getElementById("<%=txtPanReference.ClientID%>").value = "";
            if (document.getElementById("<%=ddlPan.ClientID%>").value == "PAN") {
                document.getElementById("<%=txtPanReference.ClientID%>").style.backgroundColor = "#E5E5E5";
                document.getElementById("<%=txtPanReference.ClientID%>").disabled = false;
            }
            else {
                document.getElementById("<%=txtPanReference.ClientID%>").style.backgroundColor = "White";
                document.getElementById("<%=txtPanReference.ClientID%>").disabled = true;
            }
        }
        function Show_Popup_Import() {
            $find("popUpBulkImport_Control").show();
        }
        function Show_Popup_Export() {
            $find("popUpBulkExport_Control").show();
        }
        function ClearDeducteeName() {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) { }
            else {
                document.getElementById("<%=hdnDeducteeSlNo.ClientID%>").value = "-1";
               <%-- document.getElementById("<%=txtPAN.ClientID%>").value = "";
                document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "";
                 document.getElementById("<%=hdnIsTran.ClientID%>").value = "";--%>
            }
        }
        function GetDeducteeNameValue(source, eventArgs) {
            var contents;
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                contents = eventArgs.get_text();
                contents = contents.split('-');
                document.getElementById("<%=hdnDeducteeSlNo.ClientID%>").value = eventArgs.get_value();
            }
            else {
                contents = eventArgs.get_value();
                contents = contents.split(';');
                document.getElementById("<%=hdnDeducteeSlNo.ClientID%>").value = contents[0];
            }
        }
        function SetStatus() {           
            var hdnSearch = document.getElementById("<%=hdnSearch.ClientID%>");
             if (hdnSearch.value == "0") { hdnSearch.value = "1"; }
             else { hdnSearch.value = "0"; }
             SetSearchPanelVisibility();
         }
        function SetSearchPanelVisibility() {
            var btnSearch = document.getElementById("<%=btnOpenSearch.ClientID%>");
             var pnlSearch = document.getElementById("<%=pnlSearch.ClientID%>");
            if (btnSearch == null) { document.getElementById("<%=hdnSearch.ClientID%>").value = "0"; return; }
            else {
                 if (document.getElementById("<%=hdnSearch.ClientID%>").value == "0") {
                     if (btnSearch != null) btnSearch.style.display = '';
                     if (pnlSearch != null) pnlSearch.style.display = 'none';
                 }
                 else {
                     if (btnSearch != null) btnSearch.style.display = 'none';
                     if (pnlSearch != null) pnlSearch.style.display = '';
                 }
             }
        }
        function FormatSearch() {
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchDedSerialNo.ClientID%>").value)) {
                document.getElementById("<%=txtSearchDedSerialNo.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchChangedName.ClientID%>").value)) {
                document.getElementById("<%=txtSearchChangedName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSection.ClientID%>").value)) {
                 document.getElementById("<%=txtSection.ClientID%>").value = "";
                 return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchAmountFrom.ClientID%>").value)) {
                 document.getElementById("<%=txtSearchAmountFrom.ClientID%>").value = "";
                 return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchAmountTo.ClientID%>").value)) {
                document.getElementById("<%=txtSearchAmountTo.ClientID%>").value = "";
                return false;
            }
        }
        document.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                document.getElementById("<%=btnSave.ClientID%>").click();
              }
        });
        function FileValidation() {
            document.getElementById("<%=pnlPopup1.ClientID%>").style.display = 'block';
            var uploadFile = document.getElementById("<%=fupTextFile.ClientID%>");
            var fileType = '.txt';

            // Check if a file is selected
            if (uploadFile.files.length > 0) {
                var file = uploadFile.files[0];
                var fileName = file.name.toLowerCase(); // File name in lowercase            

                // Validate file type
                if (!fileName.endsWith(fileType)) {                   
                    alert("Only .txt files are allowed for upload.");
                    document.getElementById("<%=pnlPopup1.ClientID%>").style.display = 'none';
                    return false;
                }
            }
            return true;
        }
        <%--function ValidateViewExisting() {
            if (!Validate()) return false;
            else return true;
        }
        function Validate() {
            var count = 0;
            for (i = 0; i < document.getElementById("<%=rptrTD.ClientID%>").all.length; i++) {
                if (document.getElementById("<%=rptrTD.ClientID%>").all[i].type == 'checkbox' && document.getElementById("<%=rptrTD.ClientID%>").all[i].name.indexOf("chkExistingDedsSelect") != -1) {
                    if (document.getElementById("<%=rptrTD.ClientID%>").all[i].checked) { count = count + 1; }
                }
            }
            if (count == 0) {
                alert("Select atleast one record.");
                return false;
            }
            return true;
        }--%>
        
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="updatePanel" runat="server">
        <Triggers>
            <asp:PostBackTrigger ControlID="btnImportPopUp" />
        </Triggers>
        <ContentTemplate>
            <asp:Panel ID="pnlBulkExport" runat="server" Height="100px" BackColor="White" CssClass="modalPopup"
                Style="display: none">
                <br />
                <br />
                <asp:Label ID="lblBulkExport" Font-Size="Medium" Text="Exporting Data to Excel Sheet. Please Wait....."
                    Font-Bold="true" ForeColor="Red" runat="server"> </asp:Label>
            </asp:Panel>
            <asp:Panel ID="pnlBulkImport" runat="server" Height="100px" BackColor="White" CssClass="modalPopup"
                Style="display: none">
                <br />
                <br />
                <asp:Label ID="lblBulkImport" Font-Size="Medium" Text="Importing Excel Data. Please Wait....."
                    Font-Bold="true" ForeColor="Red" runat="server"> </asp:Label>
            </asp:Panel>
            <asp:Panel ID="pnlImport" runat="server" BackColor="White" CssClass="modalPopup"
                Width="400px" Style="display: none">
                <asp:Label ID="lblImport_Heading" Text="BULK PAN UPDATE - IMPORT" Font-Bold="true"
                    ForeColor="Brown" runat="server"> </asp:Label>
                <hr />
                <table>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td style="width: 100px">Select File
                        </td>
                        <td>
                            <asp:FileUpload ID="fileUpload" runat="server" Width="300px" />
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td align="right">
                            <asp:Button ID="btnImportPopUp" Text="Import" runat="server" Width="70px" CssClass="cmnBtn"
                                OnClientClick="Show_Popup_Import();" OnClick="btnImportPopUp_Click" />
                            <asp:Button ID="btnCloseImportPopUp" Text="Close" runat="server" Width="70px" CssClass="cmnBtn" />
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:HiddenField ID="hdnDeducteeSlNo" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnCorrStatus" runat="server" Value="5" />
            <asp:HiddenField ID="selectedPageSize" runat="server" Value="-1" />
            <asp:HiddenField ID="selectedPageIndex" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnViewExistingPageIndex" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnViewExistingPageSize" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnSelectedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnUpdatedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnUpdateItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnIsCorrEReturnValid" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnFinYear" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnDeducteeID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnMaxPanReference" runat="server" />
            <asp:HiddenField ID="hdnPanReference" runat="server" />
            <asp:HiddenField ID="hdnDefaultPan" runat="server" Value="" />
            <asp:HiddenField ID="hdnisUpdated" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsChecked" runat="server" Value="True" />
            <asp:HiddenField ID="hdnFormType" runat="server" />
            <asp:HiddenField ID="hdnDeductionSerialNo" runat="server" />
            <asp:HiddenField ID="hdnOldDeducteeSerialNo" runat="server" />
            <asp:HiddenField ID="hdnSelectedDedSlno" runat="server" />
            <asp:HiddenField ID="hdnMultiplePanOpt" runat="server" />
            <asp:HiddenField ID="hdnCorrectionID" runat="server" Value="0" />
            <asp:HiddenField ID="hdnSearch" runat="server" Value="0" />
            <asp:HiddenField ID="hdnSelectedPAN" runat="server" />
            <asp:HiddenField ID="hdnSelectedUpdatedPAN" runat="server" />
            <asp:HiddenField ID="hdnIsBOB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnPANSelectedItems" runat="server" Value="" />
            <cc1:ModalPopupExtender ID="popUpImport" runat="server" CancelControlID="btnCloseImportPopUp"
                BackgroundCssClass="modalBackground" TargetControlID="btnImport" PopupControlID="pnlImport">
            </cc1:ModalPopupExtender>
            <cc1:ModalPopupExtender ID="popUpBulkExport" BehaviorID="popUpBulkExport_Control"
                runat="server" CancelControlID="btnCloseImportPopUp" BackgroundCssClass="modalBackground"
                TargetControlID="lblBulkExport" PopupControlID="pnlBulkExport">
            </cc1:ModalPopupExtender>
            <cc1:ModalPopupExtender ID="popUpBulkImport" BehaviorID="popUpBulkImport_Control"
                runat="server" CancelControlID="btnCloseImportPopUp" BackgroundCssClass="modalBackground"
                TargetControlID="lblBulkImport" PopupControlID="pnlBulkImport">
            </cc1:ModalPopupExtender>
            <asp:MultiView ID="mvNonEmployee" runat="server" ActiveViewIndex="0">
                <asp:View ID="vwNonEmployee" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td>
                                <table cellpadding="0" cellspacing="0" width="100%">
                                    <tr>
                                        <td rowspan="0" valign="top" width="50%">
                                            <table class="eCol" style="width:100%">
                                                <tr>
                                                    <td class="vHCol">Serial Number
                                                    </td>
                                                    <td>
                                                        <asp:TextBox runat="server" ID="txtSlNo" CssClass="txtBPL" Enabled="false"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Name
                                                    </td>
                                                    <td>
                                                        <table width="100%" cellpadding="0px" cellspacing="0px">
                                                            <tr>
                                                                <td width="20%" style="padding-top: 1px;">
                                                                    <asp:DropDownList ID="ddlSalutation" runat="server" style="width: 95%;" TabIndex="1">
                                                                    </asp:DropDownList>
                                                                </td>
                                                                <td>
                                                                    <asp:TextBox ID="txtName" runat="server" CssClass="txtBML" TabIndex="2" AutoComplete="Off" style="width: 96%;"
                                                                         MaxLength="75" onkeypress="return ValidateDelimiter(this,event);"></asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">PAN
                                                    </td>
                                                    <td>
                                                        <asp:DropDownList ID="ddlPan" runat="server" Font-Size="9" BackColor="#E5E5E5"
                                                            OnChange="ChangeControlProperty();" TabIndex="17" style="width: 98%;">
                                                            <asp:ListItem Text="PAN" Value="PAN"></asp:ListItem>
                                                            <asp:ListItem Text="PANAPPLIED" Value="PANAPPLIED"></asp:ListItem>
                                                            <asp:ListItem Text="PANINVALID" Value="PANINVALID"></asp:ListItem>
                                                            <asp:ListItem Text="PANNOTAVBL" Value="PANNOTAVBL"></asp:ListItem>
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">PAN /PAN Reference
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtPanReference" CssClass="txtBPL" MaxLength="10" TabIndex="18" style="width: 96%;"
                                                            BackColor="#E5E5E5" onkeypress="return ValidateForAlphaNumeric(event);" runat="server"
                                                            onBlur="ConvertToUC(this);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr id="PantoUpdate" runat="server">
                                                    <td class="vHCol">PAN to Update 
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtChangedPanReference" CssClass="txtBPL" MaxLength="10" TabIndex="18" style="width: 96%;"
                                                            BackColor="#E5E5E5" onkeypress="return ValidateForAlphaNumeric(event);" runat="server"
                                                            onBlur="ConvertToUC(this);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr id="ChangedName" runat="server">
                                                    <td class="vHCol">Name to Update
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtChgName" runat="server" onkeyup="ClearDeducteeName()" BackColor="#E5E5E5" CssClass="txtBML" style="width: 96%;"
                                                            TabIndex="1" onkeypress="return ValidateDelimiter(this,event);" onBlur="ConvertToUC(this);"></asp:TextBox>
                                                        <%--<cc1:AutoCompleteExtender ID="autoCompleteExtender" runat="server" MinimumPrefixLength="2"
                                                            ServicePath="~/WebServices/AutoCompleteService.asmx" TargetControlID="txtChgName"
                                                            CompletionInterval="700" EnableCaching="false" CompletionSetCount="50" DelimiterCharacters=""
                                                            ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="True" OnClientItemSelected="GetDeducteeNameValue">
                                                        </cc1:AutoCompleteExtender>--%>
                                                    </td>
                                                </tr>            
                                                <tr id="ChkAllDeductions" runat="server">
                                                    <td></td>
                                                    <td>
                                                        <asp:CheckBox ID="chkIsAllDeductions" runat="server" Text="Apply PAN Change for related Deductions" Checked="true" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Flat/Door/Block No.
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtAddress1" runat="server" CssClass="txtBPL" TabIndex="3" MaxLength="25"
                                                            AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Name of Building
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtAddress2" runat="server" CssClass="txtBPL" TabIndex="4" MaxLength="25"
                                                            AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Street / Road Name
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtAddress3" runat="server" CssClass="txtBPL" TabIndex="5" MaxLength="25"
                                                            AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Area
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtAddress4" runat="server" CssClass="txtBPL" TabIndex="6" MaxLength="25"
                                                            AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                                    </td>
                                                </tr>                                                
                                            </table>
                                        </td>
                                        <td valign="top" style="width:50%">
                                            <table class="eCol" style="width:90%">
                                                <tr>
                                                    <td class="vHCol">List Deductee In
                                                    </td>
                                                    <td>
                                                        <asp:CheckBox ID="chkForm26" runat="server" Text="Form 26" Checked="true" TabIndex="10" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">&nbsp;
                                                    </td>
                                                    <td>
                                                        <asp:CheckBox ID="chkForm27" runat="server" Text="Form 27" Checked="true" TabIndex="11" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">&nbsp;
                                                    </td>
                                                    <td>
                                                        <asp:CheckBox ID="chkForm27E" runat="server" Text="Form 27E" Checked="true" TabIndex="12" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Phone
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtPhoneNumber" runat="server" CssClass="txtBPL" MaxLength="15" Width="90%"
                                                            AutoComplete="Off" TabIndex="12" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Email Address
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtEmailAddress" CssClass="txtBPL" MaxLength="75" runat="server"
                                                            AutoComplete="Off" TabIndex="13" Width="90%"> </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">City
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtCity" runat="server" MaxLength="25" TabIndex="7" CssClass="txtBPL" Width="90%"
                                                            AutoComplete="Off" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">State
                                                    </td>
                                                    <td>
                                                        <asp:DropDownList ID="ddlState" runat="server" Width="90%" TabIndex="8" Font-Size="9"
                                                            CssClass="mCBs">
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Pincode
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtPinCode" runat="server" CssClass="txtBPL" TabIndex="9" MaxLength="6"
                                                            AutoComplete="Off" onkeypress="return ValidateForOnlyNos(event);" Width="90%"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Code
                                                    </td>
                                                    <td>
                                                        <asp:DropDownList ID="ddlCode" runat="server" Width="90%" TabIndex="16" Font-Size="9"
                                                            CssClass="mCBs">
                                                            <asp:ListItem Text="Companies" Value="1" />
                                                            <asp:ListItem Text="Other Than Companies" Value="2" />
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td></td>
                                                    <td>
                                                        <asp:CheckBox ID="chkIsTransporter" runat="server" Text="Is Transporter?" Checked="false" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                                <table>
                                    <tr style="margin-left: 0">
                                        <td colspan="2">
                                            <table cellpadding="0" cellspacing="0" id="nonEmployeeControls" runat="server">
                                                <tr>
                                                    <td style="padding-right: 5px">
                                                        <asp:Button ID="btnNew" runat="server" Text="New" TabIndex="18" OnClientClick="OnNewRecord();return false;"
                                                            CssClass="cmnBtn" UseSubmitBehavior="false"></asp:Button>
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnSave" runat="server" Text="Save" TabIndex="17" CssClass="cmnBtn"
                                                            OnClientClick="return Validation();" OnClick="btnSave_Click"></asp:Button>
                                                    </td>
                                                    <td style="padding-left: 5px">
                                                        <asp:Button ID="btnDelete" runat="server" Text="Delete" CssClass="cmnBtn" TabIndex="20"
                                                            OnClientClick="return OnDelete();" OnClick="btnDelete_Click" />
                                                    </td>
                                                    <td style="padding-left: 5px">
                                                        <asp:Button ID="btnClose" runat="server" Text="Close" CssClass="cmnBtn" TabIndex="21"
                                                            OnClick="btnClose_Click" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                                <table cellpadding="0" id="panUpdateControls" runat="server">
                                    <tr>
                                        <td style="padding-left: 5px">
                                            <asp:Button ID="btnViewExisting" runat="server" Text="View Existing" CssClass="cmnBtn"
                                                TabIndex="22" OnClick="btnViewExisting_Click" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnUpdate" runat="server" Text="Update" CssClass="cmnBtn" TabIndex="20"
                                                OnClientClick="return ValidatePANUpdate();" OnClick="btnUpdate_Click" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnBlkUpdate" Text="Bulk Update" runat="server" CssClass="cmnBtn"
                                                OnClick="btnOk_Click" />
                                        </td>
                                        <td style="padding-left: 5px">
                                            <asp:Button ID="btnRemove" runat="server" Text="Remove" CssClass="cmnBtn" TabIndex="19"
                                                OnClientClick="return OnDelete();" OnClick="btnRemove_Click" />
                                        </td>
                                        <td style="padding-left: 5px">
                                            <asp:Button ID="Button1" runat="server" Text="Close" CssClass="cmnBtn" OnClick="btnClose_Click" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnOpenSearch" runat="server" Text="Search" TabIndex="20" CssClass="cmnBtn"                                               
                                                Width="80px" OnClick="btnOpenSearch_Click" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                  <asp:Panel ID="pnlSearch" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel">
                                    <table width="100%">
                                        <tr>
                                            <td colspan="2" width="20%">Serial No.
                                            </td>
                                            <td colspan="5">
                                                <asp:TextBox ID="txtSearchDedSerialNo" runat="server" Width="90%" TabIndex="20"
                                                    CssClass="txtBPL" onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75"
                                                    onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td colspan="2" width="17%">
                                                <asp:Label ID="lblSearchSection" Text="Section" runat="server"></asp:Label>
                                            </td>
                                            <td colspan="3">
                                                <asp:Panel ID="Panel2" runat="server" Style="background-color: white; width: 191px; border-right: 1px solid #9f9f9f; border-left: 1px solid #9f9f9f; border-bottom: 1px solid #9f9f9f">
                                                    <asp:CheckBoxList ID="chkSections" runat="server">
                                                    </asp:CheckBoxList>
                                                </asp:Panel>
                                                <asp:TextBox ID="txtSection" runat="server" CssClass="txtBPL" Width="70%"></asp:TextBox>
                                                <cc1:PopupControlExtender ID="PopEx" runat="server" TargetControlID="txtSection"
                                                    PopupControlID="Panel2" Position="Bottom" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">Name to Update
                                            </td>
                                            <td colspan="5">
                                                <asp:TextBox ID="txtSearchChangedName" runat="server" Width="90%" TabIndex="20" CssClass="txtBPL"
                                                    onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td colspan="2">PAN to Update
                                            </td>
                                            <td colspan="3">
                                               <asp:TextBox ID="txtSearchChangedPAN" runat="server" Width="70%" TabIndex="20" CssClass="txtBPL"
                                                    onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Amount of Payment
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">From
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSearchAmountFrom" runat="server" Width="120px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="22"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px" align="right">To
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSearchAmountTo" runat="server" Width="120px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="23"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>                                           
                                        </tr>                                                                       
                                        <tr>
                                            <td colspan="6">
                                                <table>
                                                    <tr>
                                                        <td align="right">
                                                            <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="cmnBtn" TabIndex="30"
                                                                OnClientClick="return FormatSearch();" OnClick="btnSearch_Click" />
                                                        </td>
                                                        <td>
                                                            <asp:Button ID="btnShowAll" runat="server" Text="Show All" CssClass="cmnBtn" OnClientClick="return ShowAllclick();"
                                                                OnClick="btnShowAll_Click" />
                                                        </td>
                                                        <td>
                                                            <asp:Button ID="btnClose1" runat="server" Text="Close" Width="80px" CssClass="cmnBtn"                                                               
                                                                TabIndex="32" OnClick="btnClose1_Click" />
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                            </td>
                        </tr>
                        <tr>
                            <td class="nTbl">
                                <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal" Visible="false" Width="1050px">
                                    <asp:Repeater ID="rptNonEmployee" runat="server" OnItemCommand="rptNonEmployee_ItemCommand"
                                        OnItemDataBound="rptNonEmployee_ItemDataBound">
                                        <HeaderTemplate>
                                            <table id="NavTable" cellspacing="0" cellpadding="0">
                                                <tr bgcolor="#EEEEEE">
                                                    <th>Action
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblName" Width="250px" Text="Name" />
                                                    </th>
                                                    <th id="thAddress1" runat="server">
                                                        <asp:Label ID="Label1" runat="server" Width="160px" Text="Flat/Door/Block No" />
                                                    </th>
                                                    <th id="thAddress2" runat="server">
                                                        <asp:Label ID="Label2" runat="server" Width="160px" Text="Name of Building" />
                                                    </th>
                                                    <th id="thAddress3" runat="server">
                                                        <asp:Label ID="Label3" runat="server" Width="160px" Text="Street/Road Name" />
                                                    </th>
                                                    <th id="thAddress4" runat="server">
                                                        <asp:Label ID="Label4" runat="server" Width="160px" Text="Area" />
                                                    </th>
                                                    <th id="thAddress5" runat="server">
                                                        <asp:Label ID="Label5" runat="server" Width="160px" Text="City" />
                                                    </th>
                                                    <th id="thState" runat="server">
                                                        <asp:Label ID="Label6" runat="server" Width="200px" Text="State" />
                                                    </th>
                                                    <th id="thPincode" runat="server">
                                                        <asp:Label ID="Label7" runat="server" Width="60px" Text="Pincode" />
                                                    </th>
                                                    <th id="thPhone" runat="server">
                                                        <asp:Label ID="Label11" runat="server" Width="100px" Text="Phone" />
                                                    </th>
                                                    <th id="thEmail" runat="server">
                                                        <asp:Label ID="Label8" runat="server" Width="200px" Text="E-Mail" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label9" runat="server" Width="100px" Text="PAN" />
                                                    </th>
                                                    <th id="thPanRef" runat="server">
                                                        <asp:Label ID="Label15" runat="server" Width="100px" Text="PAN Reference" />
                                                    </th>
                                                    <th id="thCode" runat="server">
                                                        <asp:Label ID="Label10" runat="server" Width="100px" Text="Code" />
                                                    </th>
                                                    <th id="thChangedName" runat="server">
                                                        <asp:Label ID="ChngdName" runat="server" Width="100px" Text="Changed Name" />
                                                    </th>
                                                    <th id="thChangedPAN" runat="server">
                                                        <asp:Label ID="ChngdPan" runat="server" Width="100px" Text="Changed PAN" />
                                                    </th>
                                                    <th id="thDedSrNo" runat="server">
                                                        <asp:Label ID="DedSrNo" runat="server" Width="100px" Text="Serial No" />
                                                    </th>
                                                    <th id="thSection" runat="server">
                                                        <asp:Label ID="Section" runat="server" Width="100px" Text="Section" />
                                                    </th>
                                                    <th id="thAmtofPymt" runat="server">
                                                        <asp:Label ID="AmtofPymt" runat="server" Width="100px" Text="Amount of Payment" />
                                                    </th>
                                                    <th id="thPaidCreditedDate" runat="server">
                                                        <asp:Label ID="PaidCredited" runat="server" Width="100px" Text="Paid/Crdited Date" />
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white">
                                                <td>
                                                    <asp:LinkButton ID="hlnkEdit" runat="server" TabIndex="19" CommandName="LoadData"
                                                        Text='Edit' CommandArgument='<%# Eval("DeducteeSlNo") %>'></asp:LinkButton>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblNonEmpName" runat="server" Text='<%#Eval("Name") %>'></asp:Label>
                                                </td>
                                                <td style="text-align: center; display: none">
                                                    <asp:Label ID="lblDeducteeSlNo" Text='<%# Eval("DeducteeSlNo")%>' runat="server"> </asp:Label>
                                                </td>
                                                <td id="tdAddress1" runat="server">
                                                    <%#Eval("Address1") %>
                                                </td>
                                                <td id="tdAddress2" runat="server">
                                                    <%# Eval("Address2") %>
                                                </td>
                                                <td id="tdAddress3" runat="server">
                                                    <%#Eval("Address3") %>
                                                </td>
                                                <td id="tdAddress4" runat="server">
                                                    <%# Eval("Address4") %>
                                                </td>
                                                <td id="tdAddress5" runat="server">
                                                    <%#Eval("Address5") %>
                                                </td>
                                                <td id="tdState" runat="server">
                                                    <%# Eval("StateName") %>
                                                </td>
                                                <td id="tdPincode" runat="server">
                                                    <%#Eval("PinCode") %>
                                                </td>
                                                <td id="tdPhone" runat="server">
                                                    <%#Eval("PhoneNumber")%>
                                                </td>
                                                <td id="tdEmail" runat="server">
                                                    <%#Eval("EmailID")%>
                                                </td>
                                                <td>
                                                    <%#Eval("PAN") %>
                                                </td>
                                                <td id="tdPanRef" runat="server">
                                                    <%#Eval("PANReference") %>
                                                </td>
                                                <td id="tdCode" runat="server">
                                                    <%#Eval("Code")%>
                                                </td>
                                                <td id="tdChangedName" runat="server">
                                                    <%#Eval("ChangedName")%>
                                                </td>
                                                <td id="tdChangedPan" runat="server">
                                                    <%#Eval("ChangedPan")%>
                                                </td>
                                                <td id="tdDedSerialNo" runat="server">
                                                    <%#Eval("DeductionSerialNo")%>
                                                </td>
                                                <td id="tdSection" runat="server">
                                                    <%#Eval("Section")%>
                                                </td>
                                                <td id="tdAmtofPaymt" runat="server">
                                                    <%#Eval("AmtofPayment")%>
                                                </td>
                                                <td id="tdPaidCredited" runat="server">
                                                    <%#Eval("PaidCredited")%>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px;" align="right" id="tblPagination" visible="false" runat="server">
                                    <tr>
                                        <td style="padding: 0px 0px 0px 0px">
                                            <asp:Label ID="ASPxLabel4" runat="server" Text="Records per page : " Font-Size="X-Small" />
                                        </td>
                                        <td>
                                            <td style="width: 50px; padding-top: 2px;">
                                                <asp:DropDownList ID="cmbGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                    OnSelectedIndexChanged="cmbGoTo_SelectedIndexChanged" AutoPostBack="true" Font-Size="X-Small">
                                                    <asp:ListItem Text="5" Value="5" />
                                                    <asp:ListItem Text="10" Value="10" />
                                                    <asp:ListItem Text="15" Value="15" />
                                                    <asp:ListItem Text="20" Value="20" />
                                                    <asp:ListItem Text="25" Value="25" />
                                                    <asp:ListItem Text="50" Value="50" />
                                                    <asp:ListItem Text="75" Value="75" />
                                                    <asp:ListItem Text="100" Value="100" />
                                                </asp:DropDownList>
                                            </td>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblGridStatus" runat="server" Style="float: left;" Text="" Font-Size="X-Small" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnFirst" runat="server" Text="&lt;&lt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnFirst_Click" CssClass="navButton" Enabled="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnPrevious" runat="server" Text="&lt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnPrevious_Click" CssClass="navButton" Enabled="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtGoToPage" runat="server" Text="1" CssClass="navTextBox" AutoPostBack="True"
                                                OnTextChanged="txtGoToPage_TextChanged" MaxLength="5"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnNext" runat="server" Text="&gt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnNext_Click" CssClass="navButton"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnLast" runat="server" Text="&gt;&gt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnLast_Click" CssClass="navButton"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td align="right"></td>
                        </tr>
                    </table>
                </asp:View>
                <asp:View ID="vwPANUpdate" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td>
                                <table>
                                    <tr>
                                        <td style="width: 75px;">Name
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtViewExistingName" runat="server" CssClass="txtBPL" MaxLength="75"
                                                Width="180px"> </asp:TextBox>
                                        </td>
                                        <td style="width: 50px;">PAN
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtViewExistingPan" runat="server" CssClass="txtBPL" Width="180px"> </asp:TextBox>
                                        </td>                                        
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:CheckBox ID="chkPanNotinITD" Text="PAN Not in ITD" runat="server" Width="120px" />
                                        </td>
                                        <td>
                                            <asp:CheckBox ID="chkDefaultSelect" Text="Default Select" runat="server" Width="100px" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingLoad" runat="server" CssClass="cmnBtn" Text="Load"
                                                OnClick="btnViewExistingLoad_Click" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="5">
                                            <br />
                                            <span>
                                            <asp:Label ID="Label17" runat="server" BorderStyle="Solid" BorderWidth="2px" Height="10px"
                                                Width="20px" BackColor="#FFFFDD"></asp:Label>
                                            &nbsp;<b style="font-size:11.5px;">The case has been identified for prosecution. Please contact your jurisdictional TDS Assessing Officer for further details</b></span>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td id="rptrTD" runat="server">
                                <asp:Panel ID="viewExistingNavPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                                    Width="900px" BorderStyle="Solid" BorderWidth="1px" BorderColor="Gray">
                                    <asp:Repeater ID="rptrExistingNonEmployees" runat="server" OnItemDataBound="rptrExistingNonEmployees_ItemDataBound">
                                        <HeaderTemplate>
                                            <table id="NavTable" border="1">
                                                <tr bgcolor="#EEEEEE">
                                                    <th></th>
                                                    <th>
                                                        <asp:Label ID="Label12" Text="Serial No" runat="server" Width="60px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label13" Text="Name" runat="server" Width="250px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label14" Text="PAN" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblSection" Width="80px" Text="Section" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblAmountOfPayment" Width="150px" Text="Amount Of Payment" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label8" Text="Paid/Credited Date" runat="server" Width="130px"></asp:Label>
                                                    </th>
                                                    <th id="ModeHeader" runat="server" style="display:none;">
                                                        <asp:Label ID="Label16" runat="server" Text="Mode" />
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white" id="trded">
                                                <td id="tdchknonemp" runat="server">
                                                    <asp:CheckBox ID="chkExistingNonEmployeesSelect" runat="server" class="panCheckBox" />
                                                </td>
                                                <td id="tddedslno" runat="server">
                                                    <asp:Label ID="lblDeducteeSlNo" Text='<%# Eval("DeducteeSlNo")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdslno" runat="server">
                                                    <asp:Label ID="lblDedSlno" Text='<%# Eval("Name")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdpan" runat="server">
                                                    <asp:Label ID="lblDedPAN" Text='<%# Eval("PAN")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdpanref" runat="server" style="display:none">
                                                    <asp:Label ID="lblDedPANRef" Text='<%# Eval("PANREFERENCE")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdsection" runat="server">
                                                    <asp:Label ID="lblSection" Text='<%#Eval("Section") %>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdamtpay" runat="server" style="text-align: right">
                                                    <asp:Label ID="lblAmtPayment" Text=' <%#Eval("AmountOfPayment")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdpaiddate" runat="server" style="text-align: left">
                                                    <asp:Label ID="lblPaymentdate" Text=' <%# Eval("PaymentDate")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdMode" runat="server" style="text-align: center; display:none;">
                                                    <asp:Label ID="lblMode" Text='<%# Eval("Mode")%>' runat="server"></asp:Label>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px; margin-right: 149px; margin-bottom: -3px;"  align="right">
                                    <tr>
                                        <td style="padding: 0px 0px 0px 0px">
                                            <asp:Label ID="Label3" runat="server" Text="Records per page : " Font-Size="X-Small" />
                                        </td>
                                        <td style="width: 50px; padding-top: 2px;">
                                            <asp:DropDownList ID="cmbViewExistingGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                AutoPostBack="true" Font-Size="X-Small" OnSelectedIndexChanged="cmbViewExistingGoTo_SelectedIndexChanged">
                                                <asp:ListItem Text="5" Value="5" />
                                                <asp:ListItem Text="10" Value="10" Selected="True" />
                                                <asp:ListItem Text="15" Value="15" />
                                                <asp:ListItem Text="20" Value="20" />
                                                <asp:ListItem Text="25" Value="25" />
                                                <asp:ListItem Text="50" Value="50" />
                                                <asp:ListItem Text="75" Value="75" />
                                                <asp:ListItem Text="100" Value="100" />
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblViewExistingNonEmployeesStatus" runat="server" Style="float: left;"
                                                Text="Showing 0-0 of 0 [Page 0 of 0]" Font-Size="X-Small" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingFirst" runat="server" Text="&lt;&lt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                                                OnClick="btnViewExistingFirst_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingPrevious" runat="server" Text="&lt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                                                OnClick="btnViewExistingPrevious_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtViewExistingGoToPage" runat="server" Text="1" CssClass="navTextBox"
                                                AutoPostBack="True" MaxLength="5" OnTextChanged="txtViewExistingGoToPage_TextChanged"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingNext" runat="server" Text="&gt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" OnClick="btnViewExistingNext_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingLast" runat="server" Text="&gt;&gt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" OnClick="btnViewExistingLast_Click"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Panel ID="pnlAdd" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel">
                                    <asp:Label ID="lblSelectOption" runat="server" Text="Select Options:" Font-Bold="true" Font-Size="10px"></asp:Label>
                                    <table style="width: 100%; padding-right: 0px;">
                                        <tr>                                                                                        
                                             <td>
                                                <asp:Label ID="lblOption1" runat="server" Text="Option 1" Font-Bold="True"></asp:Label>
                                                <asp:FileUpload ID="fupTextFile" runat="server" CssClass="browsBtn" />                                               
                                                <asp:Button ID="btnViewExistingTextAddAll" runat="server" Text="Bulk Select"
                                                            CssClass="cmnBtn" OnClientClick="return FileValidation()" OnClick="btnViewExistingTextAddAll_Click" ToolTip="Choose text file with PAN records and click here." />
                                            </td>
                                             <td align="right">
                                                <asp:Label ID="lblOption2" runat="server" Text="Option 2:" Font-Bold="True"></asp:Label>
                                                <asp:Label ID="lblSelect" runat="server" Text="Select"></asp:Label>
                                                <asp:LinkButton ID="lnkbtnCheckAll" runat="server" Text="All" OnClientClick="SelectAll();"></asp:LinkButton>
                                                <asp:Label ID="lblCorrPipe" runat="server" Text="|"></asp:Label>
                                                <asp:LinkButton ID="lnkbtnUnCheckAll" runat="server" Text="None" OnClientClick="UnSelectAll();"></asp:LinkButton>
                                                <asp:Button ID="btnViewExistingAdd" runat="server" Text="Add" CssClass="cmnBtn" OnClientClick="return ValidateViewExisting();"
                                                    OnClick="btnViewExistingAdd_Click" />
                                            </td>
                                            <td visible ="false">
                                                 <asp:Label ID="lblOption3" runat="server" Text="Option 3" Font-Bold="True" Visible="false"></asp:Label>
                                                 <asp:TextBox ID="txtSerialNo_From" Width="48px" MaxLength="7" CssClass="txtBPL" runat="server"
                                                            onkeypress="return ValidateForOnlyNos(event);" Visible="false"></asp:TextBox>
                                                 <asp:Button ID="btnViewExistingAddAll" runat="server" Text="Add From Sl No" Width="125px"
                                                            CssClass="cmnBtn" OnClick="btnViewExistingAddAll_Click" Visible="false" />
                                            </td>
                                        </tr>
                                        <tr>
                                          
                                            <td align="right">
                                                                                             
                                            </td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                                    <table style="width: 100%; padding-right: 0px;">
                                        <tr align="right">
                                            <td align="right">
                                                <asp:Button ID="btnViewExistingClose" runat="server" Text="Close" CssClass="cmnBtn"
                                                            OnClick="btnViewExistingClose_Click" />
                                            </td>
                                        </tr>
                                    </table>                              
                            </td>
                        </tr>
                    </table>
                    <div id="pnlPopup1" class="PrProgress1" runat="server" style="display: none;">
                    <div id="innerPopup" class="PrContainer">
                        <div class="PrHeader">
                            Please wait...
                        </div>
                        <div class="PrBody">
                            <img width="220px" height="19px" src="../App_Themes/Standard/Images/activity.gif"
                                alt="loading..." />
                        </div>
                    </div>
                </div>
                </asp:View>
                <asp:View ID="vwBulkPanUpdate" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td>
                                <table width="100%">
                                    <tr>
                                        <td width="100px">
                                            <asp:Button ID="btnExport" runat="server" Text="Export" CssClass="cmnBtn" OnClientClick="Show_Popup_Export()"
                                                OnClick="btnPANExport_Click" />
                                        </td>
                                        <td width="100px" align="center">
                                            <asp:Button ID="btnImport" runat="server" Text="Import" CssClass="cmnBtn" />
                                        </td>
                                        <td width="100px">
                                            <asp:Button ID="btnBulkUpdate" runat="server" Text="Update" CssClass="cmnBtn" Visible="False" />
                                        </td>
                                        <td>
                                            <asp:HyperLink ID="hlnkOpenErrors" runat="server" Text="" Target="_blank" Visible="false"> </asp:HyperLink>
                                        </td>
                                        <td align="right">
                                            <asp:Button ID="btnBulkClose" runat="server" Text="Close" CssClass="cmnBtn" OnClick="btnBulkClose_Click" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">
                                            <asp:Label ID="lblExcelNote1" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 1: Avoid Cut options in any of the work Sheets." />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">
                                            <asp:Label ID="lblExcelNote2" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 2: While Pasting data from other excel File, use only Paste Special / Values Option." />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4">
                                            <asp:Label ID="lblExcelNote3" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 3: Before any operation make sure you are not in Excel Edit mode." />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </asp:View>
            </asp:MultiView>
        </ContentTemplate>
        <Triggers>
            <asp:PostBackTrigger ControlID="btnViewExistingTextAddAll" />
        </Triggers>
    </asp:UpdatePanel>
</asp:Content>
