<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Correction_Deduction, App_Web_deduction.aspx.4fd6750c" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style type="text/css">
        .modalBackground {
            background-color: Gray;
            filter: alpha(opacity=70);
            opacity: 0.7;
        }

        .modalPopup {
            background-color: #ffffdd;
            border-width: 5px;
            border-style: solid;
            border-color: Gray;
            padding: 10px;
            width: 260px;
        }

        .style1 {
            width: 107px;
        }

        .PrProgress1 {
            position: fixed; /* Fix the element relative to the viewport */
            top: 50%; /* Center vertically */
            left: 50%; /* Center horizontally */
            transform: translate(-50%, -50%); /* Adjust for the element's size */
            z-index: 1000; /* Ensure it appears above other elements */
            /*background: rgba(255, 255, 255, 0.9);*/ /* Optional: Semi-transparent background */
            /*border: 1px solid #ccc;*/ /* Optional: Add a border for visibility */
            padding: 20px; /* Optional: Add padding for spacing inside the loader */
            border-radius: 8px; /* Optional: Rounded corners */
            text-align: center; /* Center-align content inside the loader */
            /*box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);*/ /* Optional: Add shadow for a floating effect */
        }
    </style>
    <script type="text/javascript" language="javascript">
        function Show_Popup_Export() {
            if (document.getElementById("<%=ddlBlkUpdateType.ClientID%>").value > 0) {
                $find("popUpBulkExport_Control").show();
            }
        }

        function Show_Popup_Import() {
            $find("popUpBulkImport_Control").show();
        }

        function ValidatePANforTransporter(value) {
            var value = document.getElementById("<%=txtPAN.ClientID%>").value;
            if (value.trim().length > 0) {
                for (var i = 0; i < value.length; i++) {
                    if (value.charAt(i) == ' ') {
                        document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "Invalid";
                        return false;
                    }
                }
                for (var i = 0; i < 5; i++) {
                    if ((value.charAt(i) >= 'A' && value.charAt(i) <= 'Z') || (value.charAt(i) >= 'a' && value.charAt(i) <= 'z')) { ; }
                    else {
                        document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "Invalid";
                        return false;
                    }
                }
                for (var i = 5; i < 9; i++) {
                    if (value.charAt(i) >= '0' && value.charAt(i) <= '9') {
                        ;
                    }
                    else {
                        document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "Invalid";
                        return false;
                    }
                }
                if ((value.charAt(9) >= 'A' && value.charAt(9) <= 'Z') || (value.charAt(9) >= 'a' && value.charAt(9) <= 'z')) {
                    ;
                }
                else {
                    document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "Invalid";
                    return false;
                }
                if (value.charAt(3).toUpperCase() != 'P' && value.charAt(3).toUpperCase() != 'H' && value.charAt(3).toUpperCase() != 'C' && value.charAt(3).toUpperCase() != 'J' && value.charAt(3).toUpperCase() != 'F' && value.charAt(3).toUpperCase() != 'A' && value.charAt(3).toUpperCase() != 'T' && value.charAt(3).toUpperCase() != 'B' && value.charAt(3).toUpperCase() != 'L' && value.charAt(3).toUpperCase() != 'G') {
                    document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "Invalid";
                    return false;
                }
                document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "1";
                return true;
            }
        }
        function Validations() {
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2024 && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                var NatureOfRemittance = document.getElementById("<%=ddlNatureofRemittance.ClientID%>");
                var NonDedres = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
                if (Return(document.getElementById("<%=hdnSectionID.ClientID%>").value) == 17) {
                    if ((NonDedres.value == "26")) {
                        if (!(NatureOfRemittance.value == "27")) {
                            alert("Remark 'Lower Deduction/No Deduction under sub-section (1F) of section 197A',\nis applicable for Section 195 having 'Nature of Remittance' as 'Interest Payment'.");
                            return false;
                        }
                    }
                }
                else {
                    if ((NonDedres.value == "26")) {
                        alert("Remark 'Lower Deduction/No Deduction under sub-section (1F) of section 197A' is only applicable for Section 195.");
                        return false;
                    }
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2024 && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26") {
                var NonDedres = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
                if (Return(document.getElementById("<%=hdnSectionID.ClientID%>").value) == 9) {
                    if (NonDedres.value == "7") {
                        alert("Selected Remark is applicable from FY 2024-25 Q1 onwards.");
                        return false;
                    }
                }
            }
            var correctionStatus = document.getElementById("<%=hdnCorrStatus.ClientID%>").value;
            if (Return(correctionStatus) == 4) {
                alert("'Delete' Type of correction is no longer allowed.\n\nChoose 'Update' and set Amount of Payment, TDS Amount and Tax rate to Zero.");
                return false;
            }
            var deductionSectionID = document.getElementById("<%=hdnSectionID.ClientID%>").value;
            var challanSectionID = document.getElementById("<%=hdnChallanSectionID.ClientID%>").value;
            var nonDeductionReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
            if (formType == "Form26") {
                var taxRate = document.getElementById("<%=txtTaxRate.ClientID%>").value;
                if (document.getElementById("<%=txtTaxRate.ClientID%>").value != 20 && Return(nonDeductionReason.value) == 3) {
                    if (!confirm("Less than 20% PANNOTAVAILABLE \nAre you sure you want to continue?")) return false;
                }
            }
            if (!ValidateLength(document.getElementById("<%=txtName.ClientID%>"), "Deductee Name.", 75, true)) return false;
            if (!ValidateDeductee(document.getElementById("<%=hdnDeducteeSlNo.ClientID%>"))) return false;
            if (!ValidateLength(document.getElementById("<%=txtPAN.ClientID%>"), "PAN", 10, true)) return false;
            if (!ValidateDropDown(document.getElementById("<%=ddlSection.ClientID%>"), "Section.")) return false;

            var section = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;

            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2020 && Return(document.getElementById("<%=hdnSectionID.ClientID%>").value) == 16) {
                alert("Section '194J' is not applicable from FY 2020-21 and onwards.\nSelect '194J(a)' or '194J(b)' Section.");
                return false;
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                var ddlNonDeductionReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>")[document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex].text;
                if (ddlNonDeductionReason == "Remittance less than Rs.7 lakh - First proviso to Sec. 206C(1G)" ||
                    ddlNonDeductionReason == "TCS already collected by seller - Fourth proviso to Sec. 206C(1G)" ||
                    ddlNonDeductionReason == "TDS provisions applicable/ receipt from specified persons - Fifth proviso to Sec. 206C(1G)" ||
                    ddlNonDeductionReason == "TDS provisions applicable - Second proviso to Sec. 206C(1H)" ||
                    ddlNonDeductionReason == "Receipt from specified persons or as per notification issued - Explanation to Sec. 206C(1H)") {
                    var qtr = document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0;
                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2020) {
                        alert("Selected remarks is applicable from FY 2020-21 Quarter-3");
                        return false;
                    }
                    else if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020) {
                        if (qtr < 3) {
                            alert("Selected remarks is applicable from FY 2020-21 Quarter-3");
                            return false;
                        }
                    }
                }
                if (ddlNonDeductionReason == "TDS provisions applicable - Second proviso to Sec. 206C(1H)" &&
                    section.indexOf("6CR") == -1) {
                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020 && (qtr >= 3)) {
                        alert("Remark 'G' is applicable only for section 6CR from 1st October 2020.");
                        return false;
                    }
                    else if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2020) {
                        alert("Remark 'G' is applicable only for section 6CR from 1st October 2020.");
                        return false;
                    }
                }
                if (ddlNonDeductionReason == "TDS provisions applicable/ receipt from specified persons - Fifth proviso to Sec. 206C(1G)" &&
                    section.indexOf("6CO") == -1 && section.indexOf("6CP") == -1 && section.indexOf("6CQ") == -1) {
                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020 && (qtr >= 3)) {
                        alert("Remark 'F' is applicable  for sections '6CO', '6CP' and '6CQ' from 1st October 2020");
                        return false;
                    }
                    else if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2020) {
                        alert("Remark 'F' is applicable for sections '6CO', '6CP' and '6CQ' from 1st October 2020");
                        return false;
                    }
                }

                <%--if (ddlNonDeductionReason == "Remittance less than Rs.7 lakh - First proviso to Sec. 206C(1G)" && (section.indexOf("6CO") == 0 || section.indexOf("6CP") == 0)) {
                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020 && (qtr >= 3)) {
                        alert("Selected remarks is not applicable for section 6CO and 6CP from 1st October 2020");
                        return false;
                    }
                    else if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2020) {
                        alert("Selected remarks is not applicable for section 6CO and 6CP from 1st October 2020");
                        return false;
                    }
                }--%>
            }
            var section = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;
            var txtAmountOfPayment = document.getElementById("<%=txtAmountOfPayment.ClientID%>");
            var txtAmtCashDrawn = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            if (section.indexOf("194NF") != -1) {
                if ((Return(txtAmountOfPayment.value) != null) && (Return(txtAmountOfPayment.value) != "")) {
                    if ((Return(txtAmtCashDrawn.value) != null) && (Return(txtAmtCashDrawn.value) != "")) {
                        if (!ValidateLength(document.getElementById("<%=txtAmtCashDrawn.ClientID%>"), "Amount of Cash Withdrawal", 14, true)) return false;
                    }
                }
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E")
                    if (!ValidateLength(document.getElementById("<%=txtTotalValueOfPurchase.ClientID%>"), "Total Value of Pur.(s)", 14, true)) return false;
                if ((Return(txtAmountOfPayment.value) != null) && (Return(txtAmountOfPayment.value) != "")) {
                    if (Return(txtAmountOfPayment.value) <= 2000000) {
                        //if (!confirm("For Section '194NF', 'Aggregate Amount of Payment' cannot be less than or equal to 'Rs. 2000000'\n Do you want to continue ?")) {
                        //    return false;
                        //}
                    }
                }

            }
            else if ((Return(txtAmountOfPayment.value) != null) && (Return(txtAmountOfPayment.value) != "")) {
                if (section.indexOf("194N") != -1) {
                    if (Return(txtAmountOfPayment.value) <= 10000000) {
                        //alert("For Section '194N', 'Aggregate Amount of Payment' cannot be less than or equal to 'Rs. 10000000'");
                        //return false;
                    }
                }
            }

            var txtAmtCashDrawn = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            if (txtAmtCashDrawn != null) {
                if ((Return(txtAmtCashDrawn.value) != null) && (Return(txtAmtCashDrawn.value) != "")) {
                    if (section.indexOf("194N") != -1) {
                        if (!ValidateLength(document.getElementById("<%=txtAmtCashDrawn.ClientID%>"), "Amount of Cash Withdrawal", 14, true)) return false;
                    }
                }
            }

            var labelText = (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24" && document.getElementById("<%=hdnIsJK.ClientID%>").value == "1") ? "Amt. of Salary/Pension" : "Amount Of Payment.";
            if (Return(correctionStatus) == 5 || Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) > 0)
                if (!ValidateLength(document.getElementById("<%=txtAmountOfPayment.ClientID%>"), labelText, 14, true)) return false;
            if (!ValidateCreditedDate(document.getElementById("<%=txtCreditedDate.ClientID%>"), document.getElementById("<%=hdnFinYear.ClientID%>"))) return false;
            if (!ValidateRates(document.getElementById("<%=txtSurchargeRate.ClientID%>"), document.getElementById("<%=txtEduCessRate.ClientID%>"), document.getElementById("<%=txtTaxRate.ClientID%>"))) return false;
            if (!ValidateTaxDedDate()) return false;
            if (section.indexOf("194LD") != -1) {
                if (!ValidateSectionBasedOnDate()) return false;
            }
            if (section.indexOf("192A") != -1 || section.indexOf("194LBB") != -1) {
                var date = new Date(2015, 06, 01);
                var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                var date1 = paymentDate.value.split('/', 3);
                var creditedDate = new Date(date1[2], date1[1], date1[0]);
                if (creditedDate < date) {
                    alert("Section '" + ((section.indexOf("192A") != -1) ? "192A" : "194LBB") + "' is Applicable from '01/06/2015'.");
                    return false;
                }
            }

            if (section.indexOf("194N") != -1) {
                if (!Validate194NSectionBasedOnDate()) return false;
            }

            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2012 && section.indexOf("194LC") != -1 && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "3") {
                alert("The Deduction Remark 'Deduction at Higher Rate 20% - PANNOTAVBL' is not applicable for Section 194LC");
                return false;
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                if (!ValidateSectionandNonDedReason()) return false;
                if (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "6") {
                    if (!ValidatePaymentDateBasedOnSection()) return false;
                }
            }
            if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0 && (document.getElementById("<%=txtChallanID.ClientID%>").value == "" && Return(document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex) == 0)) {
                if ((section.indexOf("194BP") == 0) || (section.indexOf("194RP") == 0) || (section.indexOf("194SP") == 0)) {
                    alert("Specify the Remarks for Deduction.");
                    document.getElementById("<%=ddlNonDeductionReason.ClientID%>").focus();
                    return false;
                }
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26") {
                if (!ValidateNonDeductionReason(document.getElementById("<%=ddlSection.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=hdnFinYear.ClientID%>"))) return false;
                //if (!ValidateTaxAmountsForParticularSections(document.getElementById("<%=ddlSection.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=txtTaxRate.ClientID%>"), document.getElementById("<%=txtITRate.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=hdnFinYear.ClientID%>"))) return false;
                if (!ValidateTaxAmountsForParticularSections(document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=txtTaxRate.ClientID%>"), document.getElementById("<%=txtITRate.ClientID%>"), document.getElementById("<%=ddlSection.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=hdnFinYear.ClientID%>"))) return false;
                if (document.getElementById("<%=hdnFinYear.ClientID%>").value != "2009") {
                    if (!ValidateThreshold(document.getElementById("<%=ddlSection.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=txtTaxRate.ClientID%>"),
                        document.getElementById("<%=ddlNonDeductionReason.ClientID%>"))) return false;
                }
            }
            if (!ValidateChallanDetails(document.getElementById("<%=hdnFormType.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=txtChallanID.ClientID%>"), document.getElementById("<%=txtITRate.ClientID%>"), document.getElementById("<%=txtITAmount.ClientID%>"), document.getElementById("<%=hdnIsNilChallan.ClientID%>"))) return false;
            if (document.getElementById("<%=hdnFinYear.ClientID%>").value != "2009") {
                if (document.getElementById("<%=hdnIsTran.ClientID%>").value != "True") {
                    if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2012 && section.indexOf("194LC") == -1) {
                        if (!ValidateIfPANNotAvailable(document.getElementById("<%=txtTaxRate.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=hdnIsValidPAN.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"))) return false;
                    }
                }
            }
            var txtAmountOfPayment = document.getElementById("<%=txtAmountOfPayment.ClientID %>");
            var txtTaxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
            if (txtAmtCashDrawn != null) {
                if (section.indexOf("194N") != -1 || section.indexOf("194NF") != -1) {
                    //                if (!Validate194NSectionBasedOnDate()) return false;
                    if ((Return(txtAmtCashDrawn.value)) > (Return(txtAmountOfPayment.value))) {
                        alert("Amount of Cash Withdrawal should be less than or equal to Amount of Payment")
                        return false;
                    }
                    if ((Return(txtTaxDeducted.value)) > (Return(txtAmtCashDrawn.value))) {
                        var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                        alert((formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount should be less than or equal to Amount of Cash Withdrawal")
                        return false;
                    }
                }
            }
            else {
                if ((Return(txtTaxDeducted.value)) > (Return(txtAmountOfPayment.value))) {
                    var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                    alert((formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount should be less than or equal to " + ((formTypeNew == "Form24" && document.getElementById("<%=hdnIsJK.ClientID%>").value == "1") ? "Amt.of Salary / Pension" : "Amount of Payment"));
                    return false;
                }
            }
            if (section.indexOf("194NF") != -1) {
                if (!ValidateNonDedReasonfor194NF(document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"))) return false;
            }
            else if (section.indexOf("194N") != -1) {
                //                if (!Validate194NSectionBasedOnDate()) return false;
                //                if ((Return(txtAmtCashDrawn.value)) > (Return(txtAmountOfPayment.value))) {
                //                    alert("Amount of Cash Withdrawal should be less than or equal to Amount of Payment")
                //                    return false;
                //                }
                if (!ValidateNonDedReasonfor194N(document.getElementById("<%=ddlNonDeductionReason.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"))) return false;
            }
            if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value == 1 && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == 3) {
                if (!confirm("Remark 'PAN Not Available-Higher Rate(20%)' Required only if 'PAN is Invalid'"))
                    return false;
            }
            if (Return(finYear) > 2012) {
                if (formType == "Form24" || formType == "Form27") {
                    if (Return(nonDeductionReason.value) == 1 || Return(nonDeductionReason.value) == 2 ||
                        Return(nonDeductionReason.value) == 65 || Return(nonDeductionReason.value) == 66) {
                        if (document.getElementById("<%=txtCertNo.ClientID%>").value.trim() == "") {
                            if (Return(finYear) < 2026) { alert("Specify 'U/s 197 Cert.No.'."); }
                            else { alert("Specify 'U/s 395 Cert.No.'."); }
                            document.getElementById("<%=txtCertNo.ClientID%>").focus();
                            return false;
                        }
                        else {
                            if (Return(finYear) < 2026) {
                                if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                    return false;
                            }
                            else {
                                var certInput = document.getElementById("<%=txtCertNo.ClientID%>");
                                if (certInput) {
                                    var value = certInput.value.trim();

                                    if (value === "") {
                                        alert("Specify U/s 395 Cert.No.");
                                        return false;
                                    } else if (!(/^[A-Za-z0-9]{10}$/.test(value) || /^[A-Za-z0-9]{15}$/.test(value))) {
                                        alert("Certificate number must be either 10 or 15 alphanumeric characters.");
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
                else if (Return(nonDeductionReason.value) == 1 || Return(nonDeductionReason.value) == 2 ||
                    Return(nonDeductionReason.value) == 65 || Return(nonDeductionReason.value) == 66) {
                    if (formType == "Form27E" && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "1" && document.getElementById("<%=txtCertNo.ClientID%>").value.trim() == "") {
                        alert("Specify 'U/s 197 Cert.No.'.");
                        document.getElementById("<%=txtCertNo.ClientID%>").focus();
                            return false;
                        }
                        else {
                            if (Return(finYear) < 2026) {
                                if (Return(nonDeductionReason.value) == 2) {
                                    if ((Return(document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0) > 2 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2015) || Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2015) {
                                        if (document.getElementById("<%=txtCertNo.ClientID%>").value.trim() != "") {
                                            var pattern = /^[gGhH]{1}[0-9]{14}$/;
                                            var val = document.getElementById("<%=txtCertNo.ClientID%>").value;
                                            var matchArray = val.match(pattern);
                                            if (matchArray == null) {
                                                if (document.getElementById("<%=hdnFormType.ClientID%>").value != "Form27E") {
                                                    alert("Specify valid 15G/15H UIN.\nEx: G123456789/H123456789");
                                                    document.getElementById("<%=txtCertNo.ClientID%>").focus();
                                                    return false;
                                                }
                                                else {
                                                    if (Return(finYear) < 2026) {
                                                        if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                                            return false;
                                                    }
                                                    else {
                                                        if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 15, true))
                                                            return false;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else {
                                    if (Return(finYear) < 2026) {
                                        if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                            return false;
                                    }
                                    else {
                                        if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 15, true))
                                            return false;
                                    }
                                }
                            }
                            if (Return(finYear) >= 2026) {
                                if (Return(nonDeductionReason.value) == 66) {
                                    if ((Return(document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0) > 2 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2015) || Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2015) {
                                        if (document.getElementById("<%=txtCertNo.ClientID%>").value.trim() != "") {
                                            var pattern = /^[gGhH]{1}[0-9]{9}$/;
                                            var val = document.getElementById("<%=txtCertNo.ClientID%>").value;
                                            var matchArray = val.match(pattern);
                                            if (matchArray == null) {
                                                if (document.getElementById("<%=hdnFormType.ClientID%>").value != "Form27E") {
                                                <%--alert("Specify valid 121 UIN.\nEx: G123456789/H123456789");
                                                document.getElementById("<%=txtCertNo.ClientID%>").focus();
                                                return false;--%>
                                                    if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 10, true))
                                                        return false;
                                                }
                                                else {
                                                    if (Return(finYear) < 2026) {
                                                        if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                                            return false;
                                                    }
                                                    else {
                                                        if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 395 Cert.No.", 10, true))
                                                            return false;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                else {
                                    if (Return(finYear) < 2026) {
                                        if (!ValidateCertificateNumber(document.getElementById("<%=txtCertNo.ClientID%>"), "U/s 197 Cert.No.", 10, true))
                                            return false;
                                    }
                                    else {
                                        var certInput = document.getElementById("<%=txtCertNo.ClientID%>");
                                    if (certInput) {
                                        var value = certInput.value.trim();

                                        if (value === "") {
                                            alert("Specify U/s 395 Cert.No.");
                                            return false;
                                        } else if (!(/^[A-Za-z0-9]{10}$/.test(value) || /^[A-Za-z0-9]{15}$/.test(value))) {
                                            alert("Certificate number must be either 10 or 15 alphanumeric characters.");
                                            return false;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }



            if (document.getElementById("<%=PnlResidentDetails.ClientID%>") != null) {
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2016
                    && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                    if (document.getElementById("<%=ddlDedNonRes.ClientID%>").selectedIndex == 0) {
                        alert("Specify whether Deductee is Non-Resident.");
                        return false;
                    }
                    else if (document.getElementById("<%=ddlDedNonRes.ClientID%>").selectedIndex == 1) {
                        if (document.getElementById("<%=ddlDedPerEstaIndia.ClientID%>").selectedIndex == 0) {
                            alert("Specify whether Deductee is having Permanent Establishment in India.");
                            return false;
                        }
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                if (!ValidateAckNo(document.getElementById("<%=txtAckNo.ClientID%>"), "15CA Ack. No.", 15, 12, false)) return false;
                if (document.getElementById("<%=ddlRateType.ClientID%>").selectedIndex == 0) {
                    if (Return(finYear) >= 2026) {
                        alert("Select TDS Rate as per.");
                        return false;
                    }
                }
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                    if (document.getElementById("<%=ddlNatureofRemittance.ClientID%>").selectedIndex == 0) {
                        alert("Select Nature of Remittance.");
                        return false;
                    }
                }
                if (document.getElementById("<%=ddlCountries.ClientID%>").selectedIndex == 0 && document.getElementById("<%=hdnCorrStatus.ClientID%>").value != "4") {
                    alert("Select Country of Residence.");
                    return false;
                }
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" && document.getElementById("<%=hdnFinYear.ClientID%>").value != "2009") {
                if (!ValidateIfTransporter(document.getElementById("<%=ddlSection.ClientID%>"), document.getElementById("<%=txtTaxRate.ClientID%>"), document.getElementById("<%=txtTaxDeducted.ClientID%>"), document.getElementById("<%=hdnIsTran.ClientID%>"), document.getElementById("<%=hdnIsValidPAN.ClientID%>"), document.getElementById("<%=ddlNonDeductionReason.ClientID%>"))) return false;
            }
            else {
                if ((document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") && (document.getElementById("<%=hdnCorrStatus.ClientID%>").value != "4") && Return(finYear) <= 2025) {
                    if ((document.getElementById("<%=hdnDeductorStatus.ClientID%>").value == 2) && (document.getElementById("<%=hdnSectionID.ClientID%>").value == 1)) {
                        return confirm("If you are making entry for payment relating to Govt Employee pension\n Click OK else Cancel");
                    }
                    if ((section.indexOf("94P") == -1)) {
                        if (document.getElementById("<%=hdnSectionID.ClientID%>").value != document.getElementById("<%=hdnDeductorStatus.ClientID%>").value) {
                            return confirm("Given Section is not valid for selected Deductor Type.\nAre you sure you want to continue?");
                        }
                    }
                }
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                var amt = document.getElementById("<%=txtAmountOfPayment.ClientID%>").value;
                if (amt > 999999999) {
                    alert("Amount of Payment should be less than 100 Crores.")
                    document.getElementById("<%=txtAmountOfPayment.ClientID%>").focus();
                    return false;
                }
            }

            var qtr = document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0;
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" && Return(finYear) >= 2021 &&
                Return(finYear) < 2026 && document.getElementById("<%=hdnSectionID.ClientID%>").value != "21" && document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1") {
                if (Return(finYear) >= 2016 && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                    if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1" && (Return(document.getElementById("<%=txtITRate.ClientID%>").value) < 20) && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "3"
                        && (document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "27" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "49" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "21"
                            || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "52" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "31"
                        || (((Return(finYear) == 2020 && qtr >= 3) || Return(finYear) > 2020)
                            && document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "16")) ||
                        (Return(finYear) >= 2023)
                        && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "3"
                    && (Return(document.getElementById("<%=txtITRate.ClientID%>").value) < 20)
                    && (document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "66"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "67"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "68"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "69"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "70")) {
                        if (document.getElementById("<%=txtEmailDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Email is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Contact Number is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtAddressDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Address is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtIdentNumDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Identification Number is mandatory.")
                            return false;
                        }
                    }
                    else {
                        if (document.getElementById("<%=txtEmailDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Email should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Contact Number should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtAddressDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Address should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtIdentNumDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Identification Number should not be given.")
                            return false;
                        }
                    }

                    var contactNo = document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim();

                    if (contactNo !== "") {
                        // Check if starts with 0 OR all characters are 0
                        if (contactNo.startsWith("0") || /^0+$/.test(contactNo)) {
                            alert("Deductee Contact Number should not start with 0 or be all zeros.");
                            return false;
                        }
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" && document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1" && (Return(finYear) >= 2026)) {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                    if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1" && (Return(document.getElementById("<%=txtITRate.ClientID%>").value) < 20) && document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "67"
                        && (document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "205" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "206" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "207" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "210"
                            || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "211" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "212"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "213" || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "216"
                        || document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value == "217")) {
                        if (document.getElementById("<%=txtEmailDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Email is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Contact Number is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtAddressDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Address is mandatory.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtIdentNumDed.ClientID%>").value.trim() == "") {
                            alert("For Invalid PAN with NonDeduction Remark \"C\", Deductee Identification Number is mandatory.")
                            return false;
                        }
                    }
                    else {
                        if (document.getElementById("<%=txtEmailDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Email should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Contact Number should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtAddressDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Address should not be given.")
                            return false;
                        }
                        else if (document.getElementById("<%=txtIdentNumDed.ClientID%>").value.trim() != "") {
                            alert("Deductee Identification Number should not be given.")
                            return false;
                        }
                    }
                    var contactNo = document.getElementById("<%=txtContactNoDed.ClientID%>").value.trim();

                    if (contactNo !== "") {
                        // Check if starts with 0 OR all characters are 0
                        if (contactNo.startsWith("0") || /^0+$/.test(contactNo)) {
                            alert("Deductee Contact Number should not start with 0 or be all zeros.");
                            return false;
                        }
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" && section.indexOf("196D(1A)") != -1 &&
                ((document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "28") || document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "29")) {
                var date = new Date(2020, 10, 01);
                var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                var date1 = paymentDate.value.split('/', 3);
                var creditedDate = new Date(date1[2], date1[1], date1[0]);
                if (creditedDate <= date) {
                    alert("Selected 'Remarks for Deduction' is Applicable from '01/11/2020'.");
                    return false;
                }
            }
            if ((document.getElementById("<%=ddlNonDeductionReason.ClientID%>").value == "7") && section.indexOf("194A") != -1) {
                var date = new Date(2021, 09, 17);
                var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                var date1 = paymentDate.value.split('/', 3);
                var creditedDate = new Date(date1[2], date1[1], date1[0]);
                if (creditedDate < date) {
                    alert("Remark 'NO DEDUCTION U/S 197A(1F)', for 194A\napplicable from '17/09/2021'.");
                    return false;
                }
            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) >= 2021 && document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                var NatureOfRemittance = document.getElementById("<%=ddlNatureofRemittance.ClientID%>");
                var NonDedres = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
                if (document.getElementById("<%=hdnSectionID.ClientID%>").value == 21) {
                    if (!(NatureOfRemittance.value == "16" || NatureOfRemittance.value == "27")) {
                        alert("Selected Nature of Remittance is not applicable for Section 196D.");
                        return false;
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                if (!ValidateSectionandNonDedReason()) return false;
            }
            if (document.getElementById("<%=hdnIsEreturnAccNo.ClientID%>").value == "1") {
                if (section.indexOf("194A") != -1 || section.indexOf("195") != -1) {
                    if (document.getElementById("<%=txtAccountNumber.ClientID%>").value.length < 10) {
                        alert("Account Number Should be of minimum 10 Digits.");
                        document.getElementById("<%=txtAccountNumber.ClientID%>").focus();
                        return false;
                    }
                }
                else if (!(section.indexOf("194A") != -1 || section.indexOf("195") != -1)) {
                    if (document.getElementById("<%=txtAccountNumber.ClientID%>").value.length > 0) {
                        alert("Account Number is allowed for 194A and 195 sections.");
                        document.getElementById("<%=txtAccountNumber.ClientID%>").focus();
                        return false;
                    }
                }
            }


            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26") {

                var quarter = document.getElementById("<%=hdnQuarter.ClientID%>").value;
                var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
                var minQuarterDate, maxQuarterDate;
                var currentDate = new Date();
                if (section.indexOf("194BP") != -1 || section.indexOf("194RP") != -1 || section.indexOf("194SP") != -1 || section.indexOf("194BAP") != -1) {
                    var SelectedChallanNumber = document.getElementById("<%=txtChallanID.ClientID%>");
                    if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0) {
                        if (Return(finYear) <= 2025) {
                            alert("For Deduction related to 194BP, 194RP, 194BAP or 194SP\nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                            return false;
                        }
                        else {
                            alert("For Deduction related to 1059, 1034, 1061 or 1038\nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                            return false;
                        }
                    }
                    if (SelectedChallanNumber.value == "") {
                        if (Return(finYear) <= 2025) {
                            alert("For '" + (
                                (section.indexOf("194BP") != -1) ? "194BP" :
                                    (section.indexOf("194BAP") != -1) ? "194BAP" :
                                        (section.indexOf("194RP") != -1) ? "194RP" : "194SP"
                            ) + "', Challan should be linked.");
                        }
                        else {
                            alert("For '" + (
                                (section.indexOf("194BP") != -1) ? "1059" :
                                    (section.indexOf("194BAP") != -1) ? "1061" :
                                        (section.indexOf("194RP") != -1) ? "1034" : "1038"
                            ) + "', Challan should be linked.");
                        }
                        return false;
                    }
                    else {
                        txtTaxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
                        txtChallanDate = document.getElementById("<%=hdnChallanDate.ClientID%>");
                        txtCreditedDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                        var date1 = txtChallanDate.value;
                        var date2 = txtCreditedDate.value;
                        if (date1.toString().indexOf("-") != -1) {
                            date1 = date1.split('-', 3);
                        }
                        else {
                            date1 = date1.split('/', 3);
                        }
                        if (date2.toString().indexOf("-") != -1) {
                            date2 = date2.split('-', 3);
                        }
                        else {
                            date2 = date2.split('/', 3);
                        }
                        var challanDate = new Date(date1[2], parseInt(date1[1]) - 1, date1[0]);
                        var creditedDate = new Date(date2[2], parseInt(date2[1]) - 1, date2[0]);
                        if (quarter == "Quarter1") {
                            minQuarterDate = new Date(finYear, 03, 01);
                            maxQuarterDate = new Date(finYear, 05, 30);
                        }
                        else if (quarter == "Quarter2") {
                            minQuarterDate = new Date(finYear, 06, 01);
                            maxQuarterDate = new Date(finYear, 08, 30);
                        }
                        else if (quarter == "Quarter3") {
                            minQuarterDate = new Date(finYear, 09, 01);
                            maxQuarterDate = new Date(finYear, 11, 31);
                        }
                        else if (quarter == "Quarter4") {
                            minQuarterDate = new Date(eval(finYear) + 1, 00, 01);
                            maxQuarterDate = new Date(eval(finYear) + 1, 02, 31);
                        }
                        if (challanDate < minQuarterDate) {
                            alert("Challan Date cannot be before Current Quarter.");
                            return false;
                        }
                        if (challanDate > maxQuarterDate) {
                            alert("Challan Date cannot be after Current Quarter.");
                            return false;
                        }
                        if (challanDate > currentDate) {
                            alert("Challan Date cannot be future date.");
                            return false;
                        }
                        if (challanDate > creditedDate) {
                            alert("For '" + ((section.indexOf("194BP") != -1) ? "194BP" : (section.indexOf("194BAP") != -1) ? "194BAP" : ((section.indexOf("194RP") != -1) ? "194RP" : "194SP"))
                                + "', Challan being linked should be paid\nOn or Before 'Paid/Credited Date'.");
                            return false;
                        }
                        if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0) {
                            if (Return(finYear) <= 2025) {
                                alert("For Deduction related to 194BP, 194RP, 194BAP or 194SP\nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                                return false;
                            }
                            else {
                                alert("For Deduction related to 1059, 1034, 1061 or 1038\nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                                return false;
                            }
                        }
                        if ((document.getElementById("<%=hdnIsValidPAN.ClientID%>").value) == "0") {
                            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2025) {
                                alert("For Deduction related to 194BP, 194RP, 194BAP or 194SP\nInvalid PAN challan cannot be link.");
                                return false;
                            }
                            else {
                                alert("For Deduction related to 1059, 1034, 1061 or 1038\nInvalid PAN challan cannot be link.");
                                return false;
                            }
                        }
                    }
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                var quarter = document.getElementById("<%=hdnQuarter.ClientID%>").value;
                var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
                var minQuarterDate, maxQuarterDate;
                var currentDate = new Date();
                if (section.indexOf("194BP") != -1 || section.indexOf("194BAP") != -1) {
                    var SelectedChallanNumber = document.getElementById("<%=txtChallanID.ClientID%>");
                    if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0) {
                        alert("For Deduction related to 194BP or 194BAP\nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                        return false;
                    }
                    if (SelectedChallanNumber.value == "") {
                        alert("For '" + ((section.indexOf("194BP") != -1) ? "194BP" : "194BAP")
                            + "', Challan should be linked.");
                        return false;
                    }
                    else {
                        txtTaxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
                        txtChallanDate = document.getElementById("<%=hdnChallanDate.ClientID%>");
                        txtCreditedDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
                        var date1 = txtChallanDate.value;
                        var date2 = txtCreditedDate.value;
                        if (date1.toString().indexOf("-") != -1) {
                            date1 = date1.split('-', 3);
                        }
                        else {
                            date1 = date1.split('/', 3);
                        }
                        if (date2.toString().indexOf("-") != -1) {
                            date2 = date2.split('-', 3);
                        }
                        else {
                            date2 = date2.split('/', 3);
                        }
                        var challanDate = new Date(date1[2], parseInt(date1[1]) - 1, date1[0]);
                        var creditedDate = new Date(date2[2], parseInt(date2[1]) - 1, date2[0]);
                        if (quarter == "Quarter1") {
                            minQuarterDate = new Date(finYear, 03, 01);
                            maxQuarterDate = new Date(finYear, 05, 30);
                        }
                        else if (quarter == "Quarter2") {
                            minQuarterDate = new Date(finYear, 06, 01);
                            maxQuarterDate = new Date(finYear, 08, 30);
                        }
                        else if (quarter == "Quarter3") {
                            minQuarterDate = new Date(finYear, 09, 01);
                            maxQuarterDate = new Date(finYear, 11, 31);
                        }
                        else if (quarter == "Quarter4") {
                            minQuarterDate = new Date(eval(finYear) + 1, 00, 01);
                            maxQuarterDate = new Date(eval(finYear) + 1, 02, 31);
                        }
                        if (challanDate < minQuarterDate) {
                            alert("Challan Date cannot be before Current Quarter.");
                            return false;
                        }
                        if (challanDate > maxQuarterDate) {
                            alert("Challan Date cannot be after Current Quarter.");
                            return false;
                        }
                        if (challanDate > currentDate) {
                            alert("Challan Date cannot be future date.");
                            return false;
                        }
                        if (challanDate > creditedDate) {
                            alert("For '" + ((section.indexOf("194BP") != -1) ? "194BP" : "194BAP")
                                + "', Challan being linked should be paid\nOn or Before 'Paid/Credited Date'.");
                            return false;
                        }
                        if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0) {
                            alert("For Deduction related to 194BP or 194BAP\nProvide Tax Rate and Deduction Amount\nto ensure Challan used for linking is not short-paid.");
                            return false;
                        }
                        if ((document.getElementById("<%=hdnIsValidPAN.ClientID%>").value) == "0") {
                            alert("For Deduction related to 194BP or 194BAP \nInvalid PAN challan cannot be link.");
                            return false;
                        }
                    }
                }

                var remittance = document.getElementById("<%=ddlNatureofRemittance.ClientID%>").value;
                var quarterr = document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0;

                if (finYear >= 2024) {
                    if (remittance == "71" && quarterr < 2 && finYear == 2024) {
                        alert("'LTCG ARISING FROM TRANSFER OF UNITS REFERRED TO IN SECTION 115AB' applicable from FY 2024-25 Quarter-2 and onwards.");
                        return false;
                    }
                    else if (remittance == "71" && section.indexOf("196B") == -1) {
                        alert("'LTCG ARISING FROM TRANSFER OF UNITS REFERRED TO IN SECTION 115AB' is applicable for Section 196B.");
                        return false;
                    }

                    if (remittance == "72" && quarterr < 2 && finYear == 2024) {
                        alert("'LTCG ARISING FROM TRANSFER OF SUCH BOND OR GLOBAL DEPOSITORY RECEIPTS REFERRED TO IN SECTION 115AC' is applicable from FY 2024-25 Quarter-2 and onwards.");
                        return false;
                    }
                    else if (remittance == "72" && section.indexOf("196C") == -1) {
                        alert("'LTCG ARISING FROM TRANSFER OF SUCH BOND OR GLOBAL DEPOSITORY RECEIPTS REFERRED TO IN SECTION 115AC' is applicable for Section 196C");
                        return false;
                    }
                }
                else if (finYear < 2024 && remittance == "71") {
                    alert("'LTCG ARISING FROM TRANSFER OF UNITS REFERRED TO IN SECTION 115AB' is applicable from FY 2024-25 Quarter-2 and onwards.");
                    return false;
                }
                else if (finYear < 2024 && remittance == "72") {
                    alert("'LTCG ARISING FROM TRANSFER OF SUCH BOND OR GLOBAL DEPOSITORY RECEIPTS REFERRED TO IN SECTION 115AC' is applicable from FY 2024-25 Quarter-2 and onwards.");
                    return false;
                }
            }

            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                var theDropDown = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
                if (theDropDown.value == 13 || theDropDown.value == 14 || theDropDown.value == 70) {
                    if (document.getElementById("<%=ddl27EQLiableOption.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "") {
                            alert("Challan Serial Number cannot be blank.");
                            document.getElementById("<%=txt27EQChallanNo.ClientID%>").focus();
                            return false;
                        }
                        if (document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "0"
                            || document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "00"
                            || document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "000"
                            || document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "0000"
                            || document.getElementById("<%=txt27EQChallanNo.ClientID%>").value == "00000"
                        ) {
                            alert("Please enter valid Challan Serial Number.");
                            document.getElementById("<%=txt27EQChallanNo.ClientID%>").focus();
                            return false;
                        }
                        if (document.getElementById("<%=txt27EQChallanNo.ClientID%>").value.length != 5) {
                            alert("Challan Serial Number Should be of 5 Digits.");
                            document.getElementById("<%=txt27EQChallanNo.ClientID%>").focus();
                            return false;
                        }
                        if (document.getElementById("<%=txt27EQPaidDate.ClientID%>").value == "") {
                            alert("Challan Paid Date cannot be blank.");
                            document.getElementById("<%=txt27EQPaidDate.ClientID%>").focus();
                            return false;
                        }
                        var currentDate = new Date();
                        var date = new Date(2019, 04, 01);
                        var date1 = document.getElementById("<%=txt27EQPaidDate.ClientID%>").value.split('/', 3);
                        var challanPaidDate = new Date(date1[2], date1[1], date1[0]);
                        var challanPaidDate1 = new Date(date1[2], parseInt(date1[1]) - 1, date1[0]);
                        if (challanPaidDate < date) {
                            alert("Challan Paid date is applicable from 01/04/2019");
                            document.getElementById("<%=txt27EQPaidDate.ClientID%>").focus();
                            return false;
                        }
                        else if (challanPaidDate1 > currentDate) {
                            alert("Challan Paid date should not be future date.");
                            document.getElementById("<%=txt27EQPaidDate.ClientID%>").focus();
                            return false;
                        }
                    }
                    else {
                        if (document.getElementById("<%=txt27EQChallanNo.ClientID%>").value != "") {
                            alert("'Payment by Collectee liable to TDS' option is set to 'No' \nHence Challan Serial Number is not allowed to enter.");
                            document.getElementById("<%=txt27EQChallanNo.ClientID%>").focus();
                            return false;
                        }
                        if (document.getElementById("<%=txt27EQPaidDate.ClientID%>").value != "") {
                            alert("'Payment by Collectee liable to TDS' option is set to 'No' \nHence Challan Paid Date is not allowed to enter.");
                            document.getElementById("<%=txt27EQPaidDate.ClientID%>").focus();
                            return false;
                        }
                    }
                }
            }
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2022) {
                if (formType == "Form27" || formType == "Form27E") {
                    if (document.getElementById("<%=cmbDeducteeCode.ClientID%>").selectedIndex == 0) {
                        if (document.getElementById("<%=hdnFinYear.ClientID%>").value < "2026") {
                            alert("Select code for 27/27E");
                        }
                        else {
                            alert("Select code for 144/143");
                        }
                        document.getElementById("<%=cmbDeducteeCode.ClientID%>").focus();
                        return false;
                    }

                }
            }

            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2022) {
                var pan = document.getElementById("<%=txtPAN.ClientID%>").value.toUpperCase();
                var code = document.getElementById("<%=cmbDeducteeCode.ClientID%>").selectedIndex;
                if (formType == "Form27" || formType == "Form27E") {
                    //if ((pan == "PANAPPLIED" || pan == "PANINVALID" || pan == "PANNOTAVBL") && code != 10) {
                    //    alert("Code for 27/27E only '10-Others' is allowed\n" +
                    //        "for PANAPPLIED, PANINVALID and PANNOTAVBL case.");
                    //    return false;
                    //}
                    if (!(pan == "PANAPPLIED" || pan == "PANINVALID" || pan == "PANNOTAVBL")) {
                        if (!Validate115bacDeducteeCode()) return false;
                    }
                }
                return true;
            }
        }
        function ValidatePaymentDateBasedOnSection() {
            var date = new Date(2012, 07, 01);
            var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            var date1 = paymentDate.value.split('/', 3);
            var creditedDate = new Date(date1[2], date1[1], date1[0]);
            if (creditedDate > date) {
                alert("Remarks 'Software Vendor Transaction' is Applicable from '01/07/2012'.");
                return false;
            }
            return true;
        }
        function ValidateSectionBasedOnDate() {
            var date = new Date(2013, 06, 01);
            var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            var date1 = paymentDate.value.split('/', 3);
            var creditedDate = new Date(date1[2], date1[1], date1[0]);
            if (creditedDate < date) {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert("Section '194LD' is Applicable from '01/06/2013' to '31/05/2015'.\nSpecify the correct date in " + (formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited") + " Date");
                return false;
            }
            return true;
        }
        function ValidateSectionandNonDedReason() {
            var nonDedReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
            var section = document.getElementById("<%=ddlSection.ClientID%>");
            var sections = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;
            var formType = document.getElementById("<%=hdnFormType.ClientID%>");

            if (formType.value == "Form24") {
                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2020) {
                    if (nonDedReason.value != "3" && section.value == "74" && document.getElementById("<%=hdnIsValidPAN.ClientID%>").value == 0) {
                        alert("Deduction Remarks 'PAN Not available - Higher Rate (20%)' is Only allowed for Section 194P.");
                        return false;
                    }
                }
            }
            else if (formType.value == "Form26") {
                if (nonDedReason.value == "6" && (!(section.value == "16" || section.value == "73"))) {
                    alert("Deduction Remarks 'Software Vendor Transaction' is applicable for Section 194J(a)/194J(b)/195/194Q Only.");
                    return false;
                }
                if (nonDedReason.value == "8" && section.value != "5") {
                    alert("Deduction Remarks 'Deduction on Interest Income for Senior Citizens' is applicable for Section 194A Only.");
                    return false;
                }
            }
            else if (formType.value == "Form27") {
                if (nonDedReason.value == "6" && section.value != "17") {
                    alert("Deduction Remarks 'Software Vendor Transaction' is applicable for Section 194J/195 Only.");
                    return false;
                }
            }
    //            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) <= 2020) {
            //                if ((!(nonDedReason.value == "28" || nonDedReason.value == "29")) && ((!(sections.indexOf("196D(1A)") != -1)))) {
            //                    alert("Selected Deduction Remarks is not applicable for Section 196D(1A).");
            //                    return false;
            //                }
            //            }
            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2020) {
                if (nonDedReason.value == "29" && section.value == "21") {
                    alert("Deduction Remarks 'No Deduction on Income under Capital gains payable to FII (Sec.196D(2))' is applicable for Section 196D from 01-04-2021.");
                    return false;
                }
            }
            return true;
        }
        function ValidateDeductee(deducteeSlNo) {
            if (deducteeSlNo.value == "-1") {
                alert("Specify valid Deductee Name.");
                document.getElementById("<%=txtName.ClientID%>").focus();
                return false;
            }
            return true;
        }
        function ValidateThreshold(section, taxRate, taxAmount, nonDedReason) {
            if (section.value != "12" && Return(taxAmount.value) != 0 && nonDedReason.value == "5") {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert("Since 'Amount " + (formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited") + " is Under Threshold'\nTax Rate & Tax Amount should be Nil.");
                document.getElementById("<%=txtITRate.ClientID%>").focus();
                return false;
            }
            else return true;
        }
        function ValidateCreditedDate(creditedDate, finYear) {
            var minDate = new Date(finYear.value, 03, 01);
            if (creditedDate.value == "") {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert("Specify " + (formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited") + " Date.");
                creditedDate.focus();
                return false;
            }
            else {
                var quarterNo = document.getElementById("<%=hdnQuarter.ClientID%>").value;
                var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
                var creditedDateDay = parseInt(creditedDate.value.substring(0, 2), 10);
                var creditedDateMonth = parseInt(creditedDate.value.substring(3, 5), 10);
                var creditedDateYear = parseInt(creditedDate.value.substring(6, 10), 10);
                var paidDate = new Date(creditedDateYear, creditedDateMonth - 1, creditedDateDay);
                var currentDate = new Date();
                var minDate = new Date(finYear, 03, 01);
                if (quarterNo == "Quarter1") {
                    minQuarterDate = new Date(finYear, 03, 01);
                    maxQuarterDate = new Date(finYear, 05, 30);
                }
                else if (quarterNo == "Quarter2") {
                    minQuarterDate = new Date(finYear, 06, 01);
                    maxQuarterDate = new Date(finYear, 08, 30);
                }
                else if (quarterNo == "Quarter3") {
                    minQuarterDate = new Date(finYear, 09, 01);
                    maxQuarterDate = new Date(finYear, 11, 31);
                }
                else if (quarterNo == "Quarter4") {
                    minQuarterDate = new Date(eval(finYear) + 1, 00, 01);
                    maxQuarterDate = new Date(eval(finYear) + 1, 02, 31);
                }

                if (paidDate > maxQuarterDate || paidDate < minDate) {
                    var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                    //alert((formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited") + " Date should be within the Financial Year and before the End Date of Quarter.");
                    alert(
                        (formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited") +
                        " Date should be within the " +
                        ((finYear <= 2025) ? "Financial" : "Tax") +
                        " Year and before the End Date of Quarter."
                    );
                    return false;
                }
            }
            return true;
        }
        function ValidateRates(eduCessRate, surRate, taxDedRate) {
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                if (eval(taxDedRate.value) > 99.999) {
                    alert("Total Tax Rate can't exceed 99.9999");
                    document.getElementById("<%=txtITRate.ClientID%>").focus();
                    return false;
                }
            }
            else if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                if (eval(eduCessRate.value) > 99.999 || eval(surRate.value) > 99.999) {
                    alert("Surcharge Rate or Edu Cess Rate can't exceed 99.9999");
                    surRate.focus();
                    return false;
                }
            }
            return true;
        }
        function ValidateTaxDedDate() {
            var taxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
            var txtCreditDate = document.getElementById("<%=txtCreditedDate.ClientID%>").value;

            if (Return(taxDeducted.value) != 0) {
                var taxDedDate = document.getElementById("<%=txtTaxDedDate.ClientID%>").value;
                if (taxDedDate == "") {
                    var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                    alert("Specify " + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Date.");
                    document.getElementById("<%=txtTaxDedDate.ClientID%>").focus();
                    return false;
                }
                else {
                    var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
                    var minQuarterDate, maxQuarterDate;
                    var taxDedDateDay = parseInt(taxDedDate.substring(0, 2), 10);
                    var taxDedDateMonth = parseInt(taxDedDate.substring(3, 5), 10);
                    var taxDedDateYear = parseInt(taxDedDate.substring(6, 10), 10);
                    var currentDate = new Date();
                    taxDedDate = new Date(taxDedDateYear, taxDedDateMonth - 1, taxDedDateDay);
                    var quarterNo = document.getElementById("<%=hdnQuarter.ClientID%>").value;
                    var startDate = new Date(finYear, 03, 01);
                    var endDate = new Date(eval(finYear) + 1, 02, 31);
                    if (quarterNo == "Quarter1") {
                        minQuarterDate = new Date(finYear, 03, 01);
                        maxQuarterDate = new Date(finYear, 05, 30);
                    }
                    else if (quarterNo == "Quarter2") {
                        minQuarterDate = new Date(finYear, 06, 01);
                        maxQuarterDate = new Date(finYear, 08, 30);
                    }
                    else if (quarterNo == "Quarter3") {
                        minQuarterDate = new Date(finYear, 09, 01);
                        maxQuarterDate = new Date(finYear, 11, 31);
                    }
                    else if (quarterNo == "Quarter4") {
                        minQuarterDate = new Date(eval(finYear) + 1, 00, 01);
                        maxQuarterDate = new Date(eval(finYear) + 1, 02, 31);
                    }

                    if (taxDedDate < minQuarterDate) {
                        var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                        alert((formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Date cannot be before Current Quarter.");
                        document.getElementById("<%=txtTaxDedDate.ClientID%>").focus();
                        return false;
                    }

                    if (taxDedDate > currentDate) {
                        var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                        alert((formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Date cannot be future date.");
                        document.getElementById("<%=txtTaxDedDate.ClientID%>").focus();
                        return false;
                    }
                }
            }
            else if (Return(taxDeducted.value) == 0 && document.getElementById("<%=txtTaxDedDate.ClientID%>").value != "") {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert((formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount is zero.\nSo " + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Date need not be specified.");
                document.getElementById("<%=txtTaxDedDate.ClientID%>").focus();
                return false;
            }
            return true;
        }
        function ValidateNonDeductionReason(section, nonDedReason, finYear) {
            if ((section.value == "6" || section.value == "7" || section.value == "8" || section.value == "9" || section.value == "12" || section.value == "13" || section.value == "14" || section.value == "15" || section.value == "22") && nonDedReason.selectedIndex == 2) {
                alert("For the selected Section , Non Deduction Reason \ncan only be 'LOWER DEDUCTION/NO DEDUCTION U/S 197'");
                return false;
            }
            else if (section.value != "8" && nonDedReason.value == "4" && finYear.value != "2009") {
                alert("For the selected section,Remarks for Deduction\ncan't be 'TRANSPORTER'");
                return false;
            }
            return true;
        }
        <%--function ValidateTaxAmountsForParticularSections(section, taxDeducted, taxDeductedRate, itRate, nonDedReason, finYear) {
            if (Return(taxDeducted.value) == 0 && Return(taxDeductedRate.value) != 0) {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert("Since " + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount is zero,\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Rate should also be zero.");
                itRate.focus();
                return false;
            }
            else {
                if (section.value == "3" || section.value == "4" || section.value == "5" || Return(finYear.value) >= 2017 && section.value == "9" || section.value == "11" || section.value == "40") {
                    if (nonDedReason.value == "2") {
                        if (Return(taxDeducted.value) != 0) {
                            alert("'NO DEDUCTION U/S 197A' has been specified.\nSo Tax Amounts should be zero.");
                            itRate.focus();
                            return false;
                        }
                        else {
                            if (Return(taxDeducted.value) == 0 && Return(taxDeductedRate.value) != 0) {
                                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                alert("Since " + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount is zero,\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Rate should also be zero.");
                                itRate.focus();
                                return false;
                            }
                            else if (Return(taxDeducted.value) != 0 && Return(taxDeductedRate.value) == 0) {
                                alert("'NO DEDUCTION U/S 197A' has been specified.\nSo Tax Amounts should be zero.");
                                itRate.focus();
                                return false;
                            }
                        }
                    }
                }
            }
            return true;
        }--%>
        function ValidateTaxAmountsForParticularSections(txtTaxDeducted, txtTaxDeductedRate, txtITRate, ddlSection, ddlNonDeductionReason, finYear) {
            if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                alert("Since Tax Deducted Amount is zero,\nTax Deducted Rate should also be zero.");
                txtITRate.focus();
                return false;
            }
            else {
                var section = ddlSection.value;
                if (Return(finYear.value) <= 2025) {
                    if (section == "3" || section == "4" || section == "5" || (Return(finYear.value) >= 2017 && section == "9") || section == "11" || section == "40") {
                        if (ddlNonDeductionReason.value == "2") {
                            if (Return(txtTaxDeducted.value) != 0) {
                                alert("'NO DEDUCTION U/S 197A' has been specified.\nSo Tax Amounts should be zero.");
                                if (!txtITRate.disabled) {
                                    txtITRate.focus();
                                } return false;
                            }
                            else {
                                if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                                    alert("Since Tax Deducted Amount is zero,\nTax Deducted Rate should also be zero.");
                                    txtITRate.focus();
                                    return false;
                                }
                            }
                        }
                    }
                }
                else if (Return(finYear.value) >= 2026) {
                    if (section == "218" || section == "227" || section == "219" || section == "220" || section == "221" || section == "206" || section == "243" || section == "228") {
                        if (ddlNonDeductionReason.value == "66") {
                            if (Return(txtTaxDeducted.value) != 0) {
                                alert("'NO DEDUCTION U/S 393(6)' has been specified.\nSo Tax Amounts should be zero.");
                                if (!txtITRate.disabled) {
                                    txtITRate.focus();
                                } return false;
                            }
                            else {
                                if (Return(txtTaxDeducted.value) == 0 && Return(txtTaxDeductedRate.value) != 0) {
                                    alert("Since Tax Deducted Amount is zero,\nTax Deducted Rate should also be zero.");
                                    txtITRate.focus();
                                    return false;
                                }
                            }
                        }
                    }
                }
                else if (section == "16" && ddlNonDeductionReason.value == "6") {
                    if (Return(txtTaxDeducted.value) != 0) {
                        alert("'Software Vendor Transaction' has been specified.\nSo Tax Amounts should be zero.");
                        txtITRate.focus();
                        return false;
                    }
                }
                else if (section == "17" && ddlNonDeductionReason.value == "6") {
                    if (Return(txtTaxDeducted.value) != 0) {
                        alert("'Software Vendor Transaction' has been specified.\nSo Tax Amounts should be zero.");
                        txtITRate.focus();
                        return false;
                    }
                }
            } return true;
        }
        function ValidateChallanDetails(formType, taxDeducted, challanAmount, itRate, itAmnt, isNilChallan) {
            if (challanAmount.isDisabled) {
                if (isNilChallan.value == "Y") {
                    if (Return(taxDeducted.value) != 0) {
                        var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                        alert("Since the record is already linked with Nil Challan,\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " should be Nil.");
                        if (formType.value == "Form26" || formType.value == "Form27") {
                            itRate.focus();
                        }
                        else
                            itAmnt.focus();
                        return false;
                    }
                }
            }
            else if (Return((taxDeducted.value)) != 0 && challanAmount.value == "") {
                alert('Since Tax is deducted,\nChallan Details has to be specified.');
                var txtChallanID = document.getElementById("<%=txtChallanID.ClientID%>");
                if (txtChallanID != null)
                    document.getElementById("<%=txtChallanID.ClientID%>").focus();
                return false;
            }

            return true;
        }
        function ValidateIfPANNotAvailable() {
            if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1") {

                if (document.getElementById("<%=hdnFormType.ClientID%>").value != "Form24" && document.getElementById("<%=hdnFormType.ClientID%>").value != "Form27E") {
                    if (Return(document.getElementById("<%=txtTaxRate.ClientID%>").value) < 20) {
                        var res = confirm('Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 20%.\nDo you want to continue?');
                        if (res) {
                            if ((document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex == 3 && document.getElementById("<%=hdnFinYear.ClientID%>") < 2026) || (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex == 3 && document.getElementById("<%=hdnFinYear.ClientID%>") >= 2026)) {
                                if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0) {
                                    var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                                    alert("For 'PAN Not available - Higher Rate (20%)',\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " can't be Nil.'");
                                    document.getElementById("<%=txtITRate.ClientID%>").focus();
                                    return false;
                                }
                            }
                        }
                        else {
                            return false;
                        }
                    }
                    else {
                        if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0 && Return(document.getElementById("<%=txtTaxRate.ClientID%>").value) != 0) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("Since " + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount is zero,\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Rate should also be zero.");
                            document.getElementById("<%=txtITRate.ClientID%>").focus();
                            return false;
                        }
                    }
                }
            }
            else if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                var txtAmtCashDrawn = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
                if (txtAmtCashDrawn != null) {
                    if (Return(document.getElementById("<%=txtTaxRate.ClientID%>").value) < 5) {
                        alert("Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 5%");
                        return false;
                    }
                }
            }
            else {
                if ((document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex == 3 && document.getElementById("<%=hdnFinYear.ClientID%>") < 2026) || (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex == 3 && document.getElementById("<%=hdnFinYear.ClientID%>") >= 2026)) {
                    if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                        if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("For 'PAN Not available - Higher Rate (20%)',\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " can't be Nil.'");
                            document.getElementById("<%=txtITAmount.ClientID%>").focus();
                            return false;
                        }
                    }
                    else {
                        if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0 &&
                            Return(document.getElementById("<%=txtTaxRate.ClientID%>").value) == 0) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("For 'PAN Not available - Higher Rate (20%)',\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " can't be Nil.'");
                            if (document.getElementById("<%=hdnFormType.ClientID%>").value != "Form24") {
                                document.getElementById("<%=txtITRate.ClientID%>").focus();
                                return false;
                            }
                        }
                        else if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) == 0 && Return(document.getElementById("<%=txtTaxRate.ClientID%>").value) != 0) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("For 'PAN Not available - Higher Rate (20%)',\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " can't be Nil.'");
                            document.getElementById("<%=txtITRate.ClientID%>").focus();
                            return false;
                        }
                        else if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) != 0 && Return(document.getElementById("<%=txtTaxRate.ClientID%>").value) == 0) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("For 'PAN Not available - Higher Rate (20%)',\n" + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Rate can't be Nil.'");
                            document.getElementById("<%=txtITRate.ClientID%>").focus();
                            return false;
                        }
                    }
                }
                return true;
            }
            if (document.getElementById("<%=hdnIsValidPAN.ClientID%>").value != "1") {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") {
                    if (Return(document.getElementById("<%=txtTaxRate.ClientID%>").value) < 5) {
                        var res = confirm('Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 5%.\nDo you want to continue?');
                        if (res) {
                            return true;
                        }
                        else {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        function ValidateIfTransporter(section, taxRate, taxDeducted, isTransporter, isHavingValidPAN, nonDedReason) {
            if (isTransporter.value == "True" && isHavingValidPAN.value == "") {//Transporter with valid PAN
                if (section.value == "8") {
                    if (nonDedReason.value != "4") {
                        if ((Return(taxDeducted.value) == "0") || (Return(taxDeducted.value) == "0" && Return(taxRate.value) != "0")) {
                            alert("Specify 'Transporter with valid PAN (0%)' as Remarks for Deduction.");
                            return false;
                        }
                        else {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            return confirm("Since Deductee is a Transporter and has a Valid PAN," + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + "\nshould be Nil. Do you want to continue?");
                        }
                    }
                    else if (nonDedReason.value == "4") {
                        if ((Return(taxDeducted.value) != "0") || (Return(taxDeducted.value) != "0" && Return(taxRate.value) != "0")) {
                            alert("For 'Transporter with valid PAN (0%),Tax Amounts should be Nil.");
                            return false;
                        }
                        else if ((Return(taxDeducted.value) != "0") || (Return(taxDeducted.value) == "0" && Return(taxRate.value) != "0")) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("Since " + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount is Nil,Tax Rate should also be Nil.");
                            return false;
                        }
                    }
                }
            }
            else if (isTransporter.value == "True" && isHavingValidPAN.value != "") {//Transporter with invalid PAN
                if (section.value == "8") {
                    if (nonDedReason.value != "4") {
                        if (Return(taxRate.value) < 20) {
                            var res = confirm("Since Deductee is having invalid PAN structure,\nTDS has to be deducted at the rate of 20%.\nDo you want to continue?'");
                            if (res) {
                                return true;
                            }
                            else {
                                return false;
                            }
                            return false;
                        }
                        else {
                            if (document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex != 3) {
                                return confirm("Since Deductee has InValid PAN  \n Remarks for Deduction 'PAN Not available - Higher Rate (20%)' should be Selected \n Are you sure you want to Continue");

                            }
                        }
                    }
                    else if (nonDedReason.value == "4") {
                        if ((Return(taxDeducted.value) != "0") || (Return(taxDeducted.value) != "0" && Return(taxRate.value) != "0")) {
                            alert("For 'Transporter with valid PAN (0%),Tax Amounts should be Nil.");
                            return false;
                        }
                        else if ((Return(taxDeducted.value) != "0") || (Return(taxDeducted.value) == "0" && Return(taxRate.value) != "0")) {
                            var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                            alert("Since " + (formTypeNew != "Form27E" ? "Tax Deducted" : "Tax Collected") + " Amount is Nil,Tax Rate should also be Nil.");
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        function ValidateViewExisting() {
            if (!Validate()) return false;
            else return true;
        }
        function Validate() {
            <%--var count = 0;
            for (i = 0; i < document.getElementById("<%=rptrTD.ClientID%>").all.length; i++) {
                if (document.getElementById("<%=rptrTD.ClientID%>").all[i].type == 'checkbox' && document.getElementById("<%=rptrTD.ClientID%>").all[i].name.indexOf("chkExistingDedsSelect") != -1) {
                    if (document.getElementById("<%=rptrTD.ClientID%>").all[i].checked) { count = count + 1; }
                }
            }
            if (count == 0) {
                alert("Select atleast one record.");
                return false;
            }--%>
            return true;
        }
        function UnSelectAll() {
            var x = document.getElementsByClassName("dedCheckBox");
            var i;
            for (i = 0; i <= x.length; i++) {
                if (i < 10) {
                    i = '0' + i;
                }
                el = document.getElementById('ctl00_contentPlaceHolderBody_rptrExistingDeductions_ctl' + i + '_chkExistingDedsSelect');
                if (el != null && el.disabled == false) {
                    el.checked = false;
                }
            }
            return false;
        }
        function SelectAll() {
            var x = document.getElementsByClassName("dedCheckBox");
            var i;
            for (i = 0; i <= x.length; i++) {
                if (i < 10) {
                    i = '0' + i;
                }
                el = document.getElementById('ctl00_contentPlaceHolderBody_rptrExistingDeductions_ctl' + i + '_chkExistingDedsSelect');
                if (el != null && el.disabled == false) {
                    el.checked = true;
                }
            }
            return false;
        }
        function UnSelectAllBulkUpdate() {
            var elementCount = document.getElementById("<%=Td1.ClientID%>").all.length;
            for (i = 0; i < elementCount; i++) {
                if (document.getElementById("<%=Td1.ClientID%>").all[i].type == 'checkbox') { document.getElementById("<%=Td1.ClientID%>").all[i].checked = false; }
            }
        }
        function SelectAllBulkUpdate() {
            var elementCount = document.getElementById("<%=Td1.ClientID%>").all.length;
            for (i = 0; i < elementCount; i++) {
                if (document.getElementById("<%=Td1.ClientID%>").all[i].type == 'checkbox') { document.getElementById("<%=Td1.ClientID%>").all[i].checked = true; }
            }
        }
        function ClearAOCW() {
            if (eval(document.getElementById("<%=txtAmtCashDrawn.ClientID%>").value) == 0) {
                document.getElementById("<%=txtAmtCashDrawn.ClientID%>").value = "";
                return true;
            }
        }
        function ClearAOP() {
            if (eval(document.getElementById("<%=txtAmountOfPayment.ClientID%>").value) == 0) {
                document.getElementById("<%=txtAmountOfPayment.ClientID%>").value = "";
                return true;
            }
        }
        function EnableDisableControls() {
            var edit = document.getElementById("<%=chkEdit.ClientID%>");
            if (edit.checked) {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                    document.getElementById("<%=txtITAmount.ClientID%>").disabled = false;
                    document.getElementById("<%=txtSurchargeAmount.ClientID%>").disabled = false;
                    document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = false;
                }
                else if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") { document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = false; }
            }
            else {
                if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27") {
                    document.getElementById("<%=txtITAmount.ClientID%>").disabled = true;
                    document.getElementById("<%=txtSurchargeAmount.ClientID%>").disabled = true;
                    document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = true;
                }
                else if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") { document.getElementById("<%=txtEduCessAmount.ClientID%>").disabled = true; }
            }
            CalculateValues();
        }
        function CalculateValues() {
            var section = document.getElementById("<%=ddlSection.ClientID%>")[document.getElementById("<%=ddlSection.ClientID%>").selectedIndex].text;
            var ddlNonDeductionReason = document.getElementById("<%=ddlNonDeductionReason.ClientID%>")[document.getElementById("<%=ddlNonDeductionReason.ClientID%>").selectedIndex].text;
            var amountOfPayment = document.getElementById("<%=txtAmountOfPayment.ClientID%>");
            if (section.indexOf("194NF") != -1 && document.getElementById("<%=hdnIsValidPAN.ClientID%>").value == 1) {
                if (ddlNonDeductionReason == "" || ddlNonDeductionReason == "Select") {
                    if (amountOfPayment.value > 2000000 && amountOfPayment.value <= 10000000) {
                        document.getElementById("<%=txtITRate.ClientID%>").value = 2;
                    }
                    else if (amountOfPayment.value > 10000000) {
                        document.getElementById("<%=txtITRate.ClientID%>").value = 5;
                    }
                }
            }
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") { CalculateTaxDeductedCorrForForm24(); }
            else if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E") { CalculateTaxDeductedCorr(); }
        }
        function CalculateTaxDeductedCorr() {
            var tempValue;
            var amountOfPayment = document.getElementById("<%=txtAmountOfPayment.ClientID%>");
            var AmountOfCashWithdrawal = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            if (AmountOfCashWithdrawal != null) {
                amountOfPayment = document.getElementById("<%=txtAmtCashDrawn.ClientID%>");
            }

            var incomeTaxRate = document.getElementById("<%=txtITRate.ClientID%>");
            var incomeTaxAmount = document.getElementById("<%=txtITAmount.ClientID%>");
            var surchargeRate = document.getElementById("<%=txtSurchargeRate.ClientID%>");
            var surchargeAmount = document.getElementById("<%=txtSurchargeAmount.ClientID%>");
            var eduCessRate = document.getElementById("<%=txtEduCessRate.ClientID%>");
            var eduCessAmount = document.getElementById("<%=txtEduCessAmount.ClientID%>");
            var taxDeductedRate = document.getElementById("<%=txtTaxRate.ClientID%>");
            var taxDeducted = document.getElementById("<%=txtTaxDeducted.ClientID%>");
            var hdnRoundOff = document.getElementById("<%=hdnRoundOff.ClientID%>");
            if (!document.getElementById("<%=chkEdit.ClientID%>").checked) {
                tempValue = (eval(Return(incomeTaxRate.value)) / 100) * eval(Return(amountOfPayment.value));
                if (hdnRoundOff.value == "HigherRupee") { tempValue = Math.ceil(tempValue) }
                else { tempValue = tempValue.toFixed(2); }
                incomeTaxAmount.value = Return(tempValue);
                tempValue = (eval(Return(surchargeRate.value)) / 100) * eval(Return(incomeTaxAmount.value));
                if (hdnRoundOff.value == "HigherRupee") { tempValue = Math.ceil(tempValue) }
                else { tempValue = tempValue.toFixed(2); }
                surchargeAmount.value = Return(tempValue);
                tempValue = (eval(Return(eduCessRate.value)) / 100) * (eval(Return(incomeTaxAmount.value)) + eval(Return(surchargeAmount.value)));
                if (hdnRoundOff.value == "HigherRupee") { tempValue = Math.ceil(tempValue) }
                else { tempValue = tempValue.toFixed(2); }
                eduCessAmount.value = Return(tempValue);
                var taxRate = ((eval(Return(surchargeRate.value)) / 100) * eval(Return(incomeTaxRate.value))) + eval(Return(incomeTaxRate.value));
                taxRate = ((eval(Return(eduCessRate.value)) / 100) * eval(Return(taxRate))) + eval(Return(taxRate));
                taxRate = taxRate.toFixed(4);
                taxDeductedRate.value = Return(taxRate);
            }
            tempValue = eval(Return(incomeTaxAmount.value)) + eval(Return(surchargeAmount.value)) + eval(Return(eduCessAmount.value));
            tempValue = tempValue.toFixed(2);
            taxDeducted.value = Return(tempValue);
            if (Return(taxDeducted.value) != 0) {
                document.getElementById("<%=txtTaxDedDate.ClientID%>").style.backgroundColor = "#E5E5E5";
                document.getElementById("<%=hdnSetColor.ClientID%>").value = "#E5E5E5";
            }
            else {
                document.getElementById("<%=txtTaxDedDate.ClientID%>").value = "";
                document.getElementById("<%=txtTaxDedDate.ClientID%>").style.backgroundColor = "White";
                document.getElementById("<%=hdnSetColor.ClientID%>").value = "White";
            }
        }
        function CalculateTaxDeductedCorrForForm24() {
            var temp;
            var hdnRoundOff = document.getElementById("<%=hdnRoundOff.ClientID%>");
            if (!document.getElementById("<%=chkEdit.ClientID%>").checked) {
                temp = eval(Return(document.getElementById("<%=txtITAmount.ClientID%>").value)) * (eval(Return(document.getElementById("<%=txtEduCessRate.ClientID%>").value)) / 100);
                if (hdnRoundOff.value == "HigherRupee") { temp = Math.ceil(temp) }
                else { temp = temp.toFixed(2); }
                document.getElementById("<%=txtEduCessAmount.ClientID%>").value = Return(temp);
            }
            temp = eval(Return(document.getElementById("<%=txtITAmount.ClientID%>").value)) + eval(Return(document.getElementById("<%=txtEduCessAmount.ClientID%>").value));
            if (hdnRoundOff.value == "HigherRupee") { temp = Math.ceil(temp) }
            else { temp = temp.toFixed(2); }
            document.getElementById("<%=txtTaxDeducted.ClientID%>").value = Return(temp);
            if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) != 0) {
                document.getElementById("<%=txtTaxDedDate.ClientID%>").style.backgroundColor = "#E5E5E5";
                document.getElementById("<%=hdnSetColor.ClientID%>").value = "#E5E5E5";
            }
            else {
                document.getElementById("<%=txtTaxDedDate.ClientID%>").value = "";
                document.getElementById("<%=txtTaxDedDate.ClientID%>").style.backgroundColor = "White";
                document.getElementById("<%=hdnSetColor.ClientID%>").value = "White";
            }
        }
        function OnConfirm() {
            if (document.getElementById("<%=hdnDeductionSlNo.ClientID%>").value == "-1") {
                alert('Select a record to remove.');
                return false;
            }
            else if (document.getElementById("<%=hdnCorrectionID.ClientID%>").value != "0") {
                return confirm('This Record was added from Correction Request\n\nTicket No : ' + document.getElementById("<%=hdnCorrectionID.ClientID%>").value + '\n\n All the records with this request will be removed\n\n Do u want to continue ?');
            }
            else { return confirm('Are you sure you want to remove ?'); }
        }
        function SetColor() {
            if (Return(document.getElementById("<%=txtTaxDeducted.ClientID%>").value) != 0) { document.getElementById("<%=txtTaxDedDate.ClientID%>").style.backgroundColor = "#E5E5E5"; }
            else {
                document.getElementById("<%=txtTaxDedDate.ClientID%>").value = "";
                document.getElementById("<%=txtTaxDedDate.ClientID%>").style.backgroundColor = "White";
            }
        }
        function ClearChallanDetail() {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) { }
            else {
                document.getElementById("<%=hdnChallanSlNo.ClientID%>").value = "-1";
                document.getElementById("<%=txtTotalAmount.ClientID%>").value = "";
                document.getElementById("<%=hdnIsNilChallan.ClientID%>").value = "Y";
                document.getElementById("<%=hdnChallanDate.ClientID%>").value = "-1";
                document.getElementById("<%=hdnChallanSection.ClientID%>").value = "-1";
            }
        }
        function GetChallanDetail(source, eventArgs) {
            //document.getElementById("<%=hdnChallanSlNo.ClientID%>").value = eventArgs.get_text().substring(0, eventArgs.get_text().indexOf('-'));            
            document.getElementById("<%=hdnChallanSlNo.ClientID%>").value = eventArgs.get_text().split(';')[0];
            document.getElementById("<%=txtChallanID.ClientID%>").value = eventArgs.get_text().split(';')[0];
            document.getElementById("<%=hdnChallanDate.ClientID%>").value = eventArgs.get_text().split(';')[3];
            document.getElementById("<%=hdnChallanSection.ClientID%>").value = eventArgs.get_text().split(';')[4];
            document.getElementById("<%=hdnChallanID.ClientID%>").value = eventArgs.get_text().split(';')[5];
            document.getElementById("<%=txtTotalAmount.ClientID%>").value = eventArgs.get_value();
            document.getElementById("<%=hdnIsNilChallan.ClientID%>").value = "N";
        }
        function GetDeducteeNameValue(source, eventArgs) {
            var contents;
            if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form24") {
                contents = eventArgs.get_text();
                contents = contents.split('-');
                document.getElementById("<%=hdnDeducteeSlNo.ClientID%>").value = eventArgs.get_value();
                document.getElementById("<%=txtPAN.ClientID%>").value = contents[contents.length - 1];
                document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "";
                document.getElementById("<%=hdnIsTran.ClientID%>").value = "";
            }
            else {
                contents = eventArgs.get_value();
                contents = contents.split(';');
                document.getElementById("<%=hdnDeducteeSlNo.ClientID%>").value = contents[0];
                document.getElementById("<%=txtPAN.ClientID%>").value = contents[1];
                ValidatePANforTransporter();
                document.getElementById("<%=hdnIsTran.ClientID%>").value = contents[3];
            }
        }
        function ClearDeducteeName() {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) { }
            else {
                document.getElementById("<%=hdnDeducteeSlNo.ClientID%>").value = "-1";
                document.getElementById("<%=txtPAN.ClientID%>").value = "";
                document.getElementById("<%=hdnIsValidPAN.ClientID%>").value = "";
                document.getElementById("<%=hdnIsTran.ClientID%>").value = "";
            }
        }
        function Return(tempValue) {
            if (isNaN(tempValue)) { return tempValue = "0"; }
            else if (tempValue == "" || tempValue == "undefined") { return 0; }
            else if (tempValue == "0.00" || tempValue == "0.0000") { return 0; }
            else { return eval(parseFloat(tempValue).toString()); }
        }
        function SetBulkUpdateType() { document.getElementById("<%=hdnBulkUpdateType.ClientID%>").value = document.getElementById("<%=ddlBlkUpdateType.ClientID%>").value; }
        function ShowSectionHelp() {
            if (document.getElementById("<%=hdnFinYear.ClientID%>").value != 2009) {
                if (document.getElementById("<%=hdnFormType .ClientID%>").value == "Form26") window.open('../TDS_Help/TDS_Rates/Form_26_(2010_11).htm');
                else window.open('../TDS_Help/TDS_Rates/Form_27_(2010_11).htm');
            }
            else {
                if (document.getElementById("<%=hdnFormType .ClientID%>").value == "Form26") window.open('../TDS_Help/TDS_Rates/Form_26_(2009_10)(Oct_Mar).htm');
                else window.open('../TDS_Help/TDS_Rates/Form_27_(2009_10)(Oct_Mar).htm');
            }
        }
        function DisplayControls() {
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            var rowCertNo = document.getElementById("<%=rowCertNo.ClientID%>");
            var rowMoreDetails = document.getElementById("<%=rowMoreDetails.ClientID%>");
            var rowAdditionalDetails = document.getElementById("<%=rowAdditionalDetails.ClientID%>");
            if (Return(finYear) > 2012) {
                if (rowCertNo != null) rowCertNo.style.display = '';
                if (rowMoreDetails != null) {
                    if (formType == "Form27")
                        rowMoreDetails.style.display = '';
                    else
                        rowMoreDetails.style.display = 'none';
                }
            }
            else {
                if (rowCertNo != null) rowCertNo.style.display = 'none';
                if (rowMoreDetails != null) rowMoreDetails.style.display = 'none';
            }
            if (Return(finYear) < 2023) {
                if (rowAdditionalDetails != null) rowAdditionalDetails.style.display = 'none';
            }
            else {
                if (formType == "Form27" || formType == "Form27E") {
                    if (rowAdditionalDetails != null) rowAdditionalDetails.style.display = '';
                }
                else {
                    if (rowAdditionalDetails != null) rowAdditionalDetails.style.display = 'none';
                }
            }
        }
        function SetNonDedReason() {
            var theDropDown = document.getElementById("<%=ddlNonDeductionReason.ClientID%>");
            var toolTipObj = new Object();
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            var txtCertNo = document.getElementById("<%=txtCertNo.ClientID%>");
            toolTipObj = document.getElementById("tooltip");
            if (theDropDown != null) {
                if (txtCertNo != null) {
                    var value = theDropDown.value;
                    if (formType == "Form24" || formType == "Form27") {
                        if (Return(value) == 1 || Return(value) == 2 || Return(value) == 65) txtCertNo.style.backgroundColor = "#E5E5E5";
                        else txtCertNo.style.backgroundColor = "White";
                    }
                    else {
                        if (Return(value) == 1 || Return(value) == 65) {
                            txtCertNo.style.backgroundColor = "#E5E5E5";
                            if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "U/s 197 Cert. No.";
                            }
                            else {
                                document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "U/s 395 Cert. No.";
                            }
                        }
                        else {
                            if (Return(value) == 2 || Return(value) == 66) {
                                if ((Return(document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter1" ? 1 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter2" ? 2 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter3" ? 3 : document.getElementById("<%=hdnQuarter.ClientID%>").value == "Quarter4" ? 4 : 0) > 2 && Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) == 2015) || Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) > 2015) {
                                    if (formType != "Form27E") {
                                        if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026)
                                            document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "15G/15H UIN";
                                        else
                                            document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "121 UIN";
                                    }
                                }
                            }
                            else {
                                if (Return(document.getElementById("<%=hdnFinYear.ClientID%>").value) < 2026) {
                                    document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "U/s 197 Cert. No.";
                                }
                                else { document.getElementById("<%=lblCertNo.ClientID%>").innerHTML = "U/s 395 Cert. No."; }
                            }
                            txtCertNo.style.backgroundColor = "White";
                        }
                    }

                    tr27EQMoreDetails = document.getElementById("<%=tr27EQMoreDetails.ClientID%>");
                    if (theDropDown.value == 13 || theDropDown.value == 14 || theDropDown.value == 70) {
                        if (tr27EQMoreDetails != null) {
                            tr27EQMoreDetails.style.display = '';
                            ddl27EQLiableOption = document.getElementById("<%=ddl27EQLiableOption.ClientID%>");
                        }
                    }
                    else {
                        if (tr27EQMoreDetails != null)
                            tr27EQMoreDetails.style.display = 'none';
                    }
                }
            }
        }
        function checkValidEmail(object) {
            if (object.value.trim() != "") {
                if (!ValidateEmail(object)) {
                    document.getElementById("<%=txtEmailDed.ClientID%>").value = "";
                    return false;
                }
            }
        }
        function checkValidContactNo(inputtxt) {
            var numbers = /^[0-9]+$/;
            if (inputtxt.value.trim() != "") {
                if (!inputtxt.value.match(numbers)) {
                    alert('Please input valid Contact Number.');
                    document.getElementById("<%=txtContactNoDed.ClientID%>").value = "";
                    return false;
                }
                else {
                    return true;
                }
            }
        }
        function checkValidDedAddress(inputtxt) {
            if (inputtxt.value != "") {
                if (!InputValidationsForAddress(inputtxt)) {
                    document.getElementById("<%=txtAddressDed.ClientID%>").value = "";
                    return false;
                }
            }
        }
        function InputValidationsForIdentNum(objName) {
            var alphaExp = /[a-zA-Z0-9]/;
            var specialcharsExp = /[`~!@#$%^&*()_+,.?;:[{]}|\/]/;
            var zeros = /[0]+$/;
            if (objName.value != "") {
                if (!objName.value.match(alphaExp)) {
                    if (!objName.value.match(specialcharsExp)) {
                        alert("Only Zeros, Special Characters or blank spaces are not allowed");
                        document.getElementById("<%=txtIdentNumDed.ClientID%>").value = "";
                        return false;
                    }
                    else {
                        return true;
                    }
                }
                else if (objName.value.match(zeros)) {
                    alert("Only Zeros, Special Characters or blank spaces are not allowed");
                    document.getElementById("<%=txtIdentNumDed.ClientID%>").value = "";
                    return false;
                }
                else {
                    return true;
                }
            }
        }
        function ShowAllclick() {
            if (confirm("Loading all details will take time.\n\nDo you want to continue?") == true) {
                return true;
            } else return false;
        }
        function ParameterChanged() { document.getElementById("<%=hdnIsSearchParameterChanged.ClientID %>").value = "1"; }
        function SetSection() {
            var cbl = document.getElementById('<%=chkSections.ClientID%>');
            var values = "";
            var tbody = cbl.childNodes[0];
            var length = (tbody.childNodes.length);
            for (i = 0; i < length; i++) {
                var td = tbody.childNodes[i].childNodes[0];
                var chk = td.childNodes[0];
                if (chk.checked) { values = td.innerText.substring(0, td.innerText.indexOf('-')).trim() + "," + values; }
            } document.getElementById("<%=txtSection.ClientID%>").value = values;
        }
        function SetStatus() {
            var hdnSearch = document.getElementById("<%=hdnSearch.ClientID%>");
            if (hdnSearch.value == "0") { hdnSearch.value = "1"; }
            else { hdnSearch.value = "0"; }
            SetSearchPanelVisibility();
        }
        function SetSearchPanelVisibility() {
            var btnSearch = document.getElementById("<%=btnOpenSearch.ClientID%>");
            var pnlSearch = document.getElementById("<%=pnlSearch.ClientID%>");
            if (btnSearch == null) { document.getElementById("<%=hdnSearch.ClientID%>").value = "0"; return; }
            else {
                if (document.getElementById("<%=hdnSearch.ClientID%>").value == "0") {
                    if (btnSearch != null) btnSearch.style.display = '';
                    if (pnlSearch != null) pnlSearch.style.display = 'none';
                }
                else {
                    if (btnSearch != null) btnSearch.style.display = 'none';
                    if (pnlSearch != null) pnlSearch.style.display = '';
                }
            }
        }
        function FormatSearch() {
            var txtSearchAmountFrom = document.getElementById("<%=txtSearchAmountFrom.ClientID%>");
            var txtSearchAmountTo = document.getElementById("<%=txtSearchAmountTo.ClientID%>");
            var txtSearchPaidDateFrom = document.getElementById("<%=txtSearchPaidDateFrom.ClientID%>");
            var txtSearchPaidDateTo = document.getElementById("<%=txtSearchPaidDateTo.ClientID%>");
            var txtSrchTaxDeductedFrom = document.getElementById("<%=txtSrchTaxDeductedFrom.ClientID%>");
            var txtSrchTaxDeductedTo = document.getElementById("<%=txtSrchTaxDeductedTo.ClientID%>");
            var txtSrchTaxDateFrom = document.getElementById("<%=txtSrchTaxDateFrom.ClientID%>");
            var txtSrchTaxDateTo = document.getElementById("<%=txtSrchTaxDateTo.ClientID%>");
            var txtSearchDedSerialNo = document.getElementById("<%=txtSearchDedSerialNo.ClientID%>");
            var txtSearchName = document.getElementById("<%=txtSearchName.ClientID%>");

            if (ValidateHtmlTags(document.getElementById("<%=txtSearchAmountFrom.ClientID%>").value)) {
                document.getElementById("<%=txtSearchAmountFrom.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchAmountTo.ClientID%>").value)) {
                document.getElementById("<%=txtSearchAmountTo.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchPaidDateFrom.ClientID%>").value)) {
                document.getElementById("<%=txtSearchPaidDateFrom.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchPaidDateTo.ClientID%>").value)) {
                document.getElementById("<%=txtSearchPaidDateTo.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSrchTaxDeductedFrom.ClientID%>").value)) {
                document.getElementById("<%=txtSrchTaxDeductedFrom.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSrchTaxDeductedTo.ClientID%>").value)) {
                document.getElementById("<%=txtSrchTaxDeductedTo.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSrchTaxDateFrom.ClientID%>").value)) {
                document.getElementById("<%=txtSrchTaxDateFrom.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSrchTaxDateTo.ClientID%>").value)) {
                document.getElementById("<%=txtSrchTaxDateTo.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchDedSerialNo.ClientID%>").value)) {
                document.getElementById("<%=txtSearchDedSerialNo.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSearchName.ClientID%>").value)) {
                document.getElementById("<%=txtSearchName.ClientID%>").value = "";
                return false;
            }
            if (ValidateHtmlTags(document.getElementById("<%=txtSection.ClientID%>").value)) {
                document.getElementById("<%=txtSection.ClientID%>").value = "";
                return false;
            }
            if (txtSearchAmountFrom.value.trim() == "" && txtSearchAmountTo.value.trim() == "" && txtSearchPaidDateFrom.value.trim() == "" && txtSearchPaidDateTo.value.trim() == "" && txtSrchTaxDeductedFrom.value.trim() == "" && txtSrchTaxDeductedTo.value.trim() == "" && txtSrchTaxDateFrom.value.trim() == "" && txtSrchTaxDateTo.value.trim() == "" && txtSearchDedSerialNo.value.trim() == "" && txtSearchName.value.trim() == "") {
                var confirmLoad;
                if (confirm("Loading all details will take time.\nRecommend to use search filters.\n\nDo you want to continue?") == true) { return true; } else { return false; }
            }
            else {
                if ((txtSearchAmountFrom.value != "") && (txtSearchAmountTo.value == "")) { txtSearchAmountTo.value = txtSearchAmountFrom.value; }
                else if ((txtSearchAmountFrom.value == "") && (txtSearchAmountTo.value != "")) { txtSearchAmountFrom.value = txtSearchAmountTo.value; }
                else if ((txtSearchAmountFrom.value != "") && (txtSearchAmountTo.value != "")) {
                    if (eval(txtSearchAmountTo.value) < eval(txtSearchAmountFrom.value)) {
                        var temp = txtSearchAmountFrom.value;
                        txtSearchAmountFrom.value = txtSearchAmountTo.value;
                        txtSearchAmountTo.value = temp;
                    }
                }
                if ((txtSrchTaxDeductedFrom.value != "") && (txtSrchTaxDeductedTo.value == "")) { txtSrchTaxDeductedTo.value = txtSrchTaxDeductedFrom.value; }
                else if ((txtSrchTaxDeductedFrom.value == "") && (txtSrchTaxDeductedTo.value != "")) { txtSrchTaxDeductedFrom.value = txtSrchTaxDeductedTo.value; }
                else if ((txtSrchTaxDeductedFrom.value != "") && (txtSrchTaxDeductedTo.value != "")) {
                    if (eval(txtSrchTaxDeductedTo.value) < eval(txtSrchTaxDeductedFrom.value)) {
                        var temp = txtSrchTaxDeductedFrom.value;
                        txtSrchTaxDeductedFrom.value = txtSrchTaxDeductedTo.value;
                        txtSrchTaxDeductedTo.value = temp;
                    }
                }
                if ((txtSearchPaidDateFrom.value.trim() != "") && (txtSearchPaidDateTo.value.trim() == "")) { txtSearchPaidDateTo.value = txtSearchPaidDateFrom.value; }
                else if ((txtSearchPaidDateFrom.value.trim() == "") && (txtSearchPaidDateTo.value.trim() != "")) { txtSearchPaidDateFrom.value = txtSearchPaidDateTo.value; }
                if (!CheckDate(txtSearchPaidDateFrom.value, txtSearchPaidDateTo.value)) {
                    var temp = txtSearchPaidDateTo.value;
                    txtSearchPaidDateTo.value = txtSearchPaidDateFrom.value;
                    txtSearchPaidDateFrom.value = temp;
                }
                if ((txtSrchTaxDateFrom.value.trim() != "") && (txtSrchTaxDateTo.value.trim() == "")) { txtSrchTaxDateTo.value = txtSrchTaxDateFrom.value; }
                else if ((txtSrchTaxDateFrom.value.trim() == "") && (txtSrchTaxDateTo.value.trim() != "")) { txtSrchTaxDateFrom.value = txtSrchTaxDateTo.value; }
                if (!CheckDate(txtSrchTaxDateFrom.value, txtSrchTaxDateTo.value)) {
                    var temp = txtSrchTaxDateTo.value;
                    txtSrchTaxDateTo.value = txtSrchTaxDateFrom.value;
                    txtSrchTaxDateFrom.value = temp;
                }
            }
        }
        function CheckDate(fromDate, toDate) {
            var fromDateDay = parseInt(fromDate.substring(0, 2), 10);
            var fromDateMonth = parseInt(fromDate.substring(3, 5), 10);
            var fromDateYear = parseInt(fromDate.substring(6, 10), 10);
            var toDatedDay = parseInt(toDate.substring(0, 2), 10);
            var toDatedMonth = parseInt(toDate.substring(3, 5), 10);
            var toDatedYear = parseInt(toDate.substring(6, 10), 10);
            var fromDateTocheck = new Date(fromDateYear, fromDateMonth - 1, fromDateDay);
            var toDateCheck = new Date(toDatedYear, toDatedMonth - 1, toDatedDay);
            if (toDateCheck < fromDateTocheck) { return false; } return true;
        }
        function ValidateNonDedReasonfor194N(ddlNonDeductionReason, txtTaxDeducted) {
            if (document.getElementById("<%=hdnFinYear.ClientID%>") < 2026) {
                if (ddlNonDeductionReason.value == "9" && Return(txtTaxDeducted.value) != 0) {
                    var res = confirm('For remark No deduction on account of Section 194N clause (iii) or (iv) or (v),\n\nDeduction amount is given.\n\nDo you want to continue?');
                    if (res) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
            }
            else {
                if (ddlNonDeductionReason.value == "78" && Return(txtTaxDeducted.value) != 0) {
                    var res = confirm('For remark No deduction on account of Section 393(4)-18 or fifth provisio to 194N,\n\nDeduction amount is given.\n\nDo you want to continue?');
                    if (res) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
            }
            return true;
        }
        function ValidateNonDedReasonfor194NF(ddlNonDeductionReason, txtTaxDeducted) {
            if (ddlNonDeductionReason.value == "22" && Return(txtTaxDeducted.value) != 0) {
                var res = confirm('For remark No deduction/lower deduction, notification issued under 2nd proviso to 194N,\n\nDeduction amount is given.\n\nDo you want to continue?');
                if (res) {
                    return true;
                }
                else {
                    return false;
                }
            }
            return true;
        }
        function Validate194NSectionBasedOnDate() {
            var date = new Date(2019, 09, 01);
            var paymentDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            var date1 = paymentDate.value;
            if (date1.toString().indexOf("-") != -1) {
                date1 = date1.split('-', 3);
            }
            else {
                date1 = date1.split('/', 3);
            }
            var creditedDate = new Date(date1[2], date1[1], date1[0]);
            if (creditedDate < date) {
                var formTypeNew = document.getElementById("<%=hdnFormType.ClientID%>").value;
                alert("Section '194N' is Applicable from '01/09/2019'.\nSpecify the correct date in " + (formTypeNew != "Form27E" ? "Paid/Credited" : "Received/Debited") + " Date");
                return false;
            }
            return true;
        }
        function Disable27EQMoreDetails() {
            tr27EQMoreDetails = document.getElementById("<%=tr27EQMoreDetails.ClientID%>");
            if (tr27EQMoreDetails != null)
                tr27EQMoreDetails.style.display = 'none';
        }
        function Validate115bacDeducteeCode() {

            var pan = document.getElementById("<%=txtPAN.ClientID%>");
            var ded115bacCode = document.getElementById("<%=cmbDeducteeCode.ClientID%>");
            var formType = document.getElementById("<%=hdnFormType.ClientID%>").value;
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
            var codeText = (parseInt(finYear, 10) >= 2026) ? "144/143" : "27/27E";
            if (formType == "Form27" || formType == "Form27E") {
                switch (pan.value.charAt(3)) {
                    case 'P':
                        if (ded115bacCode.selectedIndex != 2) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'P', select code as\n" +
                                "'02-Individual'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'H':
                        if (ded115bacCode.selectedIndex != 3 && ded115bacCode.selectedIndex != 6) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'H', select code as\n" +
                                "'03-Hindu Undivided Family'\n" +
                                "       or\n" +
                                "'06-Co-operative Society'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'C':
                        if (ded115bacCode.selectedIndex != 1 && ded115bacCode.selectedIndex != 6) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'C', select code as\n" +
                                "'01-Company'\n" +
                                "     or\n" +
                                "'06-Co-operative Society'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'J':
                        if (ded115bacCode.selectedIndex != 6 && ded115bacCode.selectedIndex != 9) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'J', select code as\n" +
                                "'06-Co-operative Society'\n" +
                                "        or\n" +
                                "'09-Artificial juridical person referred to in sub-clause (vii) of clause (31)'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'F':
                        if (ded115bacCode.selectedIndex != 6 && ded115bacCode.selectedIndex != 7) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'F', select code as\n" +
                                "'06-Co-operative Society'\n" +
                                "   or\n" +
                                "'07-Firm'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'A':
                        if (ded115bacCode.selectedIndex != 4 && ded115bacCode.selectedIndex != 5 && ded115bacCode.selectedIndex != 6) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'A', select code as\n" +
                                "'04-Association of Persons (AOP) except in case of AOP consisting of only companies as its members'\n" +
                                "          or\n" +
                                "'05-Association of Persons (AOP) consisting of only companies as its members'\n" +
                                "          or\n" +
                                "'06-Co-operative Society'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'T':
                        if (ded115bacCode.selectedIndex != 10) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'T', select code as\n" +
                                "'10-Others'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'B':
                        if (ded115bacCode.selectedIndex != 6 && ded115bacCode.selectedIndex != 8) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'B', select code as\n" +
                                "'06-Co-operative Society'\n" +
                                "        or\n" +
                                "'08-Body of individuals'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'L':
                        if (ded115bacCode.selectedIndex != 10) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'L', select code as\n" +
                                "'10-Others'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    case 'G':
                        if (ded115bacCode.selectedIndex != 10) {
                            if (confirm("Code for " + codeText + " selected is not proper.\n\n" +
                                "If 4th Character of PAN is 'G', select code as\n" +
                                "'10-Others'\n\n" +
                                "Do you want to continue?")) {
                                return true;
                            }
                            else { ded115bacCode.focus(); return false; }
                        }
                        break;
                    default:
                        alert("PAN entered is not correct.\n" +
                            "Fourth character of PAN should be either one of these\n" +
                            "     P - Personal / Individual\n" +
                            "     H - HUF\n" +
                            "     C - Company\n" +
                            "     J - Artificial Judicial Person\n" +
                            "     F - Firms\n" +
                            "     A - Association of People\n" +
                            "     T - Trusts\n" +
                            "     B - Body of Individual\n" +
                            "     L - Local Authority\n" +
                            "     G - Government");
                        break;
                }
            }
            return true;
        }

        function FileValidation() {
            document.getElementById("<%=pnlPopup1.ClientID%>").style.display = 'block';
            var uploadFile = document.getElementById("<%=fupTextFile.ClientID%>");
            var fileType = '.txt';

            // Check if a file is selected
            if (uploadFile.files.length > 0) {
                var file = uploadFile.files[0];
                var fileName = file.name.toLowerCase(); // File name in lowercase            

                // Validate file type
                if (!fileName.endsWith(fileType)) {
                    alert("Only .txt files are allowed for upload.");
                    document.getElementById("<%=pnlPopup1.ClientID%>").style.display = 'none';
                    return false;
                }
            }
            return true;
        }

        function CallServerSideReducedRate() {
            var creditedDate = document.getElementById("<%=txtCreditedDate.ClientID%>");
            if (creditedDate != null) {
                if (checkDateFormat(creditedDate)) {
                    if (document.getElementById("<%=hdnFormType.ClientID%>").value == "Form26" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27E" || document.getElementById("<%=hdnFormType.ClientID%>").value == "Form27")
                        setTimeout(__doPostBack('<%=txtCreditedDate.UniqueID%>', 'Reducedrate'), 0);
                }
            }
        }

        function checkDateFormat(ObjectName) {
            var stringValue;
            var arrDate = new Array();
            var arrInput = new Array();
            var counter = 0;
            stringValue = ObjectName.value.trim()
            if (stringValue.length > 0) {
                if (stringValue.indexOf('/') > 0)
                    arrInput = stringValue.split('/');
                else if (stringValue.indexOf('\\') > 0)
                    arrInput = stringValue.split('\\');
                else if (stringValue.indexOf('.') > 0)
                    arrInput = stringValue.split('.');
                else if (stringValue.indexOf('-') > 0)
                    arrInput = stringValue.split('-');
                else if (stringValue.indexOf(',') > 0)
                    arrInput = stringValue.split(',');
                else if (stringValue.indexOf(' ') > 0)
                    arrInput = stringValue.split(' ');

                if (arrInput == '')
                    return false;
                else
                    return true;
            }
        }

        function CreateAllValidation() {
            if (alert("Some records have been skipped because they have an \ninvalid PAN structure, \nbut TDS has not been deducted at 20% \nor the 'Higher Rate 20%' remark is not selected."))
                return true;
        }

    </script>
    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="updatePanel" runat="server" OnLoad="updatePanelDeduction_Load">
        <ContentTemplate>
            <asp:Panel ID="pnlBulkExport" runat="server" Height="100px" BackColor="White" CssClass="modalPopup"
                Style="display: none">
                <br />
                <br />
                <asp:Label ID="lblBulkExport" Font-Size="Medium" Text="Exporting Data to Excel Sheet. Please Wait....."
                    Font-Bold="true" ForeColor="Red" runat="server"> </asp:Label>
            </asp:Panel>
            <asp:Panel ID="pnlBulkImport" runat="server" Height="100px" BackColor="White" CssClass="modalPopup"
                Style="display: none">
                <br />
                <br />
                <asp:Label ID="lblBulkImport" Font-Size="Medium" Text="Importing Excel Data. Please Wait....."
                    Font-Bold="true" ForeColor="Red" runat="server"> </asp:Label>
            </asp:Panel>
            <asp:Panel ID="pnlUpBlkUpdate" runat="server" BackColor="White" CssClass="modalPopup"
                Style="display: none">
                <asp:Label ID="lblExport_Heading" Text="BULK UPDATE - EXPORT" Font-Bold="true" ForeColor="Brown"
                    runat="server"> </asp:Label>
                <hr />
                <table>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td style="width: 100px">Correction Type
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlBlkUpdateType" runat="server" Width="140px" onChange="SetBulkUpdateType();">
                                <asp:ListItem Text="Select" Value="0"></asp:ListItem>
                                <asp:ListItem Text="ADD" Value="1"></asp:ListItem>
                                <asp:ListItem Text="UPDATE" Value="2"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <%--<asp:Button ID="btnOk" Text="Ok" runat="server" Width="70px" CssClass="cmnBtn" OnClick="btnOk_Click" OnClientClick="SetBulkUpdateType();" />--%>
                            <asp:Button ID="btnOk" Text="Ok" runat="server" Width="70px" CssClass="cmnBtn" OnClientClick="Show_Popup_Export();"
                                OnClick="btnExport_Click" />
                            <asp:Button ID="btnClosePopUp" Text="Close" runat="server" Width="70px" CssClass="cmnBtn" />
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlImport" runat="server" BackColor="White" CssClass="modalPopup"
                Width="400px" Style="display: none">
                <asp:Label ID="lblImport_Heading" Text="BULK UPDATE - IMPORT" Font-Bold="true" ForeColor="Brown"
                    runat="server"> </asp:Label>
                <hr />
                <table>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td style="width: 100px">Select File
                        </td>
                        <td>
                            <asp:FileUpload ID="fileUpload" runat="server" Width="300px" />
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td align="right">
                            <asp:Button ID="btnImportPopUp" Text="Import" runat="server" Width="70px" CssClass="cmnBtn"
                                OnClientClick="Show_Popup_Import();" OnClick="btnImportPopUp_Click" />
                            <asp:Button ID="btnCloseImportPopUp" Text="Close" runat="server" Width="70px" CssClass="cmnBtn" />
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:HiddenField ID="hdnChallanAmount" runat="server" Value="" />
            <asp:HiddenField ID="hdnViewExistingPageSize" runat="server" Value="1" />
            <asp:HiddenField ID="hdnViewExistingPageIndex" runat="server" Value="10" />
            <asp:HiddenField ID="hdnUpdatedDedsPageSize" runat="server" Value="10" />
            <asp:HiddenField ID="hdnUpdatedDedsPageIndex" runat="server" Value="1" />
            <asp:HiddenField ID="hdnBulkUpdatePageIndex" runat="server" Value="1" />
            <asp:HiddenField ID="hdnBulkUpdatePageSize" runat="server" Value="10" />
            <asp:HiddenField ID="hdnSelectedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnAddedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnUpdateItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnPANUpdateItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnExcludedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnUnlinkedDedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnDelete" runat="server" Value="" />
            <asp:HiddenField ID="hdnFormType" runat="server" />
            <asp:HiddenField ID="hdnFinYear" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnDeducteeSlNo" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnPanDeducteeSlNo" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnQuarter" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnDeductionSlNo" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnChallanSlNo" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnCorrStatus" runat="server" Value="5" />
            <asp:HiddenField ID="hdnIsNilChallan" runat="server" Value="N" />
            <asp:HiddenField ID="hdnSetColor" runat="server" Value="White" />
            <asp:HiddenField ID="hdnIsCorrEReturnValid" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnIsTran" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnIsValidPAN" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnIsExcludedDed" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnIsUnlinkedDed" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnBulkUpdateType" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnRoundOff" Value="1" runat="server" />
            <asp:HiddenField ID="hdnSectionID" Value="" runat="server" />
            <asp:HiddenField ID="hdnDeductorStatus" Value="" runat="server" />
            <asp:HiddenField ID="hdnAllow92A92B" Value="0" runat="server" />
            <asp:HiddenField ID="hdnisDelete" runat="server" Value="N" />
            <asp:HiddenField ID="hdnisUpdate" runat="server" Value="N" />
            <asp:HiddenField ID="hdnBulkDedSlNo" runat="server" Value="" />
            <asp:HiddenField ID="hdnGender" runat="server" Value="0" />
            <asp:HiddenField ID="hdnSeniorCitizen" runat="server" Value="0" />
            <asp:HiddenField ID="hdnChallanSectionID" runat="server" Value="" />
            <asp:HiddenField ID="hdnisUpdated" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsSearchParameterChanged" runat="server" Value="0" />
            <asp:HiddenField ID="hdnSearch" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsCBI" runat="server" Value="0" />
            <asp:HiddenField ID="hdnChallanDate" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnChallanSection" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnChallanID" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnIsEreturnAccNo" runat="server" Value="0" />
            <asp:HiddenField ID="hdnCorrectionID" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsBOB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsJK" runat="server" Value="0" />
            <asp:HiddenField ID="hdnPANSelectedItems" runat="server" Value="" />

            <cc1:ModalPopupExtender ID="popUpBlkUpdate" runat="server" CancelControlID="btnClosePopUp"
                BackgroundCssClass="modalBackground" TargetControlID="btnExport" PopupControlID="pnlUpBlkUpdate">
            </cc1:ModalPopupExtender>
            <cc1:ModalPopupExtender ID="popUpImport" runat="server" CancelControlID="btnCloseImportPopUp"
                BackgroundCssClass="modalBackground" TargetControlID="btnImport" PopupControlID="pnlImport">
            </cc1:ModalPopupExtender>
            <cc1:ModalPopupExtender ID="popUpBulkExport" BehaviorID="popUpBulkExport_Control"
                runat="server" CancelControlID="btnCloseImportPopUp" BackgroundCssClass="modalBackground"
                TargetControlID="lblBulkExport" PopupControlID="pnlBulkExport">
            </cc1:ModalPopupExtender>
            <cc1:ModalPopupExtender ID="popUpBulkImport" BehaviorID="popUpBulkImport_Control"
                runat="server" CancelControlID="btnCloseImportPopUp" BackgroundCssClass="modalBackground"
                TargetControlID="lblBulkImport" PopupControlID="pnlBulkImport">
            </cc1:ModalPopupExtender>
            <asp:MultiView ID="mvDeduction" runat="server" ActiveViewIndex="0">
                <asp:View ID="vwDeduction" runat="server">
                    <cc1:CollapsiblePanelExtender ID="pnlChallanCollapsible" runat="server" CollapseControlID="pnlChallanHeader"
                        CollapsedText="Show" CollapsedImage="~/App_Themes/Standard/Images/collapse.png"
                        ImageControlID="imgToggle" Collapsed="false" ExpandControlID="pnlChallanHeader"
                        ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlChallan" ExpandedImage="~/App_Themes/Standard/Images/expand.png">
                    </cc1:CollapsiblePanelExtender>
                    <cc1:CollapsiblePanelExtender ID="pnlDetailsCollapsible" runat="server" CollapseControlID="pnlDetailsHead"
                        CollapsedText="Show" CollapsedImage="~/App_Themes/Standard/Images/collapse.png"
                        ImageControlID="ImgToggleDetails" Collapsed="true" ExpandControlID="pnlDetailsHead"
                        ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlMoreDetails"
                        ExpandedImage="~/App_Themes/Standard/Images/expand.png">
                    </cc1:CollapsiblePanelExtender>
                    <cc1:CollapsiblePanelExtender ID="pnl27EQDetailsCollapsible" runat="server" CollapseControlID="pnl27EQMoreDetailsHeader"
                        CollapsedText="Show" CollapsedImage="~/App_Themes/Standard/Images/collapse.png"
                        ImageControlID="img27EQMoreDetailsToggle" Collapsed="false" ExpandControlID="pnl27EQMoreDetailsHeader"
                        ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnl27EQMoreDetails"
                        ExpandedImage="~/App_Themes/Standard/Images/expand.png">
                    </cc1:CollapsiblePanelExtender>
                    <cc1:CollapsiblePanelExtender ID="pnl27QAdditionalDetailsCollapsible" runat="server" CollapseControlID="pnlAdditionalFieldsHead"
                        CollapsedText="Show" CollapsedImage="~/App_Themes/Standard/Images/collapse.png"
                        ImageControlID="imgAdditionalFields" Collapsed="false" ExpandControlID="pnlAdditionalFieldsHead"
                        ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlAdditionalFields"
                        ExpandedImage="~/App_Themes/Standard/Images/expand.png">
                    </cc1:CollapsiblePanelExtender>
                    <table class="nTbl">
                        <tr>
                            <td valign="top">
                                <table class="nTbl">
                                    <tr>
                                        <td valign="top" style="margin-left: 0px; width: 50%">
                                            <table class="eCol" cellpadding="0" style="width: 100%">
                                                <tr>
                                                    <td class="vHCol">Serial No.
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtSlNo" runat="server" CssClass="txtBPL" Enabled="False" Width="97%"> </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Name
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtName" runat="server" onkeyup="ClearDeducteeName()" CssClass="txtBML"
                                                            Width="97%" TabIndex="1" onkeypress="return ValidateDelimiter(this,event);"></asp:TextBox>
                                                        <cc1:AutoCompleteExtender ID="autoCompleteExtender" runat="server" MinimumPrefixLength="2"
                                                            ServicePath="~/WebServices/AutoCompleteService.asmx" TargetControlID="txtName"
                                                            CompletionInterval="700" EnableCaching="false" CompletionSetCount="50" DelimiterCharacters=""
                                                            ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="True" OnClientItemSelected="GetDeducteeNameValue">
                                                        </cc1:AutoCompleteExtender>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">PAN
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtPAN" runat="server" CssClass="txtBML" Text="" MaxLength="10"
                                                            Enabled="false" TabIndex="2" onkeypress="return ValidateForAlphaNumeric(event);"
                                                            onBlur="ConvertToUC(this)" Width="97%"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Section
                                                    </td>
                                                    <td>
                                                        <asp:DropDownList ID="ddlSection" runat="server" AutoPostBack="true" CssClass="mCBs"
                                                            Width="91%" TabIndex="3" Font-Size="9" OnSelectedIndexChanged="ddlSection_SelectedIndexChanged">
                                                        </asp:DropDownList>
                                                        <asp:Button ID="btnSectionHelp" runat="server" Text="?" OnClientClick="ShowSectionHelp();return false;"
                                                            CssClass="cmnBtn" Height="20px" Width="20px" />
                                                    </td>
                                                </tr>
                                                <tr id="trAmtCashDrawn" runat="server" visible="false">
                                                    <td class="vHCol">Amount of Cash Withdrawal
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtAmtCashDrawn" runat="server" MaxLength="14" AutoComplete="Off" Width="97%"
                                                            onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                            onkeyup="CalculateValues()" onBlur="ClearAOCW();" TabIndex="4" CssClass="txtBMR"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol" id="tdAmtPay" runat="server">Amount of Payment
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtAmountOfPayment" runat="server" MaxLength="14" AutoComplete="Off" Width="97%"
                                                            onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                            onkeyup="CalculateValues()" onBlur="ClearAOP();" TabIndex="4" CssClass="txtBMR"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr runat="server" id="rowForm27EDeductedDate">
                                                    <td class="vHCol">Total Value of Pur.(s)
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtTotalValueOfPurchase" runat="server" MaxLength="14" AutoComplete="Off" Width="97%"
                                                            onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                            onkeyup="CalculateValues()" onBlur="ClearAOP(this);" TabIndex="5" CssClass="txtBMR"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">
                                                        <asp:Label ID="lblpaidDate" runat="server" Text="Paid/Credited Date"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtCreditedDate" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                                            runat="server" Width="97%" BackColor="#E5E5E5" AutoComplete="Off" CssClass="txtBPR"
                                                            TabIndex="5" onBlur="setDateFormat(this);CallServerSideReducedRate();"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">
                                                        <asp:Label ID="lblIncomeTaxPercAndAmnt" runat="server" Text="Income Tax(% and Amt)">
                                                        </asp:Label>
                                                    </td>
                                                    <td>
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                                            <tr style="width: 100%">
                                                                <td width="50px">
                                                                    <asp:TextBox ID="txtITRate" runat="server" CssClass="txtBPR" Style="width: 50px;"
                                                                        AutoComplete="Off" MaxLength="14" TabIndex="6" onchange="return checkDecimalNo(this);"
                                                                        onkeypress="return numeralsOnly(this, event,2,3,0,1);" onkeyup="CalculateValues()"></asp:TextBox>
                                                                </td>
                                                                <td align="left">
                                                                    <asp:TextBox ID="txtITAmount" runat="server" CssClass="txtBPR" Style="width: 97%;"
                                                                        AutoComplete="Off" MaxLength="14" TabIndex="7" onchange="return checkDecimalNo(this);"
                                                                        onkeypress="return numeralsOnly(this, event,11,2,0,1);" onkeyup="CalculateValues();"></asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Surcharge (% and Amt)
                                                    </td>
                                                    <td>
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                                            <tr style="width: 100%">
                                                                <td width="50px">
                                                                    <asp:TextBox ID="txtSurchargeRate" runat="server" CssClass="txtBPR" Style="width: 50px;"
                                                                        AutoComplete="Off" TabIndex="8" MaxLength="14" onchange="return checkDecimalNo(this);"
                                                                        onkeypress="return numeralsOnly(this, event,2,3,0,1);" onkeyup="CalculateValues()"></asp:TextBox>
                                                                </td>
                                                                <td>
                                                                    <asp:TextBox ID="txtSurchargeAmount" runat="server" CssClass="txtBPR" Style="width: 97%;"
                                                                        AutoComplete="Off" TabIndex="9" MaxLength="14" onchange="return checkDecimalNo(this);"
                                                                        onkeypress="return numeralsOnly(this, event,11,2,0,1);" onkeyup="CalculateValues()"></asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Edu Cess (% and Amt)
                                                    </td>
                                                    <td>
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                                            <tr style="width: 100%">
                                                                <td width="50px">
                                                                    <asp:TextBox ID="txtEduCessRate" runat="server" CssClass="txtBPR" Style="width: 50px;"
                                                                        AutoComplete="Off" MaxLength="14" onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,2,3,0,1);"
                                                                        onkeyup="CalculateValues()" TabIndex="10"></asp:TextBox>
                                                                </td>
                                                                <td>
                                                                    <asp:TextBox ID="txtEduCessAmount" runat="server" CssClass="txtBPR" Style="width: 97%;"
                                                                        AutoComplete="Off" TabIndex="11" MaxLength="14" onchange="return checkDecimalNo(this);"
                                                                        onkeypress="return numeralsOnly(this, event,11,2,0,1);" onkeyup="CalculateValues()"></asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">
                                                        <table class="vHCol" cellpadding="0" cellspacing="0">
                                                            <tr>
                                                                <td>
                                                                    <asp:Label ID="lbltaxDed" runat="server" Text="Tax Deducted"></asp:Label>
                                                                </td>
                                                                <td>
                                                                    <asp:CheckBox ID="chkEdit" Text="Edit" runat="server" Checked="true" />
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                    <td>
                                                        <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                                            <tr style="width: 100%">
                                                                <td width="50px">
                                                                    <asp:TextBox ID="txtTaxRate" runat="server" MaxLength="14" CssClass="txtboxRO" AutoComplete="Off"
                                                                        Style="width: 50px;" Enabled="false"></asp:TextBox>
                                                                </td>
                                                                <td>
                                                                    <asp:TextBox ID="txtTaxDeducted" runat="server" AutoComplete="Off" CssClass="txtboxRO"
                                                                        Style="width: 97%;" MaxLength="14" Enabled="false">                                                
                                                                    </asp:TextBox>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                                <tr runat="server" id="rowAccountNumber" visible="false">
                                                    <td class="vHCol">Account Number
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtAccountNumber" runat="server" MaxLength="20" AuttoComplete="off"
                                                            TabIndex="5" CssClass="txtBMR" Width="97%">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td class="eCol" valign="top" style="width: 50%">
                                            <table style="width: 90%">
                                                <tr>
                                                    <td class="vHCol">
                                                        <asp:Label ID="lbltaxDedDate" runat="server" Text="Tax Deducted Date"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtTaxDedDate" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)" Width="97%"
                                                            runat="server" CssClass="txtBPR" TabIndex="12" AutoComplete="Off" onBlur="setDateFormat(this);"></asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td></td>
                                                    <td class="iCol">
                                                        <asp:CheckBox ID="chkBookEntry" runat="server" Text="Book Entry" TabIndex="13" />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">Non Deduction Reason
                                                    </td>
                                                    <td>
                                                        <asp:DropDownList ID="ddlNonDeductionReason" runat="server" Width="97%" TabIndex="15"
                                                            OnChange="SetNonDedReason(); CalculateValues();">
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr runat="server" id="rowCertNo">
                                                    <td class="vHCol">
                                                        <asp:Label ID="lblCertNo" runat="server" Text="U/s 197 Cert. No."></asp:Label>
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtCertNo" runat="server" Width="97%" TabIndex="15" CssClass="txtBPL"
                                                            MaxLength="20">
                                                        </asp:TextBox>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td class="vHCol">
                                                        <asp:Label ID="lblGrossingUpIndicator" runat="server" Text="Grossing up Indicator"></asp:Label>
                                                    </td>
                                                    <td>
                                                        <asp:DropDownList ID="ddlGrossingUpIndicator" runat="server" Width="97%" TabIndex="16">
                                                            <asp:ListItem Text="Yes" Value="True">
                                                            </asp:ListItem>
                                                            <asp:ListItem Text="No" Value="False"></asp:ListItem>
                                                        </asp:DropDownList>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" width="100%">
                                                        <asp:Panel ID="PnlResidentDetails" runat="server" CssClass="dialog" Style="border-top-width: 0px"
                                                            Visible="false">
                                                            <div style="padding: 10px; border-top: solid 1px gray" id="Div1" runat="server">
                                                                <table>
                                                                    <tr>
                                                                        <td class="vHCol" width="355px">Deductee is Non-Resident
                                                                        </td>
                                                                        <td class="iCol" style="padding-left: 5px">
                                                                            <asp:DropDownList ID="ddlDedNonRes" runat="server" CssClass="mdropDownList" Width="100px"
                                                                                AutoPostBack="true" OnSelectedIndexChanged="ddlDedNonRes_SelectedIndexChanged">
                                                                                <asp:ListItem Text="Select" Value=""></asp:ListItem>
                                                                                <asp:ListItem Text="Yes" Value="Y"></asp:ListItem>
                                                                                <asp:ListItem Text="No" Value="N"></asp:ListItem>
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="355px">Deductee is having Permanent Establishment in India
                                                                        </td>
                                                                        <td class="iCol" style="padding-left: 5px">
                                                                            <asp:DropDownList ID="ddlDedPerEstaIndia" runat="server" CssClass="dropDownList"
                                                                                Width="100px">
                                                                                <asp:ListItem Text="Select" Value=""></asp:ListItem>
                                                                                <asp:ListItem Text="Yes" Value="Y"></asp:ListItem>
                                                                                <asp:ListItem Text="No" Value="N"></asp:ListItem>
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr runat="server" id="tr27EQMoreDetails">
                                                    <td colspan="2" width="100%">
                                                        <asp:Panel ID="pnl27EQMoreDetailsHeader" runat="server" CssClass="dHeader" Style="cursor: hand">
                                                            More Details
                                                            <asp:Image ID="img27EQMoreDetailsToggle" runat="server" Style="margin-left: 215px; cursor: hand" />
                                                        </asp:Panel>
                                                        <asp:Panel ID="pnl27EQMoreDetails" runat="server" CssClass="dialog" Style="border-top-width: 0px">
                                                            <div style="padding: 10px; border-top: solid 1px gray" id="div27EQMoreDetails" runat="server">
                                                                <table>
                                                                    <tr>
                                                                        <td width="300px">Is Payment by Collectee liable to TDS ?
                                                                        </td>
                                                                        <td width="80px">
                                                                            <asp:DropDownList ID="ddl27EQLiableOption" runat="server" CssClass="dropDownList"
                                                                                Width="80px">
                                                                                <asp:ListItem Text="Yes" Value="1"></asp:ListItem>
                                                                                <asp:ListItem Text="No" Value="0"></asp:ListItem>
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                                <table>
                                                                    <tr>
                                                                        <td width="80px">Challan No.
                                                                        </td>
                                                                        <td width="110px">
                                                                            <asp:TextBox ID="txt27EQChallanNo" runat="server" CssClass="txtBPR" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                                                MaxLength="5" Style="width: 92px; text-align: right"> 
                                                                            </asp:TextBox>
                                                                        </td>
                                                                        <td width="65px">Paid Date
                                                                        </td>
                                                                        <td>
                                                                            <asp:TextBox ID="txt27EQPaidDate" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                                                                runat="server" Width="110px" AutoComplete="Off" CssClass="txtBPR" onBlur="setDateFormat(this);"></asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colspan="2" width="100%" id="ChallanDetail">
                                                        <asp:Panel ID="pnlChallanHeader" runat="server" CssClass="dHeader" Style="cursor: hand">
                                                            Challan Details
                                                            <asp:Image ID="imgToggle" runat="server" Style="margin-left: 215px; cursor: hand" />
                                                        </asp:Panel>
                                                        <asp:Panel ID="pnlChallan" runat="server" CssClass="dialog" Style="border-top-width: 0px">
                                                            <div style="padding: 10px; border-top: solid 1px gray" id="challanDiv" runat="server">
                                                                <table>
                                                                    <tr>
                                                                        <td width="130px">Serial No.
                                                                        </td>
                                                                        <td style="padding-left: 32px">
                                                                            <asp:TextBox ID="txtChallanID" runat="server" onkeyup="ClearChallanDetail()" CssClass="txtBML"
                                                                                Width="200px" TabIndex="1" onkeypress="return ValidateDelimiter(this,event);"
                                                                                ToolTip="ChallanSerialNo-BankChallanNo-BSRCode-ChallanPaidDate"></asp:TextBox>
                                                                            <cc1:AutoCompleteExtender ID="autoCompleteExtender1" runat="server" MinimumPrefixLength="1"
                                                                                ServicePath="~/WebServices/AutoCompleteService.asmx" TargetControlID="txtChallanID"
                                                                                ServiceMethod="GetCorrChallanSerialNo" CompletionInterval="700" EnableCaching="false"
                                                                                CompletionSetCount="20" DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true"
                                                                                FirstRowSelected="True" OnClientItemSelected="GetChallanDetail">
                                                                            </cc1:AutoCompleteExtender>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Total Amount
                                                                        </td>
                                                                        <td class="iCol" style="padding-left: 32px">
                                                                            <asp:TextBox ID="txtTotalAmount" runat="server" MaxLength="14" CssClass="txtboxRO"
                                                                                Style="width: 200px;" Enabled="false"> </asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr runat="server" id="rowMoreDetails">
                                                    <td colspan="2" width="100%" id="Td2">
                                                        <asp:Panel runat="server" CssClass="dHeader" ID="pnlDetailsHead" Style="cursor: hand">
                                                            More Details<br />
                                                            <asp:Image ID="ImgToggleDetails" runat="server" Style="margin-left: 215px; cursor: hand" />
                                                        </asp:Panel>
                                                        <asp:Panel ID="pnlMoreDetails" runat="server" CssClass="dialog" Style="border-top-width: 0px">
                                                            <div style="padding: 10px; border-top: solid 1px gray" id="Div2" runat="server">
                                                                <table>
                                                                    <tr>
                                                                        <td>TDS Rate as per
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:DropDownList ID="ddlRateType" runat="server" TabIndex="16" CssClass="dropDownList"
                                                                                Width="200px">
                                                                                <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                                                                <asp:ListItem Text="IT Act" Value="A"></asp:ListItem>
                                                                                <asp:ListItem Text="DTAA" Value="B"></asp:ListItem>
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td width="130px">15CA Ack. No.
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:TextBox ID="txtAckNo" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="12"
                                                                                onkeypress="return ValidateForAlphaNumeric(event);" onBlur="ConvertToUC(this);">
                                                                            </asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Nature of Remittance
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:DropDownList ID="ddlNatureofRemittance" runat="server" TabIndex="16" CssClass="mdropDownList"
                                                                                Width="200px">
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Country of Residence
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:DropDownList ID="ddlCountries" runat="server" TabIndex="16" CssClass="mdropDownList"
                                                                                Width="200px">
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Deductee Email
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:TextBox ID="txtEmailDed" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="75"
                                                                                onchange="return checkValidEmail(this);">
                                                                            </asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Deductee Contact No.
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:TextBox ID="txtContactNoDed" runat="server" TabIndex="16" CssClass="txtBPL"
                                                                                MaxLength="15" onchange="return checkValidContactNo(this);">
                                                                            </asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Deductee Address
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:TextBox ID="txtAddressDed" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="150"
                                                                                onchange="return checkValidDedAddress(this);">
                                                                            </asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>Deductee Identification No.
                                                                        </td>
                                                                        <td class="iCol">
                                                                            <asp:TextBox ID="txtIdentNumDed" runat="server" TabIndex="16" CssClass="txtBPL" MaxLength="25"
                                                                                onchange="return InputValidationsForIdentNum(this);">
                                                                            </asp:TextBox>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                                <tr id="rowAdditionalDetails" runat="server">
                                                    <td colspan="2" width="100%" id="AdditionalFields">
                                                        <asp:Panel ID="pnlAdditionalFieldsHead" runat="server" CssClass="dHeader" Style="cursor: hand">
                                                            Additional Details
                                                            <asp:Image ID="imgAdditionalFields" runat="server" Style="margin-left: 215px; cursor: hand" />
                                                        </asp:Panel>
                                                        <asp:Panel ID="pnlAdditionalFields" runat="server" CssClass="dialog" Style="border-top-width: 0px">
                                                            <div style="padding: 10px; border-top: solid 1px gray" id="Div3" runat="server">
                                                                <table>
                                                                    <tr id="row115bac" runat="server">
                                                                        <td width="130px">Regime Type Set
                                                                        </td>
                                                                        <td colspan="4">
                                                                            <asp:RadioButtonList ID="rbtn115bac" runat="server" RepeatDirection="Horizontal">
                                                                                <asp:ListItem runat="server" id="oldRegime" Text="Old Regime" Value="0"></asp:ListItem>
                                                                                <asp:ListItem runat="server" id="newRegime" Text="New Regime" Value="1" Selected="True"></asp:ListItem>
                                                                            </asp:RadioButtonList>
                                                                        </td>
                                                                    </tr>
                                                                    <tr id="rowfor27E" runat="server">
                                                                        <td width="130px">
                                                                            <asp:Label ID="lblFor" runat="server" Text="For 27/27E."></asp:Label>
                                                                        </td>
                                                                        <td>
                                                                            <asp:DropDownList ID="cmbDeducteeCode" runat="server" Width="200px" TabIndex="16"
                                                                                Font-Size="9" CssClass="mCBs">
                                                                                <asp:ListItem Text="SELECT" Value="-1" />
                                                                                <asp:ListItem Text="01-Company" Value="1" />
                                                                                <asp:ListItem Text="02-Individual" Value="2" />
                                                                                <asp:ListItem Text="03-Hindu Undivided Family" Value="3" />
                                                                                <asp:ListItem Text="04-Association of Persons (AOP) except in case of AOP consisting of only companies as its members" Value="4" />
                                                                                <asp:ListItem Text="05-Association of Persons (AOP) consisting of only companies as its members" Value="5" />
                                                                                <asp:ListItem Text="06-Co-operative Society" Value="6" />
                                                                                <asp:ListItem Text="07-Firm" Value="7" />
                                                                                <asp:ListItem Text="08-Body of individuals" Value="8" />
                                                                                <asp:ListItem Text="09-Artificial juridical person referred to in sub-clause (vii) of clause (31)" Value="9" />
                                                                                <asp:ListItem Text="10-Others" Value="10" />
                                                                            </asp:DropDownList>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </asp:Panel>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td class="iCol">
                                <table>
                                    <tr>
                                        <td id="rwNote" runat="server" visible="false" style="padding-bottom: 10px" colspan="7">
                                            <span><b>Note: </b></span>
                                            <asp:Label ID="lblmsg" runat="server" Text="" Style="color: Blue;"></asp:Label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <asp:Button ID="btnViewExisting" runat="server" CssClass="cmnBtn" Text="View Existing"
                                                OnClick="btnViewExisting_Click" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnNew" Text="New" runat="server" TabIndex="18" CssClass="cmnBtn"
                                                UseSubmitBehavior="False" OnClick="btnNew_Click" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnUpdate" Text="Update" OnClientClick="return Validations();" runat="server"
                                                CssClass="cmnBtn" TabIndex="17" OnClick="btnUpdate_Click" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnBlkUpdate" Text="Bulk Update" runat="server" CssClass="cmnBtn"
                                                OnClick="btnOk_Click" OnClientClick="SetBulkUpdateType();" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnRemove" runat="server" Text="Remove" CssClass="cmnBtn" OnClientClick="return OnConfirm();"
                                                OnClick="btnRemove_Click" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnClose" runat="server" Text="Close" CssClass="cmnBtn" OnClick="btnClose_Click" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnOpenSearch" runat="server" Text="Search" TabIndex="20" CssClass="cmnBtn"
                                                OnClientClick="SetStatus();return false;" Width="80px" OnClick="btnOpenSearch_Click" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Panel ID="pnlSearch" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel">
                                    <table>
                                        <tr>
                                            <td colspan="2" width="20%">Serial No.
                                            </td>
                                            <td colspan="3">
                                                <asp:TextBox ID="txtSearchDedSerialNo" runat="server" Width="90%" TabIndex="20"
                                                    CssClass="txtBPL" onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75"
                                                    onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td colspan="2" width="17%">
                                                <asp:Label ID="lblSearchSection" Text="Section" runat="server"></asp:Label>
                                            </td>
                                            <td colspan="3">
                                                <asp:Panel ID="Panel2" runat="server" Style="background-color: white; width: 191px; border-right: 1px solid #9f9f9f; border-left: 1px solid #9f9f9f; border-bottom: 1px solid #9f9f9f">
                                                    <asp:CheckBoxList ID="chkSections" runat="server">
                                                    </asp:CheckBoxList>
                                                </asp:Panel>
                                                <asp:TextBox ID="txtSection" runat="server" CssClass="txtBPL" Width="90%"></asp:TextBox>
                                                <cc1:PopupControlExtender ID="PopEx" runat="server" TargetControlID="txtSection"
                                                    PopupControlID="Panel2" Position="Bottom" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">Name
                                            </td>
                                            <td colspan="3">
                                                <asp:TextBox ID="txtSearchName" runat="server" Width="90%" TabIndex="20" CssClass="txtBPL"
                                                    onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td colspan="2">PAN
                                            </td>
                                            <td colspan="3">
                                                <asp:DropDownList ID="ddlSearchPAN" runat="server" Width="92%" CssClass="dropDownList">
                                                    <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                                    <asp:ListItem Text="PAN Given" Value="1"></asp:ListItem>
                                                    <asp:ListItem Text="PANAPPLIED" Value="2"></asp:ListItem>
                                                    <asp:ListItem Text="PANINVALID" Value="3"></asp:ListItem>
                                                    <asp:ListItem Text="PANNOTAVBL" Value="4"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td id="PaymentAmtSearch" runat="server">Amount of Payment
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px; width: 10px" align="right">From
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSearchAmountFrom" runat="server" Width="100px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="22"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px; width: 10px" align="right">To
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSearchAmountTo" runat="server" Width="100px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="23"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td>
                                                <asp:Label ID="lblSearchPaidDate" Text="Paid/Credited Date" runat="server"></asp:Label>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px; width: 10px" align="right">From
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSearchPaidDateFrom" runat="server" Width="100px" CssClass="txtBPR"
                                                    onBlur="setDateFormat(this);" TabIndex="24" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px; width: 10px" align="right">To
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSearchPaidDateTo" runat="server" Width="100px" CssClass="txtBPR"
                                                    onBlur="setDateFormat(this);" TabIndex="25" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Label ID="lblSearchDeducted" Text="Tax Deducted Amount" runat="server"></asp:Label>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px; width: 10px" align="right">From
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSrchTaxDeductedFrom" runat="server" Width="100px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="26"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px; width: 10px" align="right">To
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSrchTaxDeductedTo" runat="server" Width="100px" onkeypress="return numeralsOnly(this, event,11,2,0,1);"
                                                    Style="border: 1px solid #9f9f9f; text-align: right" MaxLength="14" TabIndex="27"
                                                    onchange="ParameterChanged();" CssClass="txtBPL"></asp:TextBox>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td>
                                                <asp:Label ID="lblSearchDeductedDate" Text="Tax Deducted Date" runat="server"></asp:Label>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px; width: 10px" align="right">From
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSrchTaxDateFrom" runat="server" Width="100px" CssClass="txtBPR"
                                                    onBlur="setDateFormat(this);" TabIndex="28" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                            <td style="padding-left: 2px; font-size: 9px; width: 10px" align="right">To
                                            </td>
                                            <td width="80px">
                                                <asp:TextBox ID="txtSrchTaxDateTo" runat="server" Width="100px" CssClass="txtBPR"
                                                    onBlur="setDateFormat(this);" TabIndex="29" onchange="ParameterChanged();"></asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">Non Deduction Reason
                                            </td>
                                            <td colspan="3">
                                                <asp:DropDownList ID="ddlSearchNonDedReason" runat="server" Width="92%" TabIndex="20"
                                                    CssClass="dropDownList">
                                                </asp:DropDownList>
                                            </td>
                                            <td style="width: 25px"></td>
                                            <td colspan="5" align="left" id="tdReferenceNo" runat="server"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="6">
                                                <table>
                                                    <tr>
                                                        <td align="right">
                                                            <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="cmnBtn" TabIndex="30"
                                                                OnClientClick="return FormatSearch();" OnClick="btnSearch_Click" />
                                                        </td>
                                                        <td>
                                                            <asp:Button ID="btnShowAll" runat="server" Text="Show All" CssClass="cmnBtn" OnClientClick="return ShowAllclick();"
                                                                OnClick="btnShowAll_Click" />
                                                        </td>
                                                        <td>
                                                            <asp:Button ID="btnClose1" runat="server" Text="Close" Width="80px" CssClass="cmnBtn"
                                                                OnClientClick="SetStatus();" TabIndex="32" OnClick="btnClose1_Click" />
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                                    Visible="false" Width="1050px">
                                    <asp:Repeater ID="rptrUpdatedDeductions" runat="server" OnItemCommand="rptrUpdatedDeductions_ItemCommand"
                                        OnItemDataBound="rptrUpdatedDeductions_ItemDataBound">
                                        <HeaderTemplate>
                                            <table id="NavTable">
                                                <tr bgcolor="#EEEEEE">
                                                    <th>Action
                                                    </th>
                                                    <th style="display: none">
                                                        <asp:Label runat="server" ID="lblCorrectionType" Width="150px" Text="Correction Type" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="Label17" Width="150px" Text="Correction Type" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblDedSlNo" Width="60px" Text="Serial No." />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblName" Width="250px" Text="Name" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblPAN" Width="90px" Text="PAN" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblAmountOfPayment" Width="150px" Text="Amount Of Payment" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label8" Text="Paid/Credited Date" runat="server" Width="150px"></asp:Label>
                                                    </th>
                                                    <th id="ITRateHeader" runat="server">
                                                        <asp:Label runat="server" ID="lblIncomeTaxRate" Width="130px" Text="Income Tax Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="Label2" Width="130px" Text="Income Tax" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label10" Text="Surcharge Rate" runat="server" Width="130px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label9" runat="server" Width="130px" Text="Surcharge" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblCessRate" Width="130px" Text="Cess Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label11" runat="server" Width="130px" Text="Cess" />
                                                    </th>
                                                    <th id="TaxRateHeader" runat="server">
                                                        <asp:Label runat="server" ID="Label5" Width="130px" Text="TaxRate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblTaxDeducted" Width="100px" Text="Tax Deducted" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblTaxDedDate" Width="130px" Text=" Tax Deducted Date" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="Label7" Width="100px" Text="Challan No." />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label12" runat="server" Width="290px" Text="Non Deduction Reason" />
                                                    </th>
                                                    <th runat="server" id="thCertNo">
                                                        <asp:Label ID="Label14" runat="server" Width="120px" Text="Certificate No." />
                                                    </th>
                                                    <th id="BookEntryHeader" runat="server">
                                                        <asp:Label ID="Label4" runat="server" Width="100px" Text="Book Entry" />
                                                    </th>
                                                    <th id="GrossingUpHeader" runat="server">
                                                        <asp:Label ID="Label1" runat="server" Width="160px" Text="Grossing Up Indicator" />
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white">
                                                <td>
                                                    <asp:LinkButton ID="lnkEdit" runat="server" Text="Edit" TabIndex="18" CommandName="Edit"
                                                        CommandArgument='<%#Eval("DeductionSlNo") %>'></asp:LinkButton>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label runat="server" ID="lblCorrType" Width="100px" Text='<%# Eval("CorrectionType")%>' />
                                                </td>
                                                <td>
                                                    <asp:Label runat="server" ID="lblCorr" Width="100px" Text='<%# Eval("Correction")%>' />
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label runat="server" ID="lblDedSerialNo" Text='<%# Eval("DeductionSlNo")%>' />
                                                </td>
                                                <td>
                                                    <%# Eval("Name")%>
                                                </td>
                                                <td>
                                                    <%# Eval("PAN")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%#Eval("AmountOfPayment")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("PaymentDate")%>
                                                </td>
                                                <td id="ITRateData" runat="server" style="text-align: right">
                                                    <%# Eval("IncomeTaxRate")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("IncomeTax")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("SurchargeRate") %>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("Surcharge") %>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("EducationCessRate")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("EducationCess")%>
                                                </td>
                                                <td id="TaxRateData" runat="server" style="text-align: right">
                                                    <%# Eval("TaxRate")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TaxDeducted")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TaxDeductedDate")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("ChallanNo")%>
                                                </td>
                                                <td>
                                                    <%# Eval("NonDedReason")%>
                                                </td>
                                                <td id="tdCertNo" runat="server">
                                                    <%# Eval("CertificateNo")%>
                                                </td>
                                                <td id="BookEntryData" runat="server" style="text-align: center">
                                                    <%# Eval("BookEntry")%>
                                                </td>
                                                <td id="GrossingUpData" runat="server" style="text-align: center">
                                                    <%# Eval("GrossingUp")%>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px" align="right"
                                    id="tblPagination" runat="server" visible="false">
                                    <tr style="height: 20px!important">
                                        <td style="padding: 0px 0px 0px 0px">
                                            <asp:Label ID="lblUpdatedDedsRecPerPage" runat="server" Text="Records per page : "
                                                Font-Size="X-Small" />
                                        </td>
                                        <td style="width: 50px; padding-top: 2px;">
                                            <asp:DropDownList ID="ddlUpdatedDedsGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                AutoPostBack="true" Font-Size="X-Small" OnSelectedIndexChanged="ddlUpdatedDedsGoTo_SelectedIndexChanged">
                                                <asp:ListItem Text="5" Value="5" />
                                                <asp:ListItem Text="10" Value="10" />
                                                <asp:ListItem Text="15" Value="15" />
                                                <asp:ListItem Text="20" Value="20" />
                                                <asp:ListItem Text="25" Value="25" />
                                                <asp:ListItem Text="50" Value="50" />
                                                <asp:ListItem Text="75" Value="75" />
                                                <asp:ListItem Text="100" Value="100" />
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblUpdatedDedsGridStatus" runat="server" Style="float: left;" Text=""
                                                Font-Size="X-Small"></asp:Label>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnUpdatedDedsFirst" runat="server" Text="&lt;&lt;" Width="35px"
                                                Font-Names="Arial" Font-Overline="False" Font-Size="X-Small" CssClass="navButton"
                                                Enabled="False" OnClick="btnUpdatedDedsFirst_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnUpdatedDedsPrevious" runat="server" Text="&lt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                                                OnClick="btnUpdatedDedsPrevious_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtUpdatedDedsGoToPage" runat="server" Text="1" CssClass="navTextBox"
                                                AutoPostBack="True" MaxLength="5" OnTextChanged="txtUpdatedDedsGoToPage_TextChanged"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnUpdatedDedsNext" runat="server" Text="&gt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" OnClick="btnUpdatedDedsNext_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnUpdatedDedsLast" runat="server" Text="&gt;&gt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" OnClick="btnUpdatedDedsLast_Click"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </asp:View>
                <asp:View ID="vwViewExisting" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td>
                                <table>
                                    <tr>
                                        <td>Section
                                        </td>
                                        <td>
                                            <asp:DropDownList ID="ddlViewExistingSection" runat="server" Width="140px">
                                            </asp:DropDownList>
                                        </td>
                                        <td>Name
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtViewExisitingName" Width="150px" CssClass="txtBPL" runat="server"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Ch SNo
                                        </td>
                                        <td>
                                            <asp:DropDownList ID="ddlChaSlNo" runat="server" Width="70px">
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingLoad" runat="server" CssClass="cmnBtn" Text="Load"
                                                Width="50px" OnClick="btnViewExistingLoad_Click" />
                                        </td>
                                        <td>
                                            <cc1:MutuallyExclusiveCheckBoxExtender ID="MutuallyExclusiveCheckBoxExtender2" runat="server"
                                                TargetControlID="chkShowExcludeDedDetails" Key="chkDeductions">
                                            </cc1:MutuallyExclusiveCheckBoxExtender>
                                            <asp:CheckBox ID="chkShowExcludeDedDetails" runat="server" Checked="false" Text="Show Excluded Deduction Details"
                                                AutoPostBack="true" OnCheckedChanged="chkShowExcludeDedDetails_CheckedChanged" />
                                            <cc1:MutuallyExclusiveCheckBoxExtender ID="MutuallyExclusiveCheckBoxExtender1" runat="server"
                                                TargetControlID="chkShowAllRecords" Key="chkDeductions">
                                            </cc1:MutuallyExclusiveCheckBoxExtender>
                                            <asp:CheckBox ID="chkShowAllRecords" runat="server" Checked="false" Text="Show All Deduction Details"
                                                AutoPostBack="true" OnCheckedChanged="chkShowAllRecords_CheckedChanged" />
                                            <asp:CheckBox ID="chkShowUnlinkDedDetails" runat="server" Checked="false" Text="Show Unlinked Deduction Details"
                                                AutoPostBack="true" OnCheckedChanged="chkShowUnlinkDedDetails_CheckedChanged" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="8">
                                            <br />
                                            <span>
                                                <asp:Label ID="Label17" runat="server" BorderStyle="Solid" BorderWidth="2px" Height="10px"
                                                    Width="20px" BackColor="#FFFFDD"></asp:Label>
                                                &nbsp;<b style="font-size: 11.5px;">The case has been identified for prosecution. Please contact your jurisdictional TDS Assessing Officer for further details</b></span>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td id="rptrTD" runat="server">
                                <asp:Panel ID="viewExistingNavPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                                    Width="1050px">
                                    <asp:Repeater ID="rptrExistingDeductions" runat="server" OnItemDataBound="rptrExistingDeductions_ItemDataBound">
                                        <HeaderTemplate>
                                            <table id="NavTable" border="0">
                                                <tr bgcolor="#EEEEEE">
                                                    <th runat="server" id="thSelect">Select
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblDedSlNo" Width="60px" Text="Serial No." />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblName" Width="250px" Text="Name" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblPAN" Width="90px" Text="PAN" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblSection" Width="80px" Text="Section" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblAmountOfPayment" Width="150px" Text="Amount Of Payment" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label8" Text="Paid/Credited Date" runat="server" Width="130px"></asp:Label>
                                                    </th>
                                                    <th id="ITRateHeader" runat="server">
                                                        <asp:Label runat="server" ID="lblIncomeTaxRate" Width="130px" Text="Income Tax Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="Label2" Width="100px" Text="Income Tax" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label10" Text="Surcharge Rate" runat="server" Width="130px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label9" runat="server" Width="100px" Text="Surcharge" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblCessRate" Width="130px" Text="Cess Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label11" runat="server" Width="100px" Text="Cess" />
                                                    </th>
                                                    <th id="TaxRateHeader" runat="server">
                                                        <asp:Label runat="server" ID="Label6" Width="130px" Text="Tax Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblTaxDeducted" Width="100px" Text="Tax Deducted" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblTaxDedDate" Width="130px" Text=" Tax Deducted Date" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="Label7" Width="100px" Text="Challan No." />
                                                    </th>
                                                    <th style="display: none">
                                                        <asp:Label ID="Label13" runat="server" Width="10px" Text="Value" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label12" runat="server" Width="290px" Text="Non Deduction Reason" />
                                                    </th>
                                                    <th id="BookEntryHeader" runat="server">
                                                        <asp:Label ID="Label4" runat="server" Width="100px" Text="Book Entry" />
                                                    </th>
                                                    <th id="GrossingUpHeader" runat="server">
                                                        <asp:Label ID="Label1" runat="server" Width="160px" Text="Grossing Up Indicator" />
                                                    </th>
                                                    <th id="ModeHeader" runat="server" style="display: none;">
                                                        <asp:Label ID="Label16" runat="server" Text="Mode" />
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white" id="trded">
                                                <td style="text-align: center" id="tdSelect" runat="server">
                                                    <asp:CheckBox ID="chkExistingDedsSelect" runat="server" class="dedCheckBox" />
                                                </td>
                                                <td id="tddedslno" runat="server" style="text-align: right">
                                                    <asp:Label ID="lblDedSlNo" Text='<%# Eval("DeductionSlNo")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdname" runat="server">
                                                    <%# Eval("Name")%>
                                                </td>
                                                <td id="tdpan" runat="server">
                                                    <%# Eval("PAN")%>
                                                </td>
                                                <td id="tdsection" runat="server">
                                                    <asp:Label ID="lblSection" Text='<%#Eval("Section") %>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdamtpay" runat="server" style="text-align: right">
                                                    <%#Eval("AmountOfPayment")%>
                                                </td>
                                                <td id="tdpaiddate" runat="server" style="text-align: left">
                                                    <%# Eval("PaymentDate")%>
                                                </td>
                                                <td id="ITRateData" runat="server" style="text-align: right">
                                                    <%# Eval("IncomeTaxRate")%>
                                                </td>
                                                <td id="tditamt" runat="server" style="text-align: right">
                                                    <%# Eval("IncomeTax")%>
                                                </td>
                                                <td id="tdsurchargerate" runat="server" style="text-align: right">
                                                    <%# Eval("SurchargeRate") %>
                                                </td>
                                                <td id="tdsurcharge" runat="server" style="text-align: right">
                                                    <%# Eval("Surcharge") %>
                                                </td>
                                                <td id="tdcessrate" runat="server" style="text-align: right">
                                                    <%# Eval("EducationCessRate")%>
                                                </td>
                                                <td id="tdcess" runat="server" style="text-align: right">
                                                    <%# Eval("EducationCess")%>
                                                </td>
                                                <td id="TaxRateData" runat="server" style="text-align: right">
                                                    <%# Eval("TaxRate")%>
                                                </td>
                                                <td id="tdtaxdeducted" runat="server" style="text-align: right">
                                                    <%# Eval("TaxDeducted")%>
                                                </td>
                                                <td id="deducteddate" runat="server" style="text-align: left">
                                                    <%# Eval("TaxDeductedDate")%>
                                                </td>
                                                <td id="tdchallanno" runat="server" style="text-align: right">
                                                    <%# Eval("ChallanNo")%>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblNonDedReasonValue" Text='<%# Eval("NonDedReasonValue")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="tdnondedreason" runat="server">
                                                    <%# Eval("NonDedReason")%>
                                                </td>
                                                <td id="BookEntryData" runat="server" style="text-align: center">
                                                    <%# Eval("BookEntry")%>
                                                </td>
                                                <td id="GrossingUpData" runat="server" style="text-align: center">
                                                    <%# Eval("GrossingUp")%>
                                                </td>
                                                <td id="tdMode" runat="server" style="text-align: center; display: none;">
                                                    <asp:Label ID="lblMode" Text='<%# Eval("Mode")%>' runat="server"></asp:Label>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px;" align="right">
                                    <tr>
                                        <td style="padding: 0px 0px 0px 0px">
                                            <asp:Label ID="lblViewExistingRecords" runat="server" Text="Records per page : "
                                                Font-Size="X-Small" />
                                        </td>
                                        <td style="width: 50px; padding-top: 2px;">
                                            <asp:DropDownList ID="cmbViewExistingGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                AutoPostBack="true" Font-Size="X-Small" OnSelectedIndexChanged="cmbViewExistingGoTo_SelectedIndexChanged">
                                                <asp:ListItem Text="5" Value="5" />
                                                <asp:ListItem Text="10" Value="10" />
                                                <asp:ListItem Text="15" Value="15" />
                                                <asp:ListItem Text="20" Value="20" />
                                                <asp:ListItem Text="25" Value="25" />
                                                <asp:ListItem Text="50" Value="50" />
                                                <asp:ListItem Text="75" Value="75" />
                                                <asp:ListItem Text="100" Value="100" />
                                                <asp:ListItem Text="200" Value="200" />
                                                <asp:ListItem Text="500" Value="500" />
                                                <%--                                            <asp:ListItem Text="800" Value="800" />
                                                <asp:ListItem Text="1000" Value="1000" />
                                                <asp:ListItem Text="2000" Value="2000" />
                                                <asp:ListItem Text="10000" Value="10000" />--%>
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblViewExistingGridStatus" runat="server" Style="float: left;" Text="Showing 0-0 of 0 [Page 0 of 0]"
                                                Font-Size="X-Small" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingFirst" runat="server" Text="&lt;&lt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                                                OnClick="btnViewExistingFirst_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingPrevious" runat="server" Text="&lt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                                                OnClick="btnViewExistingPrevious_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtViewExistingGoToPage" runat="server" Text="1" CssClass="navTextBox"
                                                AutoPostBack="True" MaxLength="5" OnTextChanged="txtViewExistingGoToPage_TextChanged"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingNext" runat="server" Text="&gt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" OnClick="btnViewExistingNext_Click"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnViewExistingLast" runat="server" Text="&gt;&gt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" OnClick="btnViewExistingLast_Click"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Panel ID="pnlAdd" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel">
                                    <asp:Label ID="lblSelectOption" runat="server" Text="Select Options:" Font-Bold="true" Font-Size="10px"></asp:Label>
                                    <table style="width: 100%; padding-right: 0px;">
                                        <tr>
                                            <td>
                                                <asp:Label ID="lblOption1" runat="server" Text="Option 1" Font-Bold="True"></asp:Label>
                                                <asp:TextBox ID="txtSerialNo_From" Width="48px" MaxLength="7" CssClass="txtBPL" runat="server"
                                                    onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                                                <asp:Button ID="btnViewExistingAddAll" runat="server" Text="Add From Sl No" Width="120px"
                                                    CssClass="cmnBtn" OnClick="btnViewExistingAddAll_Click" />
                                            </td>
                                            <td align="right">
                                                <asp:Label ID="lblOption3" runat="server" Text="Option 3:" Font-Bold="True"></asp:Label>
                                                <asp:Label ID="lblSelect" runat="server" Text="Select"></asp:Label>
                                                <asp:LinkButton ID="lnkbtnSelectAll" runat="server" Text="All" OnClientClick="return SelectAll();"></asp:LinkButton>
                                                <asp:Label ID="lblCorrPipe" runat="server" Text="|"></asp:Label>
                                                <asp:LinkButton ID="lnkbtnUnSelectAll" runat="server" Text="None" OnClientClick="return UnSelectAll();"
                                                    CausesValidation="true"></asp:LinkButton>
                                                <asp:Button ID="btnViewExistingAdd" runat="server" Text="Add" CssClass="cmnBtn" OnClientClick="return ValidateViewExisting();"
                                                    OnClick="btnViewExistingAdd_Click" />
                                                <asp:Button ID="btnCreateAll" runat="server" Text="Create All" CssClass="cmnBtn"
                                                    OnClick="btnCreateAll_Click" OnClientClick="return CreateAllValidation();" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <asp:Label ID="lblOption2" runat="server" Text="Option 2" Font-Bold="True"></asp:Label>
                                                <asp:FileUpload ID="fupTextFile" runat="server" CssClass="browsBtn" />
                                                <asp:Button ID="btnViewExistingTextAddAll" runat="server" Text="Bulk Select"
                                                    CssClass="cmnBtn" OnClientClick="return FileValidation();" OnClick="btnViewExistingTextAddAll_Click" ToolTip="Choose text file with PAN records and click here." />
                                            </td>
                                            <td align="right"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="5" style="text-align: right; display: none">Correction Type
                                            </td>
                                            <td style="text-align: right; display: none">
                                                <asp:DropDownList ID="ddlCorrectionType" runat="server">
                                                    <asp:ListItem Text="Update" Value="2"></asp:ListItem>
                                                </asp:DropDownList>
                                            </td>
                                            <td colspan="8" style="width: 120px; text-align: right;"></td>
                                        </tr>
                                    </table>
                                </asp:Panel>
                                <table style="width: 100%; padding-right: 0px;">
                                    <tr align="right">
                                        <td align="right">
                                            <asp:Button ID="btnViewExistingClose" runat="server" Text="Close" CssClass="cmnBtn"
                                                OnClick="btnViewExistingClose_Click" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                    <div id="pnlPopup1" class="PrProgress1" runat="server" style="display: none;">
                        <div id="innerPopup" class="PrContainer">
                            <div class="PrHeader">
                                Please wait...
                            </div>
                            <div class="PrBody">
                                <img width="220px" height="19px" src="../App_Themes/Standard/Images/activity.gif"
                                    alt="loading..." />
                            </div>
                        </div>
                    </div>
                </asp:View>
                <asp:View ID="vwBulkUpdate" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td id="Td1" runat="server">
                                <asp:Panel ID="Panel1" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                                    Visible="false" Width="730px">
                                    <asp:Repeater ID="rptrUpdatedBulkDeductions" runat="server" OnItemDataBound="rptrUpdatedBulkDeductions_ItemDataBound"
                                        OnItemCommand="rptrUpdatedBulkDeductions_ItemCommand" Visible="False">
                                        <HeaderTemplate>
                                            <table id="NavTable" border="0">
                                                <tr bgcolor="#EEEEEE">
                                                    <th>Select
                                                    </th>
                                                    <th style="display: none">
                                                        <asp:Label runat="server" ID="Label15" Width="150px" Text="Correction Type" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblCorrectionType" Width="150px" Text="Correction Type" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblDedSlNo" Width="60px" Text="Serial No." />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblDeducteeSlNo" Width="230px" Text="Deductee No." />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblName" Width="250px" Text="Name" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblPAN" Width="90px" Text="PAN" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblSection" Width="80px" Text="Section" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblSecID" Width="80px" Text="SectionID" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblAmountOfPayment" Width="150px" Text="Amount Of Payment" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label8" Text="Paid/Credited Date" runat="server" Width="130px"></asp:Label>
                                                    </th>
                                                    <th id="ITRateHeader" runat="server">
                                                        <asp:Label runat="server" ID="lblIncomeTaxRate" Width="130px" Text="Income Tax Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="Label2" Width="100px" Text="Income Tax" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label10" Text="Surcharge Rate" runat="server" Width="130px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label9" runat="server" Width="100px" Text="Surcharge" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblCessRate" Width="130px" Text="Cess Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label11" runat="server" Width="100px" Text="Cess" />
                                                    </th>
                                                    <th id="TaxRateHeader" runat="server">
                                                        <asp:Label runat="server" ID="Label6" Width="130px" Text="Tax Rate" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblTaxDeducted" Width="100px" Text="Tax Deducted" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="lblTaxDedDate" Width="130px" Text=" Tax Deducted Date" />
                                                    </th>
                                                    <th>
                                                        <asp:Label runat="server" ID="Label7" Width="100px" Text="Challan No." />
                                                    </th>
                                                    <th style="display: none">
                                                        <asp:Label ID="Label13" runat="server" Width="10px" Text="Value" />
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label12" runat="server" Width="290px" Text="Non Deduction Reason" />
                                                    </th>
                                                    <th id="BookEntryHeader" runat="server">
                                                        <asp:Label ID="Label4" runat="server" Width="100px" Text="Book Entry" />
                                                    </th>
                                                    <th id="GrossingUpHeader" runat="server">
                                                        <asp:Label ID="Label1" runat="server" Width="160px" Text="Grossing Up Indicator" />
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white">
                                                <td id="cbtwo">
                                                    <asp:CheckBox ID="chkDedsSelect" runat="server" Checked="true" />
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label runat="server" ID="lblCorrType" Width="100px" Text='<%# Eval("CorrectionType")%>' />
                                                </td>
                                                <td>
                                                    <asp:Label runat="server" ID="Label3" Width="100px" Text='<%# Eval("Correction")%>' />
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblDedSlNo" Text='<%# Eval("DeductionSlNo")%>' runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblDeducteeSlNo" Text=' <%# Eval("DeducteeSlNo")%>' runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblName" Text=' <%# Eval("Name")%>' runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblPan" Text=' <%# Eval("PAN")%>' runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblSection" Text='<%#Eval("Section") %>' runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblSecID" Text='<%# Eval("SectionID")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblAmtPayment" Text=' <%#Eval("AmountOfPayment")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: left">
                                                    <asp:Label ID="lblPaymentdate" Text=' <%# Eval("PaymentDate")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="ITRateData" runat="server" style="text-align: right">
                                                    <asp:Label ID="lblIncometaxRate" Text=' <%# Eval("IncomeTaxRate")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblIncomeTax" Text=' <%# Eval("IncomeTax")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblSurRate" Text=' <%# Eval("SurchargeRate") %>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblSur" Text=' <%# Eval("Surcharge") %>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblCessRate" Text=' <%# Eval("EducationCessRate")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblCess" Text=' <%# Eval("EducationCess")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="TaxRateData" runat="server" style="text-align: right">
                                                    <asp:Label ID="lblTaxRate" Text=' <%# Eval("TaxRate")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblTaxDed" Text=' <%# Eval("TaxDeducted")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: left">
                                                    <asp:Label ID="lblTaxDedDate" Text='  <%# Eval("TaxDeductedDate")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: right">
                                                    <asp:Label ID="lblChalanNo" Text=' <%# Eval("ChallanNo")%>' runat="server"></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblNonDedRes" Text=' <%# Eval("NonDedReason")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="BookEntryData" runat="server" style="text-align: center">
                                                    <asp:Label ID="lblBookEntry" Text='  <%# Eval("BookEntry")%>' runat="server"></asp:Label>
                                                </td>
                                                <td id="GrossingUpData" runat="server" style="text-align: center">
                                                    <asp:Label ID="lblGrossingUp" Text='  <%# Eval("GrossingUp")%>' runat="server"></asp:Label>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px;" align="right">
                                    <tr>
                                        <td style="padding: 0px 0px 0px 0px">
                                            <asp:Label ID="lblBulkUpdateRecordStatus0" runat="server" Text="Records per page : "
                                                Font-Size="X-Small" Visible="False" />
                                        </td>
                                        <td style="width: 50px; padding-top: 2px;">
                                            <asp:DropDownList ID="cmbBulkUpdateGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                AutoPostBack="true" Font-Size="X-Small" OnSelectedIndexChanged="cmbBulkUpdateGoTo_SelectedIndexChanged"
                                                Visible="False">
                                                <asp:ListItem Text="5" Value="5" />
                                                <asp:ListItem Text="10" Value="10" />
                                                <asp:ListItem Text="15" Value="15" />
                                                <asp:ListItem Text="20" Value="20" />
                                                <asp:ListItem Text="25" Value="25" />
                                                <asp:ListItem Text="50" Value="50" />
                                                <asp:ListItem Text="75" Value="75" />
                                                <asp:ListItem Text="100" Value="100" />
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblBulkUpdateRecordStatus" runat="server" Style="float: left;" Text="Showing 0-0 of 0 [Page 0 of 0]"
                                                Font-Size="X-Small" Visible="False" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnBulkUpdateFirst" runat="server" Text="&lt;&lt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                                                OnClick="btnBulkUpdateFirst_Click" Visible="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnBulkUpdatePrevious" runat="server" Text="&lt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                                                OnClick="btnBulkUpdatePrevious_Click" Visible="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtBulkUpdateGoToPage" runat="server" Text="1" CssClass="navTextBox"
                                                AutoPostBack="True" MaxLength="5" OnTextChanged="txtBulkUpdateGoToPage_TextChanged"
                                                Visible="False"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnBulkUpdateNext" runat="server" Text="&gt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" OnClick="btnBulkUpdateNext_Click"
                                                Visible="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnBulkUpdateLast" runat="server" Text="&gt;&gt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" CssClass="navButton" OnClick="btnBulkUpdateLast_Click"
                                                Visible="False"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>&nbsp;&nbsp;
                                <asp:LinkButton ID="LinkButton1" runat="server" Text="All" OnClientClick="return SelectAllBulkUpdate();"
                                    Visible="False"></asp:LinkButton>
                                &nbsp&nbsp
                                <asp:LinkButton ID="LinkButton2" runat="server" Text="None" OnClientClick="return UnSelectAllBulkUpdate();"
                                    CausesValidation="true" Visible="False"></asp:LinkButton>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <table width="100%">
                                    <tr>
                                        <td width="100px">
                                            <asp:Button ID="btnExport" runat="server" Text="Export" CssClass="cmnBtn" OnClick="btnBlkUpdate_Click" />
                                        </td>
                                        <td width="100px">
                                            <asp:Button ID="btnImport" runat="server" Text="Import" CssClass="cmnBtn" />
                                        </td>
                                        <td width="100px">
                                            <asp:Button ID="btnBulkUpdate" runat="server" Text="Update" CssClass="cmnBtn" OnClick="btnBulkUpdate_Click"
                                                Visible="False" />
                                        </td>
                                        <td>
                                            <asp:HyperLink ID="hlnkOpenErrors" runat="server" Text="" Target="_blank" Visible="false">
                                            </asp:HyperLink>
                                        </td>
                                        <td>
                                            <asp:HyperLink ID="hlnkMastersList" runat="server" Text="" Target="_blank" Visible="false">
                                            </asp:HyperLink>
                                        </td>
                                        <td align="right">
                                            <asp:Button ID="btnBulkClose" runat="server" Text="Close" CssClass="cmnBtn" OnClick="btnBulkClose_Click" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="5">
                                            <asp:Label ID="lblExcelNote1" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 1: Avoid Cut options in any of the work Sheets." />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="5">
                                            <asp:Label ID="lblExcelNote2" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 2: While Pasting data from other excel File, use only Paste Special / Values Option." />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="5">
                                            <asp:Label ID="lblExcelNote3" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 3: Before any operation make sure you are not in Excel Edit mode." />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </asp:View>
            </asp:MultiView>
        </ContentTemplate>
        <Triggers>
            <asp:PostBackTrigger ControlID="btnViewExistingTextAddAll" />
        </Triggers>
    </asp:UpdatePanel>
</asp:Content>
