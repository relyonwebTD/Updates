﻿<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Correction_SalaryDetail, App_Web_salarydetail.aspx.4fd6750c" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style type="text/css">
         .PrProgress1 {
            position: fixed; /* Fix the element relative to the viewport */
            top: 50%; /* Center vertically */
            left: 50%; /* Center horizontally */
            transform: translate(-50%, -50%); /* Adjust for the element's size */
            z-index: 1000; /* Ensure it appears above other elements */
            /*background: rgba(255, 255, 255, 0.9);*/ /* Optional: Semi-transparent background */
            /*border: 1px solid #ccc;*/ /* Optional: Add a border for visibility */
            padding: 20px; /* Optional: Add padding for spacing inside the loader */
            border-radius: 8px; /* Optional: Rounded corners */
            text-align: center; /* Center-align content inside the loader */
            /*box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);*/ /* Optional: Add shadow for a floating effect */
        }
     </style>
    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>
    <script type="text/javascript" language="javascript">
        function OnNewRecord() {
            document.getElementById("<%=txtName.ClientID%>").value = "";
            document.getElementById("<%=txtPan.ClientID%>").value = "";
            document.getElementById("<%=txtGrossSalary.ClientID%>").value = "";
            document.getElementById("<%=txtET.ClientID %>").value = "";
            document.getElementById("<%=txtPT.ClientID%>").value = "";
            document.getElementById("<%=ddlGender.ClientID%>").value = "-1";
            document.getElementById("<%=ddlSeniorCitizen.ClientID%>").value = "-1";
            document.getElementById("<%=txtOtherIncome.ClientID%>").value = "";
            document.getElementById("<%=txtGrossTotalIncome.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIA80CCE.ClientID%>") != null) document.getElementById("<%=txtChapterVIA80CCE.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIA80CCF.ClientID%>") != null) document.getElementById("<%=txtChapterVIA80CCF.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIA80CCG.ClientID%>") != null) document.getElementById("<%=txtChapterVIA80CCG.ClientID%>").value = "";
            document.getElementById("<%=txtChapterVIAOthers.ClientID%>").value = "";
            document.getElementById("<%=txtTotalTaxableIncome.ClientID%>").value = "";
            document.getElementById("<%=txtTaxOnTotalIncome.ClientID%>").value = "";
            document.getElementById("<%=txtSurcharge.ClientID%>").value = "";
            document.getElementById("<%=txtEducationCess.ClientID%>").value = "";
            document.getElementById("<%=txtReliefUS89.ClientID%>").value = "";
            document.getElementById("<%=txtNetTaxPayable.ClientID%>").value = "";
            document.getElementById("<%=txtTotalTDS.ClientID%>").value = "";
            document.getElementById("<%=txtTaxPayableRefundable.ClientID%>").value = "";
            document.getElementById("<%=hdnEmployeeSerialNo.ClientID%>").value = "-1";
            document.getElementById("<%=hdnCurrentCorrStatus.ClientID%>").value = "-1";
            if (document.getElementById("<%=txtCurrentTaxableIncome.ClientID%>") != null) document.getElementById("<%=txtCurrentTaxableIncome.ClientID%>").value = "";
            if (document.getElementById("<%=txtPrevTaxableIncome.ClientID%>") != null) document.getElementById("<%=txtPrevTaxableIncome.ClientID%>").value = "";
            if (document.getElementById("<%=txtCurrentTDS.ClientID%>") != null) document.getElementById("<%=txtCurrentTDS.ClientID%>").value = "";
            if (document.getElementById("<%=txtPreviousTDS.ClientID%>") != null) document.getElementById("<%=txtPreviousTDS.ClientID%>").value = "";
            if (document.getElementById("<%=ddlTDSHigherRate.ClientID%>") != null) document.getElementById("<%=ddlTDSHigherRate.ClientID%>").selectedIndex = 0;
            document.getElementById("<%=txtGrossSalarySec17.ClientID %>").value = "";
            document.getElementById("<%=txtValueOfPerq.ClientID %>").value = "";
            document.getElementById("<%=txtProfitSalary.ClientID %>").value = "";
            document.getElementById("<%=txtS10LTA.ClientID %>").value = "";
            document.getElementById("<%=txtS10Gratuity.ClientID %>").value = "";
            document.getElementById("<%=txtS10Pension.ClientID %>").value = "";
            document.getElementById("<%=txtS10LSE.ClientID %>").value = "";
            document.getElementById("<%=txtS10HRA.ClientID %>").value = "";
            document.getElementById("<%=txtS10OTH.ClientID %>").value = "";
            document.getElementById("<%=txtOthincsrc.ClientID %>").value = "";
            document.getElementById("<%=txtS10OTHSA.ClientID %>").value = "";

            document.getElementById("<%=txtChapterVIA80CCHequal.ClientID%>").value = "";
            document.getElementById("<%=txtChapterVIA80CCH_1equal.ClientID%>").value = "";
            document.getElementById("<%=txtChapterVIA80CCHgross.ClientID%>").value = "";
            document.getElementById("<%=txtChapterVIA80CCH_1gross.ClientID%>").value = "";
            document.getElementById("<%=txtChapterVIA80CCH.ClientID%>").value = "";
            document.getElementById("<%=txtChapterVIA80CCH_1.ClientID%>").value = "";

            var txtCredit87A = document.getElementById("<%=txtCredit87A.ClientID %>");
            if (txtCredit87A != null)
                document.getElementById("<%=txtCredit87A.ClientID %>").value = "";

            document.getElementById("<%=txtSD.ClientID %>").value = "";

            var ChapterVIA80C = document.getElementById("<%=txtChapterVIA80C.ClientID %>");
            if (ChapterVIA80C != null) {
                document.getElementById("<%=txtChapterVIA80C.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCC.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_1.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_1B.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_2.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80D.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80E.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80G.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80TTA.ClientID %>").value = "";

                document.getElementById("<%=txtChapterVIA80Cgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80Cqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCCgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCCqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_1gross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_1qual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_1Bgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_1Bqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_2gross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80CCD_2qual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80Dgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80Dqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80DDgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80DDqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80DD.ClientID %>").value = "";

                document.getElementById("<%=txtChapterVIA80Egross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80Equal.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80EEgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80EEqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80EE.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80EEAgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80EEAqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80EEA.ClientID %>").value = "";

                document.getElementById("<%=txtChapterVIA80Ggross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80Gqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80GGgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80GGqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80GG.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80GGCgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80GGCqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80GGC.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80TTBgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80TTBqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80TTB.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80Ugross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80Uqual.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80U.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIAOthersgross.ClientID%>").value = "";
                document.getElementById("<%=txtChapterVIAOthersqual.ClientID%>").value = "";
                document.getElementById("<%=txtChapterVIAOthers.ClientID%>").value = "";

                document.getElementById("<%=txtChapterVIA80TTAgross.ClientID %>").value = "";
                document.getElementById("<%=txtChapterVIA80TTAqual.ClientID %>").value = "";
                if (document.getElementById("<%=txtChapterVIA80CCFgross.ClientID%>") != null)
                    document.getElementById("<%=txtChapterVIA80CCFgross.ClientID %>").value = "";
                if (document.getElementById("<%=txtChapterVIA80CCFqual.ClientID%>") != null)
                    document.getElementById("<%=txtChapterVIA80CCFqual.ClientID %>").value = "";
            }
            if (document.getElementById("<%=txtChapterVIA80CCEgross.ClientID%>") != null) document.getElementById("<%=txtChapterVIA80CCEgross.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIA80CCEqual.ClientID%>") != null) document.getElementById("<%=txtChapterVIA80CCEqual.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIA80CCGgross.ClientID%>") != null) document.getElementById("<%=txtChapterVIA80CCGgross.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIA80CCGqual.ClientID%>") != null) document.getElementById("<%=txtChapterVIA80CCGqual.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIA80CCGqual.ClientID%>") != null) document.getElementById("<%=txtChapterVIA80CCGqual.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIAOthersgross.ClientID%>") != null) document.getElementById("<%=txtChapterVIAOthersgross.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIAOthersqual.ClientID%>") != null) document.getElementById("<%=txtChapterVIAOthersqual.ClientID%>").value = "";
            if (document.getElementById("<%=txtChapterVIAOthers.ClientID%>") != null) document.getElementById("<%=txtChapterVIAOthers.ClientID%>").value = "";
            if (document.getElementById("<%=txtTDSTCS.ClientID%>") != null) document.getElementById("<%=txtTDSTCS.ClientID%>").value = "";
            return true;
        }
        function ValidateCorrectionType() {
            if (document.getElementById("<%=ddlCorrectionType.ClientID%>").value == -1) {
                alert("Select Correction Type");
                return false;
            }
            else return true;
        }
        function ValidateSerialNo() {
            if (document.getElementById("<%=hdnEmployeeSerialNo.ClientID%>").value != "-1") return true;
            else {
                alert("Select valid employee");
                return false;
            }
        }
        function ShowAllclick() {
            if (confirm("Loading all details will take time.\n\nDo you want to continue?") == true) {
                return true;
            } else return false;
        }
        function Validation() {
            hdnFinYear = document.getElementById("<%=hdnFinYear.ClientID %>");
            var taxinccurrent = document.getElementById("<%=txtCurrentTaxableIncome.ClientID%>");
            var GrossSalary = document.getElementById("<%=txtGrossSalary.ClientID %>");
            var ToatalTaxableIncome = document.getElementById("<%=txtTotalTaxableIncome.ClientID %>");
            var sec17_1 = document.getElementById("<%=txtGrossSalarySec17.ClientID %>");
            var sec17_2 = document.getElementById("<%=txtValueOfPerq.ClientID %>");
            var sec17_3 = document.getElementById("<%=txtProfitSalary.ClientID %>");
            var SD = document.getElementById("<%=txtSD.ClientID %>");
            var ET = document.getElementById("<%=txtET.ClientID %>");
            var PT = document.getElementById("<%=txtPT.ClientID%>");
            var OtherIncSource = document.getElementById("<%=txtOthincsrc.ClientID %>");
            var txtCredit87A = document.getElementById("<%=txtCredit87A.ClientID %>");
            var ChapterVIA80C = document.getElementById("<%=txtChapterVIA80C.ClientID %>");
            var ChapterVIA80CCC = document.getElementById("<%=txtChapterVIA80CCC.ClientID %>");
            var ChapterVIA80CCD_1 = document.getElementById("<%=txtChapterVIA80CCD_1.ClientID %>");
            var ChapterVIA80CCD_1B = document.getElementById("<%=txtChapterVIA80CCD_1B.ClientID %>");
            var ChapterVIA80CCD_2 = document.getElementById("<%=txtChapterVIA80CCD_2.ClientID %>");
            var ChapterVIA80D = document.getElementById("<%=txtChapterVIA80D.ClientID %>");
            var ChapterVIA80E = document.getElementById("<%=txtChapterVIA80E.ClientID %>");
            var ChapterVIA80G = document.getElementById("<%=txtChapterVIA80G.ClientID %>");
            var ChapterVIA80CCG = document.getElementById("<%=txtChapterVIA80CCG.ClientID%>");
            var ChapterVIA80CCE = document.getElementById("<%=txtChapterVIA80CCE.ClientID%>");
            var ChapterVIA80TTA = document.getElementById("<%=txtChapterVIA80TTA.ClientID %>");
            var ChapterVIA80TTB = document.getElementById("<%=txtChapterVIA80TTB.ClientID %>");
            var ChapterVIA80DD = document.getElementById("<%=txtChapterVIA80DD.ClientID %>");
            var ChapterVIA80EE = document.getElementById("<%=txtChapterVIA80EE.ClientID %>");
            var ChapterVIA80EEA = document.getElementById("<%=txtChapterVIA80EEA.ClientID %>");
            var ChapterVIA80GG = document.getElementById("<%=txtChapterVIA80GG.ClientID %>");
            var ChapterVIA80GGC = document.getElementById("<%=txtChapterVIA80GGC.ClientID %>");
            var ChapterVIA80U = document.getElementById("<%=txtChapterVIA80U.ClientID %>");
            var ChapterVIOthers = document.getElementById("<%=txtChapterVIAOthers.ClientID %>");
            var txtTaxOnTotalIncome = document.getElementById("<%=txtTaxOnTotalIncome.ClientID %>");
            var txtChapterVIA80Cgross = document.getElementById("<%=txtChapterVIA80Cgross.ClientID%>");
            var txtChapterVIA80Cqual = document.getElementById("<%=txtChapterVIA80Cqual.ClientID%>");
            var txtChapterVIA80CCCgross = document.getElementById("<%=txtChapterVIA80CCCgross.ClientID%>");
            var txtChapterVIA80CCCqual = document.getElementById("<%=txtChapterVIA80CCCqual.ClientID%>");
            var txtChapterVIA80CCD_1gross = document.getElementById("<%=txtChapterVIA80CCD_1gross.ClientID%>");
            var txtChapterVIA80CCD_1qual = document.getElementById("<%=txtChapterVIA80CCD_1qual.ClientID%>");
            var txtChapterVIA80CCD_1Bgross = document.getElementById("<%=txtChapterVIA80CCD_1Bgross.ClientID%>");
            var txtChapterVIA80CCD_1Bqual = document.getElementById("<%=txtChapterVIA80CCD_1Bqual.ClientID%>");
            var txtChapterVIA80CCD_2gross = document.getElementById("<%=txtChapterVIA80CCD_2gross.ClientID%>");
            var txtChapterVIA80CCD_2qual = document.getElementById("<%=txtChapterVIA80CCD_2qual.ClientID%>");
            var txtChapterVIA80Dgross = document.getElementById("<%=txtChapterVIA80Dgross.ClientID%>");
            var txtChapterVIA80Dqual = document.getElementById("<%=txtChapterVIA80Dqual.ClientID%>");
            var txtChapterVIA80Egross = document.getElementById("<%=txtChapterVIA80Egross.ClientID%>");
            var txtChapterVIA80Equal = document.getElementById("<%=txtChapterVIA80Equal.ClientID%>");
            var txtChapterVIA80Ggross = document.getElementById("<%=txtChapterVIA80Ggross.ClientID%>");
            var txtChapterVIA80Gqual = document.getElementById("<%=txtChapterVIA80Gqual.ClientID%>");
            var txtChapterVIA80TTAgross = document.getElementById("<%=txtChapterVIA80TTAgross.ClientID%>");
            var txtChapterVIA80TTAqual = document.getElementById("<%=txtChapterVIA80TTAqual.ClientID%>");
            var txtChapterVIA80CCFgross = document.getElementById("<%=txtChapterVIA80CCFgross.ClientID%>");
            var txtChapterVIA80CCFqual = document.getElementById("<%=txtChapterVIA80CCFqual.ClientID%>");
            var txtChapterVIA80CCGgross = document.getElementById("<%=txtChapterVIA80CCGgross.ClientID%>");
            var txtChapterVIA80CCGqual = document.getElementById("<%=txtChapterVIA80CCGqual.ClientID%>");
            var txtChapterVIA80CCEgross = document.getElementById("<%=txtChapterVIA80CCEgross.ClientID%>");
            var txtChapterVIA80CCEqual = document.getElementById("<%=txtChapterVIA80CCEqual.ClientID%>");
            var txtChapterVIA80TTBgross = document.getElementById("<%=txtChapterVIA80TTBgross.ClientID%>");
            var txtChapterVIA80TTBqual = document.getElementById("<%=txtChapterVIA80TTBqual.ClientID%>");
            var txtChapterVIA80DDgross = document.getElementById("<%=txtChapterVIA80DDgross.ClientID%>");
            var txtChapterVIA80DDqual = document.getElementById("<%=txtChapterVIA80DDqual.ClientID%>");
            var txtChapterVIA80EEgross = document.getElementById("<%=txtChapterVIA80EEgross.ClientID%>");
            var txtChapterVIA80EEqual = document.getElementById("<%=txtChapterVIA80EEqual.ClientID%>");
            var txtChapterVIA80EEAgross = document.getElementById("<%=txtChapterVIA80EEAgross.ClientID%>");
            var txtChapterVIA80EEAqual = document.getElementById("<%=txtChapterVIA80EEAqual.ClientID%>");
            var txtChapterVIA80GGgross = document.getElementById("<%=txtChapterVIA80GGgross.ClientID%>");
            var txtChapterVIA80GGqual = document.getElementById("<%=txtChapterVIA80GGqual.ClientID%>");
            var txtChapterVIA80GGCgross = document.getElementById("<%=txtChapterVIA80GGCgross.ClientID%>");
            var txtChapterVIA80GGCqual = document.getElementById("<%=txtChapterVIA80GGCqual.ClientID%>");
            var txtChapterVIA80Ugross = document.getElementById("<%=txtChapterVIA80Ugross.ClientID%>");
            var txtChapterVIA80Uqual = document.getElementById("<%=txtChapterVIA80Uqual.ClientID%>");

            var txtChapterVIA80CCHequal = document.getElementById("<%=txtChapterVIA80CCHequal.ClientID%>");
            var txtChapterVIA80CCH_1equal = document.getElementById("<%=txtChapterVIA80CCH_1equal.ClientID%>");
            var txtChapterVIA80CCHgross = document.getElementById("<%=txtChapterVIA80CCHgross.ClientID%>");
            var txtChapterVIA80CCH_1gross = document.getElementById("<%=txtChapterVIA80CCH_1gross.ClientID%>");
            var txtChapterVIA80CCH = document.getElementById("<%=txtChapterVIA80CCH.ClientID %>");
            var txtChapterVIA80CCH_1 = document.getElementById("<%=txtChapterVIA80CCH_1.ClientID %>");
            var txtChapterVIAOthersgross = document.getElementById("<%=txtChapterVIAOthersgross.ClientID%>");
            var txtChapterVIAOthersqual = document.getElementById("<%=txtChapterVIAOthersqual.ClientID%>");
            var txtChapterVIA80CCG = document.getElementById("<%=txtChapterVIA80CCG.ClientID%>");
            var rbtnOldRegime = document.getElementById("<%=rbtnOldRegime.ClientID %>");

            if (hdnFinYear.value >= 2018) {
                var totalChapterVIA80C_80CCC_80CCD_1 = (Return(ChapterVIA80C.value) + Return(ChapterVIA80CCC.value) + Return(ChapterVIA80CCD_1.value));
                var totalsec17_1_2_3 = (Return(sec17_1.value) + Return(sec17_2.value) + Return(sec17_3.value));
                if (totalsec17_1_2_3 != taxinccurrent.value) {
                    alert("Sum of Gross Salary Sec.17(1), Value Of Perquisites and Profit In Lieu Salary \nShould be equal to Taxable Income Current.");
                    sec17_1.focus();
                    return false;
                }
                if (SD.value > Return(GrossSalary.value)) {
                    alert("Standard Deduction value Should Not be greater than Gross Salary Amount.");
                    SD.focus();
                    return false;
                }


                if (ET.value > 5000) {
                    alert("Amount given for ET 16(ii) is more." +
                        "\nCannot be more than Rs.5000.");
                    ET.focus();
                    return false;
                }

                if (PT.value > 5000) {
                    alert("Amount given for PT 16(iii) is more." +
                        "\nCannot be more than Rs.5000.");
                    PT.focus();
                    return false;
                }

                if (OtherIncSource.value < 0) {
                    alert("Amount Of Other Income Source Should not be less than Zero.");
                    OtherIncSource.focus();
                    return false;
                }

                if (txtCredit87A != null) {
                    if (txtTaxOnTotalIncome.value < txtCredit87A.value) {
                        alert("Credit Under Section 87A Should not be greater than Tax On Total Income Amount.")
                        txtCredit87A.focus();
                        return false;
                    }
                }

                if (totalChapterVIA80C_80CCC_80CCD_1 > 150000) {
                    alert("Sum Of ChapterVIA80C, ChapterVIA80CCC And ChapterVIA80CCD_(1) Should Not be greater than Rs.1,50,000.");
                    ChapterVIA80C.focus();
                    return false;
                }
                if (ChapterVIA80CCD_1B.value > 50000) {
                    alert("ChapterVIA80CCD_(1B) Amount Should Not be greater than Rs.50,000.");
                    ChapterVIA80CCD_1B.focus();
                    return false;
                }
                if (ChapterVIA80D.value > 100000) {
                    alert("ChapterVIA80D Amount Should Not be greater than Rs.1,00000.");
                    ChapterVIA80D.focus();
                    return false;
                }
                if (ChapterVIA80TTA.value > 10000) {
                    alert("ChapterVIA80TTA Amount Should Not be greater than Rs.10,000.");
                    ChapterVIA80TTA.focus();
                    return false;
                }
                if (txtCredit87A.value > 12500 && Return(ToatalTaxableIncome.value) <= 500000 && rbtnOldRegime.checked) {
                    alert("Amount of Credit Under Section 87A Should Not be greater than Rs.12,500.");
                    txtCredit87A.focus();
                    return false;
                }
                if (txtCredit87A.value > 25000 && hdnFinYear.value >= 2023 && Return(ToatalTaxableIncome.value) <= 700000 && rbtnOldRegime.checked == false) {
                    alert("Amount of Credit Under Section 87A Should Not be greater than Rs.25,000.");
                    txtCredit87A.focus();
                    return false;
                }
                if (txtCredit87A.value > 60000 && hdnFinYear.value >= 2025 && Return(ToatalTaxableIncome.value) <= 1200000 && rbtnOldRegime.checked == false) {
                    alert("Amount of Credit Under Section 87A Should Not be greater than Rs.60,000.");
                    txtCredit87A.focus();
                    return false;
                }
            }
            if (hdnFinYear.value <= 2018) {
                if (SD.value > 40000) {
                    alert("Standard Deduction value Should Not be greater than Rs.40,000.");
                    SD.focus();
                    return false;
                }
                if (txtCredit87A.value > 2500) {
                    alert("Amount of Credit Under Section 87A Should Not be greater than Rs.2,500.");
                    txtCredit87A.focus();
                    return false;
                }
                if (txtCredit87A != null) {
                    if (ToatalTaxableIncome.value > 350000 && txtCredit87A.value > 0) {
                        alert("Total Taxable Income Should Not be greater than Rs.3,50,000 and \nCredit Under Section 87A Should Not be greater than Zero.");
                        txtCredit87A.focus();
                        return false;
                    }
                }
            }
            if (!ValidateSerialNo()) return false;
            if (!ValidateLength(document.getElementById("<%=txtName.ClientID%>"), "Employee Name", 75, true)) return false;
            if (document.getElementById("<%=ddlGender.ClientID%>").value == "-1") {
                alert("Specify Gender");
                document.getElementById("<%=ddlGender.ClientID%>").focus();
                return false;
            }
            if (eval(document.getElementById("<%=txtTotalTaxableIncome.ClientID%>").value) < 0) {
                alert("Total taxable income cannot be negative");
                return false;
            }
            var totaltaxableincome = document.getElementById("<%=txtTotalTaxableIncome.ClientID%>").value;
            if (totaltaxableincome > 9999999999) {
                alert("Total Taxable Income should be less than 1000 Crores.")
                return false;
            }
            if (Return(ToatalTaxableIncome.value) > 500000 && Return(txtCredit87A.value) > 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value <= 2023 && rbtnOldRegime.checked == true) {
                alert("Credit Under Section 87A is Applicable Only if"
                    + " Total Taxable Income is less than RS.5,00,000.");
                return false;
            } else if (Return(ToatalTaxableIncome.value) > 700000 && Return(txtCredit87A.value) > 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value <= 2024 && rbtnOldRegime.checked == false) {
                alert("Credit Under Section 87A is Applicable Only if"
                    + " Total Taxable Income is less than RS.7,00,000.");
                return false;
            } else if (Return(ToatalTaxableIncome.value) > 1200000 && Return(txtCredit87A.value) > 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value >= 2025 && rbtnOldRegime.checked == false) {
                var relief = Return(ToatalTaxableIncome.value) - 1200000;
                if (!(relief < Return(txtTaxOnTotalIncome.value))) {
                    alert("Credit Under Section 87A is not Applicable");
                    return false;
                }
            }
            if (hdnFinYear.value >= 2018) {
                if (Return(txtChapterVIA80Cgross.value) != null || Return(txtChapterVIA80Cqual.value) != null || Return(ChapterVIA80C.value) != null) {
                    if (Return(txtChapterVIA80Cqual.value) == "") {
                        if (Return(txtChapterVIA80Cgross.value) < Return(ChapterVIA80C.value)) {
                            alert("Chap.VI(A)-80C Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                    }
                    //                    if (Return(txtChapterVIA80Cgross.value) < Return(txtChapterVIA80Cqual.value)) {
                    //                        alert("Chap.VI(A)-80C Gross Amount cannot be less than Qualifying Amount.");
                    //                        return false;
                    //                    }
                    //                    if (Return(txtChapterVIA80Cqual.value) < Return(ChapterVIA80C.value)) {
                    //                        alert("Chap.VI(A)-80C Qualifying Amount cannot be less than Deductible Amount.");
                    //                        return false;
                    //                    }
                }
                if (Return(txtChapterVIA80CCCgross.value) != null || Return(txtChapterVIA80CCCqual.value) != null || Return(ChapterVIA80CCC.value) != null) {
                    if (Return(txtChapterVIA80CCCqual.value) == "") {
                        if (Return(txtChapterVIA80CCCgross.value) < Return(ChapterVIA80CCC.value)) {
                            alert("Chap.VI(A)-80CCC Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                    }
                    //                    if (Return(txtChapterVIA80CCCgross.value) < Return(txtChapterVIA80CCCqual.value)) {
                    //                        alert("Chap.VI(A)-80CCC Gross Amount cannot be less than Qualifying Amount.");
                    //                        return false;
                    //                    }
                    //                    if (Return(txtChapterVIA80CCCqual.value) < Return(ChapterVIA80CCC.value)) {
                    //                        alert("Chap.VI(A)-80CCC Qualifying Amount cannot be less than Deductible Amount.");
                    //                        return false;
                    //                    }
                }
                if (Return(txtChapterVIA80CCD_1gross.value) != null || Return(txtChapterVIA80CCD_1qual.value) != null || Return(ChapterVIA80CCD_1.value) != null) {
                    if (Return(txtChapterVIA80CCD_1qual.value) == "") {
                        if (Return(txtChapterVIA80CCD_1gross.value) < Return(ChapterVIA80CCD_1.value)) {
                            alert("Chap.VI(A)-80CCD(1) Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                    }
                    //                    if (Return(txtChapterVIA80CCD_1gross.value) < Return(txtChapterVIA80CCD_1qual.value)) {
                    //                        alert("Chap.VI(A)-80CCD(1) Gross Amount cannot be less than Qualifying Amount.");
                    //                        return false;
                    //                    }
                    //                    if (Return(txtChapterVIA80CCD_1qual.value) < Return(ChapterVIA80CCD_1.value)) {
                    //                        alert("Chap.VI(A)-80CCD(1) Qualifying Amount cannot be less than Deductible Amount.");
                    //                        return false;
                    //                    }
                }
                if (Return(txtChapterVIA80CCD_1Bgross.value) != null || Return(txtChapterVIA80CCD_1Bqual.value) != null || Return(ChapterVIA80CCD_1B.value) != null) {
                    if (Return(txtChapterVIA80CCD_1Bqual.value) == "") {
                        if (Return(txtChapterVIA80CCD_1Bgross.value) < Return(ChapterVIA80CCD_1B.value)) {
                            alert("Chap.VI(A)-80CCD(1B) Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                    }
                    //                    if (Return(txtChapterVIA80CCD_1Bgross.value) < Return(txtChapterVIA80CCD_1Bqual.value)) {
                    //                        alert("Chap.VI(A)-80CCD(1B) Gross Amount cannot be less than Qualifying Amount.");
                    //                        return false;
                    //                    }
                    //                    if (Return(txtChapterVIA80CCD_1Bqual.value) < Return(ChapterVIA80CCD_1B.value)) {
                    //                        alert("Chap.VI(A)-80CCD(1B) Qualifying Amount cannot be less than Deductible Amount.");
                    //                        return false;
                    //                    }
                }
                if (Return(txtChapterVIA80CCD_2gross.value) != null || Return(txtChapterVIA80CCD_2qual.value) != null || Return(ChapterVIA80CCD_2.value) != null) {
                    if (Return(txtChapterVIA80CCD_2qual.value) == "") {
                        if (Return(txtChapterVIA80CCD_2gross.value) < Return(ChapterVIA80CCD_2.value)) {
                            alert("Chap.VI(A)-80CCD(2) Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                    }
                    //                    if (Return(txtChapterVIA80CCD_2gross.value) < Return(txtChapterVIA80CCD_2qual.value)) {
                    //                        alert("Chap.VI(A)-80CCD(2) Gross Amount cannot be less than Qualifying Amount.");
                    //                        return false;
                    //                    }
                    //                    if (Return(txtChapterVIA80CCD_2qual.value) < Return(ChapterVIA80CCD_2.value)) {
                    //                        alert("Chap.VI(A)-80CCD(2) Qualifying Amount cannot be less than Deductible Amount.");
                    //                        return false;
                    //                    }
                }
                if (Return(txtChapterVIA80Dgross.value) != null || Return(txtChapterVIA80Dqual.value) != null || Return(ChapterVIA80D.value) != null) {
                    if (Return(txtChapterVIA80Dqual.value) == "") {
                        if (Return(txtChapterVIA80Dgross.value) < Return(ChapterVIA80D.value)) {
                            alert("Chap.VI(A)-80D Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                    }
                    //                    if (Return(txtChapterVIA80Dgross.value) < Return(txtChapterVIA80Dqual.value)) {
                    //                        alert("Chap.VI(A)-80D Gross Amount cannot be less than Qualifying Amount.");
                    //                        return false;
                    //                    }
                    //                    if (Return(txtChapterVIA80Dqual.value) < Return(ChapterVIA80D.value)) {
                    //                        alert("Chap.VI(A)-80D Qualifying Amount cannot be less than Deductible Amount.");
                    //                        return false;
                    //                    }
                }
                if (Return(txtChapterVIA80Egross.value) != null || Return(txtChapterVIA80Equal.value) != null || Return(ChapterVIA80E.value) != null) {
                    if (Return(txtChapterVIA80Equal.value) == "") {
                        if (Return(txtChapterVIA80Egross.value) < Return(ChapterVIA80E.value)) {
                            alert("Chap.VI(A)-80E Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                    }
                    //                    if (Return(txtChapterVIA80Egross.value) < Return(txtChapterVIA80Equal.value)) {
                    //                        alert("Chap.VI(A)-80E Gross Amount cannot be less than Qualifying Amount.");
                    //                        return false;
                    //                    }
                    //                    if (Return(txtChapterVIA80Equal.value) < Return(ChapterVIA80E.value)) {
                    //                        alert("Chap.VI(A)-80E Qualifying Amount cannot be less than Deductible Amount.");
                    //                        return false;
                    //                    }
                }
                if (Return(txtChapterVIA80Ggross.value) != null || Return(txtChapterVIA80Gqual.value) != null || Return(ChapterVIA80G.value) != null) {
                    if (Return(txtChapterVIA80Ggross.value) < Return(txtChapterVIA80Gqual.value)) {
                        alert("Chap.VI(A)-80G Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80Gqual.value) < Return(ChapterVIA80G.value)) {
                        alert("Chap.VI(A)-80G Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80TTAgross.value) == "") {
                    txtChapterVIA80TTAgross.value = "0";
                }
                if (Return(txtChapterVIA80TTAqual.value) == "") {
                    txtChapterVIA80TTAqual.value = "0";
                }
                if (Return(ChapterVIA80TTA.value) == "") {
                    ChapterVIA80TTA.value = "0";
                }
                if (Return(txtChapterVIA80TTAgross.value) != "0" || Return(txtChapterVIA80TTAqual.value) != "0" || Return(ChapterVIA80TTA.value) != "0") {
                    var isSeniorCitizen = document.getElementById("<%=ddlSeniorCitizen.ClientID%>").value;
                    if (isSeniorCitizen == "1" || isSeniorCitizen == "2") {
                        alert("Chap.VI(A)-80TTA is not applicable for employee above 60 years.");
                        return false;
                    }
                    if (Return(txtChapterVIA80TTAqual.value) > 10000) {
                        alert("Maximum Qualifying Amount for the Chap.VI(A)-80TTA is 10,000.\n Qualifying Amount limited to 10,000.");
                        return false;
                    }
                    if (Return(txtChapterVIA80TTAgross.value) < Return(txtChapterVIA80TTAqual.value)) {
                        alert("Chap.VI(A)-80TTA Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80TTAqual.value) < Return(ChapterVIA80TTA.value)) {
                        alert("Chap.VI(A)-80TTA Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80Ggross.value) != null || Return(txtChapterVIA80Gqual.value) != null || Return(ChapterVIA80G.value) != null) {
                    if (Return(txtChapterVIA80Ggross.value) < Return(txtChapterVIA80Gqual.value)) {
                        alert("Chap.VI(A)-80G Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80Gqual.value) < Return(ChapterVIA80G.value)) {
                        alert("Chap.VI(A)-80G Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80TTBgross.value) != null || Return(txtChapterVIA80TTBqual.value) != null || Return(ChapterVIA80TTB.value) != null) {
                    if (Return(txtChapterVIA80TTBgross.value) < Return(txtChapterVIA80TTBqual.value)) {
                        alert("Chap.VI(A)-80TTB Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80TTBqual.value) < Return(ChapterVIA80TTB.value)) {
                        alert("Chap.VI(A)-80TTB Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80DDgross.value) != null || Return(txtChapterVIA80DDqual.value) != null || Return(ChapterVIA80DD.value) != null) {
                    if (Return(txtChapterVIA80DDgross.value) < Return(txtChapterVIA80DDqual.value)) {
                        alert("Chap.VI(A)-80DD Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80DDqual.value) < Return(ChapterVIA80DD.value)) {
                        alert("Chap.VI(A)-80DD Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80EEgross.value) != null || Return(txtChapterVIA80EEqual.value) != null || Return(ChapterVIA80EE.value) != null) {
                    if (Return(txtChapterVIA80EEgross.value) < Return(txtChapterVIA80EEqual.value)) {
                        alert("Chap.VI(A)-80EE Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80EEqual.value) < Return(ChapterVIA80EE.value)) {
                        alert("Chap.VI(A)-80EE Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80EEAgross.value) != null || Return(txtChapterVIA80EEAqual.value) != null || Return(ChapterVIA80EEA.value) != null) {
                    if (Return(txtChapterVIA80EEAgross.value) < Return(txtChapterVIA80EEAqual.value)) {
                        alert("Chap.VI(A)-80EEA Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80EEAqual.value) < Return(ChapterVIA80EEA.value)) {
                        alert("Chap.VI(A)-80EEA Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80EEAgross.value) == "") { txtChapterVIA80EEAgross.value = "0"; }
                if (Return(txtChapterVIA80EEAqual.value) == "") { txtChapterVIA80EEAqual.value = "0"; }
                if (Return(ChapterVIA80EEA.value) == "") { ChapterVIA80EEA.value = "0"; }
                if (Return(txtChapterVIA80EEgross.value) == "") { txtChapterVIA80EEgross.value = "0"; }
                if (Return(txtChapterVIA80EEqual.value) == "") { txtChapterVIA80EEqual.value = "0"; }
                if (Return(ChapterVIA80EE.value) == "") { ChapterVIA80EE.value = "0"; }

                if ((Return(txtChapterVIA80EEAgross.value) != 0 || Return(txtChapterVIA80EEAqual.value) != 0 || Return(ChapterVIA80EEA.value) != 0) &&
                    (Return(txtChapterVIA80EEgross.value) != 0 || Return(txtChapterVIA80EEqual.value) != 0 || Return(ChapterVIA80EE.value) != 0)) {
                    {
                        alert("One of the deduction u/s 80EE or 80EEA can be claimed.\nSpecify amount in 80EE or 80EEA, not in both.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80GGgross.value) != null || Return(txtChapterVIA80GGqual.value) != null || Return(ChapterVIA80GG.value) != null) {
                    if (Return(txtChapterVIA80GGgross.value) < Return(txtChapterVIA80GGqual.value)) {
                        alert("Chap.VI(A)-80GG Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80GGqual.value) < Return(ChapterVIA80GG.value)) {
                        alert("Chap.VI(A)-80GG Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80GGCgross.value) != null || Return(txtChapterVIA80GGCqual.value) != null || Return(ChapterVIA80GGC.value) != null) {
                    if (Return(txtChapterVIA80GGCgross.value) < Return(txtChapterVIA80GGCqual.value)) {
                        alert("Chap.VI(A)-80GGC Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80GGCqual.value) < Return(ChapterVIA80GGC.value)) {
                        alert("Chap.VI(A)-80GGC Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }
                if (Return(txtChapterVIA80Ugross.value) != null || Return(txtChapterVIA80Uqual.value) != null || Return(ChapterVIA80U.value) != null) {
                    if (Return(txtChapterVIA80Ugross.value) < Return(txtChapterVIA80Uqual.value)) {
                        alert("Chap.VI(A)-80U Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIA80Uqual.value) < Return(ChapterVIA80U.value)) {
                        alert("Chap.VI(A)-80U Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                }

                if (Return(txtChapterVIAOthersgross.value) != null || Return(txtChapterVIAOthersqual.value) != null || Return(ChapterVIOthers.value) != null) {
                    if (Return(txtChapterVIAOthersgross.value) < Return(txtChapterVIAOthersqual.value)) {
                        alert("Chap.VI(A)-Others Gross Amount cannot be less than Qualifying Amount.");
                        return false;
                    }
                    if (Return(txtChapterVIAOthersqual.value) < Return(ChapterVIOthers.value)) {
                        alert("Chap.VI(A)-Others Qualifying Amount cannot be less than Deductible Amount.");
                        return false;
                    }
                    //                    if (Return(txtChapterVIAOthersqual.value) == null) {
                    //                        if (Return(txtChapterVIAOthersgross.value) < Return(ChapterVIOthers.value)) {
                    //                            alert("Chap.VI(A)-Others Gross Amount cannot be less than Deductible Amount.");
                    //                            return false;
                    //                        }
                    //                    }

                    if (Return(txtChapterVIA80CCHgross.value) != null || Return(txtChapterVIA80CCHequal.value) != null || Return(txtChapterVIA80CCH.value) != null) {
                        if (Return(txtChapterVIA80CCHgross.value) < Return(txtChapterVIA80CCH.value)) {
                            alert("Chap.VI(A)-80CCH Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                        //if (Return(txtChapterVIA80CCHequal.value) < Return(txtChapterVIA80CCH.value)) {
                        //    alert("Chap.VI(A)-80CCH Qualifying Amount cannot be less than Deductible Amount.");
                        //    return false;
                        //}
                    }

                    if (Return(txtChapterVIA80CCH_1gross.value) != null || Return(txtChapterVIA80CCH_1equal.value) != null || Return(txtChapterVIA80CCH_1.value) != null) {
                        if (Return(txtChapterVIA80CCH_1gross.value) < Return(txtChapterVIA80CCH_1.value)) {
                            alert("Chap.VI(A)-80CCH(1) Gross Amount cannot be less than Deductible Amount.");
                            return false;
                        }
                        //if (Return(txtChapterVIA80CCH_1equal.value) < Return(txtChapterVIA80CCH_1.value)) {
                        //    alert("Chap.VI(A)-80CCH Qualifying Amount cannot be less than Deductible Amount.");
                        //    return false;
                        //}
                    }

                }

            }
            else return true;
        }
        function CalculateAmount() {
            hdnFinYear = document.getElementById("<%=hdnFinYear.ClientID %>");
            var sec17_1 = document.getElementById("<%=txtGrossSalarySec17.ClientID %>");
            var sec17_2 = document.getElementById("<%=txtValueOfPerq.ClientID %>");
            var sec17_3 = document.getElementById("<%=txtProfitSalary.ClientID %>");
            var txtSD = document.getElementById("<%=txtSD.ClientID %>");
            var txtOtherIncome = document.getElementById("<%=txtOtherIncome.ClientID %>");
            var txtOtherIncSrc = document.getElementById("<%=txtOthincsrc.ClientID %>");
            var txtS10LTA = document.getElementById("<%=txtS10LTA.ClientID %>");
            var txtS10Gratuity = document.getElementById("<%=txtS10Gratuity.ClientID %>");
            var txtS10Pension = document.getElementById("<%=txtS10Pension.ClientID %>");
            var txtS10LSE = document.getElementById("<%=txtS10LSE.ClientID %>");
            var txtS10HRA = document.getElementById("<%=txtS10HRA.ClientID %>");
            var txtS10OTH = document.getElementById("<%=txtS10OTH.ClientID %>");
            var txtGrossTotalIncome = document.getElementById("<%=txtGrossTotalIncome.ClientID %>");
            var txtChapterVIA80CCE = document.getElementById("<%=txtChapterVIA80CCE.ClientID%>");
            var txtChapterVIA80CCF = document.getElementById("<%=txtChapterVIA80CCF.ClientID%>");
            var txtChapterVIA80CCG = document.getElementById("<%=txtChapterVIA80CCG.ClientID%>");
            var txtVIA80OThers = document.getElementById("<%=txtChapterVIAOthers.ClientID %>");
            var txtChapterVIA80C = document.getElementById("<%=txtChapterVIA80C.ClientID %>");
            var txtChapterVIA80CCC = document.getElementById("<%=txtChapterVIA80CCC.ClientID %>");
            var txtChapterVIA80CCD_1 = document.getElementById("<%=txtChapterVIA80CCD_1.ClientID %>");
            var txtChapterVIA80CCD_1B = document.getElementById("<%=txtChapterVIA80CCD_1B.ClientID %>");
            var txtChapterVIA80CCD_2 = document.getElementById("<%=txtChapterVIA80CCD_2.ClientID %>");
            var txtChapterVIA80D = document.getElementById("<%=txtChapterVIA80D.ClientID %>");
            var txtChapterVIA80E = document.getElementById("<%=txtChapterVIA80E.ClientID %>");
            var txtChapterVIA80G = document.getElementById("<%=txtChapterVIA80G.ClientID %>");
            var txtChapterVIA80TTA = document.getElementById("<%=txtChapterVIA80TTA.ClientID %>");
            var txtChapterVIA80TTB = document.getElementById("<%=txtChapterVIA80TTB.ClientID%>");
            var txtChapterVIA80DD = document.getElementById("<%=txtChapterVIA80DD.ClientID%>");
            var txtChapterVIA80EE = document.getElementById("<%=txtChapterVIA80EE.ClientID%>");
            var txtChapterVIA80EEA = document.getElementById("<%=txtChapterVIA80EEA.ClientID%>");
            var txtChapterVIA80GG = document.getElementById("<%=txtChapterVIA80GG.ClientID%>");
            var txtChapterVIA80GGC = document.getElementById("<%=txtChapterVIA80GGC.ClientID%>");
            var txtChapterVIA80U = document.getElementById("<%=txtChapterVIA80U.ClientID%>");
            var txtCurrentTaxableIncome = document.getElementById("<%=txtCurrentTaxableIncome.ClientID %>");
            var txtPrevTaxableIncome = document.getElementById("<%=txtPrevTaxableIncome.ClientID %>");
            var txtS10OTHSA = document.getElementById("<%=txtS10OTHSA.ClientID %>");
            var txtChapterVIA80CCH = document.getElementById("<%=txtChapterVIA80CCH.ClientID%>");
            var txtChapterVIA80CCH_1 = document.getElementById("<%=txtChapterVIA80CCH_1.ClientID%>")
            var tempValue;
            var txtET = document.getElementById("<%=txtET.ClientID %>");
            var txtPT = document.getElementById("<%=txtPT.ClientID %>");
            var txtTotalTaxableIncome = document.getElementById("<%=txtTotalTaxableIncome.ClientID %>");
            var txtTaxOnTotalIncome = document.getElementById("<%=txtTaxOnTotalIncome.ClientID %>");
            var txtSurcharge = document.getElementById("<%=txtSurcharge.ClientID %>");
            var txtEducationCess = document.getElementById("<%=txtEducationCess.ClientID %>");
            var txtReliefUS89 = document.getElementById("<%=txtReliefUS89.ClientID %>");
            var txtNetTaxPayable = document.getElementById("<%=txtNetTaxPayable.ClientID %>");
            var txtTotalTDS = document.getElementById("<%=txtTotalTDS.ClientID %>");
            var txtTaxPayableRefundable = document.getElementById("<%=txtTaxPayableRefundable.ClientID %>");
            var txtCurrentTDS = document.getElementById("<%=txtCurrentTDS.ClientID %>");
            var txtPreviousTDS = document.getElementById("<%=txtPreviousTDS.ClientID %>");
            var txtGrossSalary = document.getElementById("<%=txtGrossSalary.ClientID %>");
            var txtCredit87A = document.getElementById("<%=txtCredit87A.ClientID %>");
            var rbtnOldRegime = document.getElementById("<%=rbtnOldRegime.ClientID %>");
            var txtS10OTHSA = document.getElementById("<%=txtS10OTHSA.ClientID %>");
            var txtTDSTCS = document.getElementById("<%=txtTDSTCS.ClientID%>");

            if (txtCurrentTDS != null && txtPreviousTDS != null && txtTDSTCS != null) txtTotalTDS.value = (Return(txtCurrentTDS.value) + Return(txtPreviousTDS.value) + Return(txtTDSTCS.value));
            if (hdnFinYear.value >= 2018) {
                var totalsec17_1_2_3 = (Return(sec17_1.value) + Return(sec17_2.value) + Return(sec17_3.value));

                tempValue = Return(totalsec17_1_2_3) + Return(txtPrevTaxableIncome.value);

                txtGrossSalary.value = tempValue;

                var totalSec10 = Return(txtS10LTA.value) + Return(txtS10Gratuity.value) + Return(txtS10Pension.value) + Return(txtS10LSE.value) + Return(txtS10HRA.value) +
                    Return(txtS10OTH.value) + Return(txtS10OTHSA.value);


                var grossTotalIncome = Return(txtGrossSalary.value) - (Return(totalSec10)) - (Return(txtSD.value) + Return(txtET.value) + Return(txtPT.value));

                txtGrossTotalIncome.value = Return(grossTotalIncome) + Return(txtOtherIncome.value) + Return(txtOtherIncSrc.value);

                txtTotalTaxableIncome.value = (Return(txtGrossTotalIncome.value)) - (((txtChapterVIA80CCE == null ? 0 : (Return(txtChapterVIA80CCE.value))) + Return(txtVIA80OThers.value) +
                    (txtChapterVIA80CCF == null ? 0 : (Return(txtChapterVIA80CCF.value))) + (txtChapterVIA80CCG == null ? 0 : (Return(txtChapterVIA80CCG.value))) +
                    Return(txtChapterVIA80C.value) + Return(txtChapterVIA80CCC.value) + Return(txtChapterVIA80CCD_1.value) + Return(txtChapterVIA80CCD_1B.value) +
                    Return(txtChapterVIA80CCD_2.value) + Return(txtChapterVIA80D.value) + Return(txtChapterVIA80E.value) +
                    Return(txtChapterVIA80G.value) + Return(txtChapterVIA80TTA.value) + Return(txtChapterVIA80TTB.value) + Return(txtChapterVIA80DD.value) +
                    Return(txtChapterVIA80EE.value) + Return(txtChapterVIA80EEA.value) + Return(txtChapterVIA80GG.value) + Return(txtChapterVIA80GGC.value) +
                    Return(txtChapterVIA80U.value) + (rbtnOldRegime.checked ? (Return(txtChapterVIA80CCH.value) + Return(txtChapterVIA80CCH_1.value)) : 0)));

                if (Return(txtTotalTaxableIncome.value) > 500000 && Return(txtCredit87A.value) > 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value <= 2023 && rbtnOldRegime.checked == true) {
                    alert("Credit Under Section 87A is Applicable Only if"
                        + " Total Taxable Income is less than RS.5,00,000.");
                    return false;
                } else if (Return(txtTotalTaxableIncome.value) > 700000 && Return(txtCredit87A.value) > 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value == 2024 && rbtnOldRegime.checked == false) {
                    alert("Credit Under Section 87A is Applicable Only if"
                        + " Total Taxable Income is less than RS.7,00,000.");
                    return false;
                } else if (Return(txtTotalTaxableIncome.value) > 1200000 && Return(txtCredit87A.value) > 0 && document.getElementById("<%=hdnFinYear.ClientID%>").value >= 2025 && rbtnOldRegime.checked == false) {
                    var relief = Return(txtTotalTaxableIncome.value) - 1200000;
                    if (!(relief < Return(txtTaxOnTotalIncome.value))) {
                        alert("Credit Under Section 87A is not Applicable");
                        return false;
                    }
                }
            }
            else {
                var grossTotalIncome = Return(txtGrossSalary.value) - (Return(txtET.value) + Return(txtPT.value));
                txtGrossTotalIncome.value = Return(grossTotalIncome);
                txtTotalTaxableIncome.value = (Return(txtGrossTotalIncome.value)) -
                    ((txtChapterVIA80CCE == null ? 0 : (Return(txtChapterVIA80CCE.value))) +
                        Return(txtVIA80OThers.value) +
                        (txtChapterVIA80CCF == null ? 0 : (Return(txtChapterVIA80CCF.value))) +
                        (txtChapterVIA80CCG == null ? 0 : (Return(txtChapterVIA80CCG.value))));
            }

            if (txtCredit87A != null)
                txtNetTaxPayable.value = (Return(txtTaxOnTotalIncome.value) + Return(txtSurcharge.value) + Return(txtEducationCess.value)) - Return(txtReliefUS89.value) - Return(txtCredit87A.value);
            else
                txtNetTaxPayable.value = (Return(txtTaxOnTotalIncome.value) + Return(txtSurcharge.value) + Return(txtEducationCess.value)) - Return(txtReliefUS89.value);

            var payRefundable = Return(txtNetTaxPayable.value) - Return(txtTotalTDS.value);
            if (Return(payRefundable) > 0) txtTaxPayableRefundable.value = Return(payRefundable);
            else { txtTaxPayableRefundable.value = "(" + Math.abs(Return(payRefundable)) + ")"; }
        }
        function Return(tempValue) {
            if (isNaN(tempValue)) {
                tempValue = "0"
                return eval(tempValue);
            }
            else if (tempValue == "" || tempValue == "undefined") { return 0; }
            else { return eval(parseFloat(tempValue).toString()); }
        }
        function GetDeducteeNameValue(source, eventArgs) {
            var value = eventArgs.get_value();
            var arrValue = new Array();
            arrValue = value.split('-');
            document.getElementById("<%=hdnEmployeeSerialNo.ClientID%>").value = arrValue[0];
            document.getElementById("<%=txtTotalTDS.ClientID%>").value = Number(arrValue[1]);
            var content = eventArgs.get_text();
            var arr = new Array();
            arr = content.split('-');
            //document.getElementById("<%=txtPan.ClientID%>").value = arr.length > 2 ? arr[2] : arr[1];
            document.getElementById("<%=txtName.ClientID%>").value = arr[0];
            document.getElementById("<%=txtPan.ClientID%>").value = arr[1];
            document.getElementById("<%=ddlGender.ClientID%>").value = arr[2];
            document.getElementById("<%=ddlSeniorCitizen.ClientID%>").value = arr[3];
        }
        function ClearDeducteeName() {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) { }
            else {
                document.getElementById("<%=hdnEmployeeSerialNo.ClientID%>").value = "-1";
                document.getElementById("<%=txtPan.ClientID%>").value = "";
            }
        }
        function UpdateCheckBoxStatus() {
            var hdnIsChecked = document.getElementById("<%=hdnIsChecked.ClientID%>");
            hdnIsChecked.value = "False";
        }
        function SelectAllCheckBox() {
            var panel = document.getElementById("Panel1");
            for (i = 0; i < document.all.length; i++) {
                if (document.all[i].type == 'checkbox') {
                    document.all[i].checked = true;
                    UpdateCheckBoxStatus();
                }
            }
            return false;
        }
        function UnSelectAllCheckBox() {
            for (i = 0; i < document.all.length; i++) {
                if (document.all[i].type == 'checkbox') {
                    document.all[i].checked = false;
                    UpdateCheckBoxStatus();
                }
            }
            return false;
        }
        function checkFinYear(objectName, option) {
            if (document.getElementById("<%=hdnFinYear.ClientID%>").value < 2016) {
                if (option == "1" || option == "2" || option == "3" || option == "4" || option == "5" || option == "6" || option == "7" || option == "8") {
                    if (objectName.value.trim() != "") {
                        alert("Landlord detail is applicable from FY 2016-17.");
                        return false;
                    }
                }
                else {
                    if (objectName.value.trim() != "") {
                        alert("Lender detail is applicable from FY 2016-17.");
                        return false;
                    }
                }
            }
            return true;
        }
        function checkValidatePAN(objectName, option) {
            objectName.value = objectName.value.toUpperCase();
            var message = option == "1" ? "Landlord 1" : option == "2" ? "Landlord 2" : option == "3" ? "Landlord 3" : option == "4" ? "Landlord 4" : option == "5" ? "Lender 1" : option == "6" ? "Lender 2" : option == "7" ? "Lender 3" : "Lender 4";
            return ValidatePAN(objectName, message + " PAN", 10, false);
        }
        function validateMoreDetails() {
            SAFName = document.getElementById("<%=txtSAFName.ClientID%>").value
            SAFContributionFrom = document.getElementById("<%=txtSAFContributionFrom.ClientID%>").value
            SAFContributionTo = document.getElementById("<%=txtSAFContributionTo.ClientID%>").value
            SAFContributionRepaid = document.getElementById("<%=txtSAFContributionRepaid.ClientID%>").value
            SAFAvgTaxRate = document.getElementById("<%=txtSAFAvgTaxRate.ClientID%>").value
            SAFTaxDeducted = document.getElementById("<%=txtSAFTaxDeducted.ClientID%>").value
            if (SAFName.trim() != "" || SAFContributionFrom.trim() != "" || SAFContributionTo.trim() != "" || SAFContributionRepaid.trim() != "" || SAFAvgTaxRate.trim() != "" || SAFTaxDeducted.trim() != "") {
                if (SAFName.trim() == "") {
                    alert("Specify Name of the superannuation fund");
                    document.getElementById("<%=txtSAFName.ClientID%>").focus();
                    return false;
                }
                else if (SAFContributionFrom.trim() == "") {
                    alert("Specify Contribution From");
                    document.getElementById("<%=txtSAFContributionFrom.ClientID%>").focus();
                    return false;
                }
                else if (SAFContributionTo.trim() == "") {
                    alert("Specify Contribution To");
                    document.getElementById("<%=txtSAFContributionTo.ClientID%>").focus();
                    return false;
                }
                else if (SAFContributionRepaid.trim() == "") {
                    alert("Specify Contribution Repaid");
                    document.getElementById("<%=txtSAFContributionRepaid.ClientID%>").focus();
                    return false;
                }
                else if (SAFAvgTaxRate.trim() == "") {
                    alert("Specify Average tax rate");
                    document.getElementById("<%=txtSAFAvgTaxRate.ClientID%>").focus();
                    return false;
                }
                else if (SAFTaxDeducted.trim() == "") {
                    alert("Specify Tax Deducted");
                    document.getElementById("<%=txtSAFTaxDeducted.ClientID%>").focus();
                    return false;
                }
            }
            date1 = new Date();
            var date1 = new Date();
            date1.setFullYear(SAFContributionFrom.substring(6), (SAFContributionFrom.substring(3, 5)), SAFContributionFrom.substring(0, 2));
            var date2 = new Date();
            date2.setFullYear(SAFContributionTo.substring(6), (SAFContributionTo.substring(3, 5)), SAFContributionTo.substring(0, 2));
            if ((date1 >= date2) && ((SAFContributionFrom.trim() != "") || (SAFContributionTo.trim() != ""))) {
                alert("Contribution From cannot be greater than or equal to Contribution To");
                document.getElementById("<%=txtSAFContributionTo.ClientID%>").focus();
                return false;
            }
            if (Return(SAFAvgTaxRate) >= 100) {
                alert("Average tax rate should be below 100%");
                document.getElementById("<%=txtSAFAvgTaxRate.ClientID%>").focus();
                return false;
            }
            if (SAFAvgTaxRate.trim() == "0") {
                alert("Average tax rate should be greater than zero");
                document.getElementById("<%=txtSAFAvgTaxRate.ClientID%>").focus();
                return false;
            }
            var reqdTaxDeducted = Return(SAFContributionRepaid) * (Return(SAFAvgTaxRate) / 100)
            if ((Return(SAFTaxDeducted) < (reqdTaxDeducted - 10)) || (Return(SAFTaxDeducted) > (reqdTaxDeducted + 10))) {
                alert("Based on ( Contribution Repaid * Average Tax Rate (%)) Tax Deducted  is allowed a margin of error of Rs 10.");
                return false;
            }
            if ((document.getElementById("<%=txtNameLL1.ClientID%>").value == "") && (document.getElementById("<%=txtPANLL1.ClientID%>").value != "")) {
                alert("PAN for LandLord 1 is given, Provide Name for LandLord 1");
                return false;
            }
            else if ((document.getElementById("<%=txtNameLL1.ClientID%>").value != "") && (document.getElementById("<%=txtPANLL1.ClientID%>").value == "")) {
                alert("Name for LandLord 1 is given, Provide PAN for LandLord 1");
                return false;
            }
            else if ((document.getElementById("<%=txtNameLL2.ClientID%>").value == "") && (document.getElementById("<%=txtPANLL2.ClientID%>").value != "")) {
                alert("PAN for LandLord 2 is given, Provide Name for LandLord 2");
                return false;
            }
            else if ((document.getElementById("<%=txtNameLL2.ClientID%>").value != "") && (document.getElementById("<%=txtPANLL2.ClientID%>").value == "")) {
                alert("Name for LandLord 2 is given, Provide PAN for LandLord 2");
                return false;
            }
            else if ((document.getElementById("<%=txtNameLL3.ClientID%>").value == "") && (document.getElementById("<%=txtPANLL3.ClientID%>").value != "")) {
                alert("PAN for LandLord 3 is given, Provide Name for LandLord 3");
                return false;
            }
            else if ((document.getElementById("<%=txtNameLL3.ClientID%>").value != "") && (document.getElementById("<%=txtPANLL3.ClientID%>").value == "")) {
                alert("Name for LandLord 3 is given, Provide PAN for LandLord 3");
                return false;
            }
            else if ((document.getElementById("<%=txtNameLL4.ClientID%>").value == "") && (document.getElementById("<%=txtPANLL4.ClientID%>").value != "")) {
                alert("PAN for LandLord 4 is given, Provide Name for LandLord 4");
                return false;
            }
            else if ((document.getElementById("<%=txtNameLL4.ClientID%>").value != "") && (document.getElementById("<%=txtPANLL4.ClientID%>").value == "")) {
                alert("Name for LandLord 4 is given, Provide PAN for LandLord 4");
                return false;
            }
            if ((document.getElementById("<%=txtNameL1.ClientID%>").value == "") && (document.getElementById("<%=txtPANL1.ClientID%>").value != "")) {
                alert("PAN for Lender 1 is given, Provide Name for Lender 1");
                return false;
            }
            else if ((document.getElementById("<%=txtNameL1.ClientID%>").value != "") && (document.getElementById("<%=txtPANL1.ClientID%>").value == "")) {
                alert("Name for Lender 1 is given, Provide PAN for Lender 1");
                return false;
            }
            else if ((document.getElementById("<%=txtNameL2.ClientID%>").value == "") && (document.getElementById("<%=txtPANL2.ClientID%>").value != "")) {
                alert("PAN for Lender 2 is given, Provide Name for Lender 2");
                return false;
            }
            else if ((document.getElementById("<%=txtNameL2.ClientID%>").value != "") && (document.getElementById("<%=txtPANL2.ClientID%>").value == "")) {
                alert("Name for Lender 2 is given, Provide PAN for Lender 2");
                return false;
            }
            else if ((document.getElementById("<%=txtNameL3.ClientID%>").value == "") && (document.getElementById("<%=txtPANL3.ClientID%>").value != "")) {
                alert("PAN for Lender 3 is given, Provide Name for Lender 3");
                return false;
            }
            else if ((document.getElementById("<%=txtNameL3.ClientID%>").value != "") && (document.getElementById("<%=txtPANL3.ClientID%>").value == "")) {
                alert("Name for Lender 3 is given, Provide PAN for Lender 3");
                return false;
            }
            else if ((document.getElementById("<%=txtNameL4.ClientID%>").value == "") && (document.getElementById("<%=txtPANL4.ClientID%>").value != "")) {
                alert("PAN for Lender 4 is given, Provide Name for Lender 4");
                return false;
            }
            else if ((document.getElementById("<%=txtNameL4.ClientID%>").value != "") && (document.getElementById("<%=txtPANL4.ClientID%>").value == "")) {
                alert("Name for Lender 4 is given, Provide PAN for Lender 4");
                return false;
            }
            return true;
        }
        function SetStatus() {
            var hdnSearch = document.getElementById("<%=hdnSearch.ClientID%>");
            if (hdnSearch.value == "0") { hdnSearch.value = "1"; }
            else { hdnSearch.value = "0"; }
            SetSearchPanelVisibility();
        }
        function Show_Popup_Export() {
            if (document.getElementById("<%=ddlBlkUpdateType.ClientID%>").value > 0) {
                $find("popUpBulkExport_Control").show();
            }
        }
        function Show_Popup_Import() {
            $find("popUpBulkImport_Control").show();
        }
        function SetBulkUpdateType() { document.getElementById("<%=hdnBulkUpdateType.ClientID%>").value = document.getElementById("<%=ddlBlkUpdateType.ClientID%>").value; }
        function SetSearchPanelVisibility() {
            var btnOpenSearch = document.getElementById("<%=btnOpenSearch.ClientID%>");
            var pnlSearch = document.getElementById("<%=pnlSearch.ClientID%>");
            if (btnOpenSearch == null) { document.getElementById("<%=hdnSearch.ClientID%>").value = "0"; return; }
            else {
                if (document.getElementById("<%=hdnSearch.ClientID%>").value == "0") {
                    if (btnOpenSearch != null) btnOpenSearch.style.display = '';
                    if (pnlSearch != null) pnlSearch.style.display = 'none';
                    document.getElementById("<%=txtSearchSerialNo.ClientID%>").value = "";
                    document.getElementById("<%=txtSearchPAN.ClientID%>").value = "";
                }
                else {
                    if (btnOpenSearch != null) btnOpenSearch.style.display = 'none';
                    if (pnlSearch != null) pnlSearch.style.display = '';
                }
            }
        }
        function FileValidation() {
            document.getElementById("<%=pnlPopup1.ClientID%>").style.display = 'block';
            var uploadFile = document.getElementById("<%=fupTextFile.ClientID%>");
             var fileType = '.txt';

             // Check if a file is selected
             if (uploadFile.files.length > 0) {
                 var file = uploadFile.files[0];
                 var fileName = file.name.toLowerCase(); // File name in lowercase            

                 // Validate file type
                 if (!fileName.endsWith(fileType)) {
                     alert("Only .txt files are allowed for upload.");
                    document.getElementById("<%=pnlPopup1.ClientID%>").style.display = 'none';
                    return false;
                }
            }
            return true;
        }
    </script>
    <style type="text/css">
        .style1 {
            width: 151px;
        }

        .auto-style1 {
            width: 39px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="corrSalaryUpdatePanel" runat="server">
        <ContentTemplate>
            <asp:Panel ID="pnlBulkExport" runat="server" Height="100px" BackColor="White" CssClass="modalPopup"
                Style="display: none">
                <br />
                <br />
                <asp:Label ID="lblBulkExport" Font-Size="Medium" Text="Exporting Data to Excel Sheet. Please Wait....."
                    Font-Bold="true" ForeColor="Red" runat="server"> </asp:Label>
            </asp:Panel>
            <asp:Panel ID="pnlBulkImport" runat="server" Height="100px" BackColor="White" CssClass="modalPopup"
                Style="display: none">
                <br />
                <br />
                <asp:Label ID="lblBulkImport" Font-Size="Medium" Text="Importing Excel Data. Please Wait....."
                    Font-Bold="true" ForeColor="Red" runat="server"> </asp:Label>
            </asp:Panel>
            <asp:Panel ID="pnlUpBlkUpdate" runat="server" BackColor="White" CssClass="modalPopup"
                Style="display: none">
                <asp:Label ID="lblExport_Heading" Text="BULK UPDATE - EXPORT" Font-Bold="true" ForeColor="Brown"
                    runat="server"> </asp:Label>
                <hr />
                <table>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td style="width: 100px">Correction Type
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlBlkUpdateType" runat="server" Width="140px" onChange="SetBulkUpdateType();">
                                <asp:ListItem Text="Select" Value="0"></asp:ListItem>
                                <asp:ListItem Text="ADD" Value="1"></asp:ListItem>
                                <asp:ListItem Text="UPDATE" Value="2"></asp:ListItem>
                                <asp:ListItem Text="DELETE" Value="3"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <%--<asp:Button ID="btnOk" Text="Ok" runat="server" Width="70px" CssClass="cmnBtn" OnClick="btnOk_Click" OnClientClick="SetBulkUpdateType();" />--%>
                            <asp:Button ID="btnOk" Text="Ok" runat="server" Width="70px" CssClass="cmnBtn" OnClientClick="Show_Popup_Export();"
                                OnClick="btnExport_Click" />
                            <asp:Button ID="btnClosePopUp" Text="Close" runat="server" Width="70px" CssClass="cmnBtn" />
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlImport" runat="server" BackColor="White" CssClass="modalPopup"
                Width="400px" Style="display: none">
                <asp:Label ID="lblImport_Heading" Text="BULK UPDATE - IMPORT" Font-Bold="true" ForeColor="Brown"
                    runat="server"> </asp:Label>
                <hr />
                <table>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td style="width: 100px">Select File
                        </td>
                        <td>
                            <asp:FileUpload ID="fileUpload" runat="server" Width="300px" />
                        </td>
                    </tr>
                    <tr>
                        <td style="height: 10px"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td align="right">
                            <asp:Button ID="btnImportPopUp" Text="Import" runat="server" Width="70px" CssClass="cmnBtn"
                                OnClientClick="Show_Popup_Import();" OnClick="btnImportPopUp_Click" />
                            <asp:Button ID="btnCloseImportPopUp" Text="Close" runat="server" Width="70px" CssClass="cmnBtn" />
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="panelAnnexure2" runat="server" CssClass="modalPopup" Style="width: 50%; display: none; border-style: inset; border-color: Black"
                BackColor="White">
                <div style="width: 100%; height: 15px; border: 1px; border-color: Black; margin-bottom: 15px; background-color: Black; color: White; padding: 5px 0px 5px 0px;">
                    <center>
                        <asp:Label ID="lblAnnexure2" runat="server" Font-Bold="true"> Upload Defaults File</asp:Label>
                    </center>
                </div>
                <table style="float: inherit; margin: auto;">
                    <tr>
                        <td>
                            <label>
                                Select
                            </label>
                        </td>
                        <td>
                            <asp:FileUpload ID="fupPfxFile" runat="server" BackColor="#E5E5E5" Width="555px" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Button ID="btnUploadDefaults" runat="server" Text="Upload" CssClass="cmnBtn"
                                OnClick="btnUploadDefaults_Click" />
                        </td>
                        <td>
                            <asp:Button ID="btnCancelAnnex2" runat="server" Text="Cancel" CssClass="cmnBtn" />
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <cc1:ModalPopupExtender ID="allOrRowWise" runat="server" CancelControlID="btnCancelAnnex2"
                TargetControlID="btnUpdDefaults" BackgroundCssClass="modalBackground" BehaviorID="behaviourAnnexure2"
                PopupControlID="panelAnnexure2">
            </cc1:ModalPopupExtender>
            <asp:HiddenField ID="hdnEmployeeSerialNo" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnCurrentCorrStatus" runat="server" Value="-1" />
            <asp:HiddenField ID="hdnPopupPageIndex" runat="server" Value="1" />
            <asp:HiddenField ID="hdnPopupPageSize" runat="server" Value="10" />
            <asp:HiddenField ID="hdnUpdatedSalsPageSize" runat="server" Value="10" />
            <asp:HiddenField ID="hdnUpdatedSalsPageIndex" runat="server" Value="1" />
            <asp:HiddenField ID="hdnSelectedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnUpdatedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnUpdateItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnDeleteItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnIsCorrEREturnValid" runat="server" Value="0" />
            <asp:HiddenField ID="hdnExcludedItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnUnlinkedSalItems" runat="server" Value="" />
            <asp:HiddenField ID="hdnIsChecked" runat="server" Value="True" />
            <asp:HiddenField ID="hdnPageIndex" runat="server" Value="1" />
            <asp:HiddenField ID="hdnPageSize" runat="server" Value="10" />
            <asp:HiddenField ID="hdnisUpdated" runat="server" Value="0" />
            <asp:HiddenField ID="hdnFinYear" runat="server" Value="" />
            <asp:HiddenField ID="hdnSearch" runat="server" Value="0" />
            <asp:HiddenField ID="hdnBulkUpdateType" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnisUpdate" runat="server" Value="N" />
            <asp:HiddenField ID="hdnisDelete" runat="server" Value="N" />
            <asp:HiddenField ID="hdnDelete" runat="server" Value="" />
            <asp:HiddenField ID="hdnIsNewRegime" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsUs94P" runat="server" Value="0" />
            <asp:HiddenField ID="hdnPANSelectedItems94P" runat="server" Value="" />
            <asp:HiddenField ID="hdnPANSelectedItems92" runat="server" Value="" />
            <cc1:ModalPopupExtender ID="popUpBlkUpdate" runat="server" CancelControlID="btnClosePopUp"
                BackgroundCssClass="modalBackground" TargetControlID="btnExport" PopupControlID="pnlUpBlkUpdate">
            </cc1:ModalPopupExtender>
            <cc1:ModalPopupExtender ID="popUpImport" runat="server" CancelControlID="btnCloseImportPopUp"
                BackgroundCssClass="modalBackground" TargetControlID="btnImport" PopupControlID="pnlImport">
            </cc1:ModalPopupExtender>
            <cc1:ModalPopupExtender ID="popUpBulkExport" BehaviorID="popUpBulkExport_Control"
                runat="server" CancelControlID="btnCloseImportPopUp" BackgroundCssClass="modalBackground"
                TargetControlID="lblBulkExport" PopupControlID="pnlBulkExport">
            </cc1:ModalPopupExtender>
            <cc1:ModalPopupExtender ID="popUpBulkImport" BehaviorID="popUpBulkImport_Control"
                runat="server" CancelControlID="btnCloseImportPopUp" BackgroundCssClass="modalBackground"
                TargetControlID="lblBulkImport" PopupControlID="pnlBulkImport">
            </cc1:ModalPopupExtender>
            <asp:MultiView ID="mvSalary" runat="server" ActiveViewIndex="0">
                <asp:View ID="vwSalary" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td>
                                <table width="90%">
                                    <tr>
                                        <td class="vHCol" style="width: 190px">Name
                                        </td>
                                        <td class="iCol" style="width: 150px">
                                            <asp:TextBox ID="txtName" runat="server" CssClass="txtBPL" onkeyup="ClearDeducteeName();"></asp:TextBox>
                                            <cc1:AutoCompleteExtender ID="autoCompleteExtender" runat="server" MinimumPrefixLength="2"
                                                ServicePath="~/WebServices/AutoCompleteService.asmx" TargetControlID="txtName"
                                                ServiceMethod="GetCorrEmployeeAutocompleteForSalary" CompletionInterval="700"
                                                EnableCaching="false" CompletionSetCount="50" DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true"
                                                FirstRowSelected="True" OnClientItemSelected="GetDeducteeNameValue">
                                            </cc1:AutoCompleteExtender>
                                        </td>
                                        <td style="width: 190px"></td>
                                        <td class="vHCol" style="width: 190px">PAN
                                        </td>
                                        <td class="iCol" style="width: 150px">
                                            <asp:TextBox ID="txtPan" runat="server" CssClass="roTxtBR" Style="text-align: left"
                                                Enabled="false"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr id="rwNewOldRegime" runat="server">
                                        <td class="vHcol">
                                            <asp:Label ID="lblNewOldRegime" Text="Calculate Tax As Per 115 BAC ?" runat="server"></asp:Label>
                                        </td>
                                        <td style="width: 200px">
                                            <table>
                                                <tr>
                                                    <td style="padding-left: 1px">
                                                        <asp:RadioButton ID="rbtnOldRegime" runat="server" Checked="true" GroupName="sal"
                                                            Text="No" onclick="CalculateAmount();" />
                                                        <asp:RadioButton ID="rbtnNewRegime" runat="server" GroupName="sal" Text="Yes" onclick="CalculateAmount();" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                        <td>
                                            <table>
                                                <tr id="rwSec194P" runat="server">
                                                    <td style="padding-left: 1px">
                                                        <asp:CheckBox ID="chk194p" Text="U/s 194P" runat="server" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol" style="width: 190px">Gender </td>
                                        <td class="iCol" style="width: 80px">
                                            <asp:DropDownList ID="ddlGender" runat="server" CssClass="dropDownList">
                                                <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                                <asp:ListItem Text="Male" Value="0"></asp:ListItem>
                                                <asp:ListItem Text="Female" Value="1"></asp:ListItem>
                                            </asp:DropDownList>
                                        </td>
                                        <td style="width: 190px"></td>
                                        <td class="vHCol" style="width: 190px">Senior Citizen </td>
                                        <td class="iCol" style="width: 150px">
                                            <asp:DropDownList ID="ddlSeniorCitizen" runat="server" CssClass="dropDownList">
                                                <asp:ListItem Text="None" Value="0"></asp:ListItem>
                                                <asp:ListItem Text="Senior Citizen" Value="1"></asp:ListItem>
                                                <asp:ListItem Text="Very Senior Citizen" Value="2"></asp:ListItem>
                                            </asp:DropDownList>
                                        </td>
                                    </tr>
                                    <tr id="trhr" runat="server" visible="true">
                                        <td colspan="6">
                                            <hr />
                                        </td>
                                    </tr>
                        </tr>
                    </table>
                    <table width="90%">
                        <tr>
                            <td class="vHCol" style="width: 190px">Gross Salary
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtGrossSalary" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">Sec.10(13A)
                            </td>
                            <td id="S10HRA" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtS10HRA" runat="server" CssClass="txtBPR" AutoComplete="Off" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onchange="return checkDecimalNo(this);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Gross Salary Sec.17(1)
                            </td>
                            <td id="GrossSalarySec17" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtGrossSalarySec17" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">Sec.10(14)</td>
                            <td id="S10OTHSA" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtS10OTHSA" runat="server" CssClass="txtBPR" AutoComplete="Off" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onchange="return checkDecimalNo(this);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Value Of Perquisites Sec.17(2)
                            </td>
                            <td id="ValueOfPerq" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtValueOfPerq" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">Any Other Exemption u/s10
                            </td>
                            <td id="S10OTH" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtS10OTH" runat="server" CssClass="txtBPR" AutoComplete="Off" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onchange="return checkDecimalNo(this);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Profits Lieu Of Salary Sec.17(3)
                            </td>
                            <td id="ProfitSalary" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtProfitSalary" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">Standard Deduction [16(ia)]
                            </td>
                            <td id="SD" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtSD" runat="server" CssClass="txtBPR" AutoComplete="Off" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onchange="return checkDecimalNo(this);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Sec.10(5)
                            </td>
                            <td id="S10LTA" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtS10LTA" runat="server" CssClass="txtBPR" AutoComplete="Off" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onchange="return checkDecimalNo(this);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">Entertainment Allowance (ET) [16(ii)]
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtET" runat="server" CssClass="txtBPR" AutoComplete="Off" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onchange="return checkDecimalNo(this);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Sec.10(10)
                            </td>
                            <td id="S10Gratuity" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtS10Gratuity" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">Profession Tax (PT) [16(iii)]
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtPT" runat="server" CssClass="txtBPR" AutoComplete="Off" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onchange="return checkDecimalNo(this);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Sec.10(10A)
                            </td>
                            <td id="S10Pension" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtS10Pension" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">
                                <asp:Label ID="LabelOtherIncome" Text="Other Income - HP" runat="server" Width="110px">
                                </asp:Label>
                            </td>
                            <td id="OtherIncome" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtOtherIncome" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,1,1);;" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Sec.10(10AA)
                            </td>
                            <td id="S10LSE" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtS10LSE" runat="server" CssClass="txtBPR" AutoComplete="Off" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onchange="return checkDecimalNo(this);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">Other Income Source
                            </td>
                            <td id="Othincsrc" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtOthincsrc" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td style="width: 30px"></td>
                            <td class="vHCol" style="width: 190px">Gross Total Income
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtGrossTotalIncome" runat="server" CssClass="roTxtBR" Enabled="false"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="tr1" runat="server" visible="true">
                            <td colspan="6">
                                <hr />
                            </td>
                        </tr>
                    </table>
                    <table width="90%">
                        <tr>
                            <td></td>
                            <td>Gross Amt.
                            </td>
                            <td>Qualifying Amt.
                            </td>
                            <td>Deductible Amt.
                            </td>
                        </tr>
                        <tr id="ChapterVIA80C" runat="server">
                            <td id="ChapterVIA80Clbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80C
                            </td>
                            <td id="ChapterVIA80Cgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80Cgross" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80Cqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80Cqual" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80C" runat="server" CssClass="txtBPR" AutoComplete="Off"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onchange="return checkDecimalNo(this);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80CCC" runat="server">
                            <td id="ChapterVIA80CCClbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80CCC
                            </td>
                            <td id="ChapterVIA80CCCgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCCgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80CCCqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCCqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCC" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80CCD_1" runat="server">
                            <td id="ChapterVIA80CCD_1lbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80CCD(1)
                            </td>
                            <td id="ChapterVIA80CCD_1gross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCD_1gross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80CCD_1qual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCD_1qual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCD_1" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80CCD_1B" runat="server">
                            <td id="ChapterVIA80CCD_1Blbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80CCD(1B)
                            </td>
                            <td id="ChapterVIA80CCD_1Bgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCD_1Bgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80CCD_1Bqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCD_1Bqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCD_1B" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80CCD_2" runat="server">
                            <td id="ChapterVIA80CCD_2lbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80CCD(2)
                            </td>
                            <td id="ChapterVIA80CCD_2gross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCD_2gross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80CCD_2qual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCD_2qual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCD_2" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80D" runat="server">
                            <td id="ChapterVIA80Dlbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80D
                            </td>
                            <td id="ChapterVIA80Dgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80Dgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80Dqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80Dqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80D" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80DD" runat="server">
                            <td id="ChapterVIA80DDlbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80DD
                            </td>
                            <td id="ChapterVIA80DDgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80DDgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80DDqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80DDqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80DD" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80E" runat="server">
                            <td id="ChapterVIA80Elbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80E
                            </td>
                            <td id="ChapterVIA80Egross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80Egross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80Equal" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80Equal" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80E" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80EE" runat="server">
                            <td id="ChapterVIA80EElbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80EE
                            </td>
                            <td id="ChapterVIA80EEgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80EEgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80EEqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80EEqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80EE" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80EEA" runat="server">
                            <td id="ChapterVIA80EEAlbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80EEA
                            </td>
                            <td id="ChapterVIA80EEAgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80EEAgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80EEAqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80EEAqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80EEA" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80G" runat="server">
                            <td id="ChapterVIA80Glbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80G
                            </td>
                            <td id="ChapterVIA80Ggross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80Ggross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80Gqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80Gqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80G" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80GG" runat="server">
                            <td id="ChapterVIA80GGlbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80GG
                            </td>
                            <td id="ChapterVIA80GGgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80GGgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80GGqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80GGqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80GG" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80GGC" runat="server">
                            <td id="ChapterVIA80GGClbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80GGC
                            </td>
                            <td id="ChapterVIA80GGCgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80GGCgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80GGCqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80GGCqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80GGC" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80TTA" runat="server">
                            <td id="ChapterVIA80TTAlbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80TTA
                            </td>
                            <td id="ChapterVIA80TTAgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80TTAgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80TTAqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80TTAqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80TTA" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80TTB" runat="server">
                            <td id="ChapterVIA80TTBlbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80TTB
                            </td>
                            <td id="ChapterVIA80TTBgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80TTBgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80TTBqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80TTBqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80TTB" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="row80CCF" runat="server">
                            <td id="row80CCFlbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80CCF
                            </td>
                            <td id="row80CCFgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCFgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="row80CCFqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCFqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCF" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="row80CCG" runat="server">
                            <td class="vHCol" style="width: 190px">Chap.VI(A)-80CCG
                            </td>
                            <td id="row80CCGgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCGgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="row80CCGqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCGqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCG" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="row80CCE" runat="server">
                            <td class="vHCol" style="width: 190px">Chap.VI(A)-80CCE
                            </td>
                            <td id="row80CCEgross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCEgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="row80CCEqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCEqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCE" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="ChapterVIA80U" runat="server">
                            <td id="ChapterVIA80Ulbl" runat="server" class="vHCol" style="width: 190px">Chap.VI(A)-80U
                            </td>
                            <td id="ChapterVIA80Ugross" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80Ugross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td id="ChapterVIA80Uqual" runat="server" class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80Uqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80U" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Chap.VI(A)-80CCH</td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCHgross" runat="server" AutoComplete="Off" CssClass="txtBPR" onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCHequal" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCH" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Chap.VI(A)-80CCH(1)</td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCH_1gross" runat="server" AutoComplete="Off" CssClass="txtBPR" onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIA80CCH_1equal" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIA80CCH_1" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Chap.VI(A)-Others
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIAOthersgross" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 190px">
                                <asp:TextBox ID="txtChapterVIAOthersqual" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtChapterVIAOthers" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr id="tr2" runat="server" visible="true">
                            <td colspan="4">
                                <hr />
                            </td>
                        </tr>
                    </table>
                    </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <td class="vHCol" style="width: 190px">Total Taxable Income
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtTotalTaxableIncome" runat="server" CssClass="roTxtBR" Enabled="false"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                            <td style="width: 190px"></td>
                            <td class="vHCol" style="width: 190px">Total TDS
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtTotalTDS" runat="server" CssClass="roTxtBR" Enabled="false" onchange="return checkDecimalNo(this);"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Tax on Total Income
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtTaxOnTotalIncome" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 190px"></td>
                            <td class="vHCol" style="width: 190px">Tax Payable/Refundable
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtTaxPayableRefundable" runat="server" CssClass="roTxtBR" Enabled="false"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Credit u/s 87A
                            </td>
                            <td id="Credit87A" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtCredit87A" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 190px"></td>
                            <td class="vHCol" style="width: 190px">Taxable Inc. Current
                            </td>
                            <td id="rowCurrentIncome" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtCurrentTaxableIncome" runat="server" CssClass="txtBPR" onchange="return checkDecimalNo(this);"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Surcharge
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtSurcharge" runat="server" CssClass="txtBPR" Enabled="true" onchange="return checkDecimalNo(this);"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 190px"></td>
                            <td class="vHCol" style="width: 190px">TDS Current
                            </td>
                            <td id="rowCurrentTDS" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtCurrentTDS" runat="server" CssClass="txtBPR" onchange="return checkDecimalNo(this);"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Education Cess
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtEducationCess" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 190px"></td>
                            <td class="vHCol" style="width: 190px">Taxable Inc. Previous
                            </td>
                            <td id="rowPreviousIncome" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtPrevTaxableIncome" runat="server" CssClass="txtBPR" onchange="return checkDecimalNo(this);"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Relief u/s 89
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtReliefUS89" runat="server" AutoComplete="Off" CssClass="txtBPR"
                                    onchange="return checkDecimalNo(this);" onkeypress="return numeralsOnly(this, event,10,2,0,1);"
                                    onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td style="width: 190px"></td>
                            <td class="vHCol" style="width: 190px">TDS Previous
                            </td>
                            <td id="rowPreviousTDS" runat="server" class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtPreviousTDS" runat="server" CssClass="txtBPR" onchange="return checkDecimalNo(this);"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol" style="width: 190px">Net Tax Payable
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtNetTaxPayable" runat="server" CssClass="roTxtBR" Enabled="false"></asp:TextBox>
                            </td>
                            <td style="width: 190px"></td>
                            <td class="vHCol" style="width: 190px">TDS at Higher Rate
                            </td>
                            <td id="rowHigherRate" runat="server" class="iCol" style="width: 150px">
                                <asp:DropDownList ID="ddlTDSHigherRate" runat="server" CssClass="dropDownList">
                                    <asp:ListItem Text="No" Value="0"></asp:ListItem>
                                    <asp:ListItem Text="Yes" Value="1"></asp:ListItem>
                                </asp:DropDownList>
                            </td>
                        </tr>
                        <tr id="newOtherTCSTDS" runat="server">
                            <td class="vHCol" style="width: 190px">TDS/TCS Credit of Other Income
                            </td>
                            <td class="iCol" style="width: 150px">
                                <asp:TextBox ID="txtTDSTCS" runat="server" CssClass="txtBPR" onchange="return checkDecimalNo(this);"
                                    onkeypress="return numeralsOnly(this, event,10,2,0,1);" onkeyUp="CalculateAmount();"></asp:TextBox>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <asp:Button ID="btnMoreDetails" runat="server" CssClass="cmnBtn" OnClick="btnMoreDetails_Click"
                                    TabIndex="7" Text="More" />
                            </td>

                        </tr>
                        <tr id="tr3" runat="server" visible="true">
                            <td colspan="6">
                                <hr />
                            </td>
                        </tr>
                    </table>
                    </td> </tr> </table> </td> </tr>
                    <tr>
                        <td>
                            <table>
                                <tr>
                                    <td>
                                        <asp:Button ID="btnViewExisting" runat="server" CssClass="cmnBtn" OnClick="btnViewExisting_Click"
                                            Text="View Existing" />
                                    </td>
                                    <td class="auto-style1">
                                        <asp:Button ID="btnNew" runat="server" CssClass="cmnBtn" OnClick="btnNew_Click" OnClientClick="return OnNewRecord();"
                                            Text="New" />
                                    </td>
                                    <td>
                                        <asp:Button ID="btnUpdate" runat="server" CssClass="cmnBtn" OnClick="btnUpdate_Click"
                                            OnClientClick="return Validation();" Text="Update" />
                                    </td>
                                    <td>
                                        <asp:Button ID="btnBlkUpdate" runat="server" CssClass="cmnBtn" OnClick="btnOk_Click"
                                            OnClientClick="SetBulkUpdateType();" Text="Bulk Update" />
                                    </td>
                                    <td>
                                        <asp:Button ID="btnRemove" runat="server" CssClass="cmnBtn" OnClick="btnRemove_Click"
                                            OnClientClick="return ValidateSerialNo();" Text="Remove" />
                                    </td>
                                    <td>
                                        <asp:Button ID="btnUpdDefaults" runat="server" CssClass="cmnBtn" OnClick="btnUpdDefaults_Click"
                                            Text="Update Defaults" Visible="false" />
                                    </td>
                                    <td>
                                        <asp:Button ID="btnClose" runat="server" CssClass="cmnBtn" OnClick="btnClose_Click"
                                            Text="Close" />
                                    </td>
                                    <td>
                                        <asp:Button ID="btnOpenSearch" runat="server" CssClass="cmnBtn" OnClientClick="SetStatus();"
                                            Style="display: none" TabIndex="20" Text="Search" Width="80px" />
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Panel ID="pnlSearch" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel">
                                <table>
                                    <tr>
                                        <td>Name
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtSearchSerialNo" runat="server" CssClass="txtBPL" MaxLength="75"
                                                onkeypress="return ValidateForAlphaNumeric(event);" TabIndex="20" Width="186px"></asp:TextBox>
                                        </td>
                                        <td style="width: 25px"></td>
                                        <td>PAN
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtSearchPAN" runat="server" CssClass="txtBPL" TabIndex="20" Width="186px"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">
                                            <table>
                                                <tr>
                                                    <td align="right">
                                                        <asp:Button ID="btnSearch1" runat="server" CssClass="cmnBtn" OnClick="btnSearch1_Click"
                                                            Text="Search" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnShowAll" runat="server" CssClass="cmnBtn" OnClick="btnShowAll_Click"
                                                            OnClientClick="return ShowAllclick();" Text="Show All" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnClose1" runat="server" CssClass="cmnBtn" OnClick="btnClose1_Click"
                                                            OnClientClick="SetStatus();return false;" Text="Close" Width="80px" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </asp:Panel>
                        </td>
                    </tr>
                    </table>
                    <table class="nTbl">
                        <tr>
                            <td>
                                <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal" Width="975px">
                                    <asp:Repeater ID="rptrUpdatedSalary" runat="server" OnItemCommand="rptrUpdatedSalary_ItemCommand"
                                        OnItemDataBound="rptrUpdatedSalary_ItemDataBound">
                                        <HeaderTemplate>
                                            <table id="NavTable">
                                                <tr bgcolor="#EEEEEE">
                                                    <th>Edit
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label18" Text="Correction Type" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th style="display: none">
                                                        <asp:Label ID="Label19" Text="Serial No" runat="server" Width="50px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label3" Text="Serial No" runat="server" Width="60px"></asp:Label>
                                                    </th>
                                                    <th id="thRecType" runat="server">
                                                        <asp:Label ID="Lable25" Text="Record Type" runat="server" Width="60px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label1" Text="Name" runat="server" Width="250px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label2" Text="PAN" runat="server" Width="80px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label7" Text="Gross Salary" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label10" Text="ET[16(II)]" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label11" Text="PT[16(III)]" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label8" Text="Other Income" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label22" Text="Gross Total Income" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label12" Text="CH VI(A)-80CCE" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th runat="server" id="th80CCF">
                                                        <asp:Label ID="Label5" Text="CH VI(A)-80CCF" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th runat="server" id="th80CCG">
                                                        <asp:Label ID="Label23" Text="CH VI(A)-80CCG" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label13" Text="CH VI(A)-Others" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label14" Text="Tax On Total Income" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label15" Text="Surcharge" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label16" Text="Education Cess" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label9" Text="Relief U/S 89" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label17" Text="Net Tax payable" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label20" Text="Total TDS" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label21" Text="TaxPayable/Refundable" runat="server"></asp:Label>
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white">
                                                <td>
                                                    <asp:LinkButton ID="btnEdit" runat="server" Text="Edit" CommandName="Edit" CommandArgument='<%#Eval("EmployeeSerialNo") %>'></asp:LinkButton>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblCurrentCorrStatus" Text='<%# Eval("CurrentCorrType")%>' runat="server"
                                                        Width="100px"></asp:Label>
                                                </td>
                                                <td style="text-align: center; display: none">
                                                    <asp:Label ID="lblEmpSerialNo" Text='<%# Eval("EmployeeSerialNo")%>' runat="server"> </asp:Label>
                                                </td>
                                                <td style="text-align: center">
                                                    <%# Eval("CorrEmployeeSerialNo")%>
                                                </td>
                                                <td id="tdRecType" runat="server">
                                                    <%# Eval("RecordType")%>
                                                </td>
                                                <td>
                                                    <%# Eval("Name")%>
                                                </td>
                                                <td style="text-align: center">
                                                    <%# Eval("PAN")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("GrossSalary")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("ET")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("PT")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("OtherIncome")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("GrossTotalIncome")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("VIA80CCE")%>
                                                </td>
                                                <td style="text-align: right" runat="server" id="td80CCF">
                                                    <%# Eval("VIA80CCF")%>
                                                </td>
                                                <td style="text-align: right" runat="server" id="td80CCG">
                                                    <%# Eval("VIA80CCG")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("VIA80Others")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TaxOnTotalIncome")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("Surcharge")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("EducationCess")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("ReliefUS89")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("NetTaxPayable")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TotalTDS")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TaxPayableRefundable")%>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px" align="right"
                                    id="tblPagination" runat="server" visible="false">
                                    <tr style="height: 20px!important">
                                        <td style="padding: 0px 0px 0px 0px">
                                            <asp:Label ID="Label1" runat="server" Text="Records per page : " Font-Size="X-Small" />
                                        </td>
                                        <td style="width: 50px; padding-top: 2px;">
                                            <asp:DropDownList ID="cmbGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                OnSelectedIndexChanged="cmbGoTo_SelectedIndexChanged" AutoPostBack="true" Font-Size="X-Small">
                                                <asp:ListItem Text="5" Value="5" />
                                                <asp:ListItem Text="10" Value="10" />
                                                <asp:ListItem Text="15" Value="15" />
                                                <asp:ListItem Text="20" Value="20" />
                                                <asp:ListItem Text="25" Value="25" />
                                                <asp:ListItem Text="50" Value="50" />
                                                <asp:ListItem Text="75" Value="75" />
                                                <asp:ListItem Text="100" Value="100" />
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblGridStatus" runat="server" Style="float: left;" Text="Showing 0-0 of 0 [Page 0 of 0]"
                                                Font-Size="X-Small" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnFirst" runat="server" Text="&lt;&lt;" Font-Names="Arial" Font-Overline="False"
                                                OnClick="btnFirst_Click" Font-Size="X-Small" CssClass="navButton" Enabled="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnPrevious" runat="server" Text="&lt;" Font-Names="Arial" Font-Overline="False"
                                                OnClick="btnPrevious_Click" Font-Size="X-Small" CssClass="navButton" Enabled="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtGoToPage" runat="server" Text="1" CssClass="navTextBox" AutoPostBack="True"
                                                OnTextChanged="txtGoToPage_TextChanged" MaxLength="5"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnNext" runat="server" Text="&gt;" Font-Names="Arial" Font-Overline="False"
                                                OnClick="btnNext_Click" Font-Size="X-Small" CssClass="navButton"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnLast" runat="server" Text="&gt;&gt;" Font-Names="Arial" Font-Overline="False"
                                                OnClick="btnLast_Click" Font-Size="X-Small" CssClass="navButton"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </asp:View>
                <asp:View ID="vwViewExisting" runat="server">
                    <table class="nTbl" width="100%">
                        <tr>
                            <td>
                                <table>
                                    <tr>
                                        <td>Name
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtSearchName" runat="server" CssClass="txtBPL" Width="150px"> </asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnSearch" runat="server" CssClass="cmnBtn" Text="Load" OnClick="btnSearch_Click" />
                                        </td>
                                        <td align="right" width="450px">
                                            <asp:RadioButton ID="rbtnsd" Text="Section 192" OnCheckedChanged="rbtnSalaryType_CheckedChanged" AutoPostBack="true" runat="server" GroupName="SalaryType" Checked="true" />
                                            &nbsp;
                                            <asp:RadioButton ID="rbtn94p" Text="Section 194P" OnCheckedChanged="rbtnSalaryType_CheckedChanged" AutoPostBack="true" runat="server" GroupName="SalaryType" />
                                            &nbsp;&nbsp;
                                            <asp:CheckBox ID="chkShowAll" runat="server" Text="Show All Salary Records" AutoPostBack="true"
                                                OnCheckedChanged="chkShowAll_CheckedChanged"></asp:CheckBox>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Panel ID="Panel1" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                                    Width="975px" BorderStyle="Solid" BorderWidth="1px" BorderColor="Gray">
                                    <asp:Repeater ID="rptrCorrSalary" runat="server" OnItemDataBound="rptrCorrSalary_ItemDataBound">
                                        <HeaderTemplate>
                                            <table id="NavTable" border="1">
                                                <tr bgcolor="#EEEEEE">
                                                    <th runat="server" id="thSelect"></th>
                                                    <th style="display: none">
                                                        <asp:Label ID="Label19" Text="Serial No" runat="server" Width="60px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label4" Text="Serial No" runat="server" Width="60px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label1" Text="Name" runat="server" Width="250px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label2" Text="PAN" runat="server" Width="80px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label7" Text="Gross Salary" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label10" Text="ET[16(II)]" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label11" Text="PT[16(III)]" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label8" Text="Other Income" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label22" Text="Gross Total Income" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label12" Text="CH VI(A) - 80CCE" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th runat="server" id="thExisting80CCF">
                                                        <asp:Label ID="Label6" Text="CH VI(A) - 80CCF" runat="server" Width="110px"></asp:Label>
                                                    </th>
                                                    <th runat="server" id="thExisting80CCG">
                                                        <asp:Label ID="Label24" Text="CH VI(A) - 80CCG" runat="server" Width="115px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label13" Text="CH VI(A) - Others" runat="server" Width="120px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label14" Text="Tax On Total Income" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label15" Text="Surcharge" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label16" Text="Education Cess" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label9" Text="Relief U/S 89" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label17" Text="Net Tax payable" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label20" Text="Total TDS" runat="server" Width="100px"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="Label21" Text="TaxPayable/Refundable" runat="server" Width="150px"></asp:Label>
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white">
                                                <td runat="server" id="tdSelect">
                                                    <asp:CheckBox ID="chkCorrSalary" runat="server" />
                                                </td>
                                                <td style="text-align: center; display: none">
                                                    <asp:Label ID="lblEmployeeSerialNo" Text='<%# Eval("EmployeeSerialNo")%>' runat="server"></asp:Label>
                                                </td>
                                                <td style="text-align: center">
                                                    <%# Eval("CorrEmployeeSerialNo")%>
                                                </td>
                                                <td>
                                                    <%# Eval("Name")%>
                                                </td>
                                                <td>
                                                    <%# Eval("PAN")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("GrossSalary")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("ET")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("PT")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("OtherIncome")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("GrossTotalIncome")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("VIA80CCE")%>
                                                </td>
                                                <td style="text-align: right" runat="server" id="tdExisting80CCF">
                                                    <%# Eval("VIA80CCF")%>
                                                </td>
                                                <td style="text-align: right" runat="server" id="tdExisting80CCG">
                                                    <%# Eval("VIA80CCG")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("VIA80Others")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TaxOnTotalIncome")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("Surcharge")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("EducationCess")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("ReliefUS89")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("NetTaxPayable")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TotalTDS")%>
                                                </td>
                                                <td style="text-align: right">
                                                    <%# Eval("TaxPayableRefundable")%>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px" align="right">
                                    <tr style="height: 20px!important">
                                        <td style="padding: 0px 0px 0px 0px">
                                            <asp:Label ID="ASPxLabel4" runat="server" Text="Records per page : " Font-Size="X-Small" />
                                        </td>
                                        <td style="width: 50px; padding-top: 2px;">
                                            <asp:DropDownList ID="cmbPopUpGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                OnSelectedIndexChanged="cmbPopUpGoTo_SelectedIndexChanged" AutoPostBack="true"
                                                Font-Size="X-Small">
                                                <asp:ListItem Text="5" Value="5" />
                                                <asp:ListItem Text="10" Value="10" Selected="True" />
                                                <asp:ListItem Text="15" Value="15" />
                                                <asp:ListItem Text="20" Value="20" />
                                                <asp:ListItem Text="25" Value="25" />
                                                <asp:ListItem Text="50" Value="50" />
                                                <asp:ListItem Text="75" Value="75" />
                                                <asp:ListItem Text="100" Value="100" />
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblPopUpGridStatus" runat="server" Style="float: left;" Text="Showing 0-0 of 0 [Page 0 of 0]"
                                                Font-Size="X-Small" />
                                        </td>
                                        <td>
                                            <asp:Button ID="btnPopUpFirst" runat="server" Text="&lt;&lt;" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" OnClick="btnPopUpFirst_Click" CssClass="navButton"
                                                Enabled="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnPopUpPrevious" runat="server" Text="&lt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnPopUpPrevious_Click" CssClass="navButton" Enabled="False"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtPopUpGoToPage" runat="server" Text="1" CssClass="navTextBox"
                                                AutoPostBack="True" OnTextChanged="txtPopUpGoToPage_TextChanged" MaxLength="5"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnPopUpNext" runat="server" Text="&gt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnPopUpNext_Click" CssClass="navButton"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnPopUpLast" runat="server" Text="&gt;&gt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnPopUpLast_Click" CssClass="navButton"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <asp:Panel ID="pnlAdd" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel">
                                    <asp:Label ID="lblSelectOption" runat="server" Text="Select Options:" Font-Bold="true" Font-Size="10px"></asp:Label>
                                    <table style="width: 100%; padding-right: 0px;">
                                        <tr>
                                            <td>
                                                <asp:Label ID="lblOption1" runat="server" Text="Option 1" Font-Bold="True"></asp:Label>
                                                <asp:TextBox ID="txtSerialNo_From" Width="48px" MaxLength="7" CssClass="txtBPL" runat="server"
                                                    onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                                                <asp:Button ID="btnViewExistingAddAll" runat="server" Text="Add From Sl No" Width="120px"
                                                    CssClass="cmnBtn" OnClick="btnViewExistingAddAll_Click" Height="29px" />
                                                <asp:Label ID="lblCorrType" runat="server" Text="Correction Type"></asp:Label>
												<asp:DropDownList ID="ddlCorrectionType" runat="server">
													<asp:ListItem Text="Select" Value="-1"></asp:ListItem>
													<asp:ListItem Text="Update" Value="2"></asp:ListItem>
													<asp:ListItem Text="Delete" Value="4"></asp:ListItem>
												</asp:DropDownList>
                                            </td>
                                          <%--  <td>
                                                 <asp:Label ID="lblCorrType" runat="server" Text="Correction Type"></asp:Label>
												<asp:DropDownList ID="ddlCorrectionType" runat="server">
													<asp:ListItem Text="Select" Value="-1"></asp:ListItem>
													<asp:ListItem Text="Update" Value="2"></asp:ListItem>
													<asp:ListItem Text="Delete" Value="4"></asp:ListItem>
												</asp:DropDownList>
											</td> --%>
                                            <td align="right" style="white-space: nowrap;">
                                                <asp:Label ID="lblOption3" runat="server" Text="Option 3:" Font-Bold="True"></asp:Label>
                                                <asp:Label ID="lblSelect" runat="server" Text="Select"></asp:Label>
                                                <asp:LinkButton ID="lnkbtnCheckAll" runat="server" Text="All" OnClientClick="return SelectAllCheckBox();"></asp:LinkButton>
                                                <asp:Label ID="lblCorrPipe" runat="server" Text="|"></asp:Label>
                                                <asp:LinkButton ID="lnkbtnUnCheckAll" runat="server" Text="None" OnClientClick="return UnSelectAllCheckBox();"
                                                    CausesValidation="true"></asp:LinkButton>
                                                <asp:Button ID="btnViewExistingAdd" runat="server" Text="Add" CssClass="cmnBtn" OnClientClick="return ValidateCorrectionType();"
                                                    OnClick="btnViewExistingAdd_Click"/>
                                                <asp:Button ID="btnCreateAll" runat="server" Text="Create All" CssClass="cmnBtn"
                                                    OnClick="btnCreateAll_Click" /> 
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="white-space: nowrap;">
                                                <asp:Label ID="lblOption2" runat="server" Text="Option 2" Font-Bold="True"></asp:Label>
                                                <asp:FileUpload ID="fupTextFile" runat="server" CssClass="browsBtn" />
                                                <asp:Button ID="btnViewExistingTextAddAll" runat="server" Text="Bulk Select"
                                                    CssClass="cmnBtn" OnClientClick="return FileValidation();" OnClick="btnViewExistingTextAddAll_Click" ToolTip="Choose text file with PAN records and click here." />                                               
                                            </td>
                                        </tr>
                                        <tr>
                                            <%--<td style="width:10%;  padding: 0 5px;">Correction Type
											</td>--%>
											 
                                            <td colspan="8" style="width: 120px; text-align: right;">
                                                
                                            </td>
                                        </tr>
                                    </table>                                   
                                </asp:Panel>
                                 <table style="width: 100%; padding-right: 0px;">
                                    <tr align="right">
                                        <td align="right">
                                                <asp:Button ID="btnViewExistingClose" runat="server" Text="Close" CssClass="cmnBtn"
                                                OnClick="btnViewExistingClose_Click" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
					<div id="pnlPopup1" class="PrProgress1" runat="server" style="display: none;">
						<div id="innerPopup" class="PrContainer">
							<div class="PrHeader">
								Please wait...
							</div>
							<div class="PrBody">
								<img width="220px" height="19px" src="../App_Themes/Standard/Images/activity.gif"
									alt="loading..." />
							</div>
						</div>
					</div>
                </asp:View>
                <asp:View ID="vwMoreDetails" runat="server">
                    <div style="padding: 10px; border-top: solid 1px gray">
                        <table width="100%">
                            <tr>
                                <td style="padding: 4px 4px 4px 10px;" class="dHeader">If aggregate rent payment exceeds Rupees One Lakh(Rs. 1,00,000)
                                </td>
                            </tr>
                        </table>
                        <table width="100%">
                            <tr>
                                <td>PAN of Landlord 1
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPANLL1" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        MaxLength="10" CssClass="txtAR" onblur="return checkValidatePAN(this,1);" onkeypress="return checkFinYear(this,1)"></asp:TextBox>
                                    <cc1:AutoCompleteExtender ID="AutoCompleteExtenderPANLL1" runat="server" MinimumPrefixLength="1"
                                        ServicePath="~/WebServices/AutoCompleteService.asmx" ServiceMethod="LandlordPAN"
                                        TargetControlID="txtPANLL1" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="false">
                                    </cc1:AutoCompleteExtender>
                                </td>
                                <td>Name of Landlord 1
                                </td>
                                <td>
                                    <asp:TextBox ID="txtNameLL1" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        CssClass="txtAR" onkeypress="return checkFinYear(this,2)"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>PAN of Landlord 2
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPANLL2" runat="server" AutoComplete="off" CssClass="txtAR" MaxLength="10"
                                        TabIndex="1" Width="170px" onblur="return checkValidatePAN(this,2);" onkeypress="return checkFinYear(this,3)"></asp:TextBox>
                                    <cc1:AutoCompleteExtender ID="AutoCompleteExtenderPANLL2" runat="server" MinimumPrefixLength="1"
                                        ServicePath="~/WebServices/AutoCompleteService.asmx" ServiceMethod="LandlordPAN"
                                        TargetControlID="txtPANLL2" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="false">
                                    </cc1:AutoCompleteExtender>
                                </td>
                                <td>Name of Landlord 2
                                </td>
                                <td>
                                    <asp:TextBox ID="txtNameLL2" runat="server" AutoComplete="off" CssClass="txtAR" TabIndex="1"
                                        Width="170px" onkeypress="return checkFinYear(this,4)"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>PAN of Landlord 3
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPANLL3" runat="server" AutoComplete="off" CssClass="txtAR" MaxLength="10"
                                        TabIndex="1" Width="170px" onblur="return checkValidatePAN(this,3);" onkeypress="return checkFinYear(this,5)"></asp:TextBox>
                                    <cc1:AutoCompleteExtender ID="AutoCompleteExtenderPANLL3" runat="server" MinimumPrefixLength="1"
                                        ServicePath="~/WebServices/AutoCompleteService.asmx" ServiceMethod="LandlordPAN"
                                        TargetControlID="txtPANLL3" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="false">
                                    </cc1:AutoCompleteExtender>
                                </td>
                                <td>Name of Landlord 3
                                </td>
                                <td>
                                    <asp:TextBox ID="txtNameLL3" runat="server" AutoComplete="off" CssClass="txtAR" TabIndex="1"
                                        Width="170px" onkeypress="return checkFinYear(this,6)"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>PAN of Landlord 4
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPANLL4" runat="server" AutoComplete="off" CssClass="txtAR" MaxLength="10"
                                        TabIndex="1" Width="170px" onblur="return checkValidatePAN(this,4);" onkeypress="return checkFinYear(this,7)"></asp:TextBox>
                                    <cc1:AutoCompleteExtender ID="AutoCompleteExtenderPANLL4" runat="server" MinimumPrefixLength="1"
                                        ServicePath="~/WebServices/AutoCompleteService.asmx" ServiceMethod="LandlordPAN"
                                        TargetControlID="txtPANLL4" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="false">
                                    </cc1:AutoCompleteExtender>
                                </td>
                                <td>Name of Landlord 4
                                </td>
                                <td>
                                    <asp:TextBox ID="txtNameLL4" runat="server" AutoComplete="off" CssClass="txtAR" TabIndex="1"
                                        Width="170px" onkeypress="return checkFinYear(this,8)"></asp:TextBox>
                                </td>
                            </tr>
                    </div>
                    <div style="padding: 10px; border-top: solid 1px gray">
                        <table width="100%">
                            <tr>
                                <td style="padding: 4px 4px 4px 10px;" class="dHeader">If interest paid to Lender under the head &#39;Income from House Property&#39;
                                </td>
                            </tr>
                        </table>
                        <table width="100%">
                            <tr>
                                <td>PAN of Lender 1
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPANL1" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        MaxLength="10" CssClass="txtAR" onblur="return checkValidatePAN(this,5);" onkeypress="return checkFinYear(this,9)"></asp:TextBox>
                                    <cc1:AutoCompleteExtender ID="AutoCompleteExtenderPANL1" runat="server" MinimumPrefixLength="1"
                                        ServicePath="~/WebServices/AutoCompleteService.asmx" ServiceMethod="LandlordPAN"
                                        TargetControlID="txtPANL1" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="false">
                                    </cc1:AutoCompleteExtender>
                                </td>
                                <td>Name of Lender 1
                                </td>
                                <td>
                                    <asp:TextBox ID="txtNameL1" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        CssClass="txtAR" onkeypress="return checkFinYear(this,10)"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>PAN of Lender 2
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPANL2" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        MaxLength="10" CssClass="txtAR" onblur="return checkValidatePAN(this,6);" onkeypress="return checkFinYear(this,11)"></asp:TextBox>
                                    <cc1:AutoCompleteExtender ID="AutoCompleteExtenderPANL2" runat="server" MinimumPrefixLength="1"
                                        ServicePath="~/WebServices/AutoCompleteService.asmx" ServiceMethod="LandlordPAN"
                                        TargetControlID="txtPANL2" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="false">
                                    </cc1:AutoCompleteExtender>
                                </td>
                                <td>Name of Lender 2
                                </td>
                                <td>
                                    <asp:TextBox ID="txtNameL2" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        CssClass="txtAR" onkeypress="return checkFinYear(this,12)"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>PAN of Lender 3
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPANL3" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        MaxLength="10" CssClass="txtAR" onblur="return checkValidatePAN(this,7);" onkeypress="return checkFinYear(this,13)"></asp:TextBox>
                                    <cc1:AutoCompleteExtender ID="AutoCompleteExtenderPANL3" runat="server" MinimumPrefixLength="1"
                                        ServicePath="~/WebServices/AutoCompleteService.asmx" ServiceMethod="LandlordPAN"
                                        TargetControlID="txtPANL3" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="false">
                                    </cc1:AutoCompleteExtender>
                                </td>
                                <td>Name of Lender 3
                                </td>
                                <td>
                                    <asp:TextBox ID="txtNameL3" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        CssClass="txtAR" onkeypress="return checkFinYear(this,14)"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>PAN of Lender 4
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPANL4" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        MaxLength="10" CssClass="txtAR" onblur="return checkValidatePAN(this,8);" onkeypress="return checkFinYear(this,15)"></asp:TextBox>
                                    <cc1:AutoCompleteExtender ID="AutoCompleteExtenderPANL4" runat="server" MinimumPrefixLength="1"
                                        ServicePath="~/WebServices/AutoCompleteService.asmx" ServiceMethod="LandlordPAN"
                                        TargetControlID="txtPANL4" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="false">
                                    </cc1:AutoCompleteExtender>
                                </td>
                                <td>Name of Lender 4
                                </td>
                                <td>
                                    <asp:TextBox ID="txtNameL4" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        CssClass="txtAR" onkeypress="return checkFinYear(this,16)"></asp:TextBox>
                                </td>
                            </tr>
                    </div>
                    <div style="padding: 10px; border-top: solid 1px gray">
                        <table width="100%">
                            <tr>
                                <td style="padding: 4px 4px 4px 10px;" class="dHeader">If contributions paid by the trustees of an approved superannuation fund
                                </td>
                            </tr>
                        </table>
                        <table width="100%">
                            <tr>
                                <td>Name of the superannuation fund
                                </td>
                                <td>
                                    <asp:TextBox ID="txtSAFName" runat="server" AutoComplete="off" Width="170px" TabIndex="1"
                                        CssClass="txtAR"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>Contribution From
                                </td>
                                <td>
                                    <asp:TextBox ID="txtSAFContributionFrom" runat="server" AutoComplete="off" Width="170px"
                                        TabIndex="1" CssClass="txtAR" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                        onBlur="setDateFormat(this);"></asp:TextBox>
                                </td>
                                <td>Contribution To
                                </td>
                                <td>
                                    <asp:TextBox ID="txtSAFContributionTo" runat="server" AutoComplete="off" Width="170px"
                                        TabIndex="1" CssClass="txtAR" ToolTip="Enter Date (Format: DD/MM/YYYY or DD MM YYYY)"
                                        onBlur="setDateFormat(this);"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>Contribution Repaid
                                </td>
                                <td>
                                    <asp:TextBox ID="txtSAFContributionRepaid" runat="server" AutoComplete="off" Width="170px"
                                        TabIndex="1" MaxLength="12" CssClass="txtAR" onkeypress="return numeralsOnly(this, event,12,0,0,0);"></asp:TextBox>
                                </td>
                                <td>Average Tax Rate (%)
                                </td>
                                <td>
                                    <asp:TextBox ID="txtSAFAvgTaxRate" runat="server" AutoComplete="off" Width="170px"
                                        TabIndex="1" MaxLength="12" CssClass="txtAR" onkeypress="return numeralsOnly(this, event,7,4,0,1,0);"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>Tax Deducted
                                </td>
                                <td>
                                    <asp:TextBox ID="txtSAFTaxDeducted" runat="server" AutoComplete="off" Width="170px"
                                        TabIndex="1" MaxLength="12" CssClass="txtAR" onkeypress="return numeralsOnly(this, event,12,0,0,0);"></asp:TextBox>
                                </td>
                                <td></td>
                                <td></td>
                            </tr>
                    </div>
                    <tr>
                        <td colspan="2">
                            <asp:Button ID="btnOkMoreDetails" Text="OK" runat="server" CssClass="cmnBtn" TabIndex="6"
                                OnClientClick="return validateMoreDetails();" OnClick="btnOkMoreDetails_Click" />
                            <asp:Button ID="btnCloseMoreDetails" Text="Back" runat="server" CssClass="cmnBtn"
                                TabIndex="6" OnClick="btnCloseMoreDetails_Click" />
                        </td>
                    </tr>
                    </table>
                </asp:View>
                <asp:View ID="vwBulkUpdate" runat="server">
                    <table class="nTbl">
                        <tr>
                            <td>
                                <table width="100%">
                                    <tr>
                                        <td width="100px">
                                            <asp:Button ID="btnExport" runat="server" Text="Export" CssClass="cmnBtn" OnClick="btnBlkUpdate_Click" />
                                        </td>
                                        <td width="100px">
                                            <asp:Button ID="btnImport" runat="server" Text="Import" CssClass="cmnBtn" Height="26px" />
                                        </td>
                                        <td width="100px">
                                            <asp:Button ID="btnBulkUpdate" runat="server" Text="Update" CssClass="cmnBtn" OnClick="btnBulkUpdate_Click"
                                                Visible="False" />
                                        </td>
                                        <td>
                                            <asp:HyperLink ID="hlnkOpenErrors" runat="server" Text="" Target="_blank" Visible="false">
                                            </asp:HyperLink>
                                        </td>
                                        <td>
                                            <asp:HyperLink ID="hlnkMastersList" runat="server" Text="" Target="_blank" Visible="false">
                                            </asp:HyperLink>
                                        </td>
                                        <td align="right">
                                            <asp:Button ID="btnBulkClose" runat="server" Text="Close" CssClass="cmnBtn" OnClick="btnBulkClose_Click" />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="5">
                                            <asp:Label ID="lblExcelNote1" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 1: Avoid Cut options in any of the work Sheets." />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="5">
                                            <asp:Label ID="lblExcelNote2" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 2: While Pasting data from other excel File, use only Paste Special / Values Option." />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="5">
                                            <asp:Label ID="lblExcelNote3" runat="server" Font-Bold="true" Font-Size="Small" ForeColor="blue"
                                                Text="Note 3: Before any operation make sure you are not in Excel Edit mode." />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </asp:View>
            </asp:MultiView>
        </ContentTemplate>
		<Triggers>
            <asp:PostBackTrigger ControlID="btnViewExistingTextAddAll" />
        </Triggers>
    </asp:UpdatePanel>
</asp:Content>