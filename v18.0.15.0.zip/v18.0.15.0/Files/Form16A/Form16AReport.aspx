<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Form16A_Form16AReport, App_Web_form16areport.aspx.1b14c1e6" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>
    <script type="text/javascript" language="javascript">
        function CheckForFileInUse() {
            var actionReturned = confirm("For Quarter-" + document.getElementById("<%=ddlQuarter.ClientID%>").value + ", Form 16A PDF zip file is seen generated.\nIf you want to download the file,\nclick 'Cancel' and then click 'Get Files'.\n\nIf you want to initiate request for generating new file\nclick 'OK'");
            document.getElementById("<%=hdnFileGeneratedStatus.ClientID%>").value = actionReturned == true ? "1" : "0";
            var btnSearch = document.getElementById("<%=btnSearch.ClientID%>");
            btnSearch.click();
        }
        function GetDeducteeNameValue(source, eventArgs) { document.getElementById("<%=hdnDeducteeID.ClientID%>").value = eventArgs.get_value(); }
        function ClearDeducteeName() {
            if (event.keyCode == 13 || event.keyCode == 37 || event.keyCode == 38 || event.keyCode == 39 || event.keyCode == 40) { }
            else { document.getElementById("<%=hdnDeducteeID.ClientID%>").value = "-1"; }
        }
        function OnDateChanged() {
            var finYear = document.getElementById("<%=hdnFinYear.ClientID%>").value;
            if (document.getElementById("<%=fromDate.ClientID%>").value == "") { document.getElementById("<%=fromDate.ClientID%>").value = "01/04/" + finYear; }
            if (document.getElementById("<%=toDate.ClientID%>").value == "") { document.getElementById("<%=toDate.ClientID%>").value = "31/03/" + String(eval(finYear) + 1); }
            document.getElementById("<%=hdnMonth.ClientID%>").value = "-1";
            document.getElementById("<%=hdnQuarter.ClientID%>").value = "-1";
        }
        function GetResult(returnValue, context) {
            if (returnValue.length > 4) {
                var array = returnValue.split("*");
                document.getElementById("<%=txtAddress1.ClientID%>").value = array[0];
                document.getElementById("<%=txtAddress2.ClientID%>").value = array[1];
                document.getElementById("<%=txtAddress3.ClientID%>").value = array[2];
                document.getElementById("<%=txtCity.ClientID%>").value = array[3];
                document.getElementById("<%=txtPINCode.ClientID%>").value = array[4];
                alert("Record saved Successfully.");
            }
            else { alert("No record found."); }
        }
        function SendRequest() { CallServer(); return false; }
        function SetStatus() {
            var rdbTinFormat = document.getElementById("<%=rbtnTIN.ClientID%>");
            var btnClick = document.getElementById("<%=btnPreview.ClientID %>");
            if (rdbTinFormat != null) {
                if (rdbTinFormat.checked == true) {
                    if (btnClick != null) btnClick.value = "Generate";
                    return;
                }
            }
            var rdbPDFSigning = document.getElementById("<%=rdbPDFSigning.ClientID%>");
            var rdbPDF = document.getElementById("<%=rdbPDF.ClientID %>");
            var pnlpfx = document.getElementById("<%=pnlPFXFileDetails.ClientID%>");
            var annexureRow = document.getElementById("<%=annexureRow.ClientID %>");
            if (rdbPDFSigning != null && rdbPDFSigning.checked) {
                if (pnlpfx != null) pnlpfx.style.display = '';
                if (btnClick != null) btnClick.value = "Generate";
                if (annexureRow != null) annexureRow.style.display = '';
            }
            else if (rdbPDF != null && rdbPDF.checked) {
                if (pnlpfx != null) pnlpfx.style.display = "none";
                if (btnClick != null) btnClick.value = "Generate";
                if (annexureRow != null) annexureRow.style.display = '';
            } else {
                if (btnClick != null) btnClick.value = "Preview";
                if (pnlpfx != null) pnlpfx.style.display = "none";
                if (annexureRow != null) annexureRow.style.display = "none";
            }
        }
        function SetStatusTraces() {
            var rdbTinFormat = document.getElementById("<%=rbtnTIN.ClientID%>");
            var btnClick = document.getElementById("<%=btnPreview.ClientID %>");
            if (rdbTinFormat != null) {
                if (rdbTinFormat.checked == true) {
                    if (btnClick != null) btnClick.value = "Generate";
                }
            }
            var rdbPDFSigning = document.getElementById("<%=rdbSignTraces.ClientID%>");
            var rdbPDF = document.getElementById("<%=rdbPDFTraces.ClientID %>");
            var pnlpfx = document.getElementById("<%=pnlTraces.ClientID%>");
            if (rdbPDFSigning != null && rdbPDFSigning.checked) {
                if (pnlpfx != null) pnlpfx.style.display = '';
                if (btnClick != null) btnClick.value = "Generate";
            }
            else if (rdbPDF != null && rdbPDF.checked) {
                if (pnlpfx != null) pnlpfx.style.display = "none";
                if (btnClick != null) btnClick.value = "Generate";
            } else {
                if (btnClick != null) btnClick.value = "Preview";
                if (pnlpfx != null) pnlpfx.style.display = "none";
            }
        }
        function PleaseWait() {
            var rbtnFormart1 = document.getElementById("<%=rbtnSaralTDS.ClientID%>");
            var btnClick = document.getElementById("<%=btnPreview.ClientID %>");
            var rbtnFormart2 = document.getElementById("<%=rbtnTIN.ClientID%>");
            if (btnClick != null && rbtnFormart1 != null && rbtnFormart1.checked) {
                if (btnClick.value == "Please Wait...") { return false; }
                else {
                    var rdbSignTraces = document.getElementById("<%=rdbPDFSigning.ClientID%>");
                    var fupPfxFile = document.getElementById("<%=fupPfxFile.ClientID%>");
                    var file = fupPfxFile.value.trim();
                    if (btnClick != null) btnClick.value = "Please Wait...";
                    if (rdbSignTraces != null && rdbSignTraces.checked) {
                        if (file == "") {
                            alert("Select PFX file");
                            fupPfxFile.focus();
                            if (btnClick != null) btnClick.value = "Generate";
                            return false;
                        }
                        if (file.slice(file.lastIndexOf(".")).toLowerCase() != ".pfx") {
                            alert("Select valid PFX file");
                            fupPfxFile.focus();
                            if (btnClick != null) btnClick.value = "Generate";
                            return false;
                        }
                        var txtPwd = document.getElementById("<%=txtPfxPassword.ClientID%>");
                        if (txtPwd.value == "") {
                            alert("Enter PFX file Password.");
                            txtPwd.focus();
                            if (btnClick != null) btnClick.value = "Generate";
                            return false;
                        }
                    }
                }
            }
            else if (rbtnFormart2 != null && rbtnFormart2.checked) {
                var uploadFile = document.getElementById("<%=fuptxtFile.ClientID%>");
                var file = uploadFile.value.trim();
                var validExtensions = new Array(".txt", ".zip");
                var allowSubmit = false;
                var count = 0;
                if (btnClick != null) {
                    if (btnClick.value == "Please Wait...") { return false; }
                    else {
                        var hlnkZippedFile = document.getElementById("<%=hlnkZippedFile.ClientID%>");
                        var hlnkZippedFileDesc = document.getElementById("<%=lblDownloadDescription.ClientID%>");
                        var flUploadTraces = document.getElementById("<%=flUploadTraces.ClientID%>");
                        var rdbSignTraces = document.getElementById("<%=rdbSignTraces.ClientID%>");
                        var fileTraces = flUploadTraces.value.trim();
                        if (hlnkZippedFile != null && hlnkZippedFileDesc != null) {
                            hlnkZippedFile.style.display = 'none';
                            hlnkZippedFileDesc.style.display = 'none';
                        }
                        if (btnClick != null) btnClick.value = "Please Wait...";
                        if (file.indexOf("\\") == -1) {
                            alert("Select a file.");
                            uploadFile.focus();
                            if (btnClick != null) btnClick.value = "Generate";
                            return false;
                        }
                        else {
                            var ext = file.slice(file.lastIndexOf(".")).toLowerCase();
                            for (var i = 0; i < validExtensions.length; i++) {
                                if (validExtensions[i] == ext) {
                                    count = count + 1;
                                    if (ext == ".zip" && document.getElementById("<%=txtTanNo.ClientID%>").value.length < 1) {
                                        alert("Specify TAN.");
                                        if (btnClick != null) btnClick.value = "Generate";
                                        return false;
                                    }
                                    else { allowSubmit = true; }
                                }
                            }
                        }
                        if (rdbSignTraces != null && rdbSignTraces.checked) {
                            if (fileTraces == "") {
                                alert("Select PFX file");
                                flUploadTraces.focus();
                                if (btnClick != null) btnClick.value = "Generate";
                                return false;
                            }
                            if (fileTraces.slice(fileTraces.lastIndexOf(".")).toLowerCase() != ".pfx") {
                                alert("Select valid PFX file");
                                flUploadTraces.focus();
                                if (btnClick != null) btnClick.value = "Generate";
                                return false;
                            }
                            var txtPwdTraces = document.getElementById("<%=txtPwdTraces.ClientID%>");
                            if (txtPwdTraces.value == "") {
                                alert("Enter PFX file Password.");
                                txtPwdTraces.focus();
                                if (btnClick != null) btnClick.value = "Generate";
                                return false;
                            }
                        }
                        if (count == 0) {
                            alert("files with extensiton .txt and .zip are allowed");
                            if (btnClick != null) btnClick.value = "Generate";
                            return false;
                        }
                        else
                            return allowSubmit;
                    }
                    return true;
                }
                else {
                    var hlnkZippedFile = document.getElementById("<%=hlnkZippedFile.ClientID%>");
                    var hlnkZippedFileDesc = document.getElementById("<%=lblDownloadDescription.ClientID%>");
                    var flUploadTraces = document.getElementById("<%=flUploadTraces.ClientID%>");
                    var rdbSignTraces = document.getElementById("<%=rdbSignTraces.ClientID%>");
                    var fileTraces = flUploadTraces.value.trim();
                    if (hlnkZippedFile != null && hlnkZippedFileDesc != null) {
                        hlnkZippedFile.style.display = 'none';
                        hlnkZippedFileDesc.style.display = 'none';
                    }
                    if (btnClick != null) btnClick.value = "Please Wait...";
                    if (file.indexOf("\\") == -1) {
                        alert("Select a file.");
                        uploadFile.focus();
                        if (btnClick != null) btnClick.value = "Generate";
                        return false;
                    }
                    else {
                        var ext = file.slice(file.lastIndexOf(".")).toLowerCase();
                        for (var i = 0; i < validExtensions.length; i++) {
                            if (validExtensions[i] == ext) {
                                count = count + 1;
                                if (ext == ".zip" && document.getElementById("<%=txtTanNo.ClientID%>").value.length < 1) {
                                    alert("Specify TAN.");
                                    if (btnClick != null) btnClick.value = "Generate";
                                    return false;
                                }
                                else { allowSubmit = true; }
                            }
                        }
                    }
                    if (rdbSignTraces != null && rdbSignTraces.checked) {
                        if (fileTraces == "") {
                            alert("Select PFX file");
                            flUploadTraces.focus();
                            if (btnClick != null) btnClick.value = "Generate";
                            return false;
                        }
                        if (fileTraces.slice(fileTraces.lastIndexOf(".")).toLowerCase() != ".pfx") {
                            alert("Select valid PFX file");
                            flUploadTraces.focus();
                            if (btnClick != null) btnClick.value = "Generate";
                            return false;
                        }
                        var txtPwdTraces = document.getElementById("<%=txtPwdTraces.ClientID%>");
                        if (txtPwdTraces.value == "") {
                            alert("Enter PFX file Password.");
                            txtPwdTraces.focus();
                            if (btnClick != null) btnClick.value = "Generate";
                            return false;
                        }
                    }
                    if (count == 0) {
                        alert("files with extensiton .txt and .zip are allowed");
                        if (btnClick != null) btnClick.value = "Generate";
                        return false;
                    }
                    else
                        return allowSubmit;
                }
                return true;
            }
        }
        function ValiadteSearchPan() {
            document.getElementById("<%=txtSearchPAN.ClientID%>").value = document.getElementById("<%=txtSearchPAN.ClientID%>").value.toUpperCase().trim();

            if (document.getElementById("<%=hdnISSB.ClientID%>").value == "1") {
                if (document.getElementById("<%=rdbAllBranch.ClientID%>").checked
                    && document.getElementById("<%=txtSearchPAN.ClientID%>").value.trim().length == 0) {
                    alert("Enter PAN.");
                    return false;
                }
            }
            else {
                if (document.getElementById("<%=txtSearchPAN.ClientID%>").value.trim().length == 0) {
                    alert("Enter PAN.");
                    return false;
                }
            }
            if (document.getElementById("<%=hdnForm16AWithoutQtr.ClientID%>").value == "0") {
                if (document.getElementById("<%=ddlQuarter.ClientID%>").value == "-1") {
                    alert("Select Quarter.");
                    return false;
                }
            }
            if (document.getElementById("<%=txtSearchPAN.ClientID%>").value.trim().length > 0) return true;
            else {
                //                if (document.getElementById("<%=ddlQuarter.ClientID%>").value != "-1") {
                //                    var confirmLoad = confirm("Display all Form16A reports for Quarter" + document.getElementById("<%=ddlQuarter.ClientID%>").value + " ?");
                //                    if (confirmLoad == true) {
                //                        return true;
                //                    }
                //                    else {
                //                        return false;
                //                    }
                //                }
                //                else {
                //                    alert("Select Quarter.");
                //                    return false;
                //                }
                return true;
            }
        }
        function ConfirmEmailDuplication() {
            var result = confirm("Emails have already been sent for some/all of the selected records.\nDo you want to send Email Again?");
            if (result == true) {
                __doPostBack('ConfirmEmailSend', 'ConfirmEmailSend');
                return true;
            }
            else {
                return false;
            }
        }
    </script>
    <script type="text/javascript" language="javascript" src="../JavaScript/Validations.js"></script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:UpdatePanel ID="updatePanel" runat="server" OnLoad="UpdatePanel_Load">
        <ContentTemplate>
            <asp:HiddenField ID="hdnQuarter" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnMonth" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnDeducteeID" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnFinYear" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnSearch" runat="server" Value="1" />
            <asp:HiddenField ID="hdnZipFileName" runat="server" Value="" />
            <asp:HiddenField ID="hdnBranchInputPageIndex" runat="server" Value="1" />
            <asp:HiddenField ID="hdnBranchInputPageSize" runat="server" Value="10" />
            <asp:HiddenField ID="hdnZoneBranchID" Value="-1" runat="server" />
            <asp:HiddenField ID="hdnFileGeneratedStatus" Value="0" runat="server" />
            <asp:HiddenField ID="hdnISSB" Value="0" runat="server" />
            <asp:HiddenField ID="hdnForm16AWithoutQtr" Value="0" runat="server" />
            <table>
                <tr id="trData" runat="server">
                    <td>Data From :
                        <asp:RadioButton ID="rbtnSaralTDS" runat="server" Text="SaralTDS " GroupName="Form16A"
                            AutoPostBack="true" OnCheckedChanged="rbtnFormat_CheckedChanged" Checked="false" />
                        <asp:RadioButton ID="rbtnTIN" runat="server" Text="TRACES" GroupName="Form16A" AutoPostBack="true"
                            OnCheckedChanged="rbtnFormat_CheckedChanged" Visible="true" Checked="true" />
                    </td>
                </tr>
            </table>
            <br />
            <asp:MultiView ID="mvwForm16A" runat="server" ActiveViewIndex="0">
                <asp:View ID="vwSaraltds" runat="server">
                    <table id="tblCITTds" runat="server" class="nTbl">
                        <tr>
                            <td colspan="2">
                                <b>CIT (TDS) Address </b>
                            </td>
                        </tr>
                        <tr>
                            <td valign="top">
                                <table class="eCol" width="400px">
                                    <tr>
                                        <td class="vHCol">Address 1
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="txtAddress1" runat="server" CssClass="txtBPL" MaxLength="25" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">Address 3
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="txtAddress3" runat="server" CssClass="txtBPL" MaxLength="25" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">PIN Code
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="txtPINCode" runat="server" CssClass="txtBPL" MaxLength="6" onkeypress="return ValidateForOnlyNos(event);"></asp:TextBox>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td valign="top">
                                <table class="eCol" width="400px">
                                    <tr>
                                        <td class="vHCol">Address 2
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="txtAddress2" runat="server" CssClass="txtBPL" MaxLength="25" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">City
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="txtCity" runat="server" CssClass="txtBPL" MaxLength="25" onkeypress="return ValidateForAlphaNumeric(event);"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <table width="100%">
                                                <tr>
                                                    <td align="right">
                                                        <asp:Button ID="btnSave" runat="server" CssClass="cmnBtn" Height="20px" OnClick="btnSave_Click"
                                                            Text="Save" />
                                                        &nbsp;<asp:Button ID="btnGetFromList" runat="server" CssClass="cmnBtn" Height="20px"
                                                            OnClick="btnGetFromList_Click" OnClientClick="return SendRequest()" Text="Get From List" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <hr />
                            </td>
                        </tr>
                    </table>
                    <table border="0" style="margin-left: 5px;">
                        <tr>
                            <td colspan="2">
                                <asp:Label ID="lblNote" runat="server" ForeColor="#0000CC" Text="Note: For Datewise selection, click on Load button to filter the records."></asp:Label>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol">Deductee Name
                            </td>
                            <td class="iCol">
                                <asp:TextBox ID="txtDeducteeName" runat="server" AutoComplete="Off" CssClass="txtBPL"
                                    onkeyup="ClearDeducteeName()" Width="550px"></asp:TextBox>
                                <cc1:AutoCompleteExtender ID="AutoCompleteExtenderName" runat="server" CompletionInterval="700"
                                    CompletionSetCount="50" DelimiterCharacters="" EnableCaching="false" FirstRowSelected="True"
                                    MinimumPrefixLength="2" OnClientItemSelected="GetDeducteeNameValue" ServiceMethod="GetDeducteesForForm16AReports"
                                    ServicePath="~/WebServices/AutoCompleteService.asmx" ShowOnlyCurrentWordInCompletionListItem="true"
                                    TargetControlID="txtDeducteeName">
                                </cc1:AutoCompleteExtender>
                            </td>
                        </tr>
                        <tr>
                            <td class="vHCol">Selection Type
                            </td>
                            <td class="iCol">
                                <asp:DropDownList ID="cmbSelectionType" runat="server" AutoPostBack="true" BackColor="#E5E5E5"
                                    OnSelectedIndexChanged="cmbSelectionType_SelectedIndexChanged" Width="555px">
                                    <asp:ListItem Text="Quarter Wise" Value="Quarter Wise"></asp:ListItem>
                                    <asp:ListItem Text="Month Wise" Value="Month Wise"></asp:ListItem>
                                    <asp:ListItem Text="Date Wise" Value="Date Wise"></asp:ListItem>
                                </asp:DropDownList>
                            </td>
                        </tr>
                    </table>
                    <table border="0" style="margin-left: 2px;">
                        <tr>
                            <td>
                                <table>
                                    <tr>
                                        <td class="vHCol">Quarter
                                        </td>
                                        <td class="iCol">
                                            <asp:DropDownList ID="cmbQuarter" runat="server" AutoPostBack="true" OnSelectedIndexChanged="cmbQuarter_SelectedIndexChanged"
                                                Width="190px">
                                            </asp:DropDownList>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">From
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="fromDate" runat="server" AutoComplete="Off" CssClass="txtBPR" onBlur="setDateFormat(this);return OnDateChanged();"
                                                Width="185px"></asp:TextBox>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">Section
                                        </td>
                                        <td class="iCol">
                                            <asp:DropDownList ID="cmbSection" runat="server" CssClass="dropDownList" Width="190px">
                                            </asp:DropDownList>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">TDS Certificate No.
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="txtCertNo" runat="server" AutoComplete="Off" CssClass="txtBPL" ToolTip="Search TDS Cert. No based on Deductee Serial No."
                                                Width="185px"></asp:TextBox>
                                            <cc1:AutoCompleteExtender ID="AutoCompleteExtender1" runat="server" CompletionInterval="700"
                                                CompletionSetCount="20" DelimiterCharacters="" EnableCaching="false" FirstRowSelected="True"
                                                MinimumPrefixLength="1" ServiceMethod="GetPrintCertNos" ServicePath="~/WebServices/AutoCompleteService.asmx"
                                                ShowOnlyCurrentWordInCompletionListItem="true" TargetControlID="txtCertNo">
                                            </cc1:AutoCompleteExtender>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">Place
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="txtPlace" runat="server" AutoComplete="Off" CssClass="txtBPL" MaxLength="150"
                                                Width="185px"> </asp:TextBox>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td>
                                <table>
                                    <tr>
                                        <td class="vHCol">Month
                                        </td>
                                        <td class="iCol">
                                            <asp:DropDownList ID="cmbMonth" runat="server" AutoPostBack="true" OnSelectedIndexChanged="cmbMonth_SelectedIndexChanged"
                                                Width="190px">
                                            </asp:DropDownList>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>To
                                        </td>
                                        <td>
                                            <table style="margin-left: -3px;">
                                                <tr>
                                                    <td>
                                                        <asp:TextBox ID="toDate" runat="server" AutoComplete="Off" CssClass="txtBPR" onBlur="setDateFormat(this);return OnDateChanged();"
                                                            Width="150px"></asp:TextBox>
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnLoad" runat="server" CssClass="cmnBtn" Enabled="false" Height="20px"
                                                            OnClick="btnLoad_Click" OnClientClick="return OnDateChanged();" Text="Load" Width="32px" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">Challan/TV No
                                        </td>
                                        <td class="iCol">
                                            <asp:DropDownList ID="cmbVoucherNos" runat="server" Width="190px">
                                            </asp:DropDownList>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="vHCol">Date
                                        </td>
                                        <td class="iCol">
                                            <asp:TextBox ID="txtDate" runat="server" AutoComplete="Off" CssClass="txtBPR" onBlur="setDateFormat(this);"
                                                Style="text-align: right" Width="185px"> </asp:TextBox>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <table>
                                    <tr>
                                        <td id="RptType" runat="server" class="vHCol">Report Type
                                        </td>
                                        <td style="width: 244px;">
                                            <table>
                                                <tr>
                                                    <td>
                                                        <asp:RadioButton ID="rdbHTML" runat="server" Checked="true" GroupName="ReportType"
                                                            onclick="SetStatus();" Text="HTML" />
                                                    </td>
                                                    <td>
                                                        <asp:RadioButton ID="rdbPDF" runat="server" GroupName="ReportType" onclick="SetStatus();"
                                                            Text="PDF" Visible="false" />
                                                    </td>
                                                    <td>
                                                        <asp:RadioButton ID="rdbPDFSigning" runat="server" GroupName="ReportType" onclick="SetStatus();"
                                                            Text="Digitally Signed PDF" Visible="false" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td></td>
                        </tr>
                        <tr id="annexureRow" runat="server" style="display: none">
                            <td colspan="2">
                                <table>
                                    <tr>
                                        <td class="vHCol"></td>
                                        <td class="iCol">
                                            <asp:CheckBox ID="chkIsAnnexure" runat="server" Checked="false" Text="Show Annexure Details" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td></td>
                        </tr>
                    </table>
                    <asp:Panel ID="pnlPFXFileDetails" runat="server" CssClass="searchPanel" Style="display: none">
                        <table cellpadding="0px">
                            <tr>
                                <td class="vHCol">Select PFX File
                                </td>
                                <td class="iCol">
                                    <asp:FileUpload ID="fupPfxFile" runat="server" BackColor="#E5E5E5" Width="555px" />
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Password
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtPfxPassword" runat="server" CssClass="txtBML" TextMode="Password"
                                        Width="164px"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Reason
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtReason" runat="server" CssClass="txtBPL" MaxLength="60" Text="Digitally signed TDS certificate as per I.T. Act, 2000."
                                        Width="550px"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Location
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtLocation" runat="server" CssClass="txtBPL" Width="164px"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td class="vHCol">Signature Format
                                </td>
                                <td class="iCol">
                                    <table>
                                        <tr>
                                            <td>
                                                <asp:RadioButton ID="rdbFormat1" runat="server" Checked="true" GroupName="format"
                                                    Text="Format1" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rdbFormat2" runat="server" GroupName="format" Text="Format2" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rdbFormat3" runat="server" GroupName="format" Text="Format3" />
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td>Cover Letter
                                </td>
                                <td>
                                    <asp:CheckBox ID="chkCoverLetter" runat="server" />
                                </td>
                            </tr>
                        </table>
                    </asp:Panel>
                </asp:View>
                <asp:View ID="vwtin" runat="server">
                    <table class="eCol">
                        <tr>
                            <td>TAN
                            </td>
                            <td class="iCol">
                                <asp:TextBox ID="txtTanNo" runat="server" AutoComplete="Off" CssClass="txtBPL" MaxLength="12"
                                    onkeypress="return ValidateForAlphaNumeric(event);" TabIndex="40" Width="150px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td>Place
                            </td>
                            <td class="iCol">
                                <asp:TextBox ID="txtTINPlace" runat="server" AutoComplete="Off" CssClass="txtBPL"
                                    MaxLength="25" onkeypress="return ValidateForAlphaNumeric(event);" TabIndex="40"
                                    Width="150px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td>Date
                            </td>
                            <td class="iCol">
                                <asp:TextBox ID="txtTINDate" runat="server" AutoComplete="Off" CssClass="txtBPL"
                                    MaxLength="25" onBlur="setDateFormat(this);" TabIndex="44" Width="150px"></asp:TextBox>
                            </td>
                        </tr>
                        <tr>
                            <td>Upload File
                            </td>
                            <td class="iCol">
                                <asp:FileUpload ID="fuptxtFile" runat="server" CssClass="browsBtn" />
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td class="iCol">
                                <asp:CheckBox ID="chkInclgd" runat="server" Text="Include Legends" ToolTip="Legend Used in Form 16A for Status of Booking" />
                            </td>
                        </tr>
                    </table>
                    <table>
                        <tr>
                            <td>
                                <table>
                                    <tr id="trRptType" runat="server">
                                        <td id="Td1" runat="server" class="vHCol">Report Type
                                        </td>
                                        <td style="width: 244px;">
                                            <table>
                                                <tr>
                                                    <td>
                                                        <asp:RadioButton ID="rdbPDFTraces" runat="server" GroupName="ReportType" onclick="SetStatusTraces();"
                                                            Text="PDF" Checked="true" />
                                                    </td>
                                                    <td>
                                                        <asp:RadioButton ID="rdbSignTraces" runat="server" GroupName="ReportType" onclick="SetStatusTraces();"
                                                            Text="Digitally Signed PDF" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                    <asp:Panel ID="pnlTraces" runat="server" CssClass="searchPanel">
                        <table cellpadding="0px">
                            <tr>
                                <td class="vHCol">Select PFX File
                                </td>
                                <td>
                                    <asp:FileUpload ID="flUploadTraces" runat="server" BackColor="#E5E5E5" Width="555px" />
                                </td>
                            </tr>
                            <tr>
                                <td>Password
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtPwdTraces" runat="server" CssClass="txtBML" TextMode="Password"
                                        Width="164px"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>Reason
                                </td>
                                <td class="iCol">
                                    <asp:TextBox ID="txtReasonTraces" runat="server" CssClass="txtBPL" MaxLength="60"
                                        Text="Digitally signed TDS certificate as per I.T. Act, 2000." Width="550px"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>Location
                                </td>
                                <td>
                                    <asp:TextBox ID="txtLocationTraces" runat="server" CssClass="txtBPL" Width="164px"></asp:TextBox>
                                </td>
                            </tr>
                            <tr>
                                <td>Cover Letter
                                </td>
                                <td>
                                    <asp:CheckBox ID="chkCvrLtrTraces" runat="server" ToolTip="Details in Form 16A and Signature Details" />
                                </td>
                            </tr>
                        </table>
                    </asp:Panel>
                </asp:View>
            </asp:MultiView>
            <table>
                <tr>
                    <td>
                        <asp:Button ID="btnPreview" runat="server" CssClass="cmnBtn" OnClick="btnPreview_Click"
                            OnClientClick="return PleaseWait();" Text="Generate" />
                    </td>
                    <td>
                        <asp:Button ID="btnCertNo" Visible="false" runat="server" CssClass="cmnBtn" Text="Cert No."
                            OnClick="btnCertNo_Click" />
                    </td>
                    <td>
                        <asp:Button ID="btnOpenSearch" runat="server" Text="Search Certificate" TabIndex="20"
                            Visible="false" CssClass="cmnBtn" Width="150px" OnClick="btnOpenSearch_Click" />
                    </td>
                    <td>
                        <asp:Button ID="btnUploadZipFiles" runat="server" Text="Upload Signed Zip" TabIndex="20"
                            Visible="false" CssClass="cmnBtn" Width="200px" OnClick="btnUploadZipFiles_Click" />
                    </td>
                    <td>
                        <table>
                            <tr>
                                <td>
                                    <asp:HyperLink ID="hlnkZippedFile" runat="server" Font-Bold="true" Target="_blank"
                                        Text=""></asp:HyperLink>
                                </td>
                                <td>
                                    <asp:Label ID="lblDownloadDescription" runat="server" ForeColor="Brown" Text="" Visible="false"></asp:Label>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <asp:Panel ID="pnlSearch" runat="server" BorderStyle="Dashed" BorderWidth="1" CssClass="searchPanel"
                Width="99%" Visible="false">
                <table width="80%">
                    <tr id="trFinancialYear" runat="server">
                        <td style="width: 120px"><asp:Label ID="lblFinancialYear" runat="server" Text="Financial Year"/>
                        </td>
                        <td class="iCol">
                            <asp:DropDownList ID="ddlFinYear" runat="server" Style="border-radius: 5px;" 
                                OnSelectedIndexChanged="ddlFinyear_SelectedIndexChanged" AutoPostBack="true"
                               Width="155px">
                                <asp:ListItem Text="2009-10" Value="2009"></asp:ListItem>
                                <asp:ListItem Text="2010-11" Value="2010"></asp:ListItem>
                                <asp:ListItem Text="2011-12" Value="2011"></asp:ListItem>
                                <asp:ListItem Text="2012-13" Value="2012"></asp:ListItem>
                                <asp:ListItem Text="2013-14" Value="2013"></asp:ListItem>
                                <asp:ListItem Text="2014-15" Value="2014"></asp:ListItem>
                                <asp:ListItem Text="2015-16" Value="2015"></asp:ListItem>
                                <asp:ListItem Text="2016-17" Value="2016"></asp:ListItem>
                                <asp:ListItem Text="2017-18" Value="2017"></asp:ListItem>
                                <asp:ListItem Text="2018-19" Value="2018"></asp:ListItem>
                                <asp:ListItem Text="2019-20" Value="2019"></asp:ListItem>
                                <asp:ListItem Text="2020-21" Value="2020"></asp:ListItem>
                                <asp:ListItem Text="2021-22" Value="2021"></asp:ListItem>
                                <asp:ListItem Text="2022-23" Value="2022"></asp:ListItem>
                                <asp:ListItem Text="2023-24" Value="2023"></asp:ListItem>
                                <asp:ListItem Text="2024-25" Value="2024"></asp:ListItem>
                                <asp:ListItem Text="2025-26" Value="2025"></asp:ListItem>
                                <asp:ListItem Text="2026-27" Value="2026"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>                    
                    <tr>
                        <td style="width: 120px">PAN
                        </td>
                        <td class="iCol">
                            <asp:TextBox ID="txtSearchPAN" runat="server" Width="150px" TabIndex="20" CssClass="txtBPL"
                                onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="10"></asp:TextBox>
                        </td>
                        <%--<td style="width: 80px; visibility: hidden">
                            Cert No.
                        </td>
                        <td class="iCol" style="visibility: hidden">
                            <asp:TextBox ID="txtSearchCertNo" runat="server" Width="150px" TabIndex="20" CssClass="txtBPL"
                                onkeypress="return ValidateForAlphaNumeric(event);" MaxLength="75"></asp:TextBox>
                        </td>--%>
                        <td colspan="2">
                            <asp:RadioButton ID="rdbInBranch" runat="server" Text="In Branch" GroupName="searchType"
                                AutoPostBack="True" Checked="true" OnCheckedChanged="ResetDetails" />
                            <asp:RadioButton ID="rdbAllBranch" runat="server" Text="All Branches" GroupName="searchType"
                                AutoPostBack="True" OnCheckedChanged="ResetDetails" />
                        </td>
                    </tr>
                    <tr id="rowQuarter">
                        <td width="120px">
                            <asp:Label ID="lblQuarter" runat="server" Text=" Select Quarter "></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlQuarter" runat="server" CssClass="mdropDownList" Width="155px"
                                AutoPostBack="True" OnSelectedIndexChanged="ddlQuarter_SelectedIndexChanged">
                                <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                <asp:ListItem Text="Quarter1" Value="1"></asp:ListItem>
                                <asp:ListItem Text="Quarter2" Value="2"></asp:ListItem>
                                <asp:ListItem Text="Quarter3" Value="3"></asp:ListItem>
                                <asp:ListItem Text="Quarter4" Value="4"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                        <td width="360px">&nbsp;
                            <asp:TextBox ID="txtStartFilePos" runat="server" CssClass="txtBPL" MaxLength="75"
                                onkeypress="return ValidateForOnlyNos(event);" TabIndex="20" Width="40px" Text="1"
                                Visible="false"></asp:TextBox>
                            &nbsp;
                            <asp:TextBox ID="txtFileCount" runat="server" CssClass="txtBPL" MaxLength="75" onkeypress="return ValidateForOnlyNos(event);"
                                TabIndex="20" Width="40px" Text="250" Visible="false"></asp:TextBox>
                        </td>
                    </tr>
                    <tr id="rowPdfType" visible="false" runat="server">
                        <td width="120px">
                            <asp:Label ID="lblPdfType" runat="server" Text="Select PDF"></asp:Label>
                        </td>
                        <td colspan="3">
                            <asp:RadioButton ID="rdbUnsigned" runat="server" Text="Unsigned" GroupName="pdfType"
                                Checked="true" AutoPostBack="True" OnCheckedChanged="rdbUnsigned_CheckedChanged" />
                            <asp:RadioButton ID="rdbSigned" runat="server" Text="Signed" GroupName="pdfType"
                                AutoPostBack="True" OnCheckedChanged="rdbSigned_CheckedChanged" />
                        </td>
                    </tr>
                    <tr id="rowWaiverData" visible="true" runat="server">
                        <td colspan="4">
                            <asp:CheckBox ID="chkWaiverData" runat="server" Text="  Show Waiver Data Only" Display="Static" />
                        </td>
                    </tr>
                    <tr id="rowZeroTDSData" visible="true" runat="server">
                        <td colspan="4">
                            <asp:CheckBox ID="chkZeroTDSData" runat="server" Text="  Show Zero TDS Only" Display="Static"
                                OnCheckedChanged="chkZeroTDSData_CheckedChanged" AutoPostBack="True" />
                        </td>
                    </tr>
                    <tr>
                        <td colspan="4">
                            <table>
                                <tr>
                                    <td align="right">
                                        <asp:Button ID="btnSearch" runat="server" CssClass="cmnBtn" TabIndex="30" Text="Search"
                                            OnClientClick="return ValiadteSearchPan();" OnClick="btnSearch_Click" />
                                    </td>
                                    <td>
                                        <asp:Button ID="btnClose" runat="server" CssClass="cmnBtn" TabIndex="32" Text="Close"
                                            Width="80px" OnClick="btnClose_Click" />
                                    </td>
                                    <td>
                                        <asp:Button ID="btnGetFiles" runat="server" CssClass="cmnBtn" TabIndex="32" Text="Get Files"
                                            Width="80px" OnClick="btnGetFiles_Click" OnClientClick="return ValiadteSearchPan();" />
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr id="rwNote" runat="server" visible="false">
                        <td colspan="4">
                            <asp:Label ID="lblNote1" runat="server" ForeColor="#0000CC" Text=" Note: To download Form 16A for SCSS customers, click 'Form 16A For SCSS Customers' checkbox. "></asp:Label>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlZipUpload" runat="server" BorderStyle="Dashed" BorderWidth="1"
                CssClass="searchPanel" Visible="false">
                <table cellpadding="0px">
                    <tr>
                        <td width="200px">
                            <asp:Label ID="lblQuarterZipUpload" runat="server" Text=" Select Quarter "></asp:Label>
                        </td>
                        <td>
                            <asp:DropDownList ID="ddlQuarterZipUpload" runat="server" CssClass="mdropDownList"
                                Width="163px" Height="23px">
                                <asp:ListItem Text="Select" Value="-1"></asp:ListItem>
                                <asp:ListItem Text="Quarter1" Value="1"></asp:ListItem>
                                <asp:ListItem Text="Quarter2" Value="2"></asp:ListItem>
                                <asp:ListItem Text="Quarter3" Value="3"></asp:ListItem>
                                <asp:ListItem Text="Quarter4" Value="4"></asp:ListItem>
                            </asp:DropDownList>
                        </td>
                    </tr>
                    <tr>
                        <td width="200px">Select Signed Zip File
                        </td>
                        <td class="iCol">
                            <asp:FileUpload ID="flUploadZip" runat="server" CssClass="browsBtn" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Button ID="btnUploadZip" runat="server" CssClass="cmnBtn" TabIndex="32" Text="Upload"
                                Width="80px" OnClick="btnUploadZip_Click" />
                            <asp:Button ID="btnCloseUploadZip" runat="server" CssClass="cmnBtn" TabIndex="32"
                                Text="Close" Width="80px" OnClick="btnCloseUploadZip_Click" />
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <table class="nTbl" id="tblrpt" runat="server" visible="false">
                <tr>
                    <td>
                        <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal" width= "100%">
                            <asp:Repeater ID="rptrPDFDownload" runat="server" OnItemCommand="rptrPDFDownload_ItemCommand">
                                <HeaderTemplate>
                                    <table id="NavTable" width= "100%">
                                        <tr bgcolor="#EEEEEE">
                                            <th>
                                                <asp:Label runat="server" ID="lblcheckFile" Width="40px" Text="Select"></asp:Label>
                                            </th>
                                            <th>
                                                <asp:Label runat="server" ID="lblSlNo" Width="40px" Text="SrNo." />
                                            </th>
                                            <th>
                                                <asp:Label runat="server" ID="lblFileName" Width="180px" Text="File Name" />
                                            </th>
                                            <th>
                                                <asp:Label runat="server" ID="lblEmailAddress" Width="145px" Text="Email" />
                                            </th>
                                            <th>
                                                <asp:Label runat="server" ID="lblPhoneNumber" Width="40px" Text="Phone" />
                                            </th>
                                            <th>
                                                <asp:Label runat="server" ID="lblCreatedDate" Width="150px" Text="Created Date"></asp:Label>
                                            </th>
                                            <th>
                                                <asp:Label runat="server" ID="lblPath" Width="150px" Text="File Path" Visible="false"></asp:Label>
                                            </th>
                                        </tr>
                                </HeaderTemplate>
                                <ItemTemplate>
                                    <tr bgcolor="white">
                                        <td style="text-align: center">
                                            <asp:CheckBox ID="checkFile" runat="server" />
                                        </td>
                                        <td>
                                            <%#Eval("SRNO")%>
                                        </td>
                                        <td>
                                            <asp:Label runat="server" ID="lblPDFName" Text='<%#Eval("PDFNAME")%>'></asp:Label>
                                        </td>
                                        <td>
                                            <asp:Label runat="server" ID="lblEmail" Text='<%#Eval("EMAIL")%>'></asp:Label>
                                        </td>
                                        <td>
                                            <asp:Label runat="server" ID="lblPhone" Text='<%#Eval("PHONE")%>'></asp:Label>
                                        </td>
                                        <td style="text-align: center">
                                            <%#Eval("CREATEDATE")%>
                                        </td>
                                        <td>
                                            <asp:Label runat="server" ID="lblFilePath" Text='<%#Eval("FILEPATH")%>' Visible="false"></asp:Label>
                                        </td>
                                    </tr>
                                </ItemTemplate>
                                <FooterTemplate>
                                    </table>
                                </FooterTemplate>
                            </asp:Repeater>
                        </asp:Panel>
                    </td>
                </tr>
            </table>
            <table id="tblpagination" runat="server" visible="false">
                <tr>
                    <td style="padding: 0px 0px 0px 532px">
                        <asp:Label ID="lblRecordsPerPage" runat="server" Text="Records per page : " Font-Size="X-Small"
                            Width="100px" />
                    </td>
                    <td style="width: 50px; padding-top: 2px;">
                        <asp:DropDownList ID="ddlBranchInputGoTo" runat="server" Style="width: 50px; float: left;"
                            AutoPostBack="true" TabIndex="35" Font-Size="X-Small" CssClass="dropDownList"
                            OnSelectedIndexChanged="ddlBranchInputGoTo_SelectedIndexChanged">
                            <%--<asp:ListItem Text="5" Value="5" Selected="True" />
                            <asp:ListItem Text="10" Value="10" />
                            <asp:ListItem Text="15" Value="15" />--%>
                            <asp:ListItem Text="20" Value="20" />
                            <asp:ListItem Text="25" Value="25" />
                            <asp:ListItem Text="50" Value="50" />
                            <asp:ListItem Text="75" Value="75" />
                            <asp:ListItem Text="100" Value="100" />
                        </asp:DropDownList>
                    </td>
                    <td>
                        <asp:Label ID="lblBranchInputStatus" runat="server" Style="float: left;" Font-Size="X-Small"></asp:Label>
                    </td>
                    <td>
                        <asp:Button ID="btnBranchInputFirst" runat="server" Text="&lt;&lt;" Width="35px"
                            Font-Names="Arial" Font-Overline="False" Font-Size="X-Small" CssClass="navButton"
                            Enabled="False" TabIndex="36" OnClick="btnBranchInputFirst_Click"></asp:Button>
                    </td>
                    <td>
                        <asp:Button ID="btnBranchInputPrevious" runat="server" Text="&lt;" Font-Names="Arial"
                            Font-Overline="False" Font-Size="X-Small" CssClass="navButton" Enabled="False"
                            TabIndex="37" OnClick="btnBranchInputPrevious_Click"></asp:Button>
                    </td>
                    <td>
                        <asp:TextBox ID="txtBranchInputGoTo" runat="server" Text="1" CssClass="navTextBox"
                            AutoPostBack="True" MaxLength="5" TabIndex="38" OnTextChanged="txtBranchInputGoTo_TextChanged"></asp:TextBox>
                    </td>
                    <td>
                        <asp:Button ID="btnBranchInputNext" runat="server" Text="&gt;" Font-Names="Arial"
                            Font-Overline="False" Font-Size="X-Small" CssClass="navButton" TabIndex="39"
                            OnClick="btnBranchInputNext_Click"></asp:Button>
                    </td>
                    <td>
                        <asp:Button ID="btnBranchInputLast" runat="server" Text="&gt;&gt;" Font-Names="Arial"
                            Font-Overline="False" Font-Size="X-Small" CssClass="navButton" TabIndex="40"
                            OnClick="btnBranchInputLast_Click"></asp:Button>
                    </td>
                </tr>
            </table>
            <table width="60%">
                <tr>
                    <td style="text-align: left;">
                        <asp:Button ID="btnSelectAll" runat="server" CssClass="cmnBtn" Text="Select All"
                            CommandName="Select" Visible="false" OnClick="btnSelectAll_Click" />
                    </td>
                    <td>
                        <asp:Button ID="btnSelectAllFiles" runat="server" CssClass="cmnBtn" Text="Select All Files"
                            CommandName="SelectAllFiles" Width="130px" Visible="false" OnClick="btnSelectAllFiles_Click" />
                    </td>
                    <td>
                        <asp:Button ID="btnPrepareZip" runat="server" CssClass="cmnBtn" Text="Prepare Files For Download"
                            CommandName="PrepareZip" Width="200px" Visible="false" OnClick="btnPrepareZip_Click" />
                    </td>
                    <td>
                        <asp:Button ID="btnSendEmail" runat="server" CssClass="cmnBtn" Text="Send Email"
                            CommandName="SendEmail" Visible="false" OnClick="btnSendEmail_Click" />
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:HyperLink ID="hlnkDownloadZipFile" runat="server" Target="_blank" Visible="false"
                            Font-Bold="True">Download Zip File</asp:HyperLink>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <asp:HyperLink ID="hlnkDownloadZipFileCashWithdrawal" runat="server" Target="_blank" Visible="false"
                        Font-Bold="True">Download Zip File</asp:HyperLink>
                    </td>
                </tr>
            </table>
        </ContentTemplate>
        <Triggers>
            <asp:PostBackTrigger ControlID="btnPreview" />
            <asp:PostBackTrigger ControlID="btnUploadZip" />
        </Triggers>
    </asp:UpdatePanel>
</asp:Content>
