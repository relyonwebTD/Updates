<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Challan_ChallansPaymentIntegration, App_Web_challanspaymentintegration.aspx.66e8bc22" %>

<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <script src="../JavaScript/Validations.js" type="text/javascript" language="javascript"></script>
    <script type="text/javascript">
        function checkZAOCode(object1) {
            if (document.getElementById("<%=hdnIsSBP.ClientID%>").value == "1" || document.getElementById("<%=hdnIsCB.ClientID%>").value == "1"
                || document.getElementById("<%=hdnIsUCO.ClientID%>").value == "1" || document.getElementById("<%=hdnIsAB.ClientID%>").value == "1"
                || document.getElementById("<%=hdnIsCBI.ClientID%>").value == "1" || document.getElementById("<%=hdnIsUB.ClientID%>").value == "1"
                || document.getElementById("<%=hdnIsOBC.ClientID%>").value == "1" || document.getElementById("<%=hdnIsJK.ClientID%>").value == "1"
                || document.getElementById("<%=hdnIsKB.ClientID%>").value == "1" || document.getElementById("<%=hdnIsTMB.ClientID%>").value == "1"
                || document.getElementById("<%=hdnIsBOM.ClientID%>").value == "1" || document.getElementById("<%=hdnIsSynd.ClientID%>").value == "1") {
                if (object1 != "1" && !(document.getElementById("<%=hdnIsKB.ClientID%>").value == "1"
                    || document.getElementById("<%=hdnIsTMB.ClientID%>").value == "1"
                    || document.getElementById("<%=hdnIsBOM.ClientID%>").value == "1")) {
                    if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 4) {
                        alert("Specify Companies Index No of length 4");
                        document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                        return false;
                    }
                    else if (document.getElementById("<%=txtIndividuals.ClientID%>").value.length != 4) {
                        alert("Specify Individuals Index No of length 4");
                        document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                        return false;
                    }
                }
                else {
                    if (document.getElementById("<%=hdnIsUCO.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 14) {
                            alert("Specify Account No of length 14");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                    else if (document.getElementById("<%=hdnIsOBC.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 14) {
                            alert("Specify Account No of length 14");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                    else if (document.getElementById("<%=hdnIsCBI.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 17) {
                            alert("Specify Account No of length 17");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                    else if (document.getElementById("<%=hdnIsAB.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length == '') {
                            alert("Specify Account No of length within 16");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                    else if (document.getElementById("<%=hdnIsUB.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 14) {
                            alert("Specify Account No of length 14");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                    else if (document.getElementById("<%=hdnIsJK.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 16) {
                            alert("Specify Account No of length 16");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                    else if (document.getElementById("<%=hdnIsTMB.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 15) {
                            alert("Specify Account No of length 15");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                    else if (document.getElementById("<%=hdnIsBOM.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 11) {
                            alert("Specify Account No of length 11");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                    else if (document.getElementById("<%=hdnIsKB.ClientID%>").value == "1") {
                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 16) {
                            alert("Specify Account No of length 16");
                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                            return false;
                        }
                    }
                }
            }
            else {
                if (document.getElementById("<%=hdnIsIB.ClientID%>").value == "1") {
                    if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length == '') {
                        alert("Specify Account No of length within 12");
                        document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                        return false;
                    }
                }
                else {
                    if (document.getElementById("<%=hdnIsCB.ClientID%>").value != "1") {
                        if (document.getElementById("<%=hdnIsUCO.ClientID%>").value == "1") {
                            if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 14) {
                                alert("Specify Account No of length 14");
                                document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                                return false;
                            }
                        }
                        else {
                            if (document.getElementById("<%=hdnIsOBC.ClientID%>").value == "1") {
                                if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 14) {
                                    alert("Specify Account No of length 14");
                                    document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                                    return false;
                                }
                            }
                            else {
                                if (document.getElementById("<%=hdnIsCorp.ClientID%>").value == "1") {
                                    if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 16) {
                                        alert("Specify Account No of length 16");
                                        document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                                        return false;
                                    }
                                }
                                else {
                                    if (document.getElementById("<%=hdnIsKGSGB.ClientID%>").value == "1") {
                                        if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length == '' || document.getElementById("<%=txtAccountNo.ClientID%>").value.length > 15) {
                                            alert("Specify Account No of length within 15");
                                            document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                                            return false;
                                        }
                                    }
                                    else {
                                        if (document.getElementById("<%=hdnIsSynd.ClientID%>").value != "1") {
                                            if (document.getElementById("<%=txtAccountNo.ClientID%>").value.length != 8) {
                                                alert("Specify Account No of length 8");
                                                document.getElementById("<%=txtAccountNo.ClientID%>").focus();
                                                return false;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return true;
        }
        function OnSave() { return confirm('Do you want to Save the Records.'); }
        function UpdateCheckBoxStatus() {
            var hdnIsChecked = document.getElementById("<%=hdnIsChecked.ClientID %>");
            hdnIsChecked.value = "False";

        }
        function SelectAllCheckBox() {
            var x = document.getElementsByClassName("admChaPymnt");
            var i;
            for (i = 0; i <= x.length; i++) {
                if (i < 10) {
                    i = '0' + i;
                }
                el = document.getElementById('ctl00_contentPlaceHolderBody_rptTempChallan_ctl' + i + '_chkSelect');
                if (el != null) {
                    el.checked = true;
                    UpdateCheckBoxStatus();
                }
            }
            return false;
        }
        function UnSelectAllCheckBox() {
            var x = document.getElementsByClassName("admChaPymnt");
            var i;
            for (i = 0; i <= x.length; i++) {
                if (i < 10) {
                    i = '0' + i;
                }
                el = document.getElementById('ctl00_contentPlaceHolderBody_rptTempChallan_ctl' + i + '_chkSelect');
                if (el != null) {
                    el.checked = false;
                    UpdateCheckBoxStatus();
                }
            }
            return false;
        }
        function OnParameterChanged() {
            if (document.getElementById("<%=hdnIsSearchParameterChanged.ClientID %>").value == "1") {
                document.getElementById("<%=ddlGoTo.ClientID %>").value = document.getElementById("<%=selectedPageSize.ClientID %>").value;
                document.getElementById("<%=txtGoToPage.ClientID %>").value = document.getElementById("<%=selectedPageIndex.ClientID %>").value;
                alert("Search parameters are changed; So,Click on search and continue");
                return false;
            }
            else {
                return true;
            }
        }
        function ValidateFields() {
            if (document.getElementById("<%=hdnIsSBP.ClientID%>").value != "1" && document.getElementById("<%=hdnKBUBI.ClientID%>").value != "1") {
                var transactionNo = document.getElementById("<%=txtTransactionNo.ClientID%>");
                var transactionDate = document.getElementById("<%=txtTransactionDate.ClientID%>");
                if (trim(transactionNo.value).length == 0) {
                    alert("Specify Transaction No.");
                    transactionNo.focus();
                    return false;
                }
                if (trim(transactionDate.value).length == 0) {
                    alert("Specify Transaction Date.");
                    transactionDate.focus();
                    return false;
                }
                if (document.getElementById("<%=hdnIsSynd.ClientID%>").value == "1") {
                    var startingChallanNo = document.getElementById("<%=txtStartingChallanNo.ClientID%>");
                    if (trim(startingChallanNo.value).length == 0) {
                        alert("Specify Starting Challan No.");
                        startingChallanNo.focus();
                        return false;
                    }
                    else if (trim(startingChallanNo.value).length != 5) {
                        alert("Starting Challan No. should be of five digits");
                        startingChallanNo.focus();
                        return false;
                    }
                }
            }
            return true;
        }
        function ValidateSelection() {
            var chkType1 = document.getElementById("<%=chkType1.ClientID%>");
            var chkType2 = document.getElementById("<%=chkType2.ClientID%>");
            var chkType3 = document.getElementById("<%=chkType3.ClientID%>");
            var chkForm27EQ = document.getElementById("<%=chkForm27EQ.ClientID%>");

            var chkType4 = document.getElementById("<%=chkType4.ClientID%>");
            var chkType5 = document.getElementById("<%=chkType5.ClientID%>");
            var chkType6 = document.getElementById("<%=chkType6.ClientID%>");
            var chkType7 = document.getElementById("<%=chkType7.ClientID%>");
            var chkType8 = document.getElementById("<%=chkType8.ClientID%>");
            var chkType9 = document.getElementById("<%=chkType9.ClientID%>");
            var chkType10 = document.getElementById("<%=chkType10.ClientID%>");

            var isUBI = document.getElementById("<%=hdnIsUBI.ClientID%>");
            var isJK = document.getElementById("<%=hdnIsJK.ClientID%>");

            var isKB = document.getElementById("<%=hdnIsKB.ClientID%>");
            if (isKB.value == "1") {
                var rdbUBI = document.getElementById("<%=rdbUBI.ClientID %>");
                if (rdbUBI != null) {
                    if (document.getElementById("<%=rdbUBI.ClientID %>").checked) {
                        var txtUBIScrollID = document.getElementById("<%=txtUBIScrollID.ClientID %>");
                        if (txtUBIScrollID != null) {
                            if (document.getElementById("<%=txtUBIScrollID.ClientID %>").value == "") {
                                alert("Please enter Scroll ID.");
                                document.getElementById("<%=txtUBIScrollID.ClientID %>").focus();
                                return false;
                            }
                        }
                    }
                }
            }

            if (document.getElementById("<%=txtTransactionNo.ClientID%>") != null)
                document.getElementById("<%=txtTransactionNo.ClientID%>").value = "";
            if (document.getElementById("<%=txtTransactionDate.ClientID%>") != null)
                document.getElementById("<%=txtTransactionDate.ClientID%>").value = "";
            if (!(chkType1.checked || chkType2.checked || (chkType3 != null && chkType3.checked)
                || (chkForm27EQ != null && chkForm27EQ.checked)
                || (chkType4 != null && chkType4.checked) || (chkType5 != null && chkType5.checked)
                || (chkType6 != null && chkType6.checked) || (chkType7 != null && chkType7.checked)
                || (chkType8 != null && chkType8.checked) || (chkType9 != null && chkType9.checked)
                || (chkType10 != null && chkType10.checked))) {
                alert("Select at least one account type.");
                chkType1.focus();
                return false;
            }
            if (isJK.value == "1") {
                var result = confirm('Have you reviewed Exception Report and Mismatch Report ? \nClick Ok to Continue. \nClick Cancel to Check the Reports.', 'Confirm');
                if (!result) { return false; }
            }
            return true;
        }
        //        function Show_Popup_Cancel() {
        //            if (document.getElementById("<%=hdnIsBOM.ClientID%>").value == "1") {
        //                $find("popUpCancel_Control").show();
        //                document.getElementById("<%=txtChalGenDate.ClientID%>").value = "";
        //                document.getElementById("<%=txtChalGenDate.ClientID%>").focus();
        //            }
        //        }
        function MakeEmptyGenDate() {
            if (document.getElementById("<%=hdnIsBOM.ClientID%>").value == "1") {
                document.getElementById("<%=txtChalGenDate.ClientID%>").value = "";
                document.getElementById("<%=txtCancelReason.ClientID%>").value = "";
            }
        }
        function ValidateCancelProcess() {
            var txtChalGenDate = document.getElementById("<%=txtChalGenDate.ClientID%>").value;
            var txtCancelReason = document.getElementById("<%=txtCancelReason.ClientID%>").value;
            if (txtChalGenDate == "") {
                alert("Specify Challan Generation Date");
                return false;
            }
            if (txtCancelReason == "") {
                alert("Specify Reason For Cancellation");
                return false;
            }
        }
    </script>
    <style type="text/css">
        .style1 {
            width: 101px;
        }

        .navButton {
            width: 20px;
        }
    </style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <cc1:ModalPopupExtender ID="popUpCancel" runat="server" CancelControlID="btnCloseCancelPopUp"
        BackgroundCssClass="modalBackground" TargetControlID="lblPopUpDummy" PopupControlID="pnlCancel">
    </cc1:ModalPopupExtender>
    <asp:Panel ID="pnlCancel" runat="server" BackColor="White" CssClass="modalPopup"
        Width="400px" Style="display: none">
        <asp:Label ID="lblImport_Heading" Text="CHALLAN PAYMENT - CANCEL" Font-Bold="true"
            ForeColor="Brown" runat="server"> </asp:Label>
        <hr />
        <table>
            <tr>
                <td style="height: 10px"></td>
            </tr>
            <tr>
                <td style="width: 170px">Challan Generation Date
                </td>
                <td>
                    <asp:TextBox ID="txtChalGenDate" runat="server" MaxLength="14" AutoComplete="Off"
                        TabIndex="30" Width="170px" onBlur="setDateFormat(this);" CssClass="txtBPR" BackColor="#E5E5E5"
                        Height="20px"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td style="width: 170px">Reason For Cancellation
                </td>
                <td>
                    <asp:TextBox ID="txtCancelReason" runat="server" MaxLength="100" TabIndex="31" Width="170px"
                        BackColor="#E5E5E5" Height="40px" TextMode="MultiLine"></asp:TextBox>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <p style="color: Red; font-size: 15px">
                        Note : Ensure Date provided is correct. Data will be deleted for provided date.
                    </p>
                </td>
            </tr>
            <tr>
                <td style="height: 10px"></td>
            </tr>
            <tr>
                <td align="right">
                    <asp:Button ID="btnCancelPopUp" Text="Submit" runat="server" Width="110px" TabIndex="32"
                        CssClass="cmnBtn" OnClientClick="return ValidateCancelProcess()" OnClick="btnCancelPopUp_Click" />
                </td>
                <td align="center">
                    <asp:Button ID="btnCloseCancelPopUp" Text="Close" runat="server" Width="70px" TabIndex="33"
                        CssClass="cmnBtn" />
                    <asp:Label ID="lblPopUpDummy" Text="" runat="server" />
                </td>
            </tr>
        </table>
    </asp:Panel>
    <asp:UpdatePanel ID="updatepanelChallan" runat="server">
        <ContentTemplate>
            <asp:HiddenField ID="hdnIsSearchParameterChanged" runat="server" Value="0" />
            <asp:HiddenField ID="selectedPageSize" runat="server" />
            <asp:HiddenField ID="selectedPageIndex" runat="server" />
            <asp:HiddenField ID="hdnIsSearchActive" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsChalanNull" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsChecked" runat="server" Value="True" />
            <asp:HiddenField ID="hdnIsIB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsUBI" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsUCO" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsSBP" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsCB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsKB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsCBI" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsAB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsKGSGB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsUB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsSynd" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsOBC" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsCorp" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsJK" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsTMB" runat="server" Value="0" />
            <asp:HiddenField ID="hdnIsBOM" runat="server" Value="0" />
            <asp:HiddenField ID="hdnTotalchallanCount" runat="server" Value="0" />
            <asp:HiddenField ID="hdnKBUBI" runat="server" Value="0" />
            <table>
                <tr>
                    <td style="display: none" colspan="8">
                        <asp:Button ID="btnDisableMakePayment" runat="server" Text="Disable Make Payment"
                            CssClass="cmnBtn" OnClick="btnDisableMakePayment_Click" Visible="false" Width="150px" />
                    </td>
                </tr>
            </table>
            <table>
                <tr>
                    <td style="display: none">
                        <asp:Label ID="lblFormatType" Text="Format Type:" runat="server"></asp:Label>
                    </td>
                    <td style="display: none">
                        <asp:RadioButton ID="rdbAxis" runat="server" Text="Axis Bank" Checked="true"
                            GroupName="FileFormatType" OnCheckedChanged="rdbAxis_Checked" AutoPostBack="true" />
                    </td>
                    <td style="display: none; width: 330px">
                        <asp:RadioButton ID="rdbUBI" runat="server" Text="Union Bank of India" GroupName="FileFormatType"
                            OnCheckedChanged="rdbUBI_Checked" AutoPostBack="true" />
                        &nbsp&nbsp
                        <asp:Label ID="lblUBIScrollID" Text="Scroll ID:" runat="server"></asp:Label>
                        &nbsp
                        <asp:TextBox ID="txtUBIScrollID" runat="server" MaxLength="4" Width="60px"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td style="display: none">
                        <table>
                            <tr runat="server" id="trindividuals" visible="false">
                                <td style="float: right" colspan="6" width="470px"></td>
                                <td style="padding-left: 28px; float: right" colspan="2">
                                    <asp:Label ID="lblIndividuals" Text="Individuals Index No" runat="server"></asp:Label>
                                    &nbsp;&nbsp;
                                    <asp:TextBox ID="txtIndividuals" runat="server" Width="70px" MaxLength="12" CssClass="txtAR"
                                        onkeypress="return numeralsOnly(this, event,12,0,0,0);"></asp:TextBox>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <table>
                <tr>
                    <td>
                        <asp:Label ID="lblSelectMonth" Text="Select Month:" runat="server"></asp:Label>
                    </td>
                    <td style="padding-left: 20px; width: 100px">
                        <asp:DropDownList ID="ddlMonth" runat="server" Width="80px" CssClass="dropDownList"
                            OnSelectedIndexChanged="ddlMonth_SelectedIndexChanged" AutoPostBack="True">
                            <asp:ListItem Text="April" Value="4"></asp:ListItem>
                            <asp:ListItem Text="May" Value="5"></asp:ListItem>
                            <asp:ListItem Text="June" Value="6"></asp:ListItem>
                            <asp:ListItem Text="July" Value="7"></asp:ListItem>
                            <asp:ListItem Text="August" Value="8"></asp:ListItem>
                            <asp:ListItem Text="September" Value="9"></asp:ListItem>
                            <asp:ListItem Text="October" Value="10"></asp:ListItem>
                            <asp:ListItem Text="November" Value="11"></asp:ListItem>
                            <asp:ListItem Text="December" Value="12"></asp:ListItem>
                            <asp:ListItem Text="January" Value="1"></asp:ListItem>
                            <asp:ListItem Text="February" Value="2"></asp:ListItem>
                            <asp:ListItem Text="March" Value="3"></asp:ListItem>
                        </asp:DropDownList>
                    </td>
                    
                </tr>
            </table>
            <table>
                <tr>
                    <td>
                        <asp:Label ID="lblAccountType" runat="server" Text="Account Type:"></asp:Label>
                    </td>
                    <td style="padding-left: 10px">
                        <asp:CheckBox ID="chkType1" runat="server" Text="26QI &amp; 27Q" />
                    </td>
                    <td style="padding-left: 10px">
                        <asp:CheckBox ID="chkType2" runat="server" Text="26QV" />
                    </td>
                    <td style="padding-left: 10px">
                        <asp:CheckBox ID="chkType3" runat="server" Text="24Q" />
                    </td>
                    <td colspan="2" width="110"></td>
                    <td>
                        <asp:Label ID="lblAcc" runat="server" Text="Account No:"></asp:Label>
                    </td>
                    <td style="padding-left: 10px; float: right;">
                        <asp:TextBox ID="txtAccountNo" runat="server" CssClass="txtAR" MaxLength="17" onkeypress="return numeralsOnly(this, event,17,0,0,0);"
                            Width="90px"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td style="padding-left: 10px">
                        <asp:CheckBox ID="chkForm27EQ" runat="server" Text="27EQ" />
                    </td>
                    <td style="padding-left: 10px">
                        <asp:CheckBox ID="chkType9" runat="server" Text="6CG" Visible="false" />
                    </td>
                    <td style="padding-left: 10px">
                        <asp:CheckBox ID="chkType10" runat="server" Text="6CP" Visible="false" />
                    </td>
                </tr>
                <tr id="tr26QVSections" runat="server" visible="false">
                    <td></td>
                    <td id="tdchkType4" runat="server" style="display:none; padding-left:10px;">
                        <asp:CheckBox ID="chkType4" runat="server" Text="194J" />
                    </td>
                    <td id="tdchkType5" runat="server" style="display:none; padding-left:10px;">
                        <asp:CheckBox ID="chkType5" runat="server" Text="194C" />
                    </td>
                    <td id="tdchkType6" runat="server" style="display:none; padding-left:10px;">
                        <asp:CheckBox ID="chkType6" runat="server" Text="194H" />
                    </td>
                    <td id="tdchkType7" runat="server" style="display:none; padding-left:10px;">
                        <asp:CheckBox ID="chkType7" runat="server" Text="194I" />
                    </td>
                    <td id="tdchkType8" runat="server" style="display:none; padding-left:10px;">
                        <asp:CheckBox ID="chkType8" runat="server" Text="194N" />
                    </td>
                    <td></td>
                </tr>
            </table>
            <table>
                <tr>
                    <td align="left" colspan="4">
                        <asp:Button ID="bulkMakePayment" runat="server" Text="Initiate Bulk Make Payment"
                            OnClientClick="return ValidateSelection();" CssClass="cmnBtn" Width="170px" OnClick="bulkMakePayment_Click" />
                        &nbsp;
                        <asp:Button ID="btnShow" runat="server" CssClass="cmnBtn" OnClick="btnShow_Click"
                            Text="Show Details" />
                        &nbsp;
                        <asp:Button ID="btnErrorReport" runat="server" CssClass="cmnBtn" Text="Exception Report"
                            Width="120px" OnClick="btnErrorReport_Click" />
                        &nbsp;
                        <asp:Button ID="btnShowExcluded" runat="server" CssClass="cmnBtn" Text="Show Excluded Records"
                            Width="155px" OnClick="btnShowExcluded_Click" />
                        &nbsp;
                    </td>
                </tr>
            </table>
            <table>
                <tr>
                    <td colspan="4" align="left">
                        <asp:Button ID="btnShowMismatch" runat="server" CssClass="cmnBtn" Text="Show Mismatch Report"
                            Width="150px" OnClick="btnShowMismatch_Click" />
                        &nbsp;
                        <asp:Button ID="btnRequiredAmount" runat="server" Text="Required Amount" Visible="true"
                            Width="120px" CssClass="cmnBtn" OnClick="btnRequiredAmount_Click" />
                        &nbsp;
                        <asp:Button ID="btnBalanceParkedAmount" runat="server" Text="Balance Amount" Visible="false"
                            Width="120px" CssClass="cmnBtn" OnClick="btnBalanceParkedAmount_Click" />
                        &nbsp;
                    </td>
                    <td colspan="2" align="left">
                        <asp:HyperLink ID="hlnkOpenException" runat="server" Text="" Visible="true" Target="_blank"></asp:HyperLink>
                    </td>
                    <td colspan="2" align="right">
                        <asp:HyperLink ID="hlnkOpenErrors" runat="server" Text="" Visible="true" Target="_blank"></asp:HyperLink>
                    </td>
                </tr>
            </table>
            <asp:MultiView ID="mvChallan" runat="server" ActiveViewIndex="0">
                <asp:View ID="vwShowDetail" runat="server">
                    <table cellpadding="0" cellspacing="0" width="100%" style="margin-top: 15px;">
                        <tr>
                            <td>
                                <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                                    Width="950px" Height="350px" BorderStyle="Solid" BorderWidth="1px" BorderColor="Gray"
                                    Visible="true">
                                    <asp:Repeater ID="rptBulkChallan" runat="server" OnItemDataBound="rptBulkChallan_ItemDataBound">
                                        <HeaderTemplate>
                                            <table cellpadding="0" cellspacing="0" id="NavTable" width="100%">
                                                <tr bgcolor="#EEEEEE">
                                                    <th style="width: 150px">Branch Name
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="lblHeadSectionName" runat="server" Text="Section Name"></asp:Label>
                                                    </th>
                                                    <th style="width: 100px">
                                                        <asp:Label ID="lblHeadDeducteeCode" runat="server" Text="Deductee Code"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="lblHeadIncomeTaxAmt" runat="server" Text="Income Tax Amt"></asp:Label>
                                                    </th>
                                                    <th id="thSurcharge" runat="server">
                                                        <asp:Label ID="lblHeadSurchargeAmt" runat="server" Text="Surcharge"></asp:Label>
                                                    </th>
                                                    <th id="thCess" runat="server">
                                                        <asp:Label ID="lblHeadCessAmt" runat="server" Text="Cess"></asp:Label>
                                                    </th>
                                                    <th>
                                                        <asp:Label ID="lblHeadTotalAmt" runat="server" Text="Total Amt"></asp:Label>
                                                    </th>
                                                    <th id="thChallanNo" runat="server">
                                                        <asp:Label ID="lblHeadChallanNo" runat="server" Text="Challan No"></asp:Label>
                                                    </th>
                                                    <th id="thChallanDate" runat="server">
                                                        <asp:Label ID="lblHeadChallanDate" runat="server" Text="Challan Date"></asp:Label>
                                                    </th>
                                                    <th id="thBSRCODE" runat="server">
                                                        <asp:Label ID="lblHeadBSRCode" runat="server" Text="BSR Code"></asp:Label>
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white">
                                                <td>
                                                    <asp:Label ID="lblBranchName" runat="server" Text='<%# Eval("BranchName") %>'></asp:Label>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblBranchID" runat="server" Text='<%# Eval("BranchID") %>'></asp:Label>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblSectionID" runat="server" Text='<%# Eval("SectionID")%>'> </asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblSection" runat="server" Text='<%# Eval("SectionName")%>'> </asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblDeducteeCode" runat="server" Text='<%# Eval("DeducteeCode")%>'> </asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblIncomeTax" runat="server" Text='<%# Eval("IncomeTax")%>'> </asp:Label>
                                                </td>
                                                <td id="tdSurchage" runat="server">
                                                    <asp:Label ID="lblSurcharge" runat="server" Text='<%# Eval("Surcharge")%>'> </asp:Label>
                                                </td>
                                                <td id="tdCess" runat="server">
                                                    <asp:Label ID="lblEducationCess" runat="server" Text='<%# Eval("EducationCess")%>'> </asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblTotalAmount" runat="server" Text='<%# Eval("TotalAmount")%>'> </asp:Label>
                                                </td>
                                                <td id="tdChallanNo" runat="server">
                                                    <asp:Label ID="lblChallanNo" runat="server" Text='<%# Eval("BankChallanNO")%>'></asp:Label>
                                                </td>
                                                <td id="tdChallanDate" runat="server">
                                                    <asp:Label ID="lblChallanDate" runat="server" Text='<%# Eval("BankChallanDate")%>'>></asp:Label>
                                                </td>
                                                <td id="tdBSRCODE" runat="server">
                                                    <asp:Label ID="lblBSRCode" runat="server" Text='<%# Eval("BSRCode")%>'></asp:Label>
                                                </td>
                                                <td style="display: none">
                                                    <asp:TextBox ID="txthide" runat="server" Style="display: none"> </asp:TextBox>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblHasPartPayment" runat="server" Text='<%# Eval("HasPartPayment")%>'
                                                        Style="display: none"> </asp:Label>
                                                    <td style="display: none">
                                                        <asp:Label ID="lblChallanID" runat="server" Text='<%# Eval("ChallanID") %>'></asp:Label>
                                                    </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table style="padding-right: 0px; margin-right: -2px; margin-bottom: -3px" align="left">
                                    <tr>
                                        <td style="padding: 0px 0px 0px 463px">
                                            <asp:Label ID="ASPxLabel4" runat="server" Text="Records per page : " Font-Size="X-Small" />
                                        </td>
                                        <td style="width: 50px; padding-top: 2px;">
                                            <asp:DropDownList ID="ddlGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                onchange="if(!OnParameterChanged()) return false" OnSelectedIndexChanged="ddlGoTo_SelectedIndexChanged"
                                                AutoPostBack="true" TabIndex="35" Font-Size="X-Small" CssClass="dropDownList">
                                                <asp:ListItem Text="5" Value="5" />
                                                <asp:ListItem Text="10" Value="10" />
                                                <asp:ListItem Text="15" Value="15" />
                                                <asp:ListItem Text="20" Value="20" />
                                                <asp:ListItem Text="25" Value="25" />
                                                <asp:ListItem Text="50" Value="50" />
                                                <asp:ListItem Text="75" Value="75" />
                                                <asp:ListItem Text="100" Value="100" />
                                            </asp:DropDownList>
                                        </td>
                                        <td>
                                            <asp:Label ID="lblGridStatus" runat="server" Style="float: left;" Text="" Font-Size="X-Small"></asp:Label>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnFirst" runat="server" Text="&lt;&lt;" Width="35px" Font-Names="Arial"
                                                Font-Overline="False" Font-Size="X-Small" OnClick="btnFirst_Click" CssClass="navButton"
                                                Enabled="False" TabIndex="36" OnClientClick="return OnParameterChanged();"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnPrevious" runat="server" Text="&lt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnPrevious_Click" CssClass="navButton" Enabled="False"
                                                TabIndex="37" OnClientClick="return OnParameterChanged();"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:TextBox ID="txtGoToPage" runat="server" Text="1" CssClass="navTextBox" AutoPostBack="True"
                                                OnTextChanged="txtGoToPage_TextChanged" MaxLength="5" TabIndex="38" onchange="if(!OnParameterChanged()) return false"></asp:TextBox>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnNext" runat="server" Text="&gt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnNext_Click" CssClass="navButton" TabIndex="39"
                                                OnClientClick="return OnParameterChanged();"></asp:Button>
                                        </td>
                                        <td>
                                            <asp:Button ID="btnLast" runat="server" Text="&gt;&gt;" Font-Names="Arial" Font-Overline="False"
                                                Font-Size="X-Small" OnClick="btnLast_Click" CssClass="navButton" TabIndex="40"
                                                OnClientClick="return OnParameterChanged();"></asp:Button>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td style="height: 12px"></td>
                        </tr>
                        <table>
                            <tr>
                                <td align="left" style="padding-right: 7px">
                                    <asp:Button ID="btnBranchList" runat="server" CssClass="cmnBtn" Text="Branch List"
                                        Width="100px" OnClick="btnBranchList_Click" />
                                </td>
                                <td align="left">
                                    <asp:Button ID="btnGenerateTTUM" runat="server" CssClass="cmnBtn" Text="Generate TTUM"
                                        Width="100px" OnClick="btnGenerateTTUM_Click" OnClientClick="return checkZAOCode(1);" />
                                </td>
                                <td>
                                    <asp:Button ID="btnClearOltas" Text="Clear TTUM" runat="server" CssClass="cmnBtn"
                                        OnClick="btnClearOltas_Click" />
                                </td>
                                <td>
                                    <asp:Button ID="btnCancelProcess" runat="server" CssClass="cmnBtn" Width="110px"
                                        Text="Cancel Process" OnClick="btnCancelProcess_Click" OnClientClick="MakeEmptyGenDate()" />
                                </td>
                                <td>
                                    <asp:Button ID="btnCreate" runat="server" CssClass="cmnBtn" Width="110px" OnClick="btnCreate_Click"
                                        Text="Create Challan No" OnClientClick="return ValidateFields();" />
                                </td>
                                <td align="left" style="padding-right: 7px">
                                    <asp:Button ID="btnGenerateOltas" runat="server" CssClass="cmnBtn" Text="Generate Oltas"
                                        Width="190px" OnClick="btnGenerateOltas_Click" OnClientClick="return checkZAOCode(0);" />
                                </td>
                                <td>
                                    <asp:Button ID="btnGenerateFiles" runat="server" CssClass="cmnBtn" Text="Generate Files"
                                        OnClientClick="return checkZAOCode();" Width="100px" OnClick="btnGenerateFiles_Click" />
                                </td>
                            </tr>
                            <tr>
                                <td colspan="6">
                                    <table cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td valign="top">
                                                <asp:HyperLink ID="hlnDownloadRT" runat="server" Target="_blank" Visible="False"
                                                    Width="120px" Font-Bold="True">Download RT01 and 04 File</asp:HyperLink>
                                            </td>
                                            <td style="padding-left: 5px" valign="top">
                                                <asp:HyperLink ID="hlnkDownloadRT02" runat="server" Target="_blank" Visible="False"
                                                    Width="120px" Font-Bold="True" ForeColor="#6600FF">Download RT01 and RT02</asp:HyperLink>
                                            </td>
                                            <td style="padding-left: 5px" valign="top">
                                                <asp:HyperLink ID="hlinkDownloadTTUM" runat="server" Target="_blank" Visible="False"
                                                    Width="120px" Font-Bold="True" ForeColor="Green">Download TTUM</asp:HyperLink>
                                            </td>
                                            <td style="padding-left: 5px" valign="top">
                                                <asp:HyperLink ID="hlinkDownloadText" runat="server" Target="_blank" Visible="False"
                                                    Width="180px" Font-Bold="True">Download Challan Deduction Link Text file</asp:HyperLink>
                                            </td>
                                            <td style="padding-left: 5px" valign="top">
                                                <asp:HyperLink ID="hlnk26QV" runat="server" Target="_blank" Visible="False" Font-Bold="True"
                                                    Width="120px">Download 26QV Summary file</asp:HyperLink>
                                            </td>
                                        </tr>
                                    </table>
                                    <table>
                                        <tr id="trStartingChallanNoSection" runat="server" visible="false">
                                            <td>Starting Challan No.
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtStartingChallanNo" MaxLength="5" runat="server" BackColor="#E5E5E5"></asp:TextBox>
                                            </td>
                                        </tr>
                                        <tr id="transactionSection" runat="server">
                                            <td>Transaction No.
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtTransactionNo" runat="server" BackColor="#E5E5E5"></asp:TextBox>
                                            </td>
                                            <td>Transaction Date.
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtTransactionDate" runat="server" MaxLength="14" AutoComplete="Off"
                                                    TabIndex="3" Width="117px" onBlur="setDateFormat(this);" CssClass="txtBPR" BackColor="#E5E5E5"
                                                    Height="20px"></asp:TextBox>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                </asp:View>
                <asp:View ID="vwFromTempChallan" runat="server">
                    <table cellpadding="0" cellspacing="0" width="100%" style="margin-top: 15px; width: 102%; height: 404px;">
                        <tr>
                            <td id="rptrTD" runat="server">
                                <asp:Panel ID="Panel1" CssClass="navPanel" runat="server" ScrollBars="Horizontal"
                                    Width="730px" Height="350px" BorderStyle="Solid" BorderWidth="1px" BorderColor="Gray"
                                    Visible="true">
                                    <asp:Repeater ID="rptTempChallan" runat="server" OnItemDataBound="rptTempChallan_ItemDataBound">
                                        <HeaderTemplate>
                                            <table cellpadding="0" cellspacing="0" id="NavTable" width="100%">
                                                <tr bgcolor="#EEEEEE">
                                                    <th>Select
                                                    </th>
                                                    <th style="display: none">ID
                                                    </th>
                                                    <th style="width: auto">Branch Name
                                                    </th>
                                                    <th>Section
                                                    </th>
                                                    <th>Quarter
                                                    </th>
                                                    <th style="width: 100px">Deductee Code
                                                    </th>
                                                    <th>Total Deducted
                                                    </th>
                                                </tr>
                                        </HeaderTemplate>
                                        <ItemTemplate>
                                            <tr bgcolor="white">
                                                <td>
                                                    <asp:CheckBox ID="chkSelect" runat="server" class="admChaPymnt" />
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblID" runat="server" Text='<%# Eval("ID") %>'></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblBranchID" runat="server" Text='<%# Eval("BranchName") %>'></asp:Label>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblBranchIDNew" runat="server" Text='<%# Eval("BranchID") %>'></asp:Label>
                                                </td>
                                                <td style="display: none">
                                                    <asp:Label ID="lblSectionID" runat="server" Text='<%# Eval("SectionID")%>'> </asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblSectionName" runat="server" Text='<%# Eval("SectionName")%>'> </asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblQuarter" runat="server" Text='<%# Eval("Quarter") %>'></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblDeducteeCode" runat="server" Text='<%# Eval("DeducteeCode") %>'></asp:Label>
                                                </td>
                                                <td>
                                                    <asp:Label ID="lblTotalDeducted" runat="server" Text='<%# Eval("TotalDeducted") %>'></asp:Label>
                                                </td>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            </table>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </asp:Panel>
                                <table cellpadding="2" cellspacing="2">
                                    <tr>
                                        <td>
                                            <table>
                                                <tr>
                                                    <td>Select
                                                    </td>
                                                    <td>
                                                        <asp:LinkButton ID="lnkbtnCheckAll" runat="server" Text="All" OnClientClick="return SelectAllCheckBox();"></asp:LinkButton>
                                                    </td>
                                                    <td>
                                                        <asp:LinkButton ID="lnkbtnUnCheckAll" runat="server" Text="None" OnClientClick="return UnSelectAllCheckBox();"
                                                            CausesValidation="true"></asp:LinkButton>
                                                    </td>
                                                    <td style="padding-left: 145px">
                                                        <asp:Label ID="ASPxLabe15" runat="server" Text="Records per page : " Font-Size="X-Small" />
                                                    </td>
                                                    <td style="width: 50px; padding-top: 2px;">
                                                        <asp:DropDownList ID="cmbGoTo" runat="server" Style="width: 50px; height: 15px; float: left;"
                                                            OnSelectedIndexChanged="cmbGoTo1_SelectedIndexChanged" AutoPostBack="True" Font-Size="X-Small"
                                                            TabIndex="17" CssClass="dropDownList">
                                                            <asp:ListItem Text="5" Value="5" />
                                                            <asp:ListItem Text="10" Value="10" />
                                                            <asp:ListItem Text="15" Value="15" />
                                                            <asp:ListItem Text="20" Value="20" />
                                                            <asp:ListItem Text="25" Value="25" />
                                                            <asp:ListItem Text="50" Value="50" />
                                                            <asp:ListItem Text="75" Value="75" />
                                                            <asp:ListItem Text="100" Value="100" />
                                                        </asp:DropDownList>
                                                    </td>
                                                    <td>
                                                        <asp:Label ID="lblGridStatus1" runat="server" Style="float: left;" Font-Size="X-Small" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnFirst1" runat="server" Text="&lt;&lt;" OnClick="btnFirst1_Click"
                                                            TabIndex="18" CssClass="navButton" Enabled="False"></asp:Button>
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnPrevious1" runat="server" Text="&lt;" OnClick="btnPrevious1_Click"
                                                            TabIndex="19" CssClass="navButton" Enabled="False"></asp:Button>
                                                    </td>
                                                    <td>
                                                        <asp:TextBox ID="txtGoToPage1" runat="server" Text="1" CssClass="navTextBox" AutoPostBack="True"
                                                            TabIndex="20" OnTextChanged="txtGoToPage1_TextChanged" MaxLength="5"></asp:TextBox>
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnNext1" runat="server" Text="&gt;" OnClick="btnNext1_Click" CssClass="navButton"
                                                            TabIndex="21"></asp:Button>
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnLast1" runat="server" Text="&gt;&gt;" OnClick="btnLast1_Click"
                                                            CssClass="navButton" TabIndex="22"></asp:Button>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <table>
                                                <tr>
                                                    <td>
                                                        <asp:Button ID="btnTempOK" Text="OK" runat="server" CssClass="cmnBtn" Width="91px"
                                                            OnClick="btnTempOK_Click" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnDelete" Text="Delete" runat="server" CssClass="cmnBtn" Width="91px"
                                                            OnClick="btnDelete_Click" />
                                                    </td>
                                                    <td>
                                                        <asp:Button ID="btnCreateAll" Text="Create All" runat="server" CssClass="cmnBtn"
                                                            Width="91px" OnClick="btnCreateAll_Click" />
                                                    </td>
                                                    <td align="center">
                                                        <asp:Button ID="btnTempClose" Text="Close" runat="server" CssClass="cmnBtn" Width="91px"
                                                            OnClick="btnTempClose_Click" />
                                                    </td>
                                                    <td align="right">
                                                        <asp:Button ID="btnReport" Text="Report Preview" runat="server" CssClass="cmnBtn"
                                                            Width="100px" OnClick="btnReport_Click" />
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </asp:View>
            </asp:MultiView>
        </ContentTemplate>
        <Triggers>
            <asp:PostBackTrigger ControlID="btnErrorreport" />
            <asp:PostBackTrigger ControlID="btnRequiredAmount" />
        </Triggers>
    </asp:UpdatePanel>
</asp:Content>
