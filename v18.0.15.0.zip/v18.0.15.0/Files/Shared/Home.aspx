<%@ page title="" language="C#" masterpagefile="~/SaralTDS.master" autoeventwireup="true" inherits="Shared_Home, App_Web_home.aspx.48153819" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<%@ MasterType VirtualPath="~/SaralTDS.master" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style type="text/css">
        .modalBackground {
            background-color: Gray;
            filter: alpha(opacity=70);
            opacity: 0.7;
            border-radius: 5px;
        }

        .modalPopup {
            background-color: #ffffdd;
            border-width: 5px;
            border-style: solid;
            border-color: Gray;
            padding: 5px;
            width: 300px;
            border-radius: 5px;
        }

        .autoCompleteList {
            background-color: Blue !important;
            margin: 0px;
            z-index: 100000 !important;
            border-radius: 5px;
        }

        .panel-container {
            width: 100%;
            overflow: hidden; /* Clear floats */
            text-align: left; /* Center-align the panels */
        }

        .panel-box {
            padding: 0px 10px;
            float: left;
            width: 45%; /* Adjust width as needed */
            margin: 0 2.5%; /* Even spacing between panels */
        }

        .d-flex {
            display: flex;
            justify-content: space-around;
        }

        .auto-style2 {
            width: 105%;
        }
    </style>
    <script type="text/javascript">
        function ConfirmFYChange(FYValue, branchCode) {
            var confirm_value = document.createElement("INPUT");
            confirm_value.type = "hidden";
            confirm_value.name = "confirm_value";
            var fyValue = document.getElementById("<%=hdnUserFY.ClientID%>").value;
            var branchValue = document.getElementById("<%=hdnUserBranchCode.ClientID%>").value;
            var label = (parseInt(fyValue.substring(0, 4)) <= 2025) ? "FY" : "TY";

            var confirmation = confirm(
                "In " + label + " " + fyValue +
                ", details of Branch: " + branchValue +
                " will be shown\n\nContinue changing " + label + "?"
            );

            if (confirmation == true)
                confirm_value.value = "Yes";
            else
                confirm_value.value = "No";

            document.forms[0].appendChild(confirm_value);
            var btnChangeFY = document.getElementById("<%=btnChangeFY.ClientID%>");
            btnChangeFY.click();
        }
        function validateSummaryReport() {
            if (!document.getElementById("<%=chkForm24.ClientID %>").checked &&
                !document.getElementById("<%=chkForm26.ClientID %>").checked &&
                !document.getElementById("<%=chkForm27.ClientID %>").checked &&
                !document.getElementById("<%=chkForm27E.ClientID %>").checked
            ) {
                alert("Select atleast one Form to generate report");
                return false;
            } else {
                if (!document.getElementById("<%=chkQ1.ClientID %>").checked &&
                    !document.getElementById("<%=chkQ2.ClientID %>").checked &&
                    !document.getElementById("<%=chkQ3.ClientID %>").checked &&
                    !document.getElementById("<%=chkQ4.ClientID %>").checked
                ) {
                    alert("Select atleast one Quarter to generate report");
                    return false;
                } else {
                    return true;
                }
            }
        }
        function setHeadereReturnSummary() {
            document.getElementById("<%=lblRptPopHeader.ClientID%>").innerHTML = "E-Return Summary Report";
            document.getElementById("<%=hdnReportType.ClientID%>").value = "eReturnSummary";
            $find('rptPopup').show();
        }
        function setHeaderNilReturnSummary() {
            document.getElementById("<%=lblRptPopHeader.ClientID%>").innerHTML = "Nil Return Status";
            document.getElementById("<%=hdnReportType.ClientID%>").value = "NileReturnStatus";
            $find('rptPopup').show();
        }
        function EnableDisableOptions() {
            var yourSelect = document.getElementById("<%=ddlEReturnStatus.ClientID%>");
            var strUser = yourSelect.options[yourSelect.selectedIndex].text;
            if (strUser == "Select") {
                if (document.getElementById("<%=hdnEnalbeDisableText.ClientID%>").value == "1") {
                    document.getElementById("<%=txtParentBranch.ClientID%>").disabled = true;
                }
                document.getElementById("<%=ddlFormTypes.ClientID%>").disabled = true;
                document.getElementById("<%=ddlQuarter.ClientID%>").disabled = true;
            }
            else {
                if (document.getElementById("<%=hdnEnalbeDisableText.ClientID%>").value == "1") {
                    document.getElementById("<%=txtParentBranch.ClientID%>").disabled = false;
                }
                else
                    document.getElementById("<%=txtParentBranch.ClientID%>").disabled = true;
                document.getElementById("<%=ddlFormTypes.ClientID%>").disabled = false;
                document.getElementById("<%=ddlQuarter.ClientID%>").disabled = false;
            } return false;
        }
        function EnterParentBranch() {
            var searchText = document.getElementById("<%=txtParentBranch.ClientID%>").value;
            document.getElementById("<%=hdnAnnx5ParentBrnch.ClientID%>").value = searchText;
            var yourSelect = document.getElementById("<%=ddlEReturnStatus.ClientID%>");
            var strUser = yourSelect.options[yourSelect.selectedIndex].text;
            if (strUser == "All") {
                if (searchText == "") {
                    return true;
                }
                else {
                    var dashIndex = searchText.indexOf("-");
                    if (searchText.length > 0) {
                        if (dashIndex > 0) {
                            return true;
                        }
                        else {
                            alert("Please select parent branch");
                            return false;
                        } return false;
                    } return false;
                }
            }
            if (strUser == "Select") {
                alert("Please select eReturn status.");
                return false;
            }
            if (strUser != "All") {
                var parentBranch = document.getElementById("<%=txtParentBranch.ClientID%>");
                if (parentBranch.value == "") {
                    alert("Please select parent branch");
                    return false;
                }
                else {
                    var dashIndex = searchText.indexOf("-");
                    if (searchText.length > 0) {
                        if (dashIndex > 0) {
                            var userID = searchText.substring(dashIndex + 1, searchText.length);
                            if (userID != null) {
                                document.getElementById("<%=hdnAnnx5ParentBrnch.ClientID%>").value = searchText;
                                return true;
                            }
                            else {
                                alert("Please select parent branch");
                                return false;
                            }
                        }
                        else {
                            alert("Please select parent branch");
                            return false;
                        }
                    } return false;
                }
            } return false;
        }
        function Annexure2Clicked() {
            document.getElementById("<%=hdnAnnx2.ClientID%>").value = "Yes";
            document.getElementById("<%=hdnAnnx5.ClientID%>").value = "NO";
            return true;
        }
        function Annexure5Clicked() {
            document.getElementById("<%=hdnAnnx5.ClientID%>").value = "Yes";
            document.getElementById("<%=hdnAnnx2.ClientID%>").value = "NO";
            return true;
        }
        function ChangeSelection() {
            var yourSelect = document.getElementById("<%=ddlEReturnStatus.ClientID%>");
            var strUser = yourSelect.options[yourSelect.selectedIndex].text;
            if (strUser == "All") {
                document.getElementById("<%=txtParentBranch.ClientID%>").value = "";
                return false;
            }
        }
        function HideShowTextAnnx2() {
            var yourSelect = document.getElementById("<%=ddlAnnexure2.ClientID%>");
            var strUser = yourSelect.options[yourSelect.selectedIndex].text;
            if (document.getElementById("<%=hdnEnalbeDisableText.ClientID%>").value == "1") {
                if (strUser == "RO wise") {
                    document.getElementById("<%=txtRoName.ClientID%>").disabled = false;
                }
                else {
                    document.getElementById("<%=txtRoName.ClientID%>").disabled = true;
                }
            }
            else {
                document.getElementById("<%=txtRoName.ClientID%>").disabled = true;
            }
        }
        function SetHdnAnnex2Value() {
            var searchText = document.getElementById("<%=txtRoName.ClientID%>").value;
            document.getElementById("<%=hdnAnnx2ParentBranch.ClientID%>").value = searchText;
            if (searchText == "") {
                return true;
            }
            else {
                var dashIndex = searchText.indexOf("-");
                if (searchText.length > 0) {
                    if (dashIndex > 0) {
                        return true;
                    }
                    else {
                        alert("Please select parent branch");
                        return false;
                    } return false;
                } return false;
            } return false;
        }
        function PswExpiry(message) {
            var r = confirm("Password expires in " + message + " days.\nDo you want to change password now?");
            if (r == true) {
                __doPostBack("yes");
            }
            return true;
        }
        function handleLinkClick(panValue, typeOfData, panStatus) {
            var PAN = (panStatus === 'Operative' ? "Operative" : "InOperative");
            var DeducteeType = typeOfData;
            var encodedMessage1 = encodeURIComponent(PAN);
            var encodedMessage2 = encodeURIComponent(DeducteeType);
            var encodedMessage3 = encodeURIComponent(panValue);
            var combinedMessage = encodedMessage1 + "||" + encodedMessage2 + "||" + encodedMessage3;
            if (panValue == 0) {
                alert("PAN count is zero. Cannot be proceed.");
                return false;
            }
            var r = confirm("Do you want to proceed?");
            if (r == true) {
                __doPostBack("OK", combinedMessage);
            } else {
                console.log("User canceled the action.");
            }
            return true;
        }
    </script>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="contentPlaceHolderBody" runat="Server">
    <asp:Button ID="btnChangeFY" runat="server" Text="" CssClass="cmnBtn" BackColor="Transparent"
        BorderColor="Transparent" Width="0px" Visible="false" OnClick="btnChangeFY_Click" />
    <asp:HiddenField ID="hdnAnnx5ParentBrnch" runat="server" />
    <asp:HiddenField ID="hdnAnnx2ParentBranch" runat="server" />
    <asp:HiddenField ID="hdnAnnx5" runat="server" />
    <asp:HiddenField ID="hdnAnnx2" runat="server" />
    <asp:HiddenField ID="hdnUserBranchCode" runat="server" />
    <asp:HiddenField ID="hdnUserFY" runat="server" />
    <asp:HiddenField ID="hdnEnalbeDisableText" runat="server" />
    <cc1:ModalPopupExtender ID="ModalPopup" runat="server" CancelControlID="btnClose"
        TargetControlID="btn" BackgroundCssClass="modalBackground" PopupControlID="pnlReturn">
    </cc1:ModalPopupExtender>
    <cc1:ModalPopupExtender ID="ModalPopupCorrection" runat="server" CancelControlID="btnClose1"
        TargetControlID="btn" BackgroundCssClass="modalBackground" PopupControlID="pnlRevised">
    </cc1:ModalPopupExtender>
    <div id="MaskedDiv1" class="MaskedDiv" runat="server">
    </div>
    <asp:HiddenField ID="hdnReportType" runat="server" />
    <asp:HiddenField ID="hdnMessage" runat="server" />
    <asp:HiddenField ID="hdnIsSIB" runat="server" Value="0" />
    <asp:HiddenField ID="hdnIsIB" runat="server" Value="0" />
    <asp:HiddenField ID="hdnIsBOB" runat="server" Value="0" />
    <cc1:ModalPopupExtender ID="popUp27A" runat="server" CancelControlID="btnCancel"
        BehaviorID="rptPopup" BackgroundCssClass="modalBackground" TargetControlID="btnSummary"
        PopupControlID="pnlSummaryReport">
    </cc1:ModalPopupExtender>
    <cc1:ModalPopupExtender ID="popupWarning" runat="server" CancelControlID="btnPopupOk"
        BackgroundCssClass="modalBackground" BehaviorID="warningPopup" PopupControlID="Panel1"
        TargetControlID="pop">
    </cc1:ModalPopupExtender>
    <cc1:ModalPopupExtender ID="allOrRowWise" runat="server" CancelControlID="btnCancelAnnex2"
        TargetControlID="pop" BackgroundCssClass="modalBackground" BehaviorID="behaviourAnnexure2"
        PopupControlID="panelAnnexure2">
    </cc1:ModalPopupExtender>
    <cc1:ModalPopupExtender ID="eTDSStatus" runat="server" CancelControlID="btnCancelAnnexure5"
        TargetControlID="pop" BackgroundCssClass="modalBackground" BehaviorID="behaviourAnnexure5"
        PopupControlID="panelAnnexure5">
    </cc1:ModalPopupExtender>
    <asp:Panel ID="Panel1" runat="server" BackColor="White" CssClass="modalPopup" Style="display: none"
        Width="620px">
        <div style="width: 100%; height: 15px; border: 1px; border-color: Black; margin-bottom: 15px; background-color: #7f858b; color: White; padding: 5px 0px 5px 0px;">
            <center>
                <asp:Label ID="Label1" runat="server" Font-Bold="true"> Warning</asp:Label></center>
        </div>
        <table>
            <tr>
                <td>
                    <asp:Label ID="lblWarning" runat="server"></asp:Label>
                </td>
            </tr>
            <tr>
                <td align="center">
                    <asp:Button ID="btnPopupOk" runat="server" Text="Ok" CssClass="cmnBtn" />
                </td>
            </tr>
        </table>
    </asp:Panel>
    <asp:Button ID="pop" runat="server" Text="click" Style="display: none;" />
    <asp:Panel ID="pnlSummaryReport" runat="server" BackColor="White" CssClass="modalPopup"
        Style="display: none">
        <div style="width: 100%; height: 15px; border: 1px; border-color: Black; margin-bottom: 15px; background-color: Black; color: White; padding: 5px 0px 5px 0px;">
            <center>
                <asp:Label ID="lblRptPopHeader" runat="server" Font-Bold="true"> eReturn Summary Report</asp:Label></center>
        </div>
        <table>
            <tr>
                <td style="width: 100px">Form
                </td>
                <td>
                    <asp:CheckBox ID="chkForm24" runat="server" Text="24Q" Checked="true" />
                </td>
                <td>
                    <asp:CheckBox ID="chkForm26" runat="server" Text="26Q" Checked="true" />
                </td>
                <td>
                    <asp:CheckBox ID="chkForm27" runat="server" Text="27Q" Checked="true" />
                </td>
                <td>
                    <asp:CheckBox ID="chkForm27E" runat="server" Text="27EQ" Checked="true" />
                </td>
            </tr>
            <tr>
                <td>Quarter
                </td>
                <td>
                    <asp:CheckBox ID="chkQ1" runat="server" Text="Q1" Checked="true" />
                </td>
                <td>
                    <asp:CheckBox ID="chkQ2" runat="server" Text="Q2" Checked="true" />
                </td>
                <td>
                    <asp:CheckBox ID="chkQ3" runat="server" Text="Q3" Checked="true" />
                </td>
                <td>
                    <asp:CheckBox ID="chkQ4" runat="server" Text="Q4" Checked="true" />
                </td>
            </tr>
            <tr>
                <td colspan="5">
                    <table width="100%">
                        <tr>
                            <td>
                                <center>
                                    <br />
                                    <asp:Button ID="btnPreview" runat="server" Text="Preview" CssClass="cmnBtn" OnClientClick="return validateSummaryReport();"
                                        OnClick="btnPreview_Click" />
                                    <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="cmnBtn" />
                                </center>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </asp:Panel>
    <asp:Panel ID="panelAnnexure2" runat="server" CssClass="modalPopup" Style="display: none"
        BackColor="White">
        <div style="width: 100%; height: 15px; border: 1px; border-color: Black; margin-bottom: 15px; background-color: Black; color: White; padding: 5px 0px 5px 0px;">
            <center>
                <asp:Label ID="lblAnnexure2" runat="server" Font-Bold="true"> Annexure 2</asp:Label>
            </center>
        </div>
        <table style="float: inherit; margin: auto;">
            <tr>
                <td>
                    <label>
                        Select
                    </label>
                </td>
                <td>
                    <asp:DropDownList ID="ddlAnnexure2" runat="server" Style="width: 90px;" onChange="HideShowTextAnnx2();">
                        <asp:ListItem Text="ALL" Value="All"></asp:ListItem>
                        <asp:ListItem Text="RO wise" Value="Ro"></asp:ListItem>
                    </asp:DropDownList>
                </td>
            </tr>
            <tr>
                <td>
                    <label>
                        Select Parent Branch
                    </label>
                </td>
                <td>
                    <asp:TextBox ID="txtRoName" runat="server" Enabled="false"></asp:TextBox>
                    <cc1:AutoCompleteExtender ID="AutoCompleteExtender1" runat="server" MinimumPrefixLength="2"
                        ServiceMethod="GetParentBranchNameWithIDs" ServicePath="~/WebServices/AutoCompleteService.asmx"
                        TargetControlID="txtRoName" CompletionInterval="700" EnableCaching="false" CompletionSetCount="20"
                        DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true" FirstRowSelected="True"
                        CompletionListCssClass="autoCompleteList">
                    </cc1:AutoCompleteExtender>
                </td>
            </tr>
        </table>
        <table style="float: inherit; margin: auto;">
            <tr>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td style="float: inherit; margin: auto;">
                    <asp:Button ID="btnAnnexure2All" runat="server" OnClick="btneReturnAnnexure_Click"
                        OnClientClick="if(!SetHdnAnnex2Value()){return false;}" CssClass="cmnBtn" Text="Submit" />
                </td>
                <td>
                    <asp:Button ID="btnCancelAnnex2" runat="server" Text="Cancel" CssClass="cmnBtn" />
                </td>
            </tr>
        </table>
    </asp:Panel>
    <asp:Panel ID="panelAnnexure5" runat="server" CssClass="modalPopup" Style="display: none"
        BackColor="White">
        <div style="width: 100%; height: 15px; border: 1px; border-color: Black; margin-bottom: 15px; background-color: Black; color: White; padding: 5px 0px 5px 0px;">
            <center>
                <asp:Label ID="lblAnnexure5" runat="server" Font-Bold="true"> Annexure 5</asp:Label>
            </center>
        </div>
        <table>
            <tr>
                <td>
                    <label>
                        eReturn Status
                    </label>
                </td>
                <td>
                    <asp:DropDownList ID="ddlEReturnStatus" runat="server" Style="width: 160px;" onChange="EnableDisableOptions();">
                        <asp:ListItem Text="Select" Value="Select" Selected="True"></asp:ListItem>
                        <asp:ListItem Text="All" Value="All"></asp:ListItem>
                        <asp:ListItem Text="Generated and filed" Value="gnf"></asp:ListItem>
                        <asp:ListItem Text="Generated but not filed" Value="gnnf"></asp:ListItem>
                        <asp:ListItem Text="Nil return" Value="nil"></asp:ListItem>
                        <asp:ListItem Text="Not generated" Value="NG"></asp:ListItem>
                    </asp:DropDownList>
                </td>
            </tr>
            <tr>
                <td>
                    <label>
                        Form
                    </label>
                </td>
                <td>
                    <asp:DropDownList ID="ddlFormTypes" runat="server" Style="width: 87px;" Enabled="false">
                        <asp:ListItem Text="All" Value="All"></asp:ListItem>
                        <asp:ListItem Text="Form24Q" Value="Form24Q"></asp:ListItem>
                        <asp:ListItem Text="Form26Q" Value="Form26Q"></asp:ListItem>
                        <asp:ListItem Text="Form27Q" Value="Form27Q"></asp:ListItem>
                    </asp:DropDownList>
                </td>
            </tr>
            <tr>
                <td>
                    <label>
                        Quarter
                    </label>
                </td>
                <td>
                    <asp:DropDownList ID="ddlQuarter" runat="server" Style="width: 87px;" Enabled="false">
                        <asp:ListItem Text="All" Value="All"></asp:ListItem>
                        <asp:ListItem Text="Quarter 1" Value="QUARTER1"></asp:ListItem>
                        <asp:ListItem Text="Quarter 2" Value="QUARTER2"></asp:ListItem>
                        <asp:ListItem Text="Quarter 3" Value="QUARTER3"></asp:ListItem>
                        <asp:ListItem Text="Quarter 4" Value="QUARTER4"></asp:ListItem>
                    </asp:DropDownList>
                </td>
            </tr>
            <tr>
                <td>
                    <label>
                        Select Parent Branch
                    </label>
                </td>
                <td>
                    <asp:TextBox ID="txtParentBranch" runat="server" Style="width: 154px;" Enabled="false"></asp:TextBox>
                    <cc1:AutoCompleteExtender ID="autoCompleteExtend" runat="server" MinimumPrefixLength="2"
                        ServiceMethod="GetParentBranchNameWithIDs" ServicePath="~/WebServices/AutoCompleteService.asmx"
                        TargetControlID="txtParentBranch" CompletionInterval="700" EnableCaching="false"
                        CompletionSetCount="20" DelimiterCharacters="" ShowOnlyCurrentWordInCompletionListItem="true"
                        FirstRowSelected="True" CompletionListCssClass="autoCompleteList">
                    </cc1:AutoCompleteExtender>
                </td>
            </tr>
        </table>
        <table style="float: inherit; margin: auto;">
            <tr>
                <td>
                    <asp:Button ID="btnAnnexure5" runat="server" OnClick="btnEReturnAnnexureSummary_Click"
                        OnClientClick="if(!EnterParentBranch()){return false;}" CssClass="cmnBtn" Text="Submit" />
                    <asp:Button ID="btnCancelAnnexure5" runat="server" Text="Cancel" CssClass="cmnBtn" />
                </td>
            </tr>
        </table>
    </asp:Panel>
    <asp:MultiView ID="mvMain" runat="server">
        <asp:View runat="server" ID="vwBasic">
            <asp:Button ID="btn" runat="server" Style="display: none" />
            <asp:Panel ID="pnlReturn" runat="server" Style="width: 460px; display: none">
                <table style="border: 2px solid #7f858b; height: auto;">
                    <tr>
                        <td style="background-color: #7f858b; font-weight: bold; color: White">e-Return Details
                            <asp:Button ID="btnClose" CssClass="cmnBtn" runat="server" Text="X" Width="20px"
                                Height="18px" Style="margin-left: 320px" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Panel ID="pnleReturn" runat="server" CssClass="navPanel" Width="450px">
                                <asp:Repeater ID="rptreReturnDetail" runat="server">
                                    <HeaderTemplate>
                                        <table class="nTbl">
                                            <tr bgcolor="#EEEEEE">
                                                <th id="headerDeductionAction" runat="server">
                                                    <asp:Label ID="Label3" runat="server" Width="70px" Text="Form" />
                                                </th>
                                                <th>
                                                    <asp:Label ID="Label4" runat="server" Width="70px" Text="Quarter" />
                                                </th>
                                                <th style="border-right-width: 0px">
                                                    <asp:Label ID="Label5" runat="server" Width="120px" Text="Description" />
                                                </th>
                                            </tr>
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <tr bgcolor="white">
                                            <td>
                                                <%# Eval("Form")%>
                                            </td>
                                            <td>
                                                <%# Eval("Quarter")%>
                                            </td>
                                            <td>
                                                <%# Eval("Remarks")%>
                                            </td>
                                        </tr>
                                    </ItemTemplate>
                                    <FooterTemplate>
                                        </table>
                                    </FooterTemplate>
                                </asp:Repeater>
                            </asp:Panel>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlRevised" runat="server" Style="width: 460px; display: none">
                <table style="border: 2px solid #7f858b; height: auto;">
                    <tr>
                        <td style="background-color: #7f858b; font-weight: bold; color: White">Revised RR no. and Filed date Details
                            <asp:Button ID="btnClose1" CssClass="cmnBtn" runat="server" Text="X" Width="20px"
                                Height="18px" Style="margin-left: 185px" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <asp:Panel ID="pnlRevisedRRNo" runat="server" CssClass="navPanel" Width="450px">
                                <asp:Repeater ID="rptrRevisedRRDetail" runat="server">
                                    <HeaderTemplate>
                                        <table class="nTbl">
                                            <tr bgcolor="#EEEEEE">
                                                <th id="headerDeductionAction" runat="server">
                                                    <asp:Label ID="Label6" runat="server" Width="70px" Text="Form" />
                                                </th>
                                                <th>
                                                    <asp:Label ID="Label7" runat="server" Width="70px" Text="Quarter" />
                                                </th>
                                                <th style="border-right-width: 0px">
                                                    <asp:Label ID="Label8" runat="server" Width="120px" Text="Description" />
                                                </th>
                                            </tr>
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <tr bgcolor="white">
                                            <td>
                                                <%# Eval("Form")%>
                                            </td>
                                            <td>
                                                <%# Eval("Quarter")%>
                                            </td>
                                            <td>
                                                <%# Eval("Remarks")%>
                                            </td>
                                        </tr>
                                    </ItemTemplate>
                                    <FooterTemplate>
                                        </table>
                                    </FooterTemplate>
                                </asp:Repeater>
                            </asp:Panel>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <table style="border-collapse: collapse; width: 94%; margin-bottom: 10px;">
                <tr style="width: 100%">
                    <td id="finYearJK" runat="server" visible="false" style="width: 88%"> <asp:Label ID="lblSelFinYear" runat="server" Width="150px" Text="&nbsp;&nbsp;Select Financial Year  " />                        
                        <asp:DropDownList ID="ddlFinYear" runat="server" Font-Size="X-Small" CssClass="dropDownList" Width="88px">
                            <asp:ListItem Text="2026-27" Value="2026"></asp:ListItem>
                            <asp:ListItem Text="2025-26" Value="2025"></asp:ListItem>
                            <asp:ListItem Text="2024-25" Value="2024"></asp:ListItem>
                            <asp:ListItem Text="2023-24" Value="2023"></asp:ListItem>
                            <asp:ListItem Text="2022-23" Value="2022"></asp:ListItem>
                            <asp:ListItem Text="2021-22" Value="2021"></asp:ListItem>
                            <asp:ListItem Text="2020-21" Value="2020"></asp:ListItem>
                            <asp:ListItem Text="2019-20" Value="2019"></asp:ListItem>
                            <asp:ListItem Text="2018-19" Value="2018"></asp:ListItem>
                            <asp:ListItem Text="2017-18" Value="2017"></asp:ListItem>
                            <asp:ListItem Text="2016-17" Value="2016"></asp:ListItem>
                            <asp:ListItem Text="2015-16" Value="2015"></asp:ListItem>
                            <asp:ListItem Text="2014-15" Value="2014"></asp:ListItem>
                            <asp:ListItem Text="2013-14" Value="2013"></asp:ListItem>
                            <asp:ListItem Text="2012-13" Value="2012"></asp:ListItem>
                            <asp:ListItem Text="2011-12" Value="2011"></asp:ListItem>
                            <asp:ListItem Text="2010-11" Value="2010"></asp:ListItem>
                            <asp:ListItem Text="2009-10" Value="2009"></asp:ListItem>
                        </asp:DropDownList>
                        &nbsp
                        <asp:Button ID="btnChangeFinYear" runat="server" Text="Change Financial Year" Width="150px"
                            AutoPostBack="false" OnClick="btnChangeFinYear_Click" CssClass="cmnBtn"></asp:Button>
                    </td>
                    <td align="right">
                        <asp:LinkButton ID="lnkShowAll" runat="server" Text="Show All" Font-Underline="false"
                            Font-Bold="true" ForeColor="White" CssClass="homelb" OnClick="btnShowAll_Click"></asp:LinkButton>
                    </td>
                </tr>
            </table>
            <div>
                <asp:Panel ID="pnlPANSummary" runat="server" Style="margin-left: 13px; margin-bottom: 4px; width: 92%;">
                    <table style="border-collapse: collapse; margin-bottom: 1px; width: 101%">
                        <tr class="d-flex">
                            <td style="padding: .3em; width: 93%" align="center" class="home">
                                <b>PAN Summary</b>
                            </td>
                            <td style="padding: .3em; text-align: left;" align="center" class="home">
                                <asp:LinkButton ID="btnPANSummary" runat="server" Text="Show" Font-Bold="true" Font-Underline="false"
                                    OnClick="btnPANSummary_Click" CssClass="homelb"></asp:LinkButton>
                            </td>
                        </tr>
                    </table>
                </asp:Panel>
            </div>
            <div class="panel-container">
                <asp:Panel ID="pnlPANSummaryContent" runat="server" Visible="false" CssClass="panel-box" Style="margin-left: 1px;">
                    <asp:Repeater ID="rptPANSummary" runat="server" OnItemDataBound="rptPANSummary_ItemDataBound">
                        <HeaderTemplate>
                            <table style="border-collapse: collapse; width: 204%; margin: 0px 0px 0px 8px;">
                                <tr>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"></th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center">PAN Not Given
                                    </th>
                                    <th id="headerValidPAN" runat="server" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center">PAN Valid</th>
                                    <th id="headerOperativePAN" runat="server" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center">PAN Valid (Operative) 
                                    </th>
                                    <th id="headerInOperativePAN" runat="server" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center">PAN Valid (Inoperative) 
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center">PAN Invalid
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center">PAN Not Verified
                                    </th>
                                </tr>
                        </HeaderTemplate>
                        <ItemTemplate>
                            <tr>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <%# Eval("TYPEOFDATA")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <%# Eval("PANNOTGIVEN")%>
                                </td>
                                <td id="colValidPAN" runat="server" style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <%# Eval("PANVALID")%>
                                </td>
                                <td id="colOperativePAN" runat="server" style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <a id="acolOperativePAN" href="javascript:void(0);" onclick="handleLinkClick('<%# Eval("PANVALIDOPERATIVE") %>', '<%# Eval("TYPEOFDATA") %>', 'Operative')">
                                        <%# Eval("PANVALIDOPERATIVE")%>
                                    </a>
                                </td>
                                <td id="colInOperativePAN" runat="server" style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <a id="acolInOperativePAN" href="javascript:void(0);" onclick="handleLinkClick('<%# Eval("PANVALIDINOPERATIVE") %>', '<%# Eval("TYPEOFDATA") %>', 'InOperative')">
                                        <%# Eval("PANVALIDINOPERATIVE")%>
                                    </a>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <%# Eval("PANINVALID")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <%# Eval("PANNOTVERIFIED")%>
                                </td>
                            </tr>
                        </ItemTemplate>
                        <FooterTemplate>
                            </table>
                        </FooterTemplate>
                    </asp:Repeater>
                </asp:Panel>
            </div>
            <br />
            <div class="panel-container d-flex">
                <asp:Panel ID="pnlForm24" runat="server" CssClass="panel-box" Style="margin-left: 1px;">
                    <table style="border-collapse: collapse; width: 101%; margin-bottom: 1px;margin: 0px 0px 0px -3px;">
                        <tr>
                            <td style="padding: .3em; width: 686px;" align="center" class="home">
                                <asp:Label ID="lblForm24QAddl" runat="server" Text="Form 24Q" Font-Bold="true"></asp:Label>
                            </td>
                            <td style="padding: .3em;" align="center">
                                <asp:LinkButton ID="btnShowForm24" runat="server" Text="Show" Font-Bold="true" CssClass="homelb"
                                    Font-Underline="false" OnClick="btnShowForm24_Click"></asp:LinkButton>
                            </td>
                        </tr>
                    </table>
                </asp:Panel>
                <asp:Panel ID="pnlForm26" runat="server" CssClass="panel-box" Style="margin-left: -10px;">
                    <table style="border-collapse: collapse; margin-bottom: 1px; margin: 0px 0px 0px -16px; width: 99%">
                        <tr>
                            <td style="padding: .3em; width: 100%" align="center" class="home">
                                <asp:Label ID="lblForm26QAddl" runat="server" Text="Form 26Q" Font-Bold="true"></asp:Label>
                            </td>
                            <td style="padding: .3em;" align="center">
                                <asp:LinkButton ID="btnShowForm26" runat="server" Text="Show" Font-Bold="true" CssClass="homelb"
                                    Font-Underline="false" OnClick="btnShowForm26_Click"></asp:LinkButton>
                            </td>
                        </tr>
                    </table>
                </asp:Panel>
            </div>
            <div class="panel-container">
                <table>
                    <tr>
                        <td style="text-align: left; width: 50%">
                            <asp:Panel ID="pnlForm24Content" runat="server" Visible="false" CssClass="panel-box" Style="margin-left: -1px; width:91%">
                                <asp:Repeater ID="rptrForm24Summary" runat="server">
                                    <HeaderTemplate>
                                        <table style="border-collapse: collapse; margin-bottom: 10px;">
                                            <tr>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                                    <asp:Label runat="server" Text="Qtr"></asp:Label>
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Deduction Count
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Amount Paid
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Deduction Amount
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Challan Count
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Challan Amount
                                                </th>
                                            </tr>
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <tr>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                                <%# Eval("Quarter")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("DeductionCount")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("PAYMENTMADE")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("DEDUCTIONTOTAL")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("CHALLANCOUNT")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("CHALLANTOTAL")%>
                                            </td>
                                        </tr>
                                    </ItemTemplate>
                                    <FooterTemplate>
                                        </table>
                                    </FooterTemplate>
                                </asp:Repeater>
                            </asp:Panel>
                        </td>
                        <td style="text-align: right; width: 50%">
                            <asp:Panel ID="pnlForm26Content" runat="server" Visible="false" CssClass="panel-box" Style="margin-left: -17px; width: 89%">
                                <asp:Repeater ID="rptrForm26Summary" runat="server">
                                    <HeaderTemplate>
                                        <table style="border-collapse: collapse; margin-bottom: 10px;">
                                            <tr>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                                    <asp:Label ID="Label2" runat="server" Text="Qtr"></asp:Label>
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Deduction Count
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Amount Paid
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Deduction Amount
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Challan Count
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Challan Amount
                                                </th>
                                            </tr>
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <tr>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                                <%# Eval("Quarter")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("DeductionCount")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("PAYMENTMADE")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("DEDUCTIONTOTAL")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("CHALLANCOUNT")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("CHALLANTOTAL")%>
                                            </td>
                                        </tr>
                                    </ItemTemplate>
                                    <FooterTemplate>
                                        </table>
                                    </FooterTemplate>
                                </asp:Repeater>
                            </asp:Panel>
                        </td>
                    </tr>
                </table>
                <br />
            </div>
            <asp:Panel ID="pnlForm24g" runat="server">
                <table style="border-collapse: collapse; width: 100%; margin-bottom: 1px;">
                    <tr>
                        <td style="padding: .3em; width: 686px;" align="center" class="home">
                            <b>Form 24G</b>
                        </td>
                        <td style="padding: .3em;" align="center">
                            <asp:LinkButton ID="btnShowForm24G" runat="server" Text="Show" Font-Bold="true" Font-Underline="false"
                                OnClick="btnShowForm24G_Click" CssClass="homelb"></asp:LinkButton>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlForm24GContent" runat="server" Visible="false">
                <asp:Repeater ID="rptForm24GSummary" runat="server">
                    <HeaderTemplate>
                        <table style="border-collapse: collapse; width: 100%; margin-bottom: 10px;">
                            <tr>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label4" runat="server" Width="70px" Text="Month"></asp:Label>
                                </th>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Deduction Count
                                </th>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Deduction Amount
                                </th>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Remitted Count
                                </th>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Remitted Amount
                                </th>
                            </tr>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                <%# Eval("Month")%>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <%# Eval("DEDCOUNT")%>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <%# Eval("DEDUCTIONAMOUNT")%>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <%# Eval("REMCOUNT")%>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <%# Eval("REMITTEDAMOUNT")%>
                            </td>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                        </table>
                    </FooterTemplate>
                </asp:Repeater>
            </asp:Panel>
            <div class="panel-container d-flex">
                <asp:Panel ID="pnlForm27" runat="server" CssClass="panel-box" Style="margin-left: 1px;">
                    <table style="border-collapse: collapse; width: 101%;margin: 0px 0px 0px -3px;margin-bottom: 1px;">
                        <tr>
                            <td style="padding: .3em; width: 686px;" align="center" class="home">
                                <asp:Label ID="lblForm27QAddl" runat="server" Text="Form 27Q" Font-Bold="true"></asp:Label>
                            </td>
                            <td style="padding: .3em;" align="center">
                                <asp:LinkButton ID="btnShowForm27" runat="server" Text="Show" Font-Bold="true" CssClass="homelb"
                                    Font-Underline="false" OnClick="btnShowForm27_Click"></asp:LinkButton>
                            </td>
                        </tr>
                    </table>
                </asp:Panel>
                <asp:Panel ID="pnlForm27E" runat="server" CssClass="panel-box" Style="margin-left: -10px;">
                    <table style="border-collapse: collapse; width: 99%; margin-bottom: 1px;margin: 0px 0px 0px -17px;">
                        <tr>
                            <td style="padding: .3em; width: 100%;" align="center" class="home">
                                <asp:Label ID="lblForm27EQAddl" runat="server" Text="Form 27EQ" Font-Bold="true"></asp:Label>
                            </td>
                            <td style="padding: .3em;" align="center">
                                <asp:LinkButton ID="btnShowForm27E" runat="server" Text="Show" Font-Bold="true" CssClass="homelb"
                                    Font-Underline="false" OnClick="btnShowForm27E_Click"></asp:LinkButton>
                            </td>
                        </tr>
                    </table>
                </asp:Panel>
            </div>
            <div class="panel-container">
                <table>
                    <tr>
                        <td style="text-align: left; width: 50%">
                            <asp:Panel ID="pnlForm27Content" runat="server" Visible="false" CssClass="panel-box" Style="margin-left: -1px;width: 91%;">
                                <asp:Repeater ID="rptrForm27Summary" runat="server">
                                    <HeaderTemplate>
                                        <table style="border-collapse: collapse; margin-bottom: 10px;">
                                            <tr>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                                    <asp:Label ID="Label4" runat="server" Text="Qtr"></asp:Label>
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Deduction Count
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Amount Paid
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Deduction Amount
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Challan Count
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Challan Amount
                                                </th>
                                            </tr>
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <tr>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                                <%# Eval("Quarter")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("DeductionCount")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("PAYMENTMADE")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("DEDUCTIONTOTAL")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("CHALLANCOUNT")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("CHALLANTOTAL")%>
                                            </td>
                                        </tr>
                                    </ItemTemplate>
                                    <FooterTemplate>
                                        </table>
                                    </FooterTemplate>
                                </asp:Repeater>
                            </asp:Panel>
                        </td>
                        <td style="text-align: right; width: 50%">
                            <asp:Panel ID="pnlForm27EContent" runat="server" Visible="false" Style="width: 88%; margin: 0px 0px 0px -4px;">
                                <asp:Repeater ID="rptForm27ESummary" runat="server">
                                    <HeaderTemplate>
                                        <table style="border-collapse: collapse; width: 100%; margin-bottom: 10px;">
                                            <tr>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                                    <asp:Label ID="Label4" runat="server" Text="Qtr"></asp:Label>
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Collection Count
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Amount Paid
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Collection Amount
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Challan Count
                                                </th>
                                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Total Challan Amount
                                                </th>
                                            </tr>
                                    </HeaderTemplate>
                                    <ItemTemplate>
                                        <tr>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                                <%# Eval("Quarter")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("DeductionCount")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("PAYMENTMADE")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("DEDUCTIONTOTAL")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("CHALLANCOUNT")%>
                                            </td>
                                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                                <%# Eval("CHALLANTOTAL")%>
                                            </td>
                                        </tr>
                                    </ItemTemplate>
                                    <FooterTemplate>
                                        </table>
                                    </FooterTemplate>
                                </asp:Repeater>
                            </asp:Panel>
                        </td>
                    </tr>
                </table>
            </div>
            <br />
            <div>
                <asp:Panel ID="PanelForm15GH" runat="server" Style="margin-left: 12px; margin-bottom: 4px; width: 93%;">
                    <table style="border-collapse: collapse; width: 100%; margin-bottom: 1px;">
                        <tr class="d-flex">
                            <td style="padding: .3em; width: 93.3%;" align="center" class="home">
                                <asp:Label ID="lblF15GH" runat="server" text="Form 15G/15H" style="font-weight:600"></asp:Label>
                            </td>
                            <td style="padding: .3em; text-align: left;" align="center" class="home">
                                <asp:LinkButton ID="btnShowForm15GH" runat="server" Text="Show" Font-Bold="true"
                                    CssClass="homelb" Font-Underline="false" OnClick="btnShowForm15GH_Click"></asp:LinkButton>
                            </td>
                        </tr>
                    </table>
                </asp:Panel>
            </div>
            <div class="panel-container">
                <asp:Panel ID="PanelForm15GHContent" runat="server" Visible="false" CssClass="panel-box" Style="margin-left: 1px;">
                    <asp:Repeater ID="rptForm15GHSummary" runat="server">
                        <HeaderTemplate>
                            <table style="border-collapse: collapse; width: 207%; margin: 0px 0px 0px 0px;">
                                <tr>
                                    <th colspan="4" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center;">Form 15G
                                    </th>
                                    <th colspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center;">Form 15H
                                    </th>
                                </tr>
                                <tr>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                        <asp:Label ID="Label2" runat="server" Text="Quarter"></asp:Label>
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Count
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Declared Amount
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Income Count/Amount
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Count
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Declared Amount
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Income Count/Amount
                                    </th>
                                </tr>
                        </HeaderTemplate>
                        <ItemTemplate>
                            <tr>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <%# Eval("Quarter")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                    <%# Eval("BASICCOUNT15G")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                    <%# Eval("DECLAREDAMT15G")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                    <%# Eval("INCOMECOUNT15G")%>
                                /
                                <%# Eval("INCOMEAMT15G")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                    <%# Eval("BASICCOUNT15H")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                    <%# Eval("DECLAREDAMT15H")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                    <%# Eval("INCOMECOUNT15H")%>
                                /
                                <%# Eval("INCOMEAMT15H")%>
                                </td>
                            </tr>
                        </ItemTemplate>
                        <FooterTemplate>
                            </table>
                        </FooterTemplate>
                    </asp:Repeater>
                    <asp:Repeater ID="rptForm121Summary" runat="server">
                        <HeaderTemplate>
                            <table style="border-collapse: collapse; width: 207%; margin: 0px 0px 0px 0px;">
                                <tr>
                                    <th colspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid; text-align: center;">Form 121[15GH]
                                    </th>
                                </tr>
                                <tr>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                        <asp:Label ID="Label2" runat="server" Text="Quarter"></asp:Label>
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Count
                                    </th>
                                    <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Declared Amount
                                    </th>
                                </tr>
                        </HeaderTemplate>
                        <ItemTemplate>
                            <tr>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                    <%# Eval("Quarter")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                    <%# Eval("BASICCOUNT15H")%>
                                </td>
                                <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                    <%# Eval("DECLAREDAMT15H")%>
                                </td>
                            </tr>
                        </ItemTemplate>
                        <FooterTemplate>
                            </table>
                        </FooterTemplate>
                    </asp:Repeater>
                </asp:Panel>
            </div>
            <br />
        </asp:View>
        <asp:View runat="server" ID="vwAdvanced">
            <br />
        </asp:View>
        <asp:View ID="vwMonth" runat="server">
            <table width="100%">
                <tr>
                    <td></td>
                    <td align="right">
                        <asp:Label ID="Label3" runat="server" BorderStyle="Solid" BorderWidth="1px" Height="10px"
                            Width="15px" BackColor="Green"></asp:Label>
                        &nbsp;<span>Paid Equal</span>
                        <asp:Label ID="Label11" runat="server" BackColor="Blue" BorderStyle="Solid" BorderWidth="1px"
                            Height="10px" Width="15px"></asp:Label>
                        &nbsp;Paid More
                        <asp:Label ID="Label2" runat="server" BackColor="Red" BorderStyle="Solid" BorderWidth="1px"
                            Height="10px" Width="15px"></asp:Label>
                        &nbsp;Paid Less
                    </td>
                </tr>
            </table>
            <cc1:CollapsiblePanelExtender ID="pnlExtForm24" runat="server" CollapseControlID="pnlForm24MonthHeader"
                Collapsed="true" ExpandControlID="pnlForm24MonthHeader" CollapsedText="Show"
                TextLabelID="lblForm24" ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlForm24MonthContent"
                ScrollContents="false">
            </cc1:CollapsiblePanelExtender>
            <asp:Panel ID="pnlForm24MonthHeader" runat="server">
                <table style="border-collapse: collapse; width: 98%; margin-bottom: 1px; cursor: pointer;">
                    <tr>
                        <td style="padding: .3em; width: 686px;" align="center" class="home">
                            <b>Form 24</b>
                        </td>
                        <td align="center" style="padding-right: .6em;">
                            <asp:Label ID="lblForm24" runat="server" Font-Bold="true" CssClass="homelb"> </asp:Label>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlForm24MonthContent" runat="server" Height="0px">
                <asp:Repeater ID="rptForm24Month" runat="server" OnItemDataBound="rptForm24Month_ItemDataBound">
                    <HeaderTemplate>
                        <table style="border-collapse: collapse; width: 98%; margin-bottom: 10px;">
                            <tr>
                                <th align="center" rowspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"
                                    valign="middle">Month
                                </th>
                                <th valign="top" colspan="4" align="center" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Deduction
                                </th>
                                <th align="center" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"
                                    colspan="2">Challan
                                </th>
                            </tr>
                            <tr>
                                <th align="center" colspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="lblForm24Remitted" runat="server" Text="Remitted"></asp:Label>
                                </th>
                                <th align="center" colspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="lblForm24UnRemitted" runat="server" Text="UnRemitted"></asp:Label>
                                </th>
                                <th align="center" valign="top" rowspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="lblForm24Count" runat="server" Text="Remitted" Width="100px"></asp:Label>
                                </th>
                                <th align="center" valign="top" rowspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="lblForm24Amount" runat="server" Text="Residual Sundry Amount Available"
                                        Width="115px"></asp:Label>
                                </th>
                            </tr>
                            <tr>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 75px">
                                    <asp:Label ID="lblForm24UnRemiitedCount" runat="server" Text="Count"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="lblForm24UnRemiitedAmount" runat="server" Text="Amount"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 75px">
                                    <asp:Label ID="lblForm24RemiitedCount" runat="server" Text="Count"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px;">
                                    <asp:Label ID="lblForm24RemiitedAmount" runat="server" Text="Amount"></asp:Label>
                                </th>
                            </tr>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                <asp:Label ID="lblForm24Month" runat="server" Text='<%# Eval("Month")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm24DedLinkCount" runat="server" Text='<%# Eval("DedLinkCount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm24DedLinkAmount" runat="server" Text='<%# Eval("DedLinkAmount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblFrom24DedUnlinkCount" runat="server" Text='<%# Eval("DedUnLinkCount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right;">
                                <asp:Label ID="lblForm24DedUnlinkAmount" runat="server" Text='<%# Eval("DedUnLinkAmount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm24ChallanCount" runat="server" Text='<%# Eval("Remitted")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm24ChallanAmount" runat="server" Text='<%# Eval("Sundry")%>'></asp:Label>
                            </td>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                        </table>
                    </FooterTemplate>
                </asp:Repeater>
            </asp:Panel>
            <br />
            <cc1:CollapsiblePanelExtender ID="pnlExtForm26" runat="server" CollapseControlID="pnlForm26MonthHeader"
                Collapsed="true" ExpandControlID="pnlForm26MonthHeader" CollapsedText="Show"
                TextLabelID="lblForm26" ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlForm26MonthContent"
                ScrollContents="false">
            </cc1:CollapsiblePanelExtender>
            <asp:Panel ID="pnlForm26MonthHeader" runat="server">
                <table style="border-collapse: collapse; width: 98%; margin-bottom: 1px; cursor: pointer;">
                    <tr>
                        <td style="padding: .3em; width: 686px;" align="center" class="home">
                            <b>Form 26</b>
                        </td>
                        <td align="center" style="padding-right: .6em;">
                            <asp:Label ID="lblForm26" runat="server" Font-Bold="true" CssClass="homelb"></asp:Label>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlForm26MonthContent" runat="server">
                <asp:Repeater ID="rptForm26Month" runat="server" OnItemDataBound="rptForm26Month_ItemDataBound">
                    <HeaderTemplate>
                        <table style="border-collapse: collapse; width: 98%; margin-bottom: 10px;">
                            <tr>
                                <th align="center" rowspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"
                                    valign="middle">Month
                                </th>
                                <th valign="top" colspan="6" align="center" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Deduction
                                </th>
                                <th align="center" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"
                                    colspan="2">Challan
                                </th>
                            </tr>
                            <tr>
                                <th align="center" colspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="lblForm26Remitted" runat="server" Text="Remitted"></asp:Label>
                                </th>
                                <th align="center" colspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="lblForm26UnRemitted" runat="server" Text="UnRemitted"></asp:Label>
                                </th>
                                <th align="center" valign="top" rowspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="lblForm26Count" runat="server" Text="Remitted" Width="100px"></asp:Label>
                                </th>
                                <th align="center" valign="top" rowspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="lblForm26Amount" runat="server" Text="Residual Sundry Amount Available"
                                        Width="115px"></asp:Label>
                                </th>
                            </tr>
                            <tr>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 75px">
                                    <asp:Label ID="Label3" runat="server" Text="Count"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="Label14" runat="server" Text="Payment Amount"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="Label8" runat="server" Text="Deducted Amount"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 75px">
                                    <asp:Label ID="Label9" runat="server" Text="Count"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="Label15" runat="server" Text="Payment Amount"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="Label16" runat="server" Text="Deducted Amount"></asp:Label>
                                </th>
                            </tr>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                <asp:Label ID="lblForm26Month" runat="server" Text='<%# Eval("Month")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm26DedLinkCount" runat="server" Text='<%# Eval("DedLinkCount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm26LinkPaidAmount" runat="server" Text='<%# Eval("LINKPAIDAMOUNT")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm26DedLinkAmount" runat="server" Text='<%# Eval("DedLinkAmount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm26DedUnlinkCount" runat="server" Text='<%# Eval("DedUnLinkCount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right;">
                                <asp:Label ID="lblForm26UnlinkedPaidAmount" runat="server" Text='<%# Eval("UNLINKPAIDAMOUNT")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right;">
                                <asp:Label ID="lblForm26DedUnlinkAmount" runat="server" Text='<%# Eval("DedUnLinkAmount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm26ChallanCount" runat="server" Text='<%# Eval("Remitted")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm26ChallanAmount" runat="server" Text='<%# Eval("Sundry")%>'></asp:Label>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                        </table>
                    </FooterTemplate>
                </asp:Repeater>
            </asp:Panel>
            <br />
            <cc1:CollapsiblePanelExtender ID="pnlExtForm27" runat="server" CollapseControlID="pnlForm27MonthHeader"
                Collapsed="true" ExpandControlID="pnlForm27MonthHeader" CollapsedText="Show"
                TextLabelID="lblForm27" ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlForm27MonthContent"
                ScrollContents="false">
            </cc1:CollapsiblePanelExtender>
            <asp:Panel ID="pnlForm27MonthHeader" runat="server">
                <table style="border-collapse: collapse; width: 98%; margin-bottom: 1px; cursor: pointer;">
                    <tr>
                        <td style="padding: .3em; width: 686px;" align="center" class="home">
                            <b>Form 27</b>
                        </td>
                        <td align="center" style="padding-right: .6em;">
                            <asp:Label ID="lblForm27" runat="server" Font-Bold="true" CssClass="homelb"></asp:Label>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlForm27MonthContent" runat="server">
                <asp:Repeater ID="rptForm27Month" runat="server" OnItemDataBound="rptForm27Month_ItemDataBound">
                    <HeaderTemplate>
                        <table style="border-collapse: collapse; width: 98%; margin-bottom: 0px;">
                            <tr>
                                <th align="center" rowspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"
                                    valign="middle">Month
                                </th>
                                <th valign="top" colspan="6" align="center" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Deduction
                                </th>
                                <th align="center" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"
                                    colspan="2">Challan
                                </th>
                            </tr>
                            <tr>
                                <th align="center" colspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label12" runat="server" Text="Remitted"></asp:Label>
                                </th>
                                <th align="center" colspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label5" runat="server" Text="UnRemitted"></asp:Label>
                                </th>
                                <th align="center" valign="top" rowspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label6" runat="server" Text="Remitted" Width="100px"></asp:Label>
                                </th>
                                <th align="center" valign="top" rowspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label7" runat="server" Text="Residual Sundry Amount Available" Width="115px"></asp:Label>
                                </th>
                            </tr>
                            <tr>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 75px">
                                    <asp:Label ID="Label3" runat="server" Text="Count"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="Label8" runat="server" Text="Payment Amount"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="Label17" runat="server" Text="Deducted Amount"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="Label18" runat="server" Text="Payment Amount"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 75px">
                                    <asp:Label ID="Label9" runat="server" Text="Remitted"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px;">
                                    <asp:Label ID="Label10" runat="server" Text="Residual Sundry Amount Available"></asp:Label>
                                </th>
                            </tr>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                <asp:Label ID="lblForm27Month" runat="server" Text='<%# Eval("Month")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27DedLinkCount" runat="server" Text='<%# Eval("DedLinkCount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27LinkPaidAmount" runat="server" Text='<%# Eval("LINKPAIDAMOUNT")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27DedLinkAmount" runat="server" Text='<%# Eval("DedLinkAmount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27DedUnlinkCount" runat="server" Text='<%# Eval("DedUnLinkCount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right;">
                                <asp:Label ID="lblForm27UnLinkPaidAmount" runat="server" Text='<%# Eval("UNLINKPAIDAMOUNT")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right;">
                                <asp:Label ID="lblForm27DedUnlinkAmount" runat="server" Text='<%# Eval("DedUnLinkAmount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27ChallanCount" runat="server" Text='<%# Eval("Remitted")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27ChallanAmount" runat="server" Text='<%# Eval("Sundry")%>'></asp:Label>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                        </table>
                    </FooterTemplate>
                </asp:Repeater>
            </asp:Panel>
            <br />
            <cc1:CollapsiblePanelExtender ID="pnExtForm27E" runat="server" CollapseControlID="pnlForm27EMonthHeader"
                Collapsed="true" ExpandControlID="pnlForm27EMonthHeader" CollapsedText="Show"
                TextLabelID="lblForm27E" ExpandedText="Hide" ExpandDirection="Vertical" TargetControlID="pnlForm27EMonthContent"
                ScrollContents="false">
            </cc1:CollapsiblePanelExtender>
            <asp:Panel ID="pnlForm27EMonthHeader" runat="server">
                <table style="border-collapse: collapse; width: 98%; margin-bottom: 1px; cursor: pointer;">
                    <tr>
                        <td style="padding: .3em; width: 686px;" align="center" class="home">
                            <b>Form 27E</b>
                        </td>
                        <td align="center" style="padding-right: .6em;">
                            <asp:Label ID="lblForm27E" runat="server" Font-Bold="true" CssClass="homelb"> </asp:Label>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlForm27EMonthContent" runat="server" Height="0px">
                <asp:Repeater ID="rptForm27EMonth" runat="server" OnItemDataBound="rptForm27EMonth_ItemDataBound">
                    <HeaderTemplate>
                        <table style="border-collapse: collapse; width: 98%; margin-bottom: 10px;">
                            <tr>
                                <th align="center" rowspan="3" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"
                                    valign="middle">Month
                                </th>
                                <th valign="top" colspan="4" align="center" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Collection
                                </th>
                                <th align="center" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;"
                                    colspan="2">Challan
                                </th>
                            </tr>
                            <tr>
                                <th align="center" colspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label13" runat="server" Text="Remitted"></asp:Label>
                                </th>
                                <th align="center" colspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label5" runat="server" Text="UnRemitted"></asp:Label>
                                </th>
                                <th align="center" valign="top" rowspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label6" runat="server" Text="Remitted" Width="100px"></asp:Label>
                                </th>
                                <th align="center" valign="top" rowspan="2" style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">
                                    <asp:Label ID="Label7" runat="server" Text="Residual Sundry Amount Available" Width="115px"></asp:Label>
                                </th>
                            </tr>
                            <tr>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 75px">
                                    <asp:Label ID="Label3" runat="server" Text="Count"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px">
                                    <asp:Label ID="Label8" runat="server" Text="Amount"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 75px">
                                    <asp:Label ID="Label9" runat="server" Text="Count"></asp:Label>
                                </th>
                                <th align="center" style="background-color: #eeeeee; border: 1px #ccc solid; width: 125px;">
                                    <asp:Label ID="Label10" runat="server" Text="Amount"></asp:Label>
                                </th>
                            </tr>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: center">
                                <asp:Label ID="lblForm27EMonth" runat="server" Text='<%# Eval("Month")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27EDedLinkCount" runat="server" Text='<%# Eval("DedLinkCount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27EDedLinkAmount" runat="server" Text='<%# Eval("DedLinkAmount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27EDedUnlinkCount" runat="server" Text='<%# Eval("DedUnLinkCount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right;">
                                <asp:Label ID="lblForm27EDedUnlinkAmount" runat="server" Text='<%# Eval("DedUnLinkAmount")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27EChallanCount" runat="server" Text='<%# Eval("Remitted")%>'></asp:Label>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <asp:Label ID="lblForm27EChallanAmount" runat="server" Text='<%# Eval("Sundry")%>'></asp:Label>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                        </table>
                    </FooterTemplate>
                </asp:Repeater>
            </asp:Panel>
            <br />
        </asp:View>
        <asp:View runat="server" ID="vwCustTax">
            <table style="border-collapse: collapse; width: 100%; margin-bottom: 10px;">
                <tr>
                    <td align="right">
                        <asp:LinkButton ID="lnkShowAllCustTax" runat="server" Text="Show All" Font-Underline="false"
                            Font-Bold="true" ForeColor="White" CssClass="homelb" OnClick="lnkShowAllCustTax_Click"></asp:LinkButton>
                    </td>
                </tr>
            </table>
            <asp:Panel ID="pnlDirecTax" runat="server">
                <table style="border-collapse: collapse; width: 100%; margin-bottom: 1px;">
                    <tr>
                        <td style="padding: .3em; width: 686px;" align="center" class="home">
                            <b>Customer Direct Tax</b>
                        </td>
                        <td style="padding: .3em;" align="center">
                            <asp:LinkButton ID="lnkShowCustDirTaxSumary" runat="server" Text="Show" Font-Bold="true"
                                CssClass="homelb" Font-Underline="false" OnClick="lnkShowCustDirTaxSumary_Click"></asp:LinkButton>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlDirecTaxContent" runat="server" Visible="false">
                <asp:Repeater ID="rptDirectTax" runat="server">
                    <HeaderTemplate>
                        <table style="border-collapse: collapse; width: 50%; margin-bottom: 10px;">
                            <tr>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Records To Be Approved
                                </th>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Challan Payment Not Done
                                </th>
                            </tr>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <%# Eval("DTAXTOBEAPPRVDCOUNT")%>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <%# Eval("DTAXPDFCOUNT")%>
                            </td>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                        </table>
                    </FooterTemplate>
                </asp:Repeater>
            </asp:Panel>
            <br />
            <asp:Panel ID="pnlIndirecTax" runat="server">
                <table style="border-collapse: collapse; width: 100%; margin-bottom: 1px;">
                    <tr>
                        <td style="padding: .3em; width: 686px;" align="center" class="home">
                            <b>Customer Indirect Tax</b>
                        </td>
                        <td style="padding: .3em;" align="center">
                            <asp:LinkButton ID="lnkShowCustIndirTaxSumary" runat="server" Text="Show" Font-Bold="true"
                                CssClass="homelb" Font-Underline="false" OnClick="lnkShowCustIndirTaxSumary_Click"></asp:LinkButton>
                        </td>
                    </tr>
                </table>
            </asp:Panel>
            <asp:Panel ID="pnlIndirecTaxContent" runat="server" Visible="false">
                <asp:Repeater ID="rptIndirectTax" runat="server">
                    <HeaderTemplate>
                        <table style="border-collapse: collapse; width: 50%; margin-bottom: 10px;">
                            <tr>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Records To Be Approved
                                </th>
                                <th style="padding: .3em; background-color: #eeeeee; border: 1px #ccc solid;">Challan Payment Not Done
                                </th>
                            </tr>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <%# Eval("ITAXTOBEAPPRVDCOUNT")%>
                            </td>
                            <td style="padding: .3em; background-color: white; border: 1px #ccc solid; text-align: right">
                                <%# Eval("ITAXPDFCOUNT")%>
                            </td>
                        </tr>
                    </ItemTemplate>
                    <FooterTemplate>
                        </table>
                    </FooterTemplate>
                </asp:Repeater>
            </asp:Panel>
        </asp:View>
    </asp:MultiView>
    <table width="100%" id="summery" runat="server" style="margin: 0px 0px 0px 10px;">
        <tr>
            <td>
                <asp:Button ID="btnMonthView" runat="server" Text="Month View" CssClass="cmnBtn"
                    Width="100px" OnClick="btnMonthView_Click" />
                <asp:Button ID="btnSummary" runat="server" Text="E-Return Status" CssClass="cmnBtn"
                    OnClientClick="setHeadereReturnSummary();return false;" Width="140px" />&nbsp;
                <asp:Button ID="btnNilReturn" runat="server" Text="Nil Return Status" CssClass="cmnBtn"
                    Width="140px" OnClientClick="setHeaderNilReturnSummary();return false;" />
                <asp:Button ID="btneReturnAnnexure" runat="server" Text="Annexure Item No. - 2" CssClass="cmnBtn"
                    Width="155px" OnClientClick="Annexure2Clicked();" OnClick="CheckKeyAndShowPopUPAnnex" />
                <asp:Button ID="btnEReturnAnnexureSummary" runat="server" Text="Annexure Item No. - 5"
                    CssClass="cmnBtn" Width="155px" OnClientClick="Annexure5Clicked();" OnClick="CheckKeyAndShowPopUPAnnex" />
            </td>
        </tr>
    </table>
</asp:Content>
