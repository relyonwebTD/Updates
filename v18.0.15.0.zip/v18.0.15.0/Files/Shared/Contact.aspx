﻿<%@ page title="" language="C#" autoeventwireup="true" inherits="Authentication_Contact, App_Web_contact.aspx.48153819" %>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="cc1" %>
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Contact Details of Tax Team in CHQ</title>
    <style type="text/css">
        .BackColorTab
        {
            font-family: Verdana, Arial, Courier New;
            font-size: 10px;
            color: Gray;
            background-color: Silver;
        }
        .style1
        {
            width: 23px;
        }
        .style2
        {
            width: 234px;
        }
    </style>
    <script language="javascript" type="text/javascript">
        function EnableDisableControls() {
            alert("'ContactDetails.txt' File Not Found.");
        }
    </script>
</head>
<body>
    <div class="ntbl" id="jsEnabled" style="visibility: visible">
        <table style="width: 100%; height: 500px; font-size: 18px;" align="center">
            <tr id="divPanel">
                <td>
                    <div>
                        <table runat="server" id="panelTable" align="center">
                            <tr>
                                <td>
                                </td>
                                <td>
                                    <asp:Label ID="lblDescriptionNote" runat="server" Font-Bold="true" Font-Size="20px"
                                        align="center" />
                                </td>
                                <td>
                                    <asp:Label ID="lblHead" runat="server" Font-Bold="true" Font-Size="16px" Text="Contact Details of Tax Team in CHQ" />
                                    <asp:Panel ID="navPanel" CssClass="navPanel" runat="server" Width="100%" BorderStyle="Solid"
                                        BorderWidth="1px" BorderColor="Gray" Visible="true">
                                        <asp:Repeater ID="rptrContactDetails" runat="server" OnItemCommand="rptrContactDetails_ItemCommand">
                                            <HeaderTemplate>
                                                <table id="NavTable" border="1">
                                                    <tr bgcolor="#EEEEEE">
                                                        <th>
                                                            Branches Associated with Zone
                                                        </th>
                                                        <th>
                                                            Principal Contact
                                                        </th>
                                                        <th>
                                                            Mobile
                                                        </th>
                                                    </tr>
                                            </HeaderTemplate>
                                            <ItemTemplate>
                                                <tr bgcolor="white">
                                                    <td>
                                                        <%# Eval("Name")%>
                                                    </td>
                                                    <td>
                                                        <%# Eval("MobileNumber") %>
                                                    </td>
                                                    <td>
                                                        <%#Eval("Level") %>
                                                    </td>
                                                </tr>
                                            </ItemTemplate>
                                            <FooterTemplate>
                                                </table>
                                            </FooterTemplate>
                                        </asp:Repeater>
                                    </asp:Panel>
                                </td>
                            </tr>
                        </table>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>
